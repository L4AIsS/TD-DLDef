# T0/P0 blocker remediation

This package follows the **code-aligned-to-paper** route requested by the audit.

| Blocker | Implemented remediation | Verification |
| --- | --- | --- |
| NF/WS/WR absent from end-to-end path | `generate_one.py` applies neuron mutation before saving the first backend model and `initial_weights`; other backends load those exact tensors. A `mutation_provenance.json` file records operators, layers, tensor/value counts, checksums, and skip reasons. | `test_neuron_mutation_is_wired_and_reports_actual_changes` |
| WR formula/shape mismatch | WR now reshapes each rank-2+ tensor to `(-1, last_axis)`, computes an orthogonal matrix by QR, applies `W' = W R`, and restores the original shape. | `test_wr_preserves_dense_conv_rnn_shapes_and_norms` |
| PV/BV/IT/NF semantics | PV selects least-used legal values; BV uses explicit powers-of-two/rate/real boundary sets; IT covers eight numeric dtypes; NF uses Laplace, centred-exponential, and sinusoidal noise. | value/IT tests plus neuron provenance test |
| Delayed Algorithm 1 feedback | Candidate layers now execute DIV immediately. A contributing candidate is accepted and updates alpha; a non-contributing candidate updates beta, is rejected, and is retried without replacement up to a finite limit. Mandatory output-adaptation layers are recorded without pretending they were TS choices. | `test_immediate_div_admission_and_posterior` |
| Beta prior counted twice | `choose_arm` samples directly from stored `(alpha, beta)`, whose initial value is `(1,1)`. | `test_ts_prior_and_updates` |

Run the blocker suite from the project root:

```bash
python -m unittest discover -s tests -v
```

Previous mutation/selection-dependent result files under `data/` are retained
only as historical inputs. They must not be presented as results of the repaired
pipeline. Re-run coverage, ablation, defect, and runtime experiments before
updating the paper's quantitative claims.
