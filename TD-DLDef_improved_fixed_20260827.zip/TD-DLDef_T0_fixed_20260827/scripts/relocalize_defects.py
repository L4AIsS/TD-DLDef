# -*- coding: utf-8 -*-
"""
缺陷重定位脚本: 从已保存的层输出 (.npy) 重算逐层 output_delta,
为缺少定位层的 inconsistency 缺陷记录补全 located_layer 与 causing_snippet。

背景: comparator 原实现中 grads['00_input_object'] KeyError 会中断
localization_map 计算 (已修复), 本脚本用于对历史实验输出做离线重定位,
无需重跑训练。

运行: python scripts/relocalize_defects.py --seed 822
"""
import argparse
import json
from pathlib import Path

import numpy as np

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def max_delta(x, y):
    if x is None or y is None:
        return None
    try:
        return float(np.max(np.abs(np.asarray(x) - np.asarray(y))))
    except Exception:
        return None


def relocalize_model(exp_dir: Path):
    """返回 (suspect_layer, info_str): 以 output_R (差异变化率) 最大层为分歧源头,
    全部层 R 不可算时退化为 output_delta 最大层"""
    json_path = exp_dir / 'models' / 'model.json'
    out_root = exp_dir / 'layer_outputs'
    if not json_path.exists() or not out_root.exists():
        return None
    model_info = json.load(open(json_path, encoding='utf-8'))
    structure = {str(k): v for k, v in model_info['model_structure'].items()}
    bk_dirs = [d for d in out_root.iterdir() if d.is_dir()]
    if len(bk_dirs) < 2:
        return None
    outs = {}
    for d in bk_dirs[:2]:
        outs[d.name] = {fn.stem: np.load(str(fn)) for fn in d.glob('*.npy')}
    b1, b2 = list(outs.keys())[:2]
    o1, o2 = outs[b1], outs[b2]

    # 逐层 output_delta
    deltas = {}
    for layer_id, info in sorted(structure.items(), key=lambda kv: int(kv[0])):
        name = info.get('args', {}).get('name', layer_id)
        if name not in o1 or name not in o2:
            continue
        d = max_delta(o1[name], o2[name])
        if d is not None:
            deltas[name] = d
    if not deltas:
        return None

    # 逐层 output_R = (delta - delta_pre) / (delta_pre + eps)
    eps = 1e-7
    best_r, best_rv = None, None
    for layer_id, info in sorted(structure.items(), key=lambda kv: int(kv[0])):
        name = info.get('args', {}).get('name', layer_id)
        if name not in deltas:
            continue
        pre_names = [structure[str(i)]['args']['name'] for i in info.get('pre_layers', [])
                     if str(i) in structure]
        pre_d = max([deltas[p] for p in pre_names if p in deltas], default=0.0)
        r = (deltas[name] - pre_d) / (pre_d + eps)
        if best_rv is None or r > best_rv:
            best_r, best_rv = name, r
    if best_r is not None:
        return best_r, 'output_R=%.4g, output_delta=%.6g' % (best_rv, deltas[best_r])
    best_d = max(deltas, key=deltas.get)
    return best_d, 'output_delta=%.6g (R unavailable)' % deltas[best_d]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--seed', type=int, default=822)
    flags = ap.parse_args()

    out_root = PROJECT_ROOT / 'data' / f'exp2_abl_out_{flags.seed}'
    defect_dir = PROJECT_ROOT / 'data' / f'exp2_defects_{flags.seed}'
    fixed = 0
    total_none = 0

    for jsonl in sorted(defect_dir.glob('*.jsonl')):
        pool, ablation = jsonl.stem.split('__')
        records = [json.loads(l) for l in open(jsonl, encoding='utf-8') if l.strip()]
        changed = False
        for r in records:
            if r['defect_type'] != 'inconsistency':
                continue
            total_none += 1
            exp_dir = out_root / pool / ablation / str(r['model_id']).zfill(6)
            res = relocalize_model(exp_dir)
            if res is None:
                continue
            suspect, info_str = res
            r['located_layer'] = suspect
            # 重新生成 causing_snippet
            try:
                import sys
                sys.path.insert(0, str(PROJECT_ROOT))
                from utils.model_snippet import layer_source_snippet
                model_info = json.load(open(exp_dir / 'models' / 'model.json', encoding='utf-8'))
                r['causing_snippet'] = layer_source_snippet(model_info, suspect)
            except Exception:
                pass
            r['detail'] = (r.get('detail') or '') + ' | relocalized(max output_R): ' + info_str
            fixed += 1
            changed = True
        if changed:
            with open(jsonl, 'w', encoding='utf-8') as f:
                for r in records:
                    f.write(json.dumps(r, ensure_ascii=False) + '\n')
            # 同步重写 CSV
            import csv
            with open(jsonl.with_suffix('.csv'), 'w', encoding='utf-8', newline='') as f:
                w = csv.writer(f)
                w.writerow(['model_id', 'framework', 'backend', 'defect_type', 'stage',
                            'located_layer', 'causing_snippet', 'detail'])
                for r in records:
                    w.writerow([r.get('model_id'), r.get('framework'), r.get('backend'),
                                r.get('defect_type'), r.get('stage'),
                                r.get('located_layer'), r.get('causing_snippet'),
                                r.get('detail')])
    print(f'relocalized: {fixed} / {total_none} inconsistency records updated')


if __name__ == '__main__':
    main()
