# -*- coding: utf-8 -*-
"""快速验证: ModelInfoGenerator 生成结构 -> generate_one 在 tensorflow 后端真实构建模型"""
import contextlib
import io
import json
import sys
from pathlib import Path

PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
sys.path.insert(0, PROJECT_ROOT)

from utils.db_manager import DbManager
from utils.selection import Selector
from utils.mutation import MutationConfig
from utils.coverage import CoverageTracker
from utils.framework_config import get_framework_config
from src.cases_generation.model_info_generator import ModelInfoGenerator

MODEL_CONFIG = {
    'var': {
        'tensor_dimension_range': (2, 5),
        'tensor_element_size_range': (2, 5),
        'weight_value_range': (-10.0, 10.0),
        'small_value_range': (0, 1),
        'vocabulary_size': 1001,
    },
    'node_num_range': (8, 8),
    'dag_io_num_range': (1, 3),
    'dag_max_branch_num': 2,
    'cell_num': 3,
    'node_num_per_normal_cell': 10,
    'node_num_per_reduction_cell': 2,
}

INPUT_SHAPE = (None, 6, 6, 3)
OUTPUT_SHAPE = (None, 4)
NODE_NUM = 8

fw_cfg = get_framework_config('keras3.10')
db = DbManager(':memory:')
selector = Selector(fw_cfg.layer_types, fw_cfg.layer_conditions)
mutation_cfg = MutationConfig()
tracker = CoverageTracker(fw_cfg.layer_types, fw_cfg.layer_conditions)
gen = ModelInfoGenerator(MODEL_CONFIG, db, selector, 'seq',
                         mutation_config=mutation_cfg, coverage_tracker=tracker,
                         layer_types=fw_cfg.layer_types,
                         layer_conditions=fw_cfg.layer_conditions)

selector.reset_model_state()
with contextlib.redirect_stdout(io.StringIO()):
    model_info, ins_shapes, out_shapes, node_num = gen.generate_seq_model(
        node_num=NODE_NUM, input_shape=INPUT_SHAPE, output_shape=OUTPUT_SHAPE)
selector.finish_model_state()

# 保存 model.json (正确格式: model_structure dict)
out_dir = Path(PROJECT_ROOT) / 'data' / 'gen_test' / 'models'
out_dir.mkdir(parents=True, exist_ok=True)
json_path = out_dir / 'model.json'
with open(str(json_path), 'w', encoding='utf-8') as f:
    json.dump(model_info, f, ensure_ascii=False, indent=2)

types = [v['type'] for v in model_info['model_structure'].values()]
print('structure len:', len(types))
print('layer types:', types)
print('input_id_list:', model_info['input_id_list'])
print('output_id_list:', model_info['output_id_list'])
print('ins_shapes:', ins_shapes)
print('out_shapes:', out_shapes)
print('json saved:', json_path)
