# -*- coding: utf-8 -*-
"""
消融实验 2 (扩展版): 各多样性空间 / 突变算子对缺陷检测与覆盖率的贡献
(Crash / NaN / Inf / Inconsistency + LIC / LPC / LSC)

实验设计 (与消融实验 1 相同的 11 种配置):
    * 基准 (full): 四个多样性评估空间 + 六种突变算子全部启用;
    * 空间消融 (去掉每个多样性评估空间, 突变算子不变):
          no_layer / no_edge / no_shape / no_dim;
    * 算子消融 (去掉每种突变算子, 多样性空间评估不变):
          no_pv / no_bv / no_it / no_nf / no_ws / no_wr。

框架 (层池视角):
    * 新框架: tensorflow2.16.1 / pytorch2.2.0 / keras3.10 共享 Keras 3 全量层池,
      在同一批模型上, tensorflow 后端的缺陷即 "tensorflow2.16.1" 视角,
      torch 后端的缺陷即 "pytorch2.2.0" 视角, 整体即 "keras3.10" 视角;
    * 老框架: tensorflow2.0.0 / cntk2.7.0 / theano1.0.4 采用受限层池
      (utils/framework_config), 生成的结构在可用的 tensorflow/torch 后端上执行
      缺陷检测 (老框架环境不可用时的最接近近似)。

统计指标:
    * 缺陷 (Oracle 测试预言, utils/oracle.py): Crash (退出码 255/1/-1) /
      NaN / Inf / Inconsistency (跨后端 delta > 阈值, 默认 0.15);
      每条缺陷记录定位层与造成缺陷的模型源码片段 (utils/defect_report.py),
      逐配置落盘到 data/exp2_defects_<seed>/;
    * 覆盖率 (utils/coverage.py, COMET 原理 + 框架适配参数): LIC / LPC / LSC,
      基于本配置生成的全部模型跨模型累积。

运行: python scripts/run_ablation_exp2.py --models 200 --workers 3 --out data/ablation_exp2_final.json
"""

import argparse
import contextlib
import io
import json
import os
import random
import sys
import time
from pathlib import Path

PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
sys.path.insert(0, PROJECT_ROOT)
os.chdir(PROJECT_ROOT)

# ---------------------------------------------------------------------- #
# 消融配置 (与 run_ablation_exp1.py 完全一致)
# ---------------------------------------------------------------------- #
ALL_SPACES = ['layer', 'edge', 'shape', 'dim']
ALL_OPS = ['pv', 'bv', 'it', 'nf', 'ws', 'wr']

SPACE_ABLATIONS = {
    'full': ALL_SPACES,
    'no_layer': [s for s in ALL_SPACES if s != 'layer'],
    'no_edge': [s for s in ALL_SPACES if s != 'edge'],
    'no_shape': [s for s in ALL_SPACES if s != 'shape'],
    'no_dim': [s for s in ALL_SPACES if s != 'dim'],
}

MUTATION_ABLATIONS = {
    'full': ALL_OPS,
    'no_pv': [o for o in ALL_OPS if o != 'pv'],
    'no_bv': [o for o in ALL_OPS if o != 'bv'],
    'no_it': [o for o in ALL_OPS if o != 'it'],
    'no_nf': [o for o in ALL_OPS if o != 'nf'],
    'no_ws': [o for o in ALL_OPS if o != 'ws'],
    'no_wr': [o for o in ALL_OPS if o != 'wr'],
}

ABLATION_ORDER = ['full'] + list(SPACE_ABLATIONS)[1:] + list(MUTATION_ABLATIONS)[1:]

# 新框架共享 Keras 3 全量层池 (framework_config 中三者为同一层池), 只实际运行一次;
# 老框架各用独立受限层池。
FRAMEWORK_POOLS = {
    'tensorflow2.16.1': 'keras3.10',
    'pytorch2.2.0': 'keras3.10',
    'keras3.10': 'keras3.10',
    'tensorflow2.0.0': 'tensorflow2.0.0',
    'cntk2.7.0': 'cntk2.7.0',
    'theano1.0.4': 'theano1.0.4',
}
UNIQUE_POOLS = ['keras3.10', 'tensorflow2.0.0', 'cntk2.7.0', 'theano1.0.4']
NEW_FRAMEWORKS = ['tensorflow2.16.1', 'pytorch2.2.0', 'keras3.10']
OLD_FRAMEWORKS = ['tensorflow2.0.0', 'cntk2.7.0', 'theano1.0.4']

MODEL_CONFIG = {
    'var': {
        'tensor_dimension_range': (2, 5),
        'tensor_element_size_range': (2, 5),
        'weight_value_range': (-10.0, 10.0),
        'small_value_range': (0, 1),
        'vocabulary_size': 1001,
    },
    'node_num_range': (8, 8),
    'dag_io_num_range': (1, 3),
    'dag_max_branch_num': 2,
    'cell_num': 3,
    'node_num_per_normal_cell': 10,
    'node_num_per_reduction_cell': 2,
}

INPUT_SHAPE = (None, 6, 6, 3)
OUTPUT_SHAPE = (None, 4)
NODE_NUM = 8
INPUT_DTYPES = ('float16', 'float32', 'float64', 'int8', 'int16', 'int32', 'int64', 'uint8')
BACKENDS = ('tensorflow', 'torch')
CASE_NUM = 200          # 默认每个消融配置生成 200 个模型


def run_one(pool_name: str, ablation: str, n_models: int, seed: int, threshold: float,
            timeout: float, out_root: str) -> dict:
    """运行一个 (层池, 消融配置) 组合, 返回缺陷 + LIC/LPC/LSC 统计 summary"""
    from utils.framework_config import get_framework_config
    from utils.selection import Selector
    from utils.mutation import MutationConfig, NeuronMutator, ValueMutator
    from utils.coverage import CoverageTracker
    from utils.oracle import DefectCollector
    from utils.defect_report import DefectReporter
    from utils.db_manager import DbManager
    from src.cases_generation.model_info_generator import ModelInfoGenerator
    from src.cases_generation.model_generator import ModelGenerator
    from src.cases_generation.data_generator import DataGenerator
    from src.incons_detection.trainer import Trainer
    from src.incons_detection.comparator import Comparator

    rng = random.Random(seed)
    random.seed(seed)   # 同时固定模块级 random (值突变/神经元突变内部使用)
    fw_cfg = get_framework_config(pool_name)

    # 依据消融配置解析启用的空间与算子 (与实验 1 相同)
    if ablation in SPACE_ABLATIONS:
        enabled_spaces = SPACE_ABLATIONS[ablation]
        enabled_ops = ALL_OPS                       # 空间消融: 突变算子不变
    else:
        enabled_spaces = ALL_SPACES                 # 算子消融: 空间评估不变
        enabled_ops = MUTATION_ABLATIONS[ablation]

    db = DbManager(':memory:')
    selector = Selector(fw_cfg.layer_types, fw_cfg.layer_conditions,
                        diversity_spaces=enabled_spaces)
    mutation_cfg = MutationConfig(enabled=enabled_ops, seed=seed)
    value_mutator = ValueMutator(mutation_cfg)
    # 覆盖率追踪器: 框架适配的参数空间
    tracker = CoverageTracker(fw_cfg.layer_types, fw_cfg.layer_conditions,
                              activation_pool=fw_cfg.activation_pool,
                              padding_pool=fw_cfg.padding_pool,
                              element_range=MODEL_CONFIG['var']['tensor_element_size_range'],
                              dim_range=MODEL_CONFIG['var']['tensor_dimension_range'])
    # 缺陷明细记录器 (定位层 + 源码片段)
    reporter = DefectReporter(framework=pool_name, ablation=ablation)
    gen = ModelInfoGenerator(MODEL_CONFIG, db, selector, 'seq',
                             mutation_config=mutation_cfg, coverage_tracker=tracker,
                             layer_types=fw_cfg.layer_types,
                             layer_conditions=fw_cfg.layer_conditions)
    neuron_ops = [o for o in enabled_ops if o in ('nf', 'ws', 'wr')]
    model_gen = ModelGenerator(MODEL_CONFIG['var']['weight_value_range'], list(BACKENDS), db, selector,
                               timeout, coverage_tracker=tracker, input_dtype='float32',
                               neuron_mutator=NeuronMutator(MutationConfig(enabled=neuron_ops, seed=seed)),
                               defect_reporter=reporter, mutation_seed=seed)
    data_gen = DataGenerator({'instance_num': 10, 'element_val_range': (0, 100)})
    trainer = Trainer(db, timeout, defect_reporter=reporter)
    comparator = Comparator(db, threshold=threshold, defect_reporter=reporter)
    collector = DefectCollector(list(BACKENDS), threshold=threshold)

    output_dir = Path(out_root) / pool_name / ablation
    output_dir.mkdir(parents=True, exist_ok=True)

    ok_total, gen_fail = 0, 0
    for i in range(n_models):
        # Input Type Mutation (IT): 启用时随机选择输入 dtype, 禁用时固定 float32
        dtype = value_mutator.input_type() if 'it' in enabled_ops else 'float32'
        try:
            selector.reset_model_state()
            with contextlib.redirect_stdout(io.StringIO()):
                model_info, ins_shapes, out_shapes, _ = gen.generate_seq_model(
                    node_num=NODE_NUM, input_shape=INPUT_SHAPE, output_shape=OUTPUT_SHAPE)
                selector.finish_model_state()
                json_path, _, _, model_id, exp_dir = gen.generate(
                    str(output_dir), model_info=model_info,
                    selection_already_recorded=True)
            # 各后端生成模型 (神经元突变 + 输入类型突变)
            # 注: ModelGenerator 会以本次实际 dtype 记录覆盖率与多样性 (跨模型累积)
            ok_backends = model_gen.generate(json_path=json_path, exp_dir=exp_dir,
                                             model_id=model_id, input_dtype=dtype)
            for bk in BACKENDS:
                if bk not in ok_backends:
                    collector.record_generate_fail(bk)
            if len(ok_backends) < 2:
                gen_fail += 1
                continue
            data_gen.generate(ins_shapes, exp_dir, out_shapes)
            status, outputs, losses, loss_grads, grads, ok_backends2, defect_counts = trainer.train(
                model_id=model_id, exp_dir=exp_dir, ok_backends=ok_backends)
            pair_deltas = comparator.compare(model_id=model_id, exp_dir=exp_dir,
                                             backends_outputs=outputs, backends_losses=losses,
                                             backends_loss_grads=loss_grads, backends_grads=grads,
                                             ok_backends=ok_backends2)
            collector.record_model(model_id, status, outputs, pair_deltas)
            ok_total += 1
        except Exception:
            gen_fail += 1
            continue

    s = collector.summary()
    s['framework_pool'] = pool_name
    s['ablation'] = ablation
    s['enabled_spaces'] = enabled_spaces
    s['enabled_ops'] = sorted(enabled_ops)
    s['total_models'] = n_models
    s['ok_models'] = ok_total
    s['gen_fail'] = gen_fail

    # LIC / LPC / LSC (基于本配置全部生成模型, 跨模型累积)
    cov = tracker.summary()
    s['LIC'] = cov['LIC']
    s['LPC'] = cov['LPC']
    s['LSC'] = cov['LSC']
    s['LSC_cov_seq'] = cov['LSC_cov_seq']
    s['LSC_denom'] = cov['LSC_denom']
    s['diversity'] = selector.diversity_summary()

    # 缺陷明细落盘 (每个 (层池, 配置) 一份 JSONL + CSV)
    try:
        root_name = Path(out_root).name
        defect_name = root_name.replace('exp2_abl_out', 'exp2_defects')
        if defect_name == root_name:
            defect_name = root_name + '_defects'
        defect_dir = Path(out_root).parent / defect_name
        reporter.dump(defect_dir / f'{pool_name}__{ablation}.jsonl')
    except Exception:
        pass
    s['defect_records'] = len(reporter.records)

    # summary 落盘, 支持断点续跑 / 复用 (与 main() 的 resume 目录一致)
    try:
        sum_dir = Path(out_root).parent / (Path(out_root).name.replace('exp2_abl_out', 'exp2_abl_summaries'))
        sum_dir.mkdir(parents=True, exist_ok=True)
        (sum_dir / f'{pool_name}__{ablation}.json').write_text(
            json.dumps(s, ensure_ascii=False, indent=2), encoding='utf-8')
    except Exception:
        pass
    return s


def _pick_view(s: dict, view: str) -> dict:
    """把某个层池的统计结果转换为指定框架视角的缺陷计数

    Inconsistency 是跨后端 (tensorflow_torch) 对级缺陷, 属于模型集整体:
      * 新框架 (keras3.10 层池): tensorflow2.16.1 视角取 tf 后端 crash/nan/inf,
        pytorch2.2.0 视角取 torch 后端, keras3.10 视角取两后端合计;
        三者的 inconsistency 均为跨后端对计数 (同一模型集共享)。
      * 旧框架 (受限层池): crash/nan/inf 为两后端合计, inconsistency 为后端对计数。
    """
    bd = s['backend_defects']
    incons = s['total']['inconsistency']
    if view == 'tensorflow2.16.1' and 'tensorflow' in bd:
        return {'crash': bd['tensorflow']['crash'], 'nan': bd['tensorflow']['nan'],
                'inf': bd['tensorflow']['inf'], 'inconsistency': incons}
    if view == 'pytorch2.2.0' and 'torch' in bd:
        return {'crash': bd['torch']['crash'], 'nan': bd['torch']['nan'],
                'inf': bd['torch']['inf'], 'inconsistency': incons}
    return {'crash': s['total']['crash'], 'nan': s['total']['nan'],
            'inf': s['total']['inf'], 'inconsistency': incons}


def main():
    parse = argparse.ArgumentParser()
    parse.add_argument('--ablation', type=str, default='all',
                       help="消融配置: all 或单个 (full/no_layer/no_edge/no_shape/no_dim/"
                            "no_pv/no_bv/no_it/no_nf/no_ws/no_wr)")
    parse.add_argument('--pool', type=str, default=None,
                       help="只运行指定层池 (keras3.10/tensorflow2.0.0/cntk2.7.0/theano1.0.4), 默认全部")
    parse.add_argument('--models', type=int, default=CASE_NUM,
                       help='每个配置生成的模型数 (默认 CASE_NUM=%d)' % CASE_NUM)
    parse.add_argument('--threshold', type=float, default=0.15,
                       help='Inconsistency 判定阈值 (论文 scripts/incons 使用 0.15)')
    parse.add_argument('--out', type=str, default=str(Path(PROJECT_ROOT) / 'data' / 'ablation_exp2_final.json'))
    parse.add_argument('--timeout', type=float, default=120, help='子进程超时 (秒)')
    parse.add_argument('--seed', type=int, default=2024)
    parse.add_argument('--workers', type=int, default=3, help='并行 worker 数 (默认 3)')
    flags = parse.parse_args()

    if flags.ablation == 'all':
        ablations = ABLATION_ORDER
    else:
        ablations = [flags.ablation]
        if flags.ablation not in ABLATION_ORDER:
            raise SystemExit(f"unknown ablation: {flags.ablation}")
    pools = [flags.pool] if flags.pool else UNIQUE_POOLS

    out_root = Path(PROJECT_ROOT) / 'data' / f'exp2_abl_out_{flags.seed}'
    sum_dir = Path(PROJECT_ROOT) / 'data' / f'exp2_abl_summaries_{flags.seed}'
    sum_dir.mkdir(parents=True, exist_ok=True)

    # 断点续跑: 已有落盘 summary 的直接复用
    done = {}
    for f in sum_dir.glob('*.json'):
        try:
            s = json.loads(f.read_text(encoding='utf-8'))
            done[(s['framework_pool'], s['ablation'])] = s
        except Exception:
            continue

    tasks, cached = [], []
    for pool in pools:
        for idx, ab in enumerate(ablations):
            if (pool, ab) in done:
                cached.append(done[(pool, ab)])
                continue
            tasks.append((pool, ab, flags.models, flags.seed + idx * 7,
                          flags.threshold, flags.timeout, str(out_root)))

    t0 = time.time()
    results = list(cached)
    print(f'[Exp2] cached summaries: {len(cached)}, new tasks: {len(tasks)}', flush=True)
    if tasks:
        if flags.workers > 1 and len(tasks) > 1:
            import multiprocessing as mp
            ctx = mp.get_context('spawn')
            with ctx.Pool(flags.workers) as pool:
                for i, s in enumerate(pool.starmap(run_one, tasks)):
                    results.append(s)
                    print(f"[{i+1}/{len(tasks)}] {s['framework_pool']}/{s['ablation']} "
                          f"crash={s['total']['crash']} nan={s['total']['nan']} "
                          f"inf={s['total']['inf']} incons={s['total']['inconsistency']} "
                          f"LIC={s.get('LIC')}% LPC={s.get('LPC')}% LSC={s.get('LSC')}% "
                          f"ok={s['ok_models']}/{s['total_models']}", flush=True)
        else:
            for i, t in enumerate(tasks):
                s = run_one(*t)
                results.append(s)
                print(f"[{i+1}/{len(tasks)}] {s['framework_pool']}/{s['ablation']} "
                      f"crash={s['total']['crash']} nan={s['total']['nan']} "
                      f"inf={s['total']['inf']} incons={s['total']['inconsistency']} "
                      f"LIC={s.get('LIC')}% LPC={s.get('LPC')}% LSC={s.get('LSC')}% "
                      f"ok={s['ok_models']}/{s['total_models']}", flush=True)

    # ---- 汇总: 按 6 框架 × 11 配置展开 ----
    by_pool = {}
    for s in results:
        by_pool.setdefault(s['framework_pool'], {})[s['ablation']] = s
    by_framework = {}
    for fw in NEW_FRAMEWORKS + OLD_FRAMEWORKS:
        pool = FRAMEWORK_POOLS[fw]
        by_framework[fw] = {}
        for ab in ablations:
            if pool in by_pool and ab in by_pool[pool]:
                s = by_pool[pool][ab]
                view = _pick_view(s, fw)
                by_framework[fw][ab] = {
                    'models': s['total_models'], 'ok_models': s['ok_models'],
                    'gen_fail': s['gen_fail'],
                    'crash': view['crash'], 'nan': view['nan'],
                    'inf': view['inf'], 'inconsistency': view['inconsistency'],
                    'total_defects': view['crash'] + view['nan'] + view['inf'] + view['inconsistency'],
                    'LIC': s.get('LIC'), 'LPC': s.get('LPC'), 'LSC': s.get('LSC'),
                    'defect_records': s.get('defect_records', 0),
                    'enabled_spaces': s['enabled_spaces'], 'enabled_ops': s['enabled_ops'],
                }

    # ---- 贡献度: 每个消融相对 full 的缺陷减少量与覆盖率下降量 ----
    contribution = {}
    for fw in NEW_FRAMEWORKS + OLD_FRAMEWORKS:
        contribution[fw] = {}
        if 'full' not in by_framework[fw]:
            continue
        full = by_framework[fw]['full']
        for ab in ablations:
            if ab == 'full' or ab not in by_framework[fw]:
                continue
            r = by_framework[fw][ab]
            contribution[fw][ab] = {
                'crash_delta': full['crash'] - r['crash'],
                'nan_delta': full['nan'] - r['nan'],
                'inf_delta': full['inf'] - r['inf'],
                'inconsistency_delta': full['inconsistency'] - r['inconsistency'],
                'total_delta': full['total_defects'] - r['total_defects'],
                'LIC_delta': round((full['LIC'] or 0) - (r['LIC'] or 0), 2),
                'LPC_delta': round((full['LPC'] or 0) - (r['LPC'] or 0), 2),
                'LSC_delta': round((full['LSC'] or 0) - (r['LSC'] or 0), 2),
            }

    out_doc = {
        'meta': {
            'experiment': 'ablation_exp2_defect_contribution',
            'models_per_config': flags.models,
            'threshold': flags.threshold,
            'backends': list(BACKENDS),
            'framework_pools': {fw: FRAMEWORK_POOLS[fw] for fw in NEW_FRAMEWORKS + OLD_FRAMEWORKS},
            'ablation_order': ablations,
            'elapsed_sec': round(time.time() - t0, 1),
            'note': '新框架共享 Keras3 全量层池: tf 后端=tensorflow2.16.1 视角, torch 后端=pytorch2.2.0 视角, 整体=keras3.10; '
                    '老框架为受限层池生成的模型在可用 tf/torch 后端上的执行结果; '
                    'LIC/LPC/LSC 为 COMET 原理 + 框架适配参数, 基于全部生成模型跨模型累积; '
                    '缺陷明细 (定位层+源码片段) 见 data/exp2_defects_<seed>/',
        },
        'by_framework': by_framework,
        'contribution': contribution,
    }
    out = Path(flags.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(str(out), 'w', encoding='utf-8') as f:
        json.dump(out_doc, f, ensure_ascii=False, indent=2)

    print('\n================= Defect Ablation Summary =================')
    for fw in NEW_FRAMEWORKS + OLD_FRAMEWORKS:
        row = by_framework[fw]
        if 'full' not in row:
            continue
        f = row['full']
        print(f"{fw:20s} full: crash={f['crash']} nan={f['nan']} inf={f['inf']} incons={f['inconsistency']} "
              f"LIC={f['LIC']}% LPC={f['LPC']}% LSC={f['LSC']}%")
        for ab in ablations[1:]:
            if ab not in row:
                continue
            c = contribution[fw][ab]
            print(f"{'':20s} {ab:8s}: Δcrash={c['crash_delta']:+d} Δnan={c['nan_delta']:+d} "
                  f"Δinf={c['inf_delta']:+d} Δincons={c['inconsistency_delta']:+d} Δtotal={c['total_delta']:+d} "
                  f"ΔLIC={c['LIC_delta']:+.2f} ΔLPC={c['LPC_delta']:+.2f} ΔLSC={c['LSC_delta']:+.2f}")
    print(f'\nResults saved to {out}')


if __name__ == '__main__':
    main()
