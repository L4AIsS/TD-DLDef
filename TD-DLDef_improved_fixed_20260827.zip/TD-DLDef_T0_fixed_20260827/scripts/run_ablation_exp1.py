# -*- coding: utf-8 -*-
"""
消融实验 1: 多样性空间与突变算子的独立贡献 (LIC / LPC / LSC)

实验设计 (对应论文 Table V 消融实验的补充):
    * 基准 (full): 四个多样性评估空间 + 六种突变算子全部启用;
    * 空间消融 (去掉每个多样性评估空间, 突变算子不变):
          no_layer / no_edge / no_shape / no_dim;
    * 算子消融 (去掉每种突变算子, 多样性空间评估不变):
          no_pv / no_bv / no_it / no_nf / no_ws / no_wr;
    * 框架: 新框架 (tensorflow2.16.1, pytorch2.2.0, keras3.10)
            + 老框架 (tensorflow2.0.0, cntk2.7.0, theano1.0.4)
            层池与参数约束由 utils.framework_config 提供。

覆盖率指标 (COMET 算法原理 + 目标框架适配参数, 见 utils/coverage.py):
    * LIC (Layer Input Coverage, 式14)
    * LPC (Layer Parameter Coverage, 式15)
    * LSC (Layer Sequence Coverage, 式16)
    统计口径: 一次测试任务中基于生成的全部模型 (跨模型累积), 非单模型。

说明: LIC/LPC/LSC 是模型结构层 (结构生成阶段) 的统计指标, 与具体后端
执行无关, 因此本实验在结构生成层面直接统计, 无需安装全部 6 个框架。
运行: python scripts/run_ablation_exp1.py [--fw tensorflow2.16.1] [--models 200]
"""

import argparse
import contextlib
import io
import json
import random
import sys
from pathlib import Path

PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
sys.path.insert(0, PROJECT_ROOT)

from utils.framework_config import NEW_FRAMEWORKS, OLD_FRAMEWORKS, get_framework_config
from utils.selection import Selector
from utils.mutation import MutationConfig, ValueMutator
from utils.coverage import CoverageTracker
from utils.db_manager import DbManager
from src.cases_generation.model_info_generator import ModelInfoGenerator

# ---------------------------------------------------------------------- #
# 消融配置
# ---------------------------------------------------------------------- #
ALL_SPACES = ['layer', 'edge', 'shape', 'dim']
ALL_OPS = ['pv', 'bv', 'it', 'nf', 'ws', 'wr']

SPACE_ABLATIONS = {
    'full': ALL_SPACES,
    'no_layer': [s for s in ALL_SPACES if s != 'layer'],
    'no_edge': [s for s in ALL_SPACES if s != 'edge'],
    'no_shape': [s for s in ALL_SPACES if s != 'shape'],
    'no_dim': [s for s in ALL_SPACES if s != 'dim'],
}

MUTATION_ABLATIONS = {
    'full': ALL_OPS,
    'no_pv': [o for o in ALL_OPS if o != 'pv'],
    'no_bv': [o for o in ALL_OPS if o != 'bv'],
    'no_it': [o for o in ALL_OPS if o != 'it'],
    'no_nf': [o for o in ALL_OPS if o != 'nf'],
    'no_ws': [o for o in ALL_OPS if o != 'ws'],
    'no_wr': [o for o in ALL_OPS if o != 'wr'],
}

# 全部消融配置: 空间消融 4 组 + 算子消融 6 组 (+ 基准 full 在两组中重复, 只统计一次)
ABLATION_ORDER = (['full'] + list(SPACE_ABLATIONS)[1:] + list(MUTATION_ABLATIONS)[1:])

MODEL_CONFIG = {
    'var': {
        'tensor_dimension_range': (2, 5),
        'tensor_element_size_range': (2, 5),
        'weight_value_range': (-10.0, 10.0),
        'small_value_range': (0, 1),
        'vocabulary_size': 1001,
    },
    'node_num_range': (8, 8),
    'dag_io_num_range': (1, 3),
    'dag_max_branch_num': 2,
    'cell_num': 3,
    'node_num_per_normal_cell': 10,
    'node_num_per_reduction_cell': 2,
}

INPUT_SHAPE = (None, 6, 6, 3)
OUTPUT_SHAPE = (None, 4)
NODE_NUM = 8
INPUT_DTYPES = ValueMutator.INPUT_DTYPES
CASE_NUM = 200          # 默认每个消融配置生成 200 个模型


def run_single_ablation(fw, ablation, n_models, seed):
    """运行一个 (框架, 消融配置) 组合, 返回 LIC/LPC/LSC 统计

    多样性评估为任务级: 四个空间基于本次运行生成的全部模型累积
    (selector 持有任务级 DiversityEvaluator)。

    :return: summary_dict
    """
    rng = random.Random(seed)
    fw_cfg = get_framework_config(fw)

    # 依据消融配置解析启用的空间与算子
    if ablation in SPACE_ABLATIONS:
        enabled_spaces = SPACE_ABLATIONS[ablation]
        enabled_ops = ALL_OPS                       # 空间消融: 突变算子不变
    else:
        enabled_spaces = ALL_SPACES                 # 算子消融: 空间评估不变
        enabled_ops = MUTATION_ABLATIONS[ablation]

    # 覆盖率追踪器: 框架适配的参数空间 (activation/padding 池按新旧框架区分)
    tracker = CoverageTracker(fw_cfg.layer_types, fw_cfg.layer_conditions,
                              activation_pool=fw_cfg.activation_pool,
                              padding_pool=fw_cfg.padding_pool,
                              element_range=MODEL_CONFIG['var']['tensor_element_size_range'],
                              dim_range=MODEL_CONFIG['var']['tensor_dimension_range'])
    selector = Selector(fw_cfg.layer_types, fw_cfg.layer_conditions,
                        diversity_spaces=enabled_spaces)
    mutation_cfg = MutationConfig(enabled=enabled_ops, seed=seed)
    value_mutator = ValueMutator(mutation_cfg)

    db = DbManager(':memory:')
    gen = ModelInfoGenerator(MODEL_CONFIG, db, selector, 'seq',
                             mutation_config=mutation_cfg,
                             coverage_tracker=tracker,
                             layer_types=fw_cfg.layer_types,
                             layer_conditions=fw_cfg.layer_conditions)

    success, fail = 0, 0
    for i in range(n_models):
        # Input Type Mutation (IT): 启用时随机选择输入 dtype
        dtype = value_mutator.input_type('float32') if 'it' in enabled_ops else 'float32'
        try:
            selector.reset_model_state()
            with contextlib.redirect_stdout(io.StringIO()):
                model_info, _, _, node_num = gen.generate_seq_model(
                    node_num=NODE_NUM, input_shape=INPUT_SHAPE, output_shape=OUTPUT_SHAPE)
            selector.finish_model_state()
            tracker.record_model(model_info, input_dtype=dtype)
            success += 1
        except Exception:
            fail += 1
            continue

    summary = tracker.summary()
    summary['framework'] = fw
    summary['ablation'] = ablation
    summary['enabled_spaces'] = enabled_spaces
    summary['enabled_ops'] = enabled_ops
    summary['success_models'] = success
    summary['fail_models'] = fail
    # 任务级多样性统计 (跨全部模型)
    summary['diversity'] = selector.diversity_summary()
    # 逐层 LIC/LPC 明细 (供论文细粒度分析)
    detail = tracker.detail()
    summary['LIC_per_layer'] = detail['LIC_per_layer']
    summary['LPC_per_layer'] = detail['LPC_per_layer']
    return summary


def main():
    parse = argparse.ArgumentParser()
    parse.add_argument('--fw', type=str, default=None, help='只运行指定框架 (默认全部)')
    parse.add_argument('--models', type=int, default=CASE_NUM,
                       help='每个配置生成的模型数 (默认 CASE_NUM=%d)' % CASE_NUM)
    parse.add_argument('--out', type=str, default=str(Path(PROJECT_ROOT) / 'data' / 'ablation_exp1.json'),
                       help='结果输出 json 路径')
    parse.add_argument('--seed', type=int, default=2024)
    flags = parse.parse_args()

    if flags.fw:
        frameworks = [flags.fw]
    else:
        frameworks = NEW_FRAMEWORKS + OLD_FRAMEWORKS

    results = []
    for fw in frameworks:
        for idx, ablation in enumerate(ABLATION_ORDER):
            print(f'[Exp1] framework={fw} ablation={ablation} ...', flush=True)
            try:
                summary = run_single_ablation(fw, ablation, flags.models,
                                              seed=flags.seed + idx * 7)
            except Exception as e:
                summary = {'framework': fw, 'ablation': ablation, 'error': str(e)}
            results.append(summary)
            print(f'    -> LIC={summary.get("LIC")}% LPC={summary.get("LPC")}% '
                  f'LSC={summary.get("LSC")}% (models={summary.get("success_models")})', flush=True)

    out = Path(flags.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(str(out), 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f'\nResults saved to {out}')


if __name__ == '__main__':
    main()
