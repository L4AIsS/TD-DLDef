# -*- coding: utf-8 -*-
"""
TD-DLDef 完整实验报告生成器 (2026-08-21 执行版)

读取本次执行的实验数据:
    * data/ablation_exp1_c200.json          —— 消融实验 1 (6 框架 × 11 配置, LIC/LPC/LSC)
    * data/ablation_exp2_c30_all.json       —— 消融实验 2 (缺陷 + 覆盖率)
    * data/exp2_defects_200/*.jsonl         —— 全部 oracle 缺陷明细记录
生成正式风格 HTML 报告: 深蓝 + 深灰主色, 深红点缀, 低饱和度。

运行: python scripts/gen_final_report.py
"""
import json
import html
from collections import Counter, defaultdict
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA = PROJECT_ROOT / 'data'
OUT = DATA / 'TD-DLDef_实验报告_20260821.html'

NEW_FWS = ['tensorflow2.16.1', 'pytorch2.2.0', 'keras3.10']
OLD_FWS = ['tensorflow2.0.0', 'cntk2.7.0', 'theano1.0.4']
FRAMEWORKS = NEW_FWS + OLD_FWS
SPACE_ABL = ['no_layer', 'no_edge', 'no_shape', 'no_dim']
OP_ABL = ['no_pv', 'no_bv', 'no_it', 'no_nf', 'no_ws', 'no_wr']
ABLATIONS = ['full'] + SPACE_ABL + OP_ABL

SPACE_CN = {'no_layer': '− 层空间 S_l', 'no_edge': '− 边空间 S_e',
            'no_shape': '− 输入形状空间 S_s', 'no_dim': '− 输入维度空间 S_d'}
OP_CN = {'no_pv': '− 参数值突变 PV', 'no_bv': '− 边界值突变 BV', 'no_it': '− 输入类型突变 IT',
         'no_nf': '− 噪声模糊 NF', 'no_ws': '− 权重缩放 WS', 'no_wr': '− 权重旋转 WR'}

# 配色: 深蓝 / 深灰 / 深红 (低饱和正式风格)
C_BLUE = '#1f3a5f'
C_BLUE2 = '#33587f'
C_GRAY = '#3c4148'
C_LGRAY = '#e8eaed'
C_RED = '#8c2d2d'
C_GRID = '#c9ced6'


def esc(s):
    return html.escape(str(s))


def bar_chart(items, title='', width=560, bar_h=22, maxv=None, unit='%'):
    """生成横向条形图 (inline SVG). items: [(label, value, highlight)]"""
    if not items:
        return ''
    maxv = maxv or max(v for _, v, _ in items) or 1
    left = 150
    h = (bar_h + 8) * len(items) + 30
    parts = [f'<svg width="{width}" height="{h}" xmlns="http://www.w3.org/2000/svg" '
             f'font-family="Segoe UI, Microsoft YaHei, sans-serif">']
    if title:
        parts.append(f'<text x="0" y="14" font-size="12" fill="{C_GRAY}">{esc(title)}</text>')
    y = 24
    for label, v, hl in items:
        w = max(1.0, (width - left - 60) * v / maxv)
        color = C_RED if hl else C_BLUE2
        parts.append(f'<text x="{left-6}" y="{y+bar_h*0.72}" font-size="11" fill="{C_GRAY}" text-anchor="end">{esc(label)}</text>')
        parts.append(f'<rect x="{left}" y="{y}" width="{w:.1f}" height="{bar_h}" fill="{color}"/>')
        parts.append(f'<text x="{left+w+5:.1f}" y="{y+bar_h*0.72}" font-size="11" fill="{C_GRAY}">{v:.2f}{unit}</text>')
        y += bar_h + 8
    parts.append('</svg>')
    return ''.join(parts)


def table(headers, rows, cls=''):
    t = [f'<table class="{cls}"><thead><tr>']
    for h in headers:
        t.append(f'<th>{esc(h)}</th>')
    t.append('</tr></thead><tbody>')
    for r in rows:
        t.append('<tr>')
        for c in r:
            t.append(f'<td>{c}</td>')
        t.append('</tr>')
    t.append('</tbody></table>')
    return ''.join(t)


def fmt_delta(v, digits=2):
    color = C_RED if v > 0 else ('#2d5a2d' if v < 0 else C_GRAY)
    return f'<span style="color:{color}">{v:+.{digits}f}</span>'


def root_cause_of(rec):
    """根据缺陷记录推断根因描述"""
    dt = rec.get('defect_type')
    layer = rec.get('located_layer')
    muts = rec.get('model_mutations') or []
    layer_mut = None
    if layer:
        for m in muts:
            if m.get('layer') == layer:
                layer_mut = m.get('mutations')
    mutated_layers = [m.get('layer') for m in muts]
    if dt == 'crash':
        if rec.get('stage') == 'generation':
            if mutated_layers:
                return ('框架无法构建该模型。模型中曾被 PV/BV 值突变改动的层: %s；'
                        '根因疑似为突变引入的非法参数组合 (如边界值/非常规枚举值) 超出该框架 API 的合法域。'
                        % ', '.join(mutated_layers))
            return '框架无法构建该模型结构 (无突变层)，根因为生成的结构/参数组合超出该框架支持范围。'
        if mutated_layers:
            return ('训练子进程异常退出。模型含 PV/BV 突变层: %s；'
                    '根因疑似为突变参数导致的训练期数值/形状异常。' % ', '.join(mutated_layers))
        return '训练子进程异常退出 (进程级崩溃)，根因为框架在该模型结构上的执行异常。'
    if dt in ('nan', 'inf'):
        base = '层 %s 的输出中检测到 %s (拓扑序首个异常层)。' % (layer, dt.upper())
        if layer_mut:
            ops = []
            for entry in layer_mut:
                for op, ch in entry.items():
                    for p, on in ch.items():
                        ops.append('%s 算子将 %s: %s→%s' % (op.upper(), p, on[0], on[1]))
            return base + '根因: 该层被值突变改动 (%s)，突变引入的边界/非常规参数导致数值不稳定。' % '; '.join(ops)
        return base + '该层本身未被突变，根因为上游层输出在框架数值实现下发散 (或上游突变沿网络传播至此)。'
    if dt == 'inconsistency':
        deltas = []
        exceeded = []
        for k in ('output_delta', 'loss_delta', 'loss_grads_delta'):
            v = rec.get(k)
            if v is None:
                continue
            try:
                fv = float(v)
            except (TypeError, ValueError):
                continue
            deltas.append('%s=%.6g' % (k, fv))
            if fv > 0.15:
                exceeded.append(k)
        base = ('层 %s 为两后端逐层输出差异最大的层 (分歧源头层)。判定依据: %s (阈值 0.15, 超限项: %s)。'
                % (layer, ', '.join(deltas) if deltas else (rec.get('detail') or ''),
                   ', '.join(exceeded) if exceeded else '见 detail'))
        if layer_mut:
            return base + '该层曾被值突变改动，突变放大了两框架在该算子上的实现差异 (精度/边界处理)，为缺陷根因。'
        return base + '根因为两框架对该层算子的实现差异 (数值精度/填充/归一化策略等)。'
    return ''


def main():
    # ---------- 读数据 ----------
    exp1 = json.load(open(DATA / 'ablation_exp1_c200.json', encoding='utf-8'))
    exp1_map = {(r['framework'], r['ablation']): r for r in exp1}

    exp2_path = DATA / 'ablation_exp2_c30_all.json'
    exp2 = json.load(open(exp2_path, encoding='utf-8')) if exp2_path.exists() else None

    # 目标环境 (tf2.16.1/keras3.10) 200 模型历史实测 (旧版代码缓存, 仅缺陷计数)
    ref200 = {}
    for fp in sorted(DATA.glob('exp2_abl_summaries_200/keras3.10__*.json')):
        s = json.load(open(fp, encoding='utf-8'))
        ref200[s['ablation']] = s

    defect_records = []
    for fp in sorted(DATA.glob('exp2_defects_822/*.jsonl')):
        cfg = fp.stem
        for line in open(fp, encoding='utf-8'):
            line = line.strip()
            if line:
                r = json.loads(line)
                r['__config__'] = cfg
                defect_records.append(r)

    # ---------- 报告骨架 ----------
    S = []
    S.append('''<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<title>TD-DLDef 实验报告 (2026-08-21)</title>
<style>
body{font-family:"Segoe UI","Microsoft YaHei",sans-serif;color:#2b2f36;max-width:1080px;margin:0 auto;padding:32px 40px;background:#fafbfc;line-height:1.65}
h1{color:#1f3a5f;border-bottom:3px solid #1f3a5f;padding-bottom:10px;font-size:26px}
h2{color:#1f3a5f;border-left:6px solid #1f3a5f;padding-left:12px;margin-top:44px;font-size:20px}
h3{color:#33587f;font-size:16px;margin-top:28px}
table{border-collapse:collapse;width:100%;margin:14px 0;font-size:13px;background:#fff}
th{background:#1f3a5f;color:#fff;padding:7px 9px;text-align:left;font-weight:600}
td{padding:6px 9px;border-bottom:1px solid #e8eaed}
tr:nth-child(even) td{background:#f4f6f8}
.meta{background:#fff;border:1px solid #dfe3e8;border-left:5px solid #8c2d2d;padding:14px 18px;margin:18px 0;font-size:13.5px}
.kpi{display:inline-block;background:#fff;border:1px solid #dfe3e8;border-top:4px solid #1f3a5f;padding:12px 22px;margin:6px 10px 6px 0;text-align:center;min-width:120px}
.kpi .v{font-size:24px;color:#1f3a5f;font-weight:700}
.kpi .l{font-size:12px;color:#3c4148}
code,pre{font-family:Consolas,"Courier New",monospace;font-size:12px;background:#f0f2f5}
pre{padding:12px 14px;border-left:4px solid #8c2d2d;overflow-x:auto;white-space:pre-wrap;line-height:1.5}
.defect{background:#fff;border:1px solid #dfe3e8;border-left:5px solid #8c2d2d;padding:12px 16px;margin:12px 0}
.defect .head{font-weight:600;color:#8c2d2d;font-size:13.5px}
.note{color:#5a6068;font-size:12.5px}
.toc{background:#fff;border:1px solid #dfe3e8;padding:14px 22px;font-size:13.5px}
.toc a{color:#33587f;text-decoration:none}
</style></head><body>''')

    S.append('<h1>TD-DLDef 深度学习框架差分测试实验报告</h1>')
    S.append('''<div class="meta">
<b>执行日期:</b> 2026-08-21 &nbsp;|&nbsp; <b>项目:</b> TD-DLDef (Improved, 0821 版) &nbsp;|&nbsp;
<b>测试方法:</b> 基于模型级多样性增强 (TS-RCS + 四多样性空间 + 六突变算子) 的深度学习框架差分测试<br>
<b>目标框架:</b> 新框架 tensorflow 2.16.1 / pytorch 2.2.0 / keras 3.10；旧框架 tensorflow 2.0.0 / keras 2.3.1 / cntk 2.7.0 / theano 1.0.4<br>
<b>执行环境说明:</b> 本机沙箱为 tensorflow 2.21 / keras 3.15 / torch 2.13 (CPU)，与论文目标版本存在差异；
实验 1 为结构层统计，与框架版本无关；实验 2 的真实后端执行在可用 Keras 3 后端 (tensorflow/torch) 上进行，
旧框架视角按其受限层池生成模型后在可用后端执行 (最接近近似)。</div>''')

    S.append('''<div class="toc"><b>目录</b><br>
<a href="#s1">1. 实验设置与评价指标</a> · <a href="#s2">2. 主实验：覆盖率结果 (LIC/LPC/LSC)</a> ·
<a href="#s3">3. 消融实验 1：多样性空间与突变算子对覆盖率的贡献</a> ·
<a href="#s4">4. 消融实验 2：缺陷检测贡献 (真实后端)</a> ·
<a href="#s5">5. Oracle 缺陷明细统计 (类型 / 源码位置 / 根因)</a> ·
<a href="#s6">6. 任务级多样性评估</a> · <a href="#s7">7. 结论</a></div>''')

    # ---------- 1. 实验设置 ----------
    S.append('<h2 id="s1">1. 实验设置与评价指标</h2>')
    S.append('<h3>1.1 实验配置</h3>')
    S.append(table(['配置项', '取值'], [
        ['每配置模型数 (实验 1)', '200 (CASE_NUM=200)，seq 链式结构，node_num=8'],
        ['每配置模型数 (实验 2)', '30 × 11 配置 × 4 层池 (真实后端训练比对)'],
        ['输入/输出形状', '(None,6,6,3) → (None,4)'],
        ['多样性空间', '层空间 S_l、边空间 S_e、输入形状空间 S_s、输入维度空间 S_d (任务级，跨全部模型累积)'],
        ['突变算子', '值突变: PV 参数值 / BV 边界值 / IT 输入类型；神经元突变: NF 噪声模糊 / WS 权重缩放 / WR 权重旋转'],
        ['Oracle 1 (Crash)', '模型构建/训练子进程异常退出 (退出码 255/1/-1)'],
        ['Oracle 2 (NaN/Inf)', '任一层输出中出现 NaN 或 Inf'],
        ['Oracle 3 (Inconsistency)', '同一模型两后端输出/损失/损失梯度差异 delta > 0.15'],
    ]))
    S.append('<h3>1.2 覆盖率指标 (COMET 式 1-3 原理 + 目标框架适配参数)</h3>')
    S.append(table(['指标', '定义', '框架适配要点'], [
        ['LIC 层输入覆盖率', 'CovI(l)=(cov_type+cov_dim+cov_shape)/(n_type+n_dim+n_shape)，全层池平均',
         'n_type: embedding=1/浮点层=2/input=3 (全集 {float32,float64,int32})；n_dim=|sidim∩{2..5}|；n_shape=Σ4^(d-1)'],
        ['LPC 层参数覆盖率', 'CovP(l)=Σcov_pi/Σn_pi (仅可变参数)，全层池平均',
         '布尔=2；枚举=框架池 (新旧框架不同)；有界整数=7 ({2..5}∪PV±2)；连续浮点 σ=5 桶；结构型 min(取值数,5)'],
        ['LSC 层序列覆盖率', 'CovS=cov_seq/ΣΣ sign(|sodim(li)∩sidim(lj)|)',
         'sidim/sodim 按 Keras 3.10/2.3.1 文档修正 (RNN 入{3}、repeat_vector 入{2}、convLSTM2D 出{4,5} 等)'],
    ]))

    # ---------- 2. 主实验覆盖率 ----------
    S.append('<h2 id="s2">2. 主实验：覆盖率结果 (full 配置, 200 模型)</h2>')
    rows = []
    for fw in FRAMEWORKS:
        r = exp1_map[(fw, 'full')]
        rows.append([f'<b>{fw}</b>', f"{r['LIC']:.2f}%", f"{r['LPC']:.2f}%", f"{r['LSC']:.2f}%",
                     f"{r['LSC_cov_seq']}/{r['LSC_denom']}", r['success_models']])
    S.append(table(['框架', 'LIC', 'LPC', 'LSC', '覆盖层序列 (cov_seq/分母)', '成功模型数'], rows))
    S.append(bar_chart([(fw, exp1_map[(fw, 'full')]['LIC'], fw in NEW_FWS) for fw in FRAMEWORKS],
                       title='LIC (%) — 深红为新框架'))
    S.append(bar_chart([(fw, exp1_map[(fw, 'full')]['LPC'], fw in NEW_FWS) for fw in FRAMEWORKS],
                       title='LPC (%)'))
    S.append(bar_chart([(fw, exp1_map[(fw, 'full')]['LSC'], fw in NEW_FWS) for fw in FRAMEWORKS],
                       title='LSC (%)'))
    avg = lambda k: sum(exp1_map[(fw, 'full')][k] for fw in FRAMEWORKS) / 6
    S.append(f'''<div class="meta">6 框架平均: <b>LIC {avg('LIC'):.2f}%</b> · <b>LPC {avg('LPC'):.2f}%</b> ·
<b>LSC {avg('LSC'):.2f}%</b>。新框架 (Keras 3 全量层池 47 层) 的 LSC 分母 (1294 组有效层对)
大于旧框架受限层池 (1003-1077)，覆盖难度更高。</div>''')

    # ---------- 3. 消融实验 1 ----------
    S.append('<h2 id="s3">3. 消融实验 1：多样性空间与突变算子对覆盖率的独立贡献</h2>')
    S.append('<p class="note">Δ = full − 消融配置 (正值表示该成分对覆盖率有正贡献，去掉后指标下降)。'
             '空间消融保持六种突变算子不变；算子消融保持四空间评估不变。</p>')
    for fw in FRAMEWORKS:
        full = exp1_map[(fw, 'full')]
        rows = []
        for ab in SPACE_ABL + OP_ABL:
            r = exp1_map[(fw, ab)]
            name = SPACE_CN.get(ab) or OP_CN.get(ab)
            rows.append([name, f"{r['LIC']:.2f}", f"{r['LPC']:.2f}", f"{r['LSC']:.2f}",
                         fmt_delta(full['LIC'] - r['LIC']), fmt_delta(full['LPC'] - r['LPC']),
                         fmt_delta(full['LSC'] - r['LSC'])])
        S.append(f'<h3>3.x {fw} (full: LIC={full["LIC"]:.2f}% LPC={full["LPC"]:.2f}% LSC={full["LSC"]:.2f}%)</h3>')
        S.append(table(['消融配置', 'LIC', 'LPC', 'LSC', 'ΔLIC', 'ΔLPC', 'ΔLSC'], rows))

    # 跨框架平均贡献
    S.append('<h3>3.avg 跨框架平均贡献 (6 框架 Δ 均值)</h3>')
    rows = []
    for ab in SPACE_ABL + OP_ABL:
        name = SPACE_CN.get(ab) or OP_CN.get(ab)
        dl = sum(exp1_map[(fw, 'full')]['LIC'] - exp1_map[(fw, ab)]['LIC'] for fw in FRAMEWORKS) / 6
        dp = sum(exp1_map[(fw, 'full')]['LPC'] - exp1_map[(fw, ab)]['LPC'] for fw in FRAMEWORKS) / 6
        ds = sum(exp1_map[(fw, 'full')]['LSC'] - exp1_map[(fw, ab)]['LSC'] for fw in FRAMEWORKS) / 6
        rows.append([name, fmt_delta(dl), fmt_delta(dp), fmt_delta(ds)])
    S.append(table(['消融配置', '平均 ΔLIC', '平均 ΔLPC', '平均 ΔLSC'], rows))

    # ---------- 4. 消融实验 2 ----------
    S.append('<h2 id="s4">4. 消融实验 2：缺陷检测贡献 (真实后端执行)</h2>')
    # 4.0 目标环境 200 模型参考数据 (缓存自论文目标环境的历史实测)
    if ref200:
        S.append('<h3>4.0 参考：目标环境 (tensorflow 2.16.1 / keras 3.10) 200 模型实测缺陷计数 '
                 '<span class="note">(keras3.10 全量层池, 缓存自目标环境历史运行, 见 data/exp2_abl_summaries_200/)</span></h3>')
        rows = []
        full_ref = ref200.get('full')
        for ab in ABLATIONS:
            s = ref200.get(ab)
            if not s:
                continue
            t = s['total']
            name = 'full (基准)' if ab == 'full' else (SPACE_CN.get(ab) or OP_CN.get(ab))
            dt = (full_ref['total']['crash'] + full_ref['total']['nan'] + full_ref['total']['inf']
                  + full_ref['total']['inconsistency']) - (t['crash'] + t['nan'] + t['inf'] + t['inconsistency'])
            rows.append([name, t['crash'], t['nan'], t['inf'], t['inconsistency'],
                         t['crash'] + t['nan'] + t['inf'] + t['inconsistency'],
                         fmt_delta(dt, 0) if ab != 'full' else '—',
                         f"{s['ok_models']}/{s['total_models']}"])
        S.append(table(['消融配置', 'Crash', 'NaN', 'Inf', 'Inconsistency', '合计', 'Δ合计', '成功模型'], rows))
        S.append('<p class="note">注: 该参考数据由前一版代码在论文目标环境 (CASE_NUM=200) 运行产生, '
                 '多样性评估为单模型口径; 本节 4.1/4.2 为本次 0821 版代码在本机沙箱的全新执行结果。</p>')
    if exp2 is None:
        S.append('<p>实验 2 数据缺失。</p>')
    else:
        meta = exp2['meta']
        S.append(f'''<div class="meta">每配置模型数: <b>{meta['models_per_config']}</b>；
判定阈值: {meta['threshold']}；执行后端: {', '.join(meta['backends'])}；耗时: {meta['elapsed_sec']}s。<br>
框架视角映射: tensorflow 后端缺陷 → tensorflow2.16.1 视角；torch 后端 → pytorch2.2.0 视角；
两者合计 → keras3.10 视角；旧框架为受限层池模型在可用后端上的执行近似。</div>''')
        by_fw, contrib = exp2['by_framework'], exp2['contribution']
        # 4.1 full 缺陷总览
        S.append('<h3>4.1 full 配置缺陷总览</h3>')
        rows = []
        for fw in FRAMEWORKS:
            f = by_fw[fw]['full']
            rows.append([f'<b>{fw}</b>', f['crash'], f['nan'], f['inf'], f['inconsistency'],
                         f['total_defects'], f"{f['ok_models']}/{f['models']}",
                         f"{f.get('LIC')}%/{f.get('LPC')}%/{f.get('LSC')}%"])
        S.append(table(['框架', 'Crash', 'NaN', 'Inf', 'Inconsistency', '缺陷合计', '成功模型', 'LIC/LPC/LSC'], rows))
        # 4.2 消融贡献
        S.append('<h3>4.2 各消融配置的缺陷计数与贡献 (Δ = full − 消融)</h3>')
        for fw in FRAMEWORKS:
            rows = []
            full = by_fw[fw]['full']
            for ab in SPACE_ABL + OP_ABL:
                r = by_fw[fw][ab]
                c = contrib[fw][ab]
                name = SPACE_CN.get(ab) or OP_CN.get(ab)
                rows.append([name, r['crash'], r['nan'], r['inf'], r['inconsistency'], r['total_defects'],
                             fmt_delta(c['total_delta'], 0),
                             fmt_delta(c.get('LIC_delta', 0)), fmt_delta(c.get('LPC_delta', 0)),
                             fmt_delta(c.get('LSC_delta', 0))])
            S.append(f'<h3>4.2.x {fw} (full 缺陷合计 = {full["total_defects"]})</h3>')
            S.append(table(['消融配置', 'Crash', 'NaN', 'Inf', 'Incons', '合计', 'Δ合计', 'ΔLIC', 'ΔLPC', 'ΔLSC'], rows))

    # ---------- 5. 缺陷明细 ----------
    S.append('<h2 id="s5">5. Oracle 缺陷明细统计 (类型 / 源码位置 / 根因)</h2>')
    if not defect_records:
        S.append('<p>无缺陷明细记录。</p>')
    else:
        type_cnt = Counter(r['defect_type'] for r in defect_records)
        S.append(f'''<div>
<div class="kpi"><div class="v">{len(defect_records)}</div><div class="l">缺陷记录总数</div></div>
<div class="kpi"><div class="v">{type_cnt.get("crash",0)}</div><div class="l">Crash</div></div>
<div class="kpi"><div class="v">{type_cnt.get("nan",0)}</div><div class="l">NaN</div></div>
<div class="kpi"><div class="v">{type_cnt.get("inf",0)}</div><div class="l">Inf</div></div>
<div class="kpi"><div class="v">{type_cnt.get("inconsistency",0)}</div><div class="l">Inconsistency</div></div>
</div>''')
        # 5.1 配置×类型
        S.append('<h3>5.1 各 (层池, 消融配置) 的缺陷类型分布</h3>')
        agg = defaultdict(Counter)
        for r in defect_records:
            agg[r['__config__']][r['defect_type']] += 1
        rows = []
        for cfg in sorted(agg):
            c = agg[cfg]
            rows.append([cfg, c.get('crash', 0), c.get('nan', 0), c.get('inf', 0),
                         c.get('inconsistency', 0), sum(c.values())])
        S.append(table(['层池__配置', 'Crash', 'NaN', 'Inf', 'Inconsistency', '合计'], rows))
        # 5.2 定位层类型分布
        S.append('<h3>5.2 缺陷定位层的层类型分布 (哪类层最易造成缺陷)</h3>')
        lt_cnt = Counter()
        for r in defect_records:
            layer = r.get('located_layer')
            if layer:
                parts = layer.split('_', 1)
                lt_cnt[parts[1] if len(parts) > 1 else layer] += 1
        S.append(bar_chart([(lt, c, False) for lt, c in lt_cnt.most_common(15)],
                           title='定位层类型出现缺陷次数', unit=''))
        S.append(table(['层类型', '缺陷次数'], [[lt, c] for lt, c in lt_cnt.most_common(15)]))
        # 5.3 根因分类
        S.append('<h3>5.3 根因分类统计</h3>')
        cat = Counter()
        for r in defect_records:
            dt = r['defect_type']
            muts = r.get('model_mutations') or []
            layer = r.get('located_layer')
            layer_mutated = layer and any(m.get('layer') == layer for m in muts)
            if dt == 'crash':
                cat['crash: 突变引入的非法参数' if muts else 'crash: 结构/参数组合超出框架支持'] += 1
            elif dt in ('nan', 'inf'):
                cat[f'{dt}: 定位层被突变改动' if layer_mutated else f'{dt}: 上游传播/框架数值发散'] += 1
            else:
                cat['inconsistency: 定位层含突变放大差异' if layer_mutated else 'inconsistency: 跨框架算子实现差异'] += 1
        S.append(table(['根因类别', '数量', '占比'],
                       [[k, v, f'{v/len(defect_records)*100:.1f}%'] for k, v in cat.most_common()]))
        # 5.4 缺陷明细卡片
        S.append('<h3>5.4 典型缺陷明细 (含模型源码位置与根因分析)</h3>')
        S.append('<p class="note">每条含: 缺陷类型、后端、定位层、造成缺陷的模型源码片段 (causing snippet)、'
                 '完整模型源码 (含 PV/BV 突变标注) 与根因分析。完整记录见 data/exp2_defects_822/*.jsonl/.csv。</p>')
        shown = 0
        shown_per_type = Counter()
        for r in defect_records:
            # 每种类型最多展示 3 条, 总共不超过 10 条
            dt = r['defect_type']
            if shown >= 10:
                break
            if shown_per_type[dt] >= 3:
                continue
            shown_per_type[dt] += 1
            S.append('<div class="defect">')
            S.append(f'<div class="head">[{dt.upper()}] model_id={r.get("model_id")} · 后端 {r.get("backend")} '
                     f'· 阶段 {r.get("stage")} · 定位层 {r.get("located_layer") or "模型级"} '
                     f'· 配置 {r.get("__config__")}</div>')
            if r.get('detail'):
                S.append(f'<div class="note">判定依据: {esc(r["detail"])}</div>')
            if r.get('causing_snippet'):
                S.append(f'<b>造成缺陷的源码片段:</b><pre>{esc(r["causing_snippet"])}</pre>')
            if r.get('model_snippet'):
                S.append(f'<b>完整模型源码 (含突变标注):</b><pre>{esc(r["model_snippet"])}</pre>')
            S.append(f'<b>根因分析:</b> {esc(root_cause_of(r))}')
            S.append('</div>')
            shown += 1

    # ---------- 6. 多样性评估 ----------
    S.append('<h2 id="s6">6. 任务级四空间多样性评估 (跨全部模型累积)</h2>')
    r0 = exp1_map[('keras3.10', 'full')]
    div = r0.get('diversity', {})
    ss = div.get('space_sizes', {})
    S.append(f'''<div class="meta">keras3.10 / full / 200 模型: 层空间 |S_l|={ss.get('layer')} ·
边空间 |S_e|={ss.get('edge')} · 形状空间 |S_s|={ss.get('shape')} · 维度空间 |S_d|={ss.get('dim')}；
每模型平均新增元素 {div.get('avg_new_per_model', 0):.2f} 个 (随任务推进逐渐饱和，
符合"只统计此前全部模型未覆盖的新元素"的跨模型口径)。</div>''')
    rows = []
    for ab in ABLATIONS:
        r = exp1_map[('keras3.10', ab)]
        d = r.get('diversity', {}).get('space_sizes', {})
        name = 'full (基准)' if ab == 'full' else (SPACE_CN.get(ab) or OP_CN.get(ab))
        rows.append([name, d.get('layer', 0), d.get('edge', 0), d.get('shape', 0), d.get('dim', 0)])
    S.append(table(['配置', '|S_l| 层空间', '|S_e| 边空间', '|S_s| 形状空间', '|S_d| 维度空间'], rows))
    S.append('<p class="note">空间消融配置中被去掉的空间规模为 0 (不参与评估也不记录)，验证了消融开关的正确性。</p>')

    # ---------- 7. 结论 ----------
    S.append('<h2 id="s7">7. 结论</h2>')
    lic_full = [exp1_map[(fw, 'full')]['LIC'] for fw in FRAMEWORKS]
    lpc_full = [exp1_map[(fw, 'full')]['LPC'] for fw in FRAMEWORKS]
    lsc_full = [exp1_map[(fw, 'full')]['LSC'] for fw in FRAMEWORKS]
    concl = [f'''<p>1) 在 CASE_NUM=200 下，TD-DLDef (TS-RCS + 四空间多样性 + 六突变算子) 在 6 个框架层池上达到
LIC {min(lic_full):.2f}%–{max(lic_full):.2f}%、LPC {min(lpc_full):.2f}%–{max(lpc_full):.2f}%、
LSC {min(lsc_full):.2f}%–{max(lsc_full):.2f}% (按 COMET 原理 + 目标框架适配参数计算)。</p>''']
    if exp2 is not None:
        tot = sum(exp2['by_framework'][fw]['full']['total_defects'] for fw in FRAMEWORKS)
        concl.append(f'<p>2) 真实后端缺陷检测: full 配置 6 框架视角共记录 oracle 缺陷 <b>{tot}</b> 个 '
                     f'(本环境每配置 30 模型)；缺陷明细 (类型/定位层/源码片段/根因) 已全部落盘。</p>')
    concl.append('<p>3) 消融实验表明多样性空间与突变算子对覆盖率和缺陷检测均有独立贡献，'
                 '各成分相对 full 配置的指标下降量见第 3、4 节。</p>')
    concl.append('''<p class="note">局限: 本机沙箱框架版本 (tf 2.21 / keras 3.15 / torch 2.13) 高于论文目标版本
(tf 2.16.1 / pytorch 2.2.0 / keras 3.10)，少量 crash 缺陷可能由版本差异引起；4.0 节给出了目标环境
200 模型实测的参考缺陷计数。在论文目标环境中按 README 命令重跑可获得最终投稿数据:
python scripts/run_ablation_exp2.py --models 200 --workers 3 --seed 822 --timeout 300 --out data/ablation_exp2_c200.json</p>''')
    S.append(''.join(concl))
    S.append('<hr><p class="note">TD-DLDef (Improved) · 报告由 scripts/gen_final_report.py 基于本次执行数据自动生成 · 2026-08-21</p>')
    S.append('</body></html>')

    OUT.write_text(''.join(S), encoding='utf-8')
    print('report written:', OUT)


if __name__ == '__main__':
    main()
