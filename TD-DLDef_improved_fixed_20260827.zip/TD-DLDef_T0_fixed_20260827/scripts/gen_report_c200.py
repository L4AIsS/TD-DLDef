# -*- coding: utf-8 -*-
"""生成 CASE_NUM=200 消融实验详细报告 (HTML)

输入:
  data/ablation_exp1_c200.json   —— 覆盖率消融 (6 框架 × 11 配置 × 200 模型)
  data/ablation_exp2_c200_tf16.json —— 缺陷消融 (keras3.10 层池 × 11 配置 × 200 模型, TF2.16.1 视角)
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'data' / '实验报告_CASE_NUM200_消融.html'

EXP1 = json.loads((ROOT / 'data' / 'ablation_exp1_c200.json').read_text(encoding='utf-8'))
EXP2 = json.loads((ROOT / 'data' / 'ablation_exp2_c200_tf16.json').read_text(encoding='utf-8'))

FWS = ['tensorflow2.16.1', 'pytorch2.2.0', 'keras3.10',
       'tensorflow2.0.0', 'cntk2.7.0', 'theano1.0.4']
SPACE_ABS = ['no_layer', 'no_edge', 'no_shape', 'no_dim']
OP_ABS = ['no_pv', 'no_bv', 'no_it', 'no_nf', 'no_ws', 'no_wr']
AB_NAMES = {
    'full': 'full（全部启用）',
    'no_layer': '去掉层空间 S_l', 'no_edge': '去掉边空间 S_e',
    'no_shape': '去掉输入形状空间 S_s', 'no_dim': '去掉输入维度空间 S_d',
    'no_pv': '去掉值突变（PV）', 'no_bv': '去掉边界值突变（BV）',
    'no_it': '去掉输入类型突变（IT）', 'no_nf': '去掉噪声模糊（NF）',
    'no_ws': '去掉权重缩放（WS）', 'no_wr': '去掉权重旋转（WR）',
}
AB_SHORT = {'full': 'full', 'no_layer': 'no_layer', 'no_edge': 'no_edge',
            'no_shape': 'no_shape', 'no_dim': 'no_dim', 'no_pv': 'no_pv',
            'no_bv': 'no_bv', 'no_it': 'no_it', 'no_nf': 'no_nf',
            'no_ws': 'no_ws', 'no_wr': 'no_wr'}
FW_NAMES = {
    'tensorflow2.16.1': 'TensorFlow 2.16.1', 'pytorch2.2.0': 'PyTorch 2.2.0',
    'keras3.10': 'Keras 3.10', 'tensorflow2.0.0': 'TensorFlow 2.0.0',
    'cntk2.7.0': 'CNTK 2.7.0', 'theano1.0.4': 'Theano 1.0.4',
}
FW_GROUP = {'tensorflow2.16.1': '新框架', 'pytorch2.2.0': '新框架', 'keras3.10': '新框架',
            'tensorflow2.0.0': '旧框架', 'cntk2.7.0': '旧框架', 'theano1.0.4': '旧框架'}

fw_map1 = {}
for r in EXP1:
    fw_map1.setdefault(r['framework'], {})[r['ablation']] = r


def esc(s):
    return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def fmt(v, suf='%'):
    return f'{v:.2f}{suf}'


# ---------------- 缺陷消融 (EXP2) ----------------
def exp2_view(data, view):
    """从 by_framework 取某个框架视角的缺陷计数 (含 full 基准与各消融配置)."""
    return data['by_framework'][view]


def defect_table(view):
    d = exp2_view(EXP2, view)
    rows = []
    for ab in ['full'] + SPACE_ABS + OP_ABS:
        s = d[ab]
        rows.append((ab, s['crash'], s['nan'], s['inf'], s['inconsistency']))
    return rows


def contribution(view):
    """相对 full 的缺陷减少量 (full − 消融), 正数表示该空间/算子贡献了缺陷检测. crash/nan/inf/inconsistency 合计."""
    d = exp2_view(EXP2, view)
    full = d['full']
    out = []
    for ab in SPACE_ABS + OP_ABS:
        s = d[ab]
        c = {'crash': full['crash'] - s['crash'],
             'nan': full['nan'] - s['nan'],
             'inf': full['inf'] - s['inf'],
             'inconsistency': full['inconsistency'] - s['inconsistency'],
             'total': (full['crash'] + full['nan'] + full['inf'] + full['inconsistency'])
                      - (s['crash'] + s['nan'] + s['inf'] + s['inconsistency'])}
        out.append((ab, c))
    return out


# ---------------- HTML 组装 ----------------
def page():
    h = []
    a = h.append
    a('<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">')
    a('<title>CASE_NUM=200 消融实验详细结果</title>')
    a('<style>')
    a('body{font-family:"Microsoft YaHei",sans-serif;margin:24px auto;max-width:1180px;color:#222;line-height:1.6}')
    a('h1{color:#0b57a8;border-bottom:3px solid #0b57a8;padding-bottom:8px}')
    a('h2{color:#0b57a8;margin-top:36px;border-left:5px solid #0b57a8;padding-left:10px}')
    a('h3{color:#1a6fc4;margin-top:24px}')
    a('table{border-collapse:collapse;margin:12px 0;width:100%;font-size:13px}')
    a('th,td{border:1px solid #b9c6d6;padding:5px 8px;text-align:center}')
    a('th{background:#e8f0fb;color:#0b3d6e}')
    a('tr:nth-child(even) td{background:#f6f9fe}')
    a('.pos{color:#c0392b;font-weight:bold}')
    a('.neg{color:#1e8449}')
    a('.kpi{display:inline-block;background:#eef5ff;border:1px solid #b9d0ef;border-radius:8px;padding:10px 18px;margin:6px 10px 6px 0}')
    a('.kpi b{font-size:20px;color:#0b57a8;display:block}')
    a('.note{background:#fff8e6;border:1px solid #f0d48a;border-radius:6px;padding:10px 14px;margin:10px 0;font-size:13px}')
    a('td.hl{background:#fdeaea!important;font-weight:bold}')
    a('td.hl2{background:#eaf7ea!important;font-weight:bold}')
    a('</style></head><body>')
    a('<h1>CASE_NUM=200 消融实验详细结果</h1>')
    a('<p>生成时间：2026-08-13 · 实验 1：6 框架 × 11 消融配置 × 200 模型（覆盖率 LIC/LPC/LSC）· '
      '实验 2：keras3.10 层池 × 11 消融配置 × 200 模型（缺陷 crash/NaN/Inf/Inconsistency，TF2.16.1 视角重点）</p>')

    # ========== 实验1 ==========
    a('<h2>一、实验 1：多样性空间 / 突变算子对覆盖率（LIC/LPC/LSC）的独立贡献</h2>')

    # 1.1 TF2.16.1 详细表
    a('<h3>1.1 TensorFlow 2.16.1：各消融配置的 LIC / LPC / LSC</h3>')
    a('<table><tr><th>消融配置</th><th>说明</th><th>LIC (%)</th><th>LPC (%)</th><th>LSC (%)</th><th>成功模型</th></tr>')
    tf = fw_map1['tensorflow2.16.1']
    full_tf = tf['full']
    for ab in ['full'] + SPACE_ABS + OP_ABS:
        r = tf[ab]
        cls = ' class="hl"' if ab == 'no_it' else ''
        a(f'<tr><td>{AB_SHORT[ab]}</td><td style="text-align:left">{AB_NAMES[ab]}</td>'
          f'<td{cls}>{fmt(r["LIC"])}</td><td>{fmt(r["LPC"])}</td><td>{fmt(r["LSC"])}</td>'
          f'<td>{r["success_models"]}/200</td></tr>')
    a('</table>')

    # 1.2 TF2.16.1 贡献度
    a('<h3>1.2 TensorFlow 2.16.1：独立贡献度（Δ = full − 消融，百分点）</h3>')
    a('<table><tr><th>消融配置</th><th>ΔLIC</th><th>ΔLPC</th><th>ΔLSC</th></tr>')
    for ab in SPACE_ABS + OP_ABS:
        r = tf[ab]
        d_lic, d_lpc, d_lsc = full_tf['LIC']-r['LIC'], full_tf['LPC']-r['LPC'], full_tf['LSC']-r['LSC']
        def cls(v): return ' class="pos"' if v > 0.5 else (' class="neg"' if v < -0.5 else '')
        a(f'<tr><td style="text-align:left">{AB_SHORT[ab]}（{AB_NAMES[ab]}）</td>'
          f'<td{cls(d_lic)}>{d_lic:+.2f}</td><td{cls(d_lpc)}>{d_lpc:+.2f}</td><td{cls(d_lsc)}>{d_lsc:+.2f}</td></tr>')
    a('</table>')

    # 1.3 全框架空间消融
    a('<h3>1.3 全框架：多样性空间消融贡献度（ΔLIC / ΔLPC，百分点）</h3>')
    a('<table><tr><th>框架</th><th>分组</th>')
    for ab in SPACE_ABS:
        a(f'<th colspan="2">{AB_SHORT[ab]}<br>ΔLIC / ΔLPC</th>')
    a('</tr>')
    for fw in FWS:
        full = fw_map1[fw]['full']
        a(f'<tr><td><b>{FW_NAMES[fw]}</b></td><td>{FW_GROUP[fw]}</td>')
        for ab in SPACE_ABS:
            r = fw_map1[fw][ab]
            a(f'<td>{full["LIC"]-r["LIC"]:+.2f}</td><td>{full["LPC"]-r["LPC"]:+.2f}</td>')
        a('</tr>')
    a('</table>')

    # 1.4 全框架算子消融
    a('<h3>1.4 全框架：突变算子消融贡献度（ΔLIC / ΔLPC / ΔLSC，百分点）</h3>')
    a('<table><tr><th>框架</th><th>分组</th>')
    for ab in OP_ABS:
        a(f'<th colspan="3">{AB_SHORT[ab]}<br>ΔLIC/ΔLPC/ΔLSC</th>')
    a('</tr>')
    for fw in FWS:
        full = fw_map1[fw]['full']
        a(f'<tr><td><b>{FW_NAMES[fw]}</b></td><td>{FW_GROUP[fw]}</td>')
        for ab in OP_ABS:
            r = fw_map1[fw][ab]
            a(f'<td>{full["LIC"]-r["LIC"]:+.2f}</td><td>{full["LPC"]-r["LPC"]:+.2f}</td><td>{full["LSC"]-r["LSC"]:+.2f}</td>')
        a('</tr>')
    a('</table>')

    # 1.5 full 绝对值
    a('<h3>1.5 全框架：full 配置的覆盖率绝对值（200 模型）</h3>')
    a('<table><tr><th>框架</th><th>分组</th><th>LIC (%)</th><th>LPC (%)</th><th>LSC (%)</th><th>成功模型</th></tr>')
    for fw in FWS:
        r = fw_map1[fw]['full']
        a(f'<tr><td><b>{FW_NAMES[fw]}</b></td><td>{FW_GROUP[fw]}</td>'
          f'<td>{fmt(r["LIC"])}</td><td>{fmt(r["LPC"])}</td><td>{fmt(r["LSC"])}</td>'
          f'<td>{r["success_models"]}/200</td></tr>')
    a('</table>')

    # ========== 实验2 ==========
    a('<h2>二、实验 2：多样性空间 / 突变算子对缺陷检测（Crash/NaN/Inf/Inconsistency）的独立贡献</h2>')
    a('<p class="note">实验 2 使用 keras3.10 全量层池在 TensorFlow 与 PyTorch 后端上真实训练 200 个随机模型/配置，'
      '按 Oracle 统计缺陷。<b>重点视角 TensorFlow 2.16.1</b>（tensorflow 后端缺陷 + 跨后端不一致性）。'
      'Inconsistency 为跨后端对缺陷，新框架三视角共享同一计数。</p>')

    for view in ['tensorflow2.16.1', 'pytorch2.2.0', 'keras3.10']:
        name = FW_NAMES[view]
        a(f'<h3>2.{ ["1","2","3"][["tensorflow2.16.1","pytorch2.2.0","keras3.10"].index(view)] } {name}：各消融配置缺陷数量</h3>')
        a('<table><tr><th>消融配置</th><th>说明</th><th>Crash</th><th>NaN</th><th>Inf</th><th>Inconsistency</th><th>合计</th></tr>')
        for ab, cr, na, inf, ic in defect_table(view):
            tot = cr + na + inf + ic
            a(f'<tr><td>{AB_SHORT[ab]}</td><td style="text-align:left">{AB_NAMES[ab]}</td>'
              f'<td>{cr}</td><td>{na}</td><td>{inf}</td><td>{ic}</td><td><b>{tot}</b></td></tr>')
        a('</table>')

    # 贡献度
    a(f'<h3>2.4 缺陷检测独立贡献度（Δ = full − 消融，正数表示该空间/算子贡献了缺陷检测）</h3>')
    a('<table><tr><th>消融配置</th><th>说明</th>')
    for view in ['tensorflow2.16.1', 'pytorch2.2.0', 'keras3.10']:
        a(f'<th colspan="2">{FW_NAMES[view]}<br>Δ缺陷 / Δ合计</th>')
    a('</tr>')
    contribs = {view: {ab: c for ab, c in contribution(view)} for view in ['tensorflow2.16.1', 'pytorch2.2.0', 'keras3.10']}
    for ab in SPACE_ABS + OP_ABS:
        a(f'<tr><td>{AB_SHORT[ab]}</td><td style="text-align:left">{AB_NAMES[ab]}</td>')
        for view in ['tensorflow2.16.1', 'pytorch2.2.0', 'keras3.10']:
            c = contribs[view][ab]
            cls = ' class="hl"' if c['total'] > 0 else (' class="hl2"' if c['total'] < 0 else '')
            a(f'<td{c["crash"]:+d}/{c["nan"]:+d}/{c["inf"]:+d}/{c["inconsistency"]:+d}</td>'
              f'<td{cls}>{c["total"]:+d}</td>')
        a('</tr>')
    a('</table>')
    a('<p class="note">Δ缺陷 格式：ΔCrash/ΔNaN/ΔInf/ΔInconsistency。Δ合计 = 四类缺陷合计的变化量。</p>')

    # ========== 结论 ==========
    a('<h2>三、结论</h2>')
    a('<ul>')
    a('<li><b>IT 输入类型突变对 LIC 贡献最大</b>：去掉 IT 后 LIC 全框架下降 11.3~16.8 个百分点'
      '（TF2.16.1：93.46% → 77.25%，Δ=16.21pp），因为 LIC 的 type 覆盖分量直接由输入数据类型多样性驱动。</li>')
    a('<li><b>PV/BV 值突变对 LPC 与缺陷检测贡献明显</b>：去掉 BV 后 TF2.16.1 LPC 下降 2.03pp；'
      '值突变注入非常规参数（如 channels_first）是后端 Crash 的主要来源。</li>')
    a('<li><b>神经元突变（NF/WS/WR）贡献集中在缺陷检测</b>：权重缩放/噪声模糊改变数值稳定性，'
      '对 NaN/Inf 与跨后端不一致性的检出有贡献，对覆盖率影响较小。</li>')
    a('<li><b>空间消融影响温和</b>：层/边/形状/维度四空间独立贡献约 0.2~2.3pp，'
      '共同作用时保证覆盖率的稳定爬升；部分框架 Δ 为负源于随机采样方差。</li>')
    a('</ul>')

    a('</body></html>')
    return '\n'.join(h)


OUT.write_text(page(), encoding='utf-8')
print('report written:', OUT)
