# -*- coding: utf-8 -*-
"""
汇总所有符合 oracle 检查的缺陷记录

读取缺陷记录 (JSONL, 由 main.py / run_ablation_exp2.py 产生), 输出:
    1. 按 (框架, 缺陷类型) 的计数表;
    2. 按定位层的缺陷分布 (哪些层类型最容易触发缺陷);
    3. 每条缺陷的模型源码片段 (造成缺陷的层语句, 含突变标注) 明细表;
    4. 突变算子与缺陷的关联统计 (缺陷层中被 PV/BV 改动的比例)。

用法:
    python scripts/summarize_defects.py data/sinewave_defect_records.jsonl
    python scripts/summarize_defects.py data/exp2_defects_2024/   # 目录: 汇总全部 jsonl
"""
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
sys.path.insert(0, PROJECT_ROOT)


def load_records(path: Path):
    files = []
    if path.is_dir():
        files = sorted(path.glob('*.jsonl'))
    elif path.exists():
        files = [path]
    records = []
    for fp in files:
        with open(str(fp), encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    r = json.loads(line)
                    r['__source__'] = fp.name
                    records.append(r)
    return records


def main():
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else \
        Path(PROJECT_ROOT) / 'data' / 'sinewave_defect_records.jsonl'
    records = load_records(target)
    print(f'缺陷记录总数: {len(records)}  (来源: {target})')
    if not records:
        return

    # ---- 1) 框架 × 缺陷类型 计数 ----
    print('\n' + '=' * 90)
    print('表 1: 各框架符合 oracle 检查的缺陷数量')
    print('=' * 90)
    agg = defaultdict(Counter)
    for r in records:
        agg[r.get('framework') or r.get('backend', '?')][r['defect_type']] += 1
    print('%-22s%8s%8s%8s%16s%8s' % ('Framework', 'Crash', 'NaN', 'Inf', 'Inconsistency', 'Total'))
    for fw, c in agg.items():
        total = sum(c.values())
        print('%-22s%8d%8d%8d%16d%8d' % (fw, c.get('crash', 0), c.get('nan', 0),
                                        c.get('inf', 0), c.get('inconsistency', 0), total))

    # ---- 2) 定位层类型分布 ----
    print('\n' + '=' * 90)
    print('表 2: 缺陷定位层的层类型分布 (哪类层最容易造成缺陷)')
    print('=' * 90)
    type_cnt = Counter()
    for r in records:
        layer = r.get('located_layer')
        if layer:
            # 层名形如 03_conv2D -> 层类型 conv2D
            parts = layer.split('_', 1)
            type_cnt[parts[1] if len(parts) > 1 else layer] += 1
    for lt, cnt in type_cnt.most_common(20):
        print(f'  {lt:30s} {cnt}')

    # ---- 3) 缺陷明细 (造成缺陷的源码片段) ----
    print('\n' + '=' * 90)
    print('表 3: 缺陷明细 (模型 ID / 类型 / 框架 / 定位层 / 造成缺陷的模型源码片段)')
    print('=' * 90)
    for r in records[:50]:
        print(f"  model={r.get('model_id')} [{r.get('defect_type')}] {r.get('backend')} "
              f"stage={r.get('stage')} layer={r.get('located_layer')}")
        snippet = r.get('causing_snippet')
        if snippet:
            for line in snippet.split('\n'):
                print(f'      {line}')
        if r.get('detail'):
            print(f"      detail: {r['detail']}")
    if len(records) > 50:
        print(f'  ... 其余 {len(records) - 50} 条见 JSONL/CSV 文件')

    # ---- 4) 突变关联统计 ----
    print('\n' + '=' * 90)
    print('表 4: 缺陷与突变算子的关联 (缺陷模型中被 PV/BV 改动过的层占比)')
    print('=' * 90)
    op_cnt = Counter()
    located_mut = Counter()
    for r in records:
        muts = r.get('model_mutations') or []
        ops = set()
        for m in muts:
            for entry in m.get('mutations', []):
                for op in entry.keys():
                    if op in ('pv', 'bv'):
                        ops.add(op)
        for op in ops:
            op_cnt[op] += 1
        # 定位层本身是否被突变改动
        layer = r.get('located_layer')
        if layer and any(m.get('layer') == layer for m in muts):
            located_mut['located_layer_mutated'] += 1
    print(f'  缺陷模型中含 PV 改动的: {op_cnt.get("pv", 0)} / {len(records)}')
    print(f'  缺陷模型中含 BV 改动的: {op_cnt.get("bv", 0)} / {len(records)}')
    print(f'  缺陷定位层本身被突变改动过的: {located_mut["located_layer_mutated"]} / {len(records)}')


if __name__ == '__main__':
    main()
