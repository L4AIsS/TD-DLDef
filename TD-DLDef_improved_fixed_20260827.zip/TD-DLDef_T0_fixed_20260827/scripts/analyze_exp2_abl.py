# -*- coding: utf-8 -*-
"""
分析消融实验 2 结果: 每个多样性空间 / 突变算子对缺陷检测与覆盖率的贡献

输出:
    * 6 框架 × 11 消融配置的 Crash / NaN / Inf / Inconsistency 计数表 (CSV + 打印);
    * 6 框架 × 11 消融配置的 LIC / LPC / LSC 表 (CSV + 打印);
    * 每个消融相对 full 的缺陷减少量与覆盖率下降量 (贡献度);
    * 每框架贡献度最大的空间与算子。
"""
import json
import sys
from pathlib import Path

PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
sys.path.insert(0, PROJECT_ROOT)

FRAMEWORKS = ['tensorflow2.16.1', 'pytorch2.2.0', 'keras3.10',
              'tensorflow2.0.0', 'cntk2.7.0', 'theano1.0.4']
ABLATION_ORDER = ['full', 'no_layer', 'no_edge', 'no_shape', 'no_dim',
                  'no_pv', 'no_bv', 'no_it', 'no_nf', 'no_ws', 'no_wr']
DEFECT_KEYS = ['crash', 'nan', 'inf', 'inconsistency', 'total_defects']


def main():
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else PROJECT_ROOT / 'data' / 'ablation_exp2_final.json'
    doc = json.load(open(path, encoding='utf-8'))
    by_fw = doc['by_framework']
    contrib = doc.get('contribution', {})

    # ---- 1) 每个框架 × 配置的缺陷计数 ----
    print('=' * 100)
    print('表 1: 各框架 × 消融配置的缺陷计数 (Crash / NaN / Inf / Inconsistency / 合计)')
    print('=' * 100)
    csv_lines = ['framework,ablation,crash,nan,inf,inconsistency,total_defects,ok_models,models']
    for fw in FRAMEWORKS:
        print(f'\n--- {fw} ---')
        for ab in ABLATION_ORDER:
            r = by_fw[fw][ab]
            line = f"{fw},{ab},{r['crash']},{r['nan']},{r['inf']},{r['inconsistency']},{r['total_defects']},{r['ok_models']},{r['models']}"
            csv_lines.append(line)
            print(f"  {ab:10s} crash={r['crash']:3d} nan={r['nan']:3d} inf={r['inf']:3d} "
                  f"incons={r['inconsistency']:3d} total={r['total_defects']:3d} (ok={r['ok_models']}/{r['models']})")
    (Path(path).parent / 'ablation_exp2_defects.csv').write_text(
        '\n'.join(csv_lines), encoding='utf-8')

    # ---- 1b) 每个框架 × 配置的 LIC/LPC/LSC ----
    if 'LIC' in by_fw[FRAMEWORKS[0]]['full']:
        print('\n' + '=' * 100)
        print('表 1b: 各框架 × 消融配置的覆盖率 (LIC / LPC / LSC, %)')
        print('=' * 100)
        cov_lines = ['framework,ablation,LIC,LPC,LSC']
        for fw in FRAMEWORKS:
            print(f'\n--- {fw} ---')
            for ab in ABLATION_ORDER:
                r = by_fw[fw][ab]
                cov_lines.append(f"{fw},{ab},{r['LIC']},{r['LPC']},{r['LSC']}")
                print(f"  {ab:10s} LIC={r['LIC']:6.2f} LPC={r['LPC']:6.2f} LSC={r['LSC']:6.2f}")
        (Path(path).parent / 'ablation_exp2_coverage.csv').write_text(
            '\n'.join(cov_lines), encoding='utf-8')

    # ---- 2) 贡献度 (相对 full 的减少) ----
    print('\n' + '=' * 100)
    print('表 2: 各消融配置相对 full 的缺陷减少量 (Δ = full − 消融, 正值=该成分对缺陷检测有正贡献)')
    print('=' * 100)
    for fw in FRAMEWORKS:
        print(f'\n--- {fw} ---')
        for ab in ABLATION_ORDER[1:]:
            c = contrib[fw][ab]
            line = (f"  {ab:10s} Δcrash={c['crash_delta']:+3d} Δnan={c['nan_delta']:+3d} "
                    f"Δinf={c['inf_delta']:+3d} Δincons={c['inconsistency_delta']:+3d} "
                    f"Δtotal={c['total_delta']:+3d}")
            if 'LIC_delta' in c:
                line += (f" | ΔLIC={c['LIC_delta']:+6.2f} ΔLPC={c['LPC_delta']:+6.2f} "
                         f"ΔLSC={c['LSC_delta']:+6.2f}")
            print(line)

    # ---- 3) 每框架贡献度排名 ----
    print('\n' + '=' * 100)
    print('表 3: 每框架对缺陷检测贡献最大的空间与算子 (按 Δtotal)')
    print('=' * 100)
    for fw in FRAMEWORKS:
        items = [(ab, contrib[fw][ab]['total_delta']) for ab in ABLATION_ORDER[1:]]
        items.sort(key=lambda x: -x[1])
        top = ', '.join(f'{ab}(Δ{delta:+d})' for ab, delta in items[:3])
        full = by_fw[fw]['full']
        print(f'  {fw:20s} full_total={full["total_defects"]:3d} | 贡献TOP3: {top}')

    # ---- 4) 汇总结论 ----
    print('\n' + '=' * 100)
    print('汇总')
    print('=' * 100)
    for fw in FRAMEWORKS:
        f = by_fw[fw]['full']
        line = f"  {fw:20s} full: crash={f['crash']} nan={f['nan']} inf={f['inf']} incons={f['inconsistency']}"
        if 'LIC' in f:
            line += f" | LIC={f['LIC']}% LPC={f['LPC']}% LSC={f['LSC']}%"
        print(line)
    total = sum(by_fw[fw]['full']['total_defects'] for fw in FRAMEWORKS)
    print(f'\n  6 框架 full 配置缺陷合计: {total}')
    # 跨框架平均贡献
    for ab in ABLATION_ORDER[1:]:
        avg = sum(contrib[fw][ab]['total_delta'] for fw in FRAMEWORKS) / len(FRAMEWORKS)
        print(f'  {ab:10s} 平均 Δtotal = {avg:+.2f} / 框架')


if __name__ == '__main__':
    main()
