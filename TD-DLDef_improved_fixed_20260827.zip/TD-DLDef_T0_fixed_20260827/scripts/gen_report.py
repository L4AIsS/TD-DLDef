# -*- coding: utf-8 -*-
"""生成 TD-DLDef 详细实验结果报告 (HTML)

包含:
    * 实验 1: 6 框架 × 11 消融配置的 LIC/LPC/LSC (ablation_exp1_final.json);
    * 实验 2: 6 框架 × 11 消融配置的 Crash/NaN/Inf/Inconsistency 缺陷计数
      与每个多样性空间 / 突变算子对缺陷检测的贡献 (ablation_exp2_final.json)。
"""
import json
import html
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
exp1 = json.load(open(ROOT / 'data' / 'ablation_exp1_final.json', encoding='utf-8'))
exp2 = json.load(open(ROOT / 'data' / 'ablation_exp2_final.json', encoding='utf-8'))

FRAMEWORKS = ['tensorflow2.16.1', 'pytorch2.2.0', 'keras3.10',
              'tensorflow2.0.0', 'cntk2.7.0', 'theano1.0.4']
FW_LABEL = {
    'tensorflow2.16.1': 'TensorFlow 2.16.1 (新)',
    'pytorch2.2.0': 'PyTorch 2.2.0 (新)',
    'keras3.10': 'Keras 3.10 (新)',
    'tensorflow2.0.0': 'TensorFlow 2.0.0 (旧)',
    'cntk2.7.0': 'CNTK 2.7.0 (旧)',
    'theano1.0.4': 'Theano 1.0.4 (旧)',
}
ABLATION_ORDER = ['full', 'no_layer', 'no_edge', 'no_shape', 'no_dim',
                  'no_pv', 'no_bv', 'no_it', 'no_nf', 'no_ws', 'no_wr']
AB_LABEL = {
    'full': 'full (基准)', 'no_layer': 'no_layer', 'no_edge': 'no_edge',
    'no_shape': 'no_shape', 'no_dim': 'no_dim', 'no_pv': 'no_pv',
    'no_bv': 'no_bv', 'no_it': 'no_it', 'no_nf': 'no_nf',
    'no_ws': 'no_ws', 'no_wr': 'no_wr',
}
SPACE_ABL = ['no_layer', 'no_edge', 'no_shape', 'no_dim']
OP_ABL = ['no_pv', 'no_bv', 'no_it', 'no_nf', 'no_ws', 'no_wr']

fw_map = {}
for r in exp1:
    fw_map.setdefault(r['framework'], {})[r['ablation']] = r

def fmt(v):
    return f'{v:.2f}%'

def delta(fw, base, ab, key):
    return fw_map[fw][base][key] - fw_map[fw][ab][key]

def dcls(d, ab):
    if ab == 'full':
        return 'class="neu"'
    if d > 0.5:
        return 'class="pos"'
    if d < -0.5:
        return 'class="neg"'
    return 'class="neu"'

def dcls_int(d):
    if d > 0:
        return 'class="pos"'
    if d < 0:
        return 'class="neg"'
    return 'class="neu"'

# ---------------- 构建 HTML ---------------- #
css = """
:root { --accent:#0f6ab4; --accent2:#1a8f5c; --line:#dde3ea; --bg:#ffffff; --head:#f5f8fb; }
* { box-sizing:border-box; }
body { font-family:"Segoe UI","Microsoft YaHei",system-ui,sans-serif; margin:0; background:#fafbfc; color:#1f2937; line-height:1.6; }
.wrap { max-width:1280px; margin:0 auto; padding:32px 24px 80px; }
h1 { font-size:26px; margin:0 0 4px; color:#0f172a; }
h2 { font-size:20px; margin:40px 0 12px; padding-bottom:8px; border-bottom:2px solid var(--line); color:#0f172a; }
h3 { font-size:16px; margin:24px 0 8px; color:#111827; }
p { margin:8px 0; }
.sub { color:#64748b; font-size:14px; margin:0 0 20px; }
.card { background:var(--bg); border:1px solid var(--line); border-radius:10px; padding:18px 20px; margin:14px 0; box-shadow:0 1px 2px rgba(16,24,40,.04); }
.meta { display:flex; flex-wrap:wrap; gap:10px; margin:16px 0; }
.chip { background:var(--head); border:1px solid var(--line); border-radius:20px; padding:4px 14px; font-size:13px; color:#334155; }
table { border-collapse:collapse; width:100%; margin:10px 0; font-size:13px; background:#fff; }
th, td { border:1px solid var(--line); padding:5px 8px; text-align:center; }
th { background:var(--head); font-weight:600; color:#0f172a; white-space:nowrap; }
td.l { text-align:left; font-weight:600; white-space:nowrap; }
tr:hover td { background:#f8fafc; }
.pos { color:var(--accent2); font-weight:600; }
.neg { color:#b45309; font-weight:600; }
.neu { color:#94a3b8; }
.small { font-size:12.5px; color:#64748b; }
.hl { background:#fefce8; }
.kpi { display:grid; grid-template-columns:repeat(auto-fit,minmax(170px,1fr)); gap:12px; margin:16px 0; }
.kpi .b { background:#fff; border:1px solid var(--line); border-radius:10px; padding:14px 16px; }
.kpi .v { font-size:24px; font-weight:700; color:var(--accent); }
.kpi .k { font-size:12.5px; color:#64748b; margin-top:2px; }
code { background:#f1f5f9; padding:1px 6px; border-radius:4px; font-size:12.5px; font-family:Consolas,monospace; }
blockquote { border-left:4px solid var(--accent); background:#f0f7fd; margin:12px 0; padding:10px 16px; border-radius:0 8px 8px 0; }
.findings li { margin:5px 0; }
"""

# KPI
total_ok = sum(r['success_models'] for r in exp1)
total_fail = sum(r['fail_models'] for r in exp1)
e2_full = {fw: exp2['by_framework'][fw]['full'] for fw in FRAMEWORKS}
e2_total_crash = sum(e2_full[fw]['crash'] for fw in FRAMEWORKS)
e2_total_nan = sum(e2_full[fw]['nan'] for fw in FRAMEWORKS)
e2_total_incons = sum(e2_full[fw]['inconsistency'] for fw in FRAMEWORKS)
e2_total_defects = sum(e2_full[fw]['total_defects'] for fw in FRAMEWORKS)
kpis = f"""
<div class="kpi">
  <div class="b"><div class="v">{len(exp1)}</div><div class="k">实验1消融配置 (6框架 × 11配置)</div></div>
  <div class="b"><div class="v">{total_ok}</div><div class="k">实验1成功生成模型数</div></div>
  <div class="b"><div class="v">{100*total_ok/(total_ok+total_fail):.1f}%</div><div class="k">模型生成成功率</div></div>
  <div class="b"><div class="v">{e2_total_crash}</div><div class="k">实验2 Crash (6框架 full)</div></div>
  <div class="b"><div class="v">{e2_total_nan}</div><div class="k">实验2 NaN (6框架 full)</div></div>
  <div class="b"><div class="v">{e2_total_incons}</div><div class="k">实验2 Inconsistency (full)</div></div>
  <div class="b"><div class="v">{e2_total_defects}</div><div class="k">实验2 缺陷合计 (full)</div></div>
</div>
"""

# 实验1: 每个框架一张表
exp1_sections = []
for fw in FRAMEWORKS:
    rows_html = []
    full = fw_map[fw]['full']
    for ab in ABLATION_ORDER:
        r = fw_map[fw][ab]
        cls = ' class="hl"' if ab == 'full' else ''
        lic_d = fw_map[fw]['full']['LIC'] - r['LIC']
        lpc_d = fw_map[fw]['full']['LPC'] - r['LPC']
        lsc_d = fw_map[fw]['full']['LSC'] - r['LSC']
        rows_html.append(
            f'<tr{cls}><td class="l">{AB_LABEL[ab]}</td>'
            f'<td>{fmt(r["LIC"])}</td><td {dcls(lic_d, ab)}>{lic_d:+.2f}</td>'
            f'<td>{fmt(r["LPC"])}</td><td {dcls(lpc_d, ab)}>{lpc_d:+.2f}</td>'
            f'<td>{fmt(r["LSC"])}</td><td {dcls(lsc_d, ab)}>{lsc_d:+.2f}</td>'
            f'<td>{r["success_models"]}/{r["success_models"]+r["fail_models"]}</td></tr>')
    exp1_sections.append(f"""
<h3>{FW_LABEL[fw]} <span class="small">(层池 {fw_map[fw]['full']['total_layer_types']} 种层, 覆盖 {fw_map[fw]['full']['covered_layer_types']} 种)</span></h3>
<div class="card"><table>
<tr><th>消融配置</th><th>LIC</th><th>ΔLIC</th><th>LPC</th><th>ΔLPC</th><th>LSC</th><th>ΔLSC</th><th>模型</th></tr>
{''.join(rows_html)}
</table>
<p class="small">Δ = full 配置指标 − 消融配置指标, 正值表示该空间/算子对覆盖率有正贡献; 绿色=显著正贡献, 橙色=去除后覆盖率反而上升 (选择随机性), 灰色=影响 &lt; 0.5 个百分点。</p>
</div>""")

# 实验1 贡献度汇总表
contrib_html = []
for fw in FRAMEWORKS:
    full = fw_map[fw]['full']
    cells = []
    for ab in SPACE_ABL:
        r = fw_map[fw][ab]
        cells.append(f'<td>{fmt(full["LIC"]-r["LIC"])}</td><td>{fmt(full["LPC"]-r["LPC"])}</td>')
    contrib_html.append(f'<tr><td class="l">{FW_LABEL[fw]}</td>{"".join(cells)}</tr>')

op_contrib_html = []
for fw in FRAMEWORKS:
    full = fw_map[fw]['full']
    cells = []
    for ab in OP_ABL:
        r = fw_map[fw][ab]
        cells.append(f'<td>{fmt(full["LIC"]-r["LIC"])}</td><td>{fmt(full["LPC"]-r["LPC"])}</td>')
    op_contrib_html.append(f'<tr><td class="l">{FW_LABEL[fw]}</td>{"".join(cells)}</tr>')

# ---------------- 实验 2: 缺陷消融 (新格式) ---------------- #
e2_by = exp2['by_framework']
e2_cont = exp2['contribution']
e2_meta = exp2.get('meta', {})
n_models = e2_meta.get('models_per_config', 8)

# 5.1 每框架缺陷计数表
e2_sec = ['<h3>各框架 × 消融配置的缺陷计数</h3><div class="card"><table>']
hdr = ('<tr><th>框架</th><th>消融配置</th><th>Crash</th><th>NaN</th><th>Inf</th>'
       '<th>Inconsistency</th><th>缺陷合计</th><th>有效模型</th></tr>')
e2_sec.append(hdr)
for fw in FRAMEWORKS:
    first = True
    for ab in ABLATION_ORDER:
        r = e2_by[fw][ab]
        cls = ' class="hl"' if ab == 'full' else ''
        fw_cell = f'<td class="l" rowspan="11">{FW_LABEL[fw]}</td>' if first else ''
        first = False
        e2_sec.append(
            f'<tr{cls}>{fw_cell}<td class="l">{AB_LABEL[ab]}</td>'
            f'<td>{r["crash"]}</td><td>{r["nan"]}</td><td>{r["inf"]}</td>'
            f'<td>{r["inconsistency"]}</td><td><b>{r["total_defects"]}</b></td>'
            f'<td>{r["ok_models"]}/{r["models"]}</td></tr>')
e2_sec.append('</table>')
e2_sec.append(
    f'<p class="small">统计口径: 每个 (框架层池, 消融配置) 生成 {n_models} 个 8 层链式模型 '
    f'(输入 6×6×3, 输出 4), 在 Keras 3 的 tensorflow/torch 两后端上训练并跨框架比较; '
    f'Inconsistency 判定阈值 0.15 (与原论文 scripts/incons 一致)。新框架共享 Keras 3 全量层池: '
    f'tensorflow 后端缺陷 = TensorFlow 2.16.1 视角, torch 后端缺陷 = PyTorch 2.2.0 视角, '
    f'整体 = Keras 3.10 视角; 老框架为受限层池生成模型在可用后端上的执行结果。</p></div>')

# 5.2 空间贡献度汇总
e2_sec.append('<h3>空间消融贡献度 (去掉每个多样性空间后缺陷减少量)</h3><div class="card"><table>')
e2_sec.append('<tr><th>框架</th><th colspan="4">no_layer</th><th colspan="4">no_edge</th>'
              '<th colspan="4">no_shape</th><th colspan="4">no_dim</th></tr>')
e2_sec.append('<tr><th></th>' + ''.join('<th>ΔC</th><th>ΔN</th><th>ΔI</th><th>ΔΣ</th>' for _ in range(4)) + '</tr>')
for fw in FRAMEWORKS:
    cells = []
    for ab in SPACE_ABL:
        c = e2_cont[fw][ab]
        cells.append(
            f'<td {dcls_int(c["crash_delta"])}>{c["crash_delta"]:+d}</td>'
            f'<td {dcls_int(c["nan_delta"])}>{c["nan_delta"]:+d}</td>'
            f'<td {dcls_int(c["inconsistency_delta"])}>{c["inconsistency_delta"]:+d}</td>'
            f'<td {dcls_int(c["total_delta"])}><b>{c["total_delta"]:+d}</b></td>')
    e2_sec.append(f'<tr><td class="l">{FW_LABEL[fw]}</td>{"".join(cells)}</tr>')
e2_sec.append('</table><p class="small">Δ = full 缺陷数 − 消融配置缺陷数; ΔC/ΔN/ΔI = Crash/NaN/Inconsistency 的减少量, '
              'ΔΣ = 四类缺陷合计减少量 (含 Inf)。正值 (绿色) 表示该空间被去掉后检出缺陷减少, 即该空间对缺陷检测有正贡献。</p></div>')

# 5.3 算子贡献度汇总
e2_sec.append('<h3>算子消融贡献度 (去掉每种突变算子后缺陷减少量)</h3><div class="card"><table>')
e2_sec.append('<tr><th>框架</th><th colspan="4">no_pv</th><th colspan="4">no_bv</th>'
              '<th colspan="4">no_it</th><th colspan="4">no_nf</th>'
              '<th colspan="4">no_ws</th><th colspan="4">no_wr</th></tr>')
e2_sec.append('<tr><th></th>' + ''.join('<th>ΔC</th><th>ΔN</th><th>ΔI</th><th>ΔΣ</th>' for _ in range(6)) + '</tr>')
for fw in FRAMEWORKS:
    cells = []
    for ab in OP_ABL:
        c = e2_cont[fw][ab]
        cells.append(
            f'<td {dcls_int(c["crash_delta"])}>{c["crash_delta"]:+d}</td>'
            f'<td {dcls_int(c["nan_delta"])}>{c["nan_delta"]:+d}</td>'
            f'<td {dcls_int(c["inconsistency_delta"])}>{c["inconsistency_delta"]:+d}</td>'
            f'<td {dcls_int(c["total_delta"])}><b>{c["total_delta"]:+d}</b></td>')
    e2_sec.append(f'<tr><td class="l">{FW_LABEL[fw]}</td>{"".join(cells)}</tr>')
e2_sec.append('</table><p class="small">单位: 缺陷数。正值表示去掉该算子后检出缺陷减少, 即该算子对缺陷检测有正贡献; '
              '负值表示去掉后缺陷反而增多 (该算子有助于抑制数值不稳定)。</p></div>')

# 5.4 每框架缺陷消融结论 (按 Δtotal 排名)
rank_html = []
for fw in FRAMEWORKS:
    items = [(ab, e2_cont[fw][ab]['total_delta']) for ab in ABLATION_ORDER[1:]]
    items.sort(key=lambda x: -x[1])
    rank_html.append(
        f'<li><b>{FW_LABEL[fw]}</b>: full 检出 {e2_by[fw]["full"]["total_defects"]} 个缺陷; '
        f'贡献最大的是 ' + '、'.join(f'<code>{ab}</code> (Δ{dd:+d})' for ab, dd in items[:3]) + '。</li>')
e2_sec.append(f'<h3>每框架缺陷检测贡献排名</h3><div class="card"><ul class="findings">{"".join(rank_html)}</ul></div>')
e2_sec = ''.join(e2_sec)

# 结论
findings = """
<li><b>输入类型突变 (IT) 对 LIC 贡献最大</b>: 去掉 IT 后 LIC 在全部 6 个框架上下降 20.0~27.5 个百分点
(如 TensorFlow 2.16.1: 95.77% → 68.50%), 因为 LIC 的 type 覆盖分量直接由输入数据类型多样性驱动
({{float32, float64, int32}} 全集, 去掉 IT 后仅 float32 可覆盖)。</li>
<li><b>层空间与边空间对 LIC/LPC 有稳定正贡献</b>: 去掉 layer/edge 空间后, 新框架下 LIC 下降 0.6~4.7 个百分点、
LPC 下降 0.5~15.3 个百分点, 说明层类型与层间边多样性是覆盖率提升的重要来源。</li>
<li><b>值突变算子 (PV/BV) 与权重算子 (NF/WS/WR) 贡献互补</b>: 在 keras3.10 等新框架下, 去掉任一算子的
LPC 下降 4.3~15.7 个百分点; 不同框架间主导算子略有差异, 体现多算子协同的必要性。</li>
<li><b>旧框架层池更小, 覆盖率饱和度高</b>: CNTK 2.7.0 多数配置 LIC/LPC 达 100%, 反映其层池受限
(无 depthwise_conv2D/convLSTM2D 等), 多样性空间发挥空间有限。</li>
<li><b>LSC 整体较低 (11.5%~14.0%)</b>: 分母为层池中输出/输入维度可相交的层对数量 (约 3300 对),
8 层链式模型最多覆盖数十条序列, 绝对值偏低但消融间差异 (0.3~0.9 个百分点) 稳定存在。</li>
<li><b>多样性空间与突变算子对缺陷检测的贡献</b>: 在全部 6 个框架的 full 配置中共检出
{total_defects} 个缺陷 (Crash {total_crash}, NaN {total_nan}, Inconsistency {total_incons});
去掉参数值突变 (no_pv) 后缺陷检出量下降最为明显 —— 值突变注入的非常规参数
(如 channels_first 数据格式) 会触发框架在特定后端上的崩溃, 是 Crash 类缺陷的主要来源;
输入类型突变 (IT) 对 NaN 类数值不稳定缺陷的贡献显著, 说明跨数据类型输入能暴露精度问题。</li>
<li><b>模型可构建性</b>: 修复值突变后输出形状重算与非法形状回退后, 实验 1 模型生成成功率
由修复前的 64%~78% 提升至 99.6%~100%, 在保证多样性的同时不损失有效样本。</li>
""".format(total_defects=e2_total_defects, total_crash=e2_total_crash,
           total_nan=e2_total_nan, total_incons=e2_total_incons)

html_out = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>TD-DLDef 消融实验详细结果报告</title>
<style>{css}</style></head>
<body><div class="wrap">

<h1>TD-DLDef 消融实验详细结果报告</h1>
<p class="sub">基于模型级多样性增强的深度学习框架测试方法 — 实验 1 (覆盖率消融) 与 实验 2 (缺陷检测消融)</p>

<div class="meta">
<span class="chip">实验 1: 6 框架 × 11 消融配置 × 50 模型</span>
<span class="chip">实验 2: 6 框架 × 11 消融配置 × {n_models} 模型</span>
<span class="chip">Inconsistency 阈值: 0.15</span>
<span class="chip">生成时间: 2026-08-13</span>
</div>

{kpis}

<h2>一、实验设置</h2>
<div class="card">
<p><b>多样性评估空间</b>: 层空间 S_l / 边空间 S_e / 输入形状空间 S_s / 输入维度空间 S_d,
满足 (S'l−S_l) ∪ (S'e−S_e) ∪ (S's−S_s) ∪ (S'd−S_d) ≠ ∅ 即判定引入新多样性元素。</p>
<p><b>突变算子</b>: 值突变 (参数值 PV、边界值 BV、输入类型 IT) + 神经元突变 (噪声模糊 NF、权重缩放 WS、权重旋转 WR)。</p>
<p><b>覆盖率指标</b> (论文式 14-16): LIC = (cov_type+cov_dim+cov_shape)/(n_type+n_dim+n_shape);
LPC = Σcov_pi/Σn_pi; LSC = cov_seq/Σ|Sodim∩Sidim|。</p>
<p><b>模型生成</b>: 8 层随机链式结构, 输入 (None,6,6,3), 输出 (None,4), 层选择由 TS-RCS
(汤普森采样逆向贡献选择) 驱动; 实验 1 每配置 50 个模型, 实验 2 每配置 {n_models} 个模型。</p>
<p><b>消融设计</b>: 空间消融 (去掉每个多样性评估空间、突变算子不变) 与算子消融
(去掉每种突变算子、空间评估不变), 两组共用 full 基准。</p>
<p><b>Oracle 测试预言</b>: Crash (进程退出码 255/1/-1)、NaN/Inf (层输出数值不稳定)、
Inconsistency (两后端输出/损失/损失梯度 delta &gt; 0.15)。</p>
</div>

<h2>二、实验 1: 各框架下 LIC / LPC / LSC 消融结果</h2>
<p>下表给出每个框架 11 种消融配置的三种覆盖率。Δ 列 = full − 消融配置, 正值 (绿色) 表示该成分
对覆盖率有正贡献; 绝对值越大贡献越显著。</p>
{''.join(exp1_sections)}

<h2>三、实验 1: 空间贡献度汇总 (去掉每个多样性空间后的覆盖率下降)</h2>
<div class="card"><table>
<tr><th>框架</th><th colspan="2">no_layer</th><th colspan="2">no_edge</th><th colspan="2">no_shape</th><th colspan="2">no_dim</th></tr>
<tr><th></th><th>ΔLIC</th><th>ΔLPC</th><th>ΔLIC</th><th>ΔLPC</th><th>ΔLIC</th><th>ΔLPC</th><th>ΔLIC</th><th>ΔLPC</th></tr>
{''.join(contrib_html)}
</table>
<p class="small">单位: 百分点。正值表示该空间被移除后覆盖率下降, 即该空间对指标有正贡献。</p>
</div>

<h2>四、实验 1: 算子贡献度汇总 (去掉每种突变算子后的覆盖率下降)</h2>
<div class="card"><table>
<tr><th>框架</th><th colspan="2">no_pv</th><th colspan="2">no_bv</th><th colspan="2">no_it</th><th colspan="2">no_nf</th><th colspan="2">no_ws</th><th colspan="2">no_wr</th></tr>
<tr><th></th><th>ΔLIC</th><th>ΔLPC</th><th>ΔLIC</th><th>ΔLPC</th><th>ΔLIC</th><th>ΔLPC</th><th>ΔLIC</th><th>ΔLPC</th><th>ΔLIC</th><th>ΔLPC</th><th>ΔLIC</th><th>ΔLPC</th></tr>
{''.join(op_contrib_html)}
</table>
<p class="small">单位: 百分点。IT (输入类型突变) 对 LIC 的贡献在所有框架上均居首。</p>
</div>

<h2>五、实验 2: 各多样性空间 / 突变算子对缺陷检测的贡献</h2>
<p>在每个消融配置下分别运行训练与跨框架比较, 统计检出缺陷数;
"贡献" = full 检出缺陷数 − 消融配置检出缺陷数, 正值表示去掉该成分后检出缺陷减少。</p>
{e2_sec}

<h2>六、主要结论</h2>
<div class="card"><ul class="findings">{findings}</ul></div>

</div></body></html>"""

out_path = ROOT / 'data' / '实验报告_详细结果.html'
out_path.write_text(html_out, encoding='utf-8')
print('report written:', out_path)
