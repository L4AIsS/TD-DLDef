import json
import tempfile
import unittest
from unittest import mock
from pathlib import Path

import numpy as np

from utils.Thompson import ThompsonSampling
from utils.mutation import MutationConfig, NeuronMutator, ValueMutator
from utils.selection import Selector
from utils.coverage import INPUT_DTYPE_UNIVERSE
from src.cases_generation.generate_one import apply_neuron_mutation
from src.cases_generation.layer_info_generator import LayerInfoGenerator
from src.cases_generation.variable_generator import VariableGenerator


class FakeLayer(object):
    def __init__(self, name, weights):
        self.name = name
        self._weights = [np.array(w, copy=True) for w in weights]

    def get_weights(self):
        return [w.copy() for w in self._weights]

    def set_weights(self, weights):
        expected = [w.shape for w in self._weights]
        actual = [w.shape for w in weights]
        if actual != expected:
            raise ValueError('shape mismatch')
        self._weights = [np.array(w, copy=True) for w in weights]


class FakeModel(object):
    def __init__(self, layers):
        self.layers = layers


class T0BlockerTests(unittest.TestCase):
    def test_ts_prior_and_updates(self):
        ts = ThompsonSampling(['dense', 'conv2D'], alpha=1, beta=1)
        self.assertEqual(ts.get_params('dense'), (1.0, 1.0))
        sampled_params = []
        def capture_beta(a, b):
            sampled_params.append((a, b))
            return 0.5
        with mock.patch('utils.Thompson.np.random.beta', side_effect=capture_beta):
            ts.choose_arm(['dense', 'conv2D'])
        self.assertEqual(sampled_params, [(1.0, 1.0), (1.0, 1.0)])
        ts.update('dense', 1)
        self.assertEqual(ts.get_params('dense'), (2.0, 1.0))

        ts = ThompsonSampling(['dense'], alpha=1, beta=1)
        ts.update('dense', 0)
        self.assertEqual(ts.get_params('dense'), (1.0, 2.0))

    def test_immediate_div_admission_and_posterior(self):
        selector = Selector(['dense'], {'dense': None})
        selector.reset_model_state()
        accepted = selector.admit_candidate(
            'dense', input_shape=(None, 4), pre_layer='flatten', input_dim=2)
        rejected = selector.admit_candidate(
            'dense', input_shape=(None, 4), pre_layer='flatten', input_dim=2)
        selector.finish_model_state()
        self.assertTrue(accepted)
        self.assertFalse(rejected)
        self.assertEqual(selector.posterior_params('dense'), (2.0, 2.0))

    def test_layer_generator_rejects_noncontributing_candidate_with_bound(self):
        selector = Selector(['dense'], {'dense': None})
        variable = VariableGenerator({
            'tensor_dimension_range': (2, 5),
            'tensor_element_size_range': (2, 5),
            'weight_value_range': (-10.0, 10.0),
            'small_value_range': (0, 1),
            'vocabulary_size': 1001,
        })
        generator = LayerInfoGenerator(
            variable, selector,
            mutation_config=MutationConfig(enabled=[], seed=1),
            layer_types=['dense'], selection_max_retries=1)
        selector.reset_model_state()
        first, _, _ = generator.generate((None, 4), last_layer='flatten')
        second, _, _ = generator.generate((None, 4), last_layer='flatten')
        selector.finish_model_state()
        self.assertEqual(first, 'dense')
        self.assertIsNone(second)
        self.assertEqual(selector.posterior_params('dense'), (2.0, 2.0))

    def test_pv_uses_legal_values_and_bv_uses_power_boundaries(self):
        pv = ValueMutator(MutationConfig(enabled=['pv'], seed=3),
                          mutation_probability=1.0)
        args = pv.mutate_layer_args('dense', {'units': 3, 'activation': 'relu'})
        self.assertIn(args['units'], ValueMutator.INTEGER_BOUNDARIES)
        self.assertIn(args['activation'], ValueMutator._LEGAL_ENUMS['activation'])

        bv = ValueMutator(MutationConfig(enabled=['bv'], seed=4),
                          mutation_probability=1.0)
        args = bv.mutate_layer_args('dense', {'units': 3})
        self.assertIn(args['units'], ValueMutator.INTEGER_BOUNDARIES)

    def test_it_explores_extended_supported_dtype_set(self):
        mutator = ValueMutator(MutationConfig(enabled=['it'], seed=5))
        observed = {mutator.input_type('float32') for _ in range(12)}
        self.assertTrue(observed.issubset(set(ValueMutator.INPUT_DTYPES)))
        self.assertGreaterEqual(len(observed), 5)
        self.assertEqual(tuple(INPUT_DTYPE_UNIVERSE), ValueMutator.INPUT_DTYPES)

    def test_wr_preserves_dense_conv_rnn_shapes_and_norms(self):
        mutator = NeuronMutator(MutationConfig(enabled=['wr'], seed=11))
        weights = [
            np.arange(15, dtype=np.float32).reshape(3, 5),       # rectangular Dense
            np.arange(72, dtype=np.float32).reshape(3, 3, 2, 4), # Conv kernel
            np.arange(24, dtype=np.float32).reshape(4, 6),       # RNN kernel
            np.arange(6, dtype=np.float32),                      # bias (skipped)
        ]
        rotated, report = mutator.mutate_weights_with_report(weights)
        for before, after in zip(weights, rotated):
            self.assertEqual(before.shape, after.shape)
        for before, after in zip(weights[:3], rotated[:3]):
            self.assertTrue(np.allclose(np.linalg.norm(before), np.linalg.norm(after),
                                        rtol=2e-5, atol=2e-5))
        rotations = report['operators'][0]['details']['rotations']
        self.assertTrue(all(item['orthogonality_error'] < 1e-5
                            for item in rotations[:3]))

    def test_neuron_mutation_is_wired_and_reports_actual_changes(self):
        layers = [
            FakeLayer('dense', [np.arange(12, dtype=np.float32).reshape(3, 4),
                                np.ones(4, dtype=np.float32)]),
            FakeLayer('no_weights', []),
        ]
        model = FakeModel(layers)
        before = layers[0].get_weights()
        summary = apply_neuron_mutation(
            model, NeuronMutator(MutationConfig(enabled=['nf', 'ws', 'wr'], seed=13)))
        after = layers[0].get_weights()
        self.assertEqual([w.shape for w in before], [w.shape for w in after])
        self.assertTrue(any(np.any(a != b) for a, b in zip(before, after)))
        self.assertEqual(summary['mutated_layers'], 1)
        self.assertGreater(summary['changed_values'], 0)
        json.dumps(summary)  # provenance must be serializable


if __name__ == '__main__':
    unittest.main()
