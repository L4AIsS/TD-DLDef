# -*- coding: utf-8 -*-
"""
模型源码片段渲染模块

把 model_info (model.json 同构的模型结构 dict) 渲染为可读的 Keras 模型源码,
用于缺陷报告: 标注每个缺陷是由哪段模型代码片段造成的。

渲染风格与 src/cases_generation/generate_one.py 的实际构建逻辑一致:
    * input_object       -> keras.Input(shape=..., dtype=...)
    * 普通层             -> x = keras.layers.Dense(units=..., ...)(x_prev)
    * 包装层 (嵌套 layer) -> keras.layers.TimeDistributed(keras.layers.Dense(...))
    * 被 PV/BV 突变改动的参数以  # [PV] param: old -> new  行内注释标出。
"""

from typing import Optional


def _fmt_value(v, indent=0):
    """格式化参数值为 Python 源码字面量"""
    if isinstance(v, str):
        return repr(v)
    if isinstance(v, (list, tuple)):
        inner = ', '.join(_fmt_value(x) for x in v)
        return '(%s)' % inner if isinstance(v, tuple) else '[%s]' % inner
    if isinstance(v, dict):
        return repr(v)
    if v is None:
        return 'None'
    return repr(v)


def _camel(layer_type):
    """'conv2D' -> 'Conv2D', 'dense' -> 'Dense' (与 utils.get_layer_func 一致)"""
    if layer_type == 'input_object':
        return 'Input'
    res = ''
    i = 0
    while i < len(layer_type):
        if i == 0:
            res += layer_type[i].upper()
        elif layer_type[i] == '_':
            i += 1
            res += layer_type[i].upper()
        else:
            res += layer_type[i]
        i += 1
    return res


def _iter_items(d):
    """按拓扑序 (层 id 升序) 遍历 model_structure, 兼容 int/str key"""
    for k in sorted(d.keys(), key=lambda x: int(x)):
        yield str(k), d[k]


def render_layer_call(layer_type: str, args: dict, mutations: Optional[dict] = None) -> str:
    """渲染单个层的构造函数调用, 如 keras.layers.Conv2D(filters=3, ...)

    :param layer_type: 层类型
    :param args:       层参数 (含 name; 不含 pre_layers)
    :param mutations:  (保留兼容, 注释由 mutation_note 生成并追加到语句末尾)
    """
    if layer_type == 'input_object':
        shape = args.get('batch_shape') or (None, *tuple(args.get('shape', ())))
        dtype = args.get('dtype')
        return 'keras.Input(shape=%s%s)' % (
            _fmt_value(tuple(shape[1:]) if shape else ()),
            ', dtype=%s' % repr(dtype) if dtype else '')

    parts = []
    for k, v in args.items():
        if k == 'name':
            continue
        if k == 'layer' and isinstance(v, dict):   # 包装层: 递归渲染内层
            inner = render_layer_call(v.get('type'), v.get('args', {}), v.get('mutations'))
            parts.append('%s' % inner)
            continue
        if k.endswith('_initializer') and isinstance(v, str):
            parts.append('%s=keras.initializers.%s' % (k, _camel(v)))
            continue
        parts.append('%s=%s' % (k, _fmt_value(v)))
    return 'keras.layers.%s(%s)' % (_camel(layer_type), ', '.join(parts))


def mutation_note(mutations: Optional[dict]) -> str:
    """生成突变标注注释: '   # MUTATED [PV] filters: 4 -> 3; [BV] units: 5 -> 1'"""
    if not mutations:
        return ''
    notes = []
    for op, changes in mutations.items():
        if isinstance(changes, dict):
            for p, on in changes.items():
                o, n = on
                notes.append('[%s] %s: %s -> %s' % (op.upper(), p, _fmt_value(o), _fmt_value(n)))
    return ('   # MUTATED ' + '; '.join(notes)) if notes else ''


def render_model_snippet(model_info: dict, only_layer: Optional[str] = None) -> str:
    """渲染整个模型的源码片段 (函数式 API 风格)

    :param model_info: 模型结构 dict (model.json 同构)
    :param only_layer: 若指定层名 (如 '03_conv2D'), 只返回该层及其直接前驱的片段
    :return: 多行源码字符串
    """
    structure = {str(k): v for k, v in model_info['model_structure'].items()}
    var_of = {}          # layer_id -> 输出变量名
    lines = []

    for layer_id, info in _iter_items(structure):
        ltype = info['type']
        args = info.get('args', {})
        name = args.get('name', '%s_%s' % (layer_id.zfill(2), ltype))
        mutations = info.get('mutations')
        pre = [str(i) for i in info.get('pre_layers', [])]

        call = render_layer_call(ltype, args, mutations)
        note = mutation_note(mutations)
        if ltype == 'input_object':
            stmt = '%s = %s' % (name, call)
        else:
            inbound = ', '.join(var_of.get(p, '?') for p in pre)
            if len(pre) > 1:
                inbound = '[%s]' % inbound
            stmt = '%s = %s(%s)' % (name, call, inbound)
        stmt += note
        var_of[layer_id] = name
        lines.append((name, stmt))

    if only_layer is not None:
        selected = [stmt for name, stmt in lines if name == only_layer]
        if selected:
            header = '# --- 缺陷定位: 层 %s ---' % only_layer
            return header + '\n' + '\n'.join(selected)
        return '# layer %s not found in model' % only_layer
    return '\n'.join(stmt for _, stmt in lines)


def layer_source_snippet(model_info: dict, layer_name: str) -> str:
    """返回指定层的单行源码片段 (含突变标注), 用于缺陷记录"""
    structure = {str(k): v for k, v in model_info['model_structure'].items()}
    for _, info in _iter_items(structure):
        args = info.get('args', {})
        if args.get('name') == layer_name:
            pre = [str(i) for i in info.get('pre_layers', [])]
            pre_names = []
            for p in pre:
                if p in structure:
                    pre_names.append(structure[p].get('args', {}).get('name', p))
            call = render_layer_call(info['type'], args, info.get('mutations'))
            note = mutation_note(info.get('mutations'))
            if info['type'] == 'input_object':
                return '%s = %s%s' % (layer_name, call, note)
            inbound = ', '.join(pre_names) if pre_names else '<model_input>'
            if len(pre_names) > 1:
                inbound = '[%s]' % inbound
            return '%s = %s(%s)%s' % (layer_name, call, inbound, note)
    return '# layer %s not found' % layer_name


def mutated_layers(model_info: dict) -> list:
    """返回模型中所有被值突变改动过的层: [(layer_name, mutations), ...]"""
    structure = {str(k): v for k, v in model_info['model_structure'].items()}
    out = []
    for _, info in _iter_items(structure):
        muts = []
        if info.get('mutations'):
            muts.append(info['mutations'])
        inner = info.get('args', {}).get('layer')
        if isinstance(inner, dict) and inner.get('mutations'):
            muts.append({'inner(%s)' % inner.get('type'): inner['mutations']})
        if muts:
            out.append((info.get('args', {}).get('name', '?'), muts))
    return out


if __name__ == '__main__':
    mi = {
        'model_structure': {
            '0': {'type': 'input_object', 'args': {'name': '00_input_object', 'shape': (6, 6, 3)},
                  'pre_layers': [], 'output_shape': (None, 6, 6, 3)},
            '1': {'type': 'conv2D',
                  'args': {'name': '01_conv2D', 'filters': 3, 'kernel_size': (2, 2), 'padding': 'valid'},
                  'pre_layers': [0], 'output_shape': (None, 5, 5, 3),
                  'mutations': {'pv': {'filters': [4, 3]}}},
            '2': {'type': 'flatten', 'args': {'name': '02_flatten'},
                  'pre_layers': [1], 'output_shape': (None, 75)},
            '3': {'type': 'dense', 'args': {'name': '03_dense', 'units': 4},
                  'pre_layers': [2], 'output_shape': (None, 4)},
        },
        'input_id_list': [0], 'output_id_list': [3],
    }
    print(render_model_snippet(mi))
    print('---')
    print(layer_source_snippet(mi, '01_conv2D'))
    print('---')
    print(mutated_layers(mi))
