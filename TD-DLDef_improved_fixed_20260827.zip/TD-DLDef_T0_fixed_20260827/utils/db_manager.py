from typing import List
import sqlite3


class DbManager(object):

    def __init__(self, db_path: str):
        super().__init__()
        self.__conn = sqlite3.connect(db_path, check_same_thread=False)
        self.__init_tables()

    def __init_tables(self):
        '''初始化必要的表 (若不存在)
        '''
        CREATE_MODEL = '''create table if not exists model(
                             dataset_name text,
                             node_num integer not null,
                             generate_fail_backends text,
                             crash_backends text,
                             nan_backends text,
                             inf_backends text,
                             loss_func text,
                             optimizer text,
                             status text
                          )
                       '''
        CREATE_INCONSISTENCY = '''create table if not exists inconsistency(
                                     model_id integer not null,
                                     backend_pair text not null,
                                     model_output_delta real,
                                     loss_delta real,
                                     loss_grads_delta real,
                                     weights_delta real,
                                     primary key (model_id, backend_pair)
                                  )
                               '''
        CREATE_LOCALIZATION_MAP = '''create table if not exists localization_map(
                                        incons_id integer not null,
                                        layer_name text not null,
                                        outputs_delta real,
                                        outputs_R real,
                                        gradients_delta real,
                                        gradients_R real,
                                        weights_delta real,
                                        inbound_layers text,
                                        primary key (incons_id, layer_name)
                                     )
                                  '''
        CREATE_DEFECT = '''create table if not exists defect(
                              id integer primary key autoincrement,
                              model_id integer,
                              defect_type text,
                              backend text
                           )
                        '''
        CREATE_DEFECT_DETAIL = '''create table if not exists defect_detail(
                              id integer primary key autoincrement,
                              model_id integer,
                              defect_type text,
                              backend text,
                              stage text,
                              located_layer text,
                              causing_snippet text,
                              detail text
                           )
                        '''
        for stmt in (CREATE_MODEL, CREATE_INCONSISTENCY, CREATE_LOCALIZATION_MAP,
                     CREATE_DEFECT, CREATE_DEFECT_DETAIL):
            self.__conn.execute(stmt)
        self.__conn.commit()

    def register_model(self, dataset_name: str, node_num: int):
        '''将模型登记在model表中，并返回分配的model_id
        '''
        INSERT_A_MODEL = '''insert into model(dataset_name, node_num)
                            values(?, ?)
                         '''
        self.__conn.execute(INSERT_A_MODEL, (dataset_name, node_num,))
        self.__conn.commit()

        FETCH_ROWID = '''select last_insert_rowid() from model'''
        cur = self.__conn.cursor()
        cur.execute(FETCH_ROWID)
        return cur.fetchone()[0]

    def update_model_generate_fail_backends(self, model_id: int, fail_backends: List[str]):
        '''记录模型的generate_fail_backends
        '''
        UPDATE_GENERATE_FAIL_BKS = '''update model
                                      set generate_fail_backends = ?
                                      where rowid = ?
                                   '''
        self.__conn.execute(UPDATE_GENERATE_FAIL_BKS, (str(fail_backends), model_id,))
        self.__conn.commit()

    def update_model_crash_backends(self, model_id: int, crash_backends: List[str]):
        '''记录模型的crash_backends
        '''
        UPDATE_CRASH_BKS = '''update model
                              set crash_backends = ?
                              where rowid = ?
                           '''
        self.__conn.execute(UPDATE_CRASH_BKS, (str(crash_backends), model_id,))
        self.__conn.commit()

    def update_model_nan_backends(self, model_id: int, nan_backends: List[str]):
        '''记录模型的nan_backends
        '''
        UPDATE_NAN_BKS = '''update model
                            set nan_backends = ?
                            where rowid = ?
                         '''
        self.__conn.execute(UPDATE_NAN_BKS, (str(nan_backends), model_id,))
        self.__conn.commit()

    def update_model_inf_backends(self, model_id: int, inf_backends: List[str]):
        '''记录模型的inf_backends
        '''
        UPDATE_INF_BKS = '''update model
                            set inf_backends = ?
                            where rowid = ?
                          '''
        self.__conn.execute(UPDATE_INF_BKS, (str(inf_backends), model_id,))
        self.__conn.commit()

    def add_inconsistencies(self, incons: List[tuple]):
        INSERT_INCONS = '''insert into inconsistency(model_id, input_index, backend_pair, output_distance)
                           values(?, ?, ?, ?)
                        '''
        self.__conn.executemany(INSERT_INCONS, incons)
        self.__conn.commit()

    def get_incons_inputs_by_model_id_and_bk(self, model_id: int, backend: str, threshlod: float):
        SELECT_INCONS_INPUTS_AND_BKS_BY_MODEL_ID = '''select distinct input_index
                                                      from inconsistency
                                                      where model_id = ? and backend_pair like ? and (output_distance > ? or output_distance is null)
                                                      order by input_index asc
                                                   '''
        cur = self.__conn.cursor()
        cur.execute(SELECT_INCONS_INPUTS_AND_BKS_BY_MODEL_ID, (model_id, '%'+backend+'%', threshlod,))
        return [res[0] for res in cur.fetchall()]

    def get_incons_bk_pairs_by_model_id_and_inputs(self, model_id: int, input_index: int, threshold: float):
        SELECT_BK_PAIRS_BY_MODEL_ID_AND_INPUTS = '''select rowid, backend_pair
                                                    from inconsistency
                                                    where model_id = ? and input_index = ? and (output_distance > ? or output_distance is null)
                                                 '''
        cur = self.__conn.cursor()
        cur.execute(SELECT_BK_PAIRS_BY_MODEL_ID_AND_INPUTS, (model_id, input_index, threshold,))
        return cur.fetchall()

    def get_huge_incons(self, threshold: float, model_id: int):
        GET_HUGE_INCONS = '''select rowid, input_index, backend_pair
                             from inconsistency
                             where model_id = ? and (output_distance > ? or output_distance is null)
                             group by backend_pair
                          '''
        cur = self.__conn.cursor()
        cur.execute(GET_HUGE_INCONS, (model_id, threshold,))
        return cur.fetchall()

    def get_localization_map(self, incons_id):
        GET_LOCALIZATION_MAP = '''select *
                                  from localization_map
                                  where inconsistency_id == ?
                               '''
        cur = self.__conn.cursor()
        cur.execute(GET_LOCALIZATION_MAP, (incons_id,))
        return cur.fetchall()

    def add_training_incons(self, model_id, backend_pair, model_output_delta, loss_delta, loss_grads_delta):
        INSERT_INCONS = '''insert into inconsistency(model_id, backend_pair, model_output_delta, loss_delta, loss_grads_delta)
                           values(?, ?, ?, ?, ?)
                        '''
        self.__conn.execute(INSERT_INCONS, (model_id, backend_pair, model_output_delta, loss_delta, loss_grads_delta,))
        self.__conn.commit()

        FETCH_ROWID = '''select last_insert_rowid() from inconsistency'''
        cur = self.__conn.cursor()
        cur.execute(FETCH_ROWID)
        return cur.fetchone()[0]

    def record_loss_optimizer(self, model_id: int, loss: str, optimizer: str):
        '''记录模型的train配置
        '''
        UPDATE_LOSS_OPTIMIZER = '''update model
                                   set loss_func = ?, optimizer = ?
                                   where rowid = ?
                                '''
        self.__conn.execute(UPDATE_LOSS_OPTIMIZER, (loss, optimizer, model_id,))
        self.__conn.commit()

    def record_status(self, model_id: int, status: list):
        UPDATE_STATUS = '''update model
                           set status = ?
                           where rowid = ?
                        '''
        self.__conn.execute(UPDATE_STATUS, (str(status), model_id,))
        self.__conn.commit()

    def get_model_info(self, model_id: int):
        GET_MODEL_INFO = '''select *
                            from model
                            where rowid = ?
                         '''
        cur = self.__conn.cursor()
        cur.execute(GET_MODEL_INFO, (model_id,))
        return cur.fetchone()

    def update_losses(self, model_id: int, bk_pair: str, loss_delta: float):
        UPDATE_LOSS = '''update inconsistency
                         set loss_delta = ?
                         where model_id = ? and backend_pair = ?
                      '''
        self.__conn.execute(UPDATE_LOSS, (loss_delta, model_id, bk_pair,))
        self.__conn.commit()

    def add_localization_map(self, infos):
        INSERT_LOCALIZATION_MAP = '''insert into localization_map(incons_id, layer_name, outputs_delta, outputs_R, gradients_delta, gradients_R, inbound_layers)
                               values(?, ?, ?, ?, ?, ?, ?)
                            '''
        self.__conn.executemany(INSERT_LOCALIZATION_MAP, infos)
        self.__conn.commit()

    def record_inconsistency(self, model_id: int, backend_pair: str):
        '''记录一个 Inconsistency 缺陷 (Oracle 3: 跨框架行为不一致)
        '''
        INSERT_INCONS_DEFECT = '''insert into defect(model_id, defect_type, backend)
                                  values(?, 'inconsistency', ?)
                               '''
        self.__conn.execute(INSERT_INCONS_DEFECT, (model_id, backend_pair,))
        self.__conn.commit()

    def record_crash_defect(self, model_id: int, backend: str):
        INSERT_CRASH = '''insert into defect(model_id, defect_type, backend)
                          values(?, 'crash', ?)
                       '''
        self.__conn.execute(INSERT_CRASH, (model_id, backend,))
        self.__conn.commit()

    def record_nan_defect(self, model_id: int, backend: str):
        INSERT_NAN = '''insert into defect(model_id, defect_type, backend)
                        values(?, 'nan', ?)
                     '''
        self.__conn.execute(INSERT_NAN, (model_id, backend,))
        self.__conn.commit()

    def record_inf_defect(self, model_id: int, backend: str):
        INSERT_INF = '''insert into defect(model_id, defect_type, backend)
                        values(?, 'inf', ?)
                     '''
        self.__conn.execute(INSERT_INF, (model_id, backend,))
        self.__conn.commit()

    def record_defect_detail(self, model_id: int, defect_type: str, backend: str,
                             stage: str = '', located_layer=None,
                             causing_snippet=None, detail=None):
        '''记录缺陷明细 (缺陷定位层 + 造成缺陷的模型源码片段)
        '''
        INSERT_DETAIL = '''insert into defect_detail(model_id, defect_type, backend, stage,
                                                     located_layer, causing_snippet, detail)
                           values(?, ?, ?, ?, ?, ?, ?)
                        '''
        self.__conn.execute(INSERT_DETAIL, (model_id, defect_type, backend, stage,
                                            located_layer, causing_snippet, detail,))
        self.__conn.commit()

    def get_defect_details(self):
        '''取出全部缺陷明细'''
        cur = self.__conn.cursor()
        cur.execute('''select model_id, defect_type, backend, stage, located_layer,
                              causing_snippet, detail
                       from defect_detail order by id asc''')
        return cur.fetchall()

    def get_defect_stats(self):
        '''统计各框架的缺陷数量 (实验 2)
        '''
        QUERY = '''select backend, defect_type, count(*)
                   from defect
                   group by backend, defect_type
                   order by backend, defect_type
                '''
        cur = self.__conn.cursor()
        cur.execute(QUERY)
        return cur.fetchall()
