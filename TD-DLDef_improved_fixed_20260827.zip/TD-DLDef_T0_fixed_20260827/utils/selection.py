# -*- coding: utf-8 -*-
"""
选择器 (Selector): 多臂强盗 + TS-RCS + 四多样性空间评估

选择流程 (对应论文 Algorithm 1):
    1. choose_element: 基于 TS-RCS 从可用候选层中选出一个层类型;
    2. 生成部分模型候选层并立即调用 admit_candidate 执行 DIV;
    3. 有新多样性则更新 alpha 并接纳，否则更新 beta、拒绝并在有界次数内重试。

多样性评估口径 (重要):
    四个多样性空间 (layer/edge/shape/dim) 在**一次测试任务中基于生成的全部
    模型**累积评估, 模型之间不重置 —— 只有引入了此前全部模型都未覆盖的新
    元素才计为新的多样性贡献 (见 utils/diversity.py)。

消融支持:
    * diversity_spaces: 参与多样性评估的空间集合 (去掉某个空间即消融);
    * reward_mode: 'diversity' (按多样性贡献) / 'explore' (按探索程度, 用于
      "无多样性评估" 的消融配置)。
"""

from typing import List, Optional
from utils.Thompson import ThompsonSampling
from utils.diversity import DiversityEvaluator


class Selector(object):
    """层选择器"""

    class Element(object):
        def __init__(self, name: str, selected: int = 0):
            self.name = name
            self.selected = selected

        def record(self):
            self.selected += 1

        @property
        def score(self):
            return 1.0 / (self.selected + 1)

    def __init__(self, layer_types: List[str], layer_conditions: dict,
                 diversity_spaces: Optional[list] = None,
                 reward_mode: str = 'diversity'):
        """
        :param layer_types:       候选层类型列表
        :param layer_conditions:  层可用性条件
        :param diversity_spaces:  参与多样性评估的空间列表 (None=全部启用)
        :param reward_mode:       'diversity' 或 'explore'
        """
        self.__pool = {name: self.Element(name=name) for name in layer_types}
        self.__layer_conditions = layer_conditions
        self.__thompson_sampling = ThompsonSampling(layer_types, 1, 1)
        self.__diversity = DiversityEvaluator(diversity_spaces)
        self.__reward_mode = reward_mode

    # ------------------------------------------------------------------ #
    # 状态管理
    # ------------------------------------------------------------------ #
    def reset_model_state(self):
        """每个新模型生成前调用。

        注意: 四多样性空间是任务级的 (跨全部模型累积), 此处**不重置**空间,
        仅开始记录当前模型的多样性贡献 (begin_model)。
        """
        self.__diversity.begin_model()

    def finish_model_state(self):
        """Finish per-model contribution accounting after structure generation."""
        self.__diversity.end_model()

    # ------------------------------------------------------------------ #
    # 候选选择
    # ------------------------------------------------------------------ #
    def choose_element(self, pool: List[str], **kwargs):
        """挑选候选者 (TS-RCS 选择)"""
        candidates = []
        for el_name in pool:
            cond = self.__layer_conditions.get(el_name, None)
            if cond is None or cond(**kwargs):
                candidates.append(self.__pool[el_name].name)
        candidate = self.__thompson_sampling.choose_arm(candidates)
        return candidate

    # ------------------------------------------------------------------ #
    # 多样性评估 + 后验更新
    # ------------------------------------------------------------------ #
    def update(self, name, input_shape=None, pre_layer=None, input_dim=None,
               input_num=None, evaluate=True):
        """层加入模型后调用: 评估其对任务级四空间的多样性贡献并更新 TS 后验

        :param name:        层类型
        :param input_shape: 该层输入形状
        :param pre_layer:   直接前驱层类型
        :param input_dim:   输入维度
        :param input_num:   合并层输入分支数
        :param evaluate:    是否执行多样性评估 (False 用于消融配置)
        """
        if name == 'input_object':
            return True

        if evaluate and self.__reward_mode == 'diversity':
            is_new, contrib = self.__diversity.evaluate_and_record(
                name, input_shape=input_shape, pre_layer_type=pre_layer,
                input_dim=input_dim, input_num=input_num)
            reward = 1 if is_new else 0
        else:
            # 无多样性评估: 基于探索程度给出奖励
            reward = self.__thompson_sampling.is_reward(name)

        self.__thompson_sampling.update(name, reward)
        return bool(reward)

    def admit_candidate(self, name, input_shape=None, pre_layer=None,
                        input_dim=None, input_num=None):
        """Immediately evaluate a partial-model candidate.

        Diversity mode accepts only a contributing candidate.  The no-diversity
        ablation keeps the historical exploration reward but always accepts the
        compatible candidate because there is no DIV gate to evaluate.
        """
        reward = self.update(name, input_shape=input_shape, pre_layer=pre_layer,
                             input_dim=input_dim, input_num=input_num,
                             evaluate=(self.__reward_mode == 'diversity'))
        if self.__reward_mode != 'diversity':
            return True
        return reward

    def record_committed_layer(self, name, input_shape=None, pre_layer=None,
                               input_dim=None, input_num=None):
        """Record a mandatory/non-TS layer in diversity spaces without updating an arm."""
        if name == 'input_object' or self.__reward_mode != 'diversity':
            return
        self.__diversity.evaluate_and_record(
            name, input_shape=input_shape, pre_layer_type=pre_layer,
            input_dim=input_dim, input_num=input_num)

    def update_with_model(self, model_info):
        """Replay/import helper for a pre-existing model.

        Newly generated models must use immediate ``admit_candidate`` feedback;
        calling this helper on them would duplicate the posterior updates.
        """
        structure = model_info['model_structure']
        # 统一 key 为字符串 (兼容内存中 int key 与 json 中 str key)
        structure = {str(k): v for k, v in structure.items()}
        self.__diversity.begin_model()
        for layer_id, layer_info in structure.items():
            layer_type = layer_info['type']
            pre_layers = layer_info.get('pre_layers', [])
            input_shapes = [structure[str(i)]['output_shape'] for i in pre_layers if str(i) in structure]
            if input_shapes:
                input_shape = tuple(input_shapes[0])
            else:
                input_shape = None
            pre_type = structure[str(pre_layers[0])]['type'] if pre_layers and str(pre_layers[0]) in structure else None
            input_dim = len(input_shape) if input_shape else None
            self.update(layer_type, input_shape=input_shape, pre_layer=pre_type,
                        input_dim=input_dim, input_num=len(pre_layers) if len(pre_layers) > 1 else None)
        self.__diversity.end_model()

    # ------------------------------------------------------------------ #
    # 统计接口
    # ------------------------------------------------------------------ #
    def coverage(self):
        return self.__thompson_sampling.cal_coverage()

    def branch_lines(self):
        return self.__thompson_sampling.cal_branch_and_lines()

    def get_single_record(self):
        return self.__thompson_sampling.get_single_record()

    def posterior_params(self, layer):
        """Expose posterior parameters for verification and experiment logs."""
        return self.__thompson_sampling.get_params(layer)

    def get_global_spaces(self):
        """任务级四多样性空间 (跨全部已评估模型累积)"""
        return self.__diversity.get_spaces()

    def get_diversity(self):
        return self.__diversity

    def diversity_summary(self):
        """任务级多样性统计: 各空间累积规模 + 每个模型的新元素贡献"""
        sizes = self.__diversity.space_sizes()
        contribs = self.__diversity.model_contributions
        n = len(contribs)
        return {
            'space_sizes': sizes,
            'models_evaluated': n,
            'avg_new_per_model': (sum(c['new_total'] for c in contribs) / n) if n else 0.0,
            'per_space_avg_new': {s: (sum(c[s] for c in contribs) / n) if n else 0.0
                                  for s in DiversityEvaluator.SPACES},
        }
