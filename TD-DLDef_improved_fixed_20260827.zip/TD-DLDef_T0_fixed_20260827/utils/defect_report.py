# -*- coding: utf-8 -*-
"""
缺陷信息记录模块 (需求: 统计所有符合 oracle 检查的缺陷信息)

对每一个符合 Oracle 检查 (crash / NaN / Inf / inconsistency) 的缺陷, 记录:
    * model_id / framework(backend 或 backend 对) / defect_type / 触发阶段;
    * 缺陷定位到的层名 (NaN/Inf 取拓扑序上首个出现异常的层;
      inconsistency 取 output_delta 最大的层; crash 为模型级);
    * 造成缺陷的模型源码片段 (该层的 Keras 构建语句, 含 PV/BV 突变标注);
    * 完整模型源码片段 (model_snippet) 与模型的值突变记录;
    * 附加细节 (exit_code / delta 值 / NaN 层列表等)。

输出: JSONL (每行一条缺陷记录) + CSV (汇总表) + 控制台统计表。
"""

import csv
import json
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

from utils.model_snippet import (render_model_snippet, layer_source_snippet,
                                 mutated_layers)
from utils.oracle import DEFECT_CRASH, DEFECT_NAN, DEFECT_INF, DEFECT_INCONSISTENCY


# ---------------------------------------------------------------------- #
# 缺陷定位辅助
# ---------------------------------------------------------------------- #
def _topo_layer_names(model_info: dict) -> List[str]:
    """按拓扑序返回层名列表"""
    structure = model_info['model_structure']
    names = []
    for k in sorted(structure.keys(), key=lambda x: int(x)):
        names.append(structure[k].get('args', {}).get('name', str(k)))
    return names


def localize_nan_inf(outputs_data: Optional[dict], model_info: dict) -> dict:
    """定位 NaN / Inf 缺陷: 返回拓扑序上首个出现 NaN / Inf 的层

    :param outputs_data: {layer_name: np.ndarray} (各层输出)
    :return: {'nan_layer': 层名或None, 'inf_layer': 层名或None,
              'nan_layers': [...], 'inf_layers': [...]}
    """
    res = {'nan_layer': None, 'inf_layer': None, 'nan_layers': [], 'inf_layers': []}
    if not outputs_data:
        return res
    for name in _topo_layer_names(model_info):
        if name not in outputs_data:
            continue
        arr = outputs_data[name]
        try:
            arr = np.asarray(arr)
            if arr.dtype.kind not in ('f', 'c') or not arr.size:
                continue
            if np.isnan(arr).any():
                res['nan_layers'].append(name)
                if res['nan_layer'] is None:
                    res['nan_layer'] = name
            if np.isinf(arr).any():
                res['inf_layers'].append(name)
                if res['inf_layer'] is None:
                    res['inf_layer'] = name
        except Exception:
            continue
    return res


def localize_inconsistency(localization_map: Dict[str, tuple]) -> Optional[str]:
    """定位 Inconsistency 缺陷: 返回 output_R (输出差异相对前驱的变化率) 最大的层名

    output_R 刻画"分歧在该层被放大的程度", 比 output_delta 更接近分歧源头
    (链式结构中末层 output_delta 天然最大, 但不一定是根因层);
    全部层 R 缺失时退化为 output_delta 最大层。

    :param localization_map: {layer_name: (output_delta, output_R, grad_delta, grad_R, inbound)}
    """
    best_r, best_rv = None, None
    best_d, best_dv = None, -1.0
    for layer_name, infos in (localization_map or {}).items():
        delta, out_r = infos[0], infos[1]
        try:
            r = float(out_r) if out_r is not None else None
        except (TypeError, ValueError):
            r = None
        if r is not None and (best_rv is None or r > best_rv):
            best_r, best_rv = layer_name, r
        try:
            d = float(delta) if delta is not None else None
        except (TypeError, ValueError):
            d = None
        if d is not None and d > best_dv:
            best_d, best_dv = layer_name, d
    return best_r if best_r is not None else best_d


# ---------------------------------------------------------------------- #
# 缺陷记录器
# ---------------------------------------------------------------------- #
class DefectReporter(object):
    """聚合一次测试任务中所有符合 oracle 检查的缺陷记录"""

    def __init__(self, framework: str = '', ablation: str = 'full'):
        self.framework = framework
        self.ablation = ablation
        self.records: List[dict] = []

    # ------------------------------------------------------------------ #
    def record(self, model_id: int, defect_type: str, backend: str,
               model_info: Optional[dict] = None,
               layer_name: Optional[str] = None,
               stage: str = 'training',
               detail: str = '',
               extra: Optional[dict] = None):
        """记录一条缺陷

        :param model_id:    模型 ID
        :param defect_type: crash / nan / inf / inconsistency
        :param backend:     缺陷出现的框架 (或 backend 对, 如 tensorflow_torch)
        :param model_info:  模型结构 (用于渲染造成缺陷的源码片段)
        :param layer_name:  缺陷定位到的层名 (None = 模型级缺陷, 如 crash)
        :param stage:       触发阶段 (generation / training / comparison)
        :param detail:      附加说明 (exit_code / delta / NaN 层列表等)
        :param extra:       其他需要落盘的字段 (如各 delta 值)
        """
        rec = {
            'model_id': model_id,
            'framework': self.framework or backend,
            'backend': backend,
            'defect_type': defect_type,
            'stage': stage,
            'located_layer': layer_name,
            'detail': detail,
        }
        if model_info is not None:
            # 造成缺陷的模型源码片段: 定位到层 -> 该层语句; 否则整模型
            if layer_name:
                rec['causing_snippet'] = layer_source_snippet(model_info, layer_name)
            else:
                rec['causing_snippet'] = None
            rec['model_snippet'] = render_model_snippet(model_info)
            muts = mutated_layers(model_info)
            if muts:
                rec['model_mutations'] = [
                    {'layer': name, 'mutations': m} for name, m in muts]
        if extra:
            rec.update(extra)
        self.records.append(rec)
        return rec

    # ------------------------------------------------------------------ #
    def extend_from_localization(self, model_id: int, model_info: dict,
                                 backend: str, outputs_data: Optional[dict],
                                 stage: str = 'training'):
        """按层输出自动定位并记录 NaN / Inf 缺陷"""
        loc = localize_nan_inf(outputs_data, model_info)
        if loc['nan_layer'] is not None:
            self.record(model_id, DEFECT_NAN, backend, model_info,
                        layer_name=loc['nan_layer'], stage=stage,
                        detail='NaN in layer outputs: %s' % ', '.join(loc['nan_layers']),
                        extra={'nan_layers': loc['nan_layers']})
        if loc['inf_layer'] is not None:
            self.record(model_id, DEFECT_INF, backend, model_info,
                        layer_name=loc['inf_layer'], stage=stage,
                        detail='Inf in layer outputs: %s' % ', '.join(loc['inf_layers']),
                        extra={'inf_layers': loc['inf_layers']})
        return loc

    # ------------------------------------------------------------------ #
    def summary(self) -> dict:
        """按 (framework, defect_type) 聚合计数"""
        agg: Dict[str, Dict[str, int]] = {}
        for r in self.records:
            fw = r.get('framework') or r.get('backend', '?')
            agg.setdefault(fw, {})
            agg[fw][r['defect_type']] = agg[fw].get(r['defect_type'], 0) + 1
        total = {d: 0 for d in (DEFECT_CRASH, DEFECT_NAN, DEFECT_INF, DEFECT_INCONSISTENCY)}
        for r in self.records:
            if r['defect_type'] in total:
                total[r['defect_type']] += 1
        return {'framework_defects': agg, 'total': total, 'count': len(self.records)}

    def to_table(self) -> str:
        s = self.summary()
        lines = ['%-22s%8s%8s%8s%16s' % ('Framework', 'Crash', 'NaN', 'Inf', 'Inconsistency')]
        for fw, c in s['framework_defects'].items():
            lines.append('%-22s%8d%8d%8d%16d' % (
                fw, c.get(DEFECT_CRASH, 0), c.get(DEFECT_NAN, 0),
                c.get(DEFECT_INF, 0), c.get(DEFECT_INCONSISTENCY, 0)))
        t = s['total']
        lines.append('%-22s%8d%8d%8d%16d' % ('TOTAL', t[DEFECT_CRASH], t[DEFECT_NAN],
                                             t[DEFECT_INF], t[DEFECT_INCONSISTENCY]))
        return '\n'.join(lines)

    # ------------------------------------------------------------------ #
    def dump(self, out_path):
        """落盘: <out_path> (JSONL) 与同名 .csv 汇总"""
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with open(str(out_path), 'w', encoding='utf-8') as f:
            for r in self.records:
                f.write(json.dumps(r, ensure_ascii=False) + '\n')
        csv_path = out_path.with_suffix('.csv')
        with open(str(csv_path), 'w', encoding='utf-8', newline='') as f:
            w = csv.writer(f)
            w.writerow(['model_id', 'framework', 'backend', 'defect_type', 'stage',
                        'located_layer', 'causing_snippet', 'detail'])
            for r in self.records:
                w.writerow([r.get('model_id'), r.get('framework'), r.get('backend'),
                            r.get('defect_type'), r.get('stage'),
                            r.get('located_layer'), r.get('causing_snippet'),
                            r.get('detail')])
        return str(out_path), str(csv_path)


if __name__ == '__main__':
    mi = {
        'model_structure': {
            '0': {'type': 'input_object', 'args': {'name': '00_input_object', 'shape': (49, 1)},
                  'pre_layers': [], 'output_shape': (None, 49, 1)},
            '1': {'type': 'LSTM', 'args': {'name': '01_LSTM', 'units': 3},
                  'pre_layers': [0], 'output_shape': (None, 3),
                  'mutations': {'bv': {'units': [4, 1]}}},
            '2': {'type': 'dense', 'args': {'name': '02_dense', 'units': 1},
                  'pre_layers': [1], 'output_shape': (None, 1)},
        },
        'input_id_list': [0], 'output_id_list': [2],
    }
    outputs = {'00_input_object': np.zeros((2, 49, 1)),
               '01_LSTM': np.full((2, 3), np.nan),
               '02_dense': np.full((2, 1), np.nan)}
    rep = DefectReporter(framework='keras3.10')
    rep.extend_from_localization(7, mi, 'tensorflow', outputs)
    rep.record(7, DEFECT_INCONSISTENCY, 'tensorflow_torch', mi,
               layer_name='01_LSTM', stage='comparison',
               detail='output_delta=1.83 > 0.15', extra={'output_delta': 1.83})
    print(rep.to_table())
    print(json.dumps(rep.records[0], ensure_ascii=False, indent=2)[:600])
