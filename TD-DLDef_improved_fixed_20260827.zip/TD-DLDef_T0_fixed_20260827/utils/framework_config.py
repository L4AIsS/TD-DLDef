# -*- coding: utf-8 -*-
"""
框架配置模块 (Framework Configuration)

定义新旧两代深度学习框架下可用的层类型池与参数约束, 用于:
    * 消融实验 1: 在 tensorflow 2.16.1 / pytorch 2.2.0 / keras 3.10
      (新框架) 与 tensorflow 2.0.0 / cntk 2.7.0 / theano 1.0.4 (旧框架)
      下分别统计 LIC / LPC / LSC。

新框架 (Keras 3.x 时代) 支持完整层池;
旧框架 (Keras 2.3.x + CNTK/Theano 后端时代) 仅支持部分层, 且部分参数
(如 causal padding, depthwise_conv2D, convLSTM2D 等) 不可用。
"""

from .utils import (seq_layer_types, RNN_layer_types, activation_layer_types,
                    merging_layer_types, layer_types, layer_conditions)

NEW_FRAMEWORKS = ['tensorflow2.16.1', 'pytorch2.2.0', 'keras3.10']
OLD_FRAMEWORKS = ['tensorflow2.0.0', 'cntk2.7.0', 'theano1.0.4']

# 旧框架 (Keras 2.3 时代) 不支持的层类型
OLD_UNSUPPORTED_LAYERS = {
    'depthwise_conv2D',      # CNTK/Theano 后端不支持
    'convLSTM2D',            # 旧版 Keras 的 CNTK/Theano 后端不支持
    'separable_conv1D',      # CNTK 后端不支持
    'separable_conv2D',      # CNTK/Theano 后端不支持
    'conv3D_transpose',      # 旧后端不支持
}

# 旧框架中部分层不可用的参数取值
OLD_PADDING_POOL = ('valid', 'same')          # 无 'causal'
OLD_ACTIVATION_POOL = ('relu', 'sigmoid', 'tanh', 'elu', 'linear', 'softmax')

# CNTK 后端额外限制 (Keras 2.3 文档): RNN 类仅 LSTM/GRU/SimpleRNN
CNTK_UNSUPPORTED_LAYERS = {'convLSTM2D', 'time_distributed', 'bidirectional'}
# Theano 后端额外限制
THEANO_UNSUPPORTED_LAYERS = {'convLSTM2D', 'bidirectional'}


class FrameworkConfig(object):
    """某个框架的层可用性配置"""

    def __init__(self, name, layer_types_=None, layer_conditions_=None,
                 padding_pool=None, activation_pool=None):
        self.name = name
        self.layer_types = list(layer_types_ if layer_types_ is not None else layer_types)
        self.layer_conditions = dict(layer_conditions_ if layer_conditions_ is not None else layer_conditions)
        self.padding_pool = list(padding_pool if padding_pool is not None else ('valid', 'same', 'causal'))
        self.activation_pool = list(activation_pool if activation_pool is not None else (
            'relu', 'sigmoid', 'softmax', 'softplus', 'tanh', 'selu', 'elu', 'linear'))

    @property
    def is_old(self):
        return self.name in OLD_FRAMEWORKS

    def describe(self):
        return '{}: {} layers'.format(self.name, len(self.layer_types))


def get_framework_config(name):
    """按框架名获取配置 (新/旧框架自适应层池)"""
    if name in NEW_FRAMEWORKS:
        return FrameworkConfig(name)
    if name in OLD_FRAMEWORKS:
        unsupported = set(OLD_UNSUPPORTED_LAYERS)
        if name == 'cntk2.7.0':
            unsupported |= CNTK_UNSUPPORTED_LAYERS
        if name == 'theano1.0.4':
            unsupported |= THEANO_UNSUPPORTED_LAYERS
        lts = [lt for lt in layer_types if lt not in unsupported]
        return FrameworkConfig(name, layer_types_=lts,
                               padding_pool=OLD_PADDING_POOL,
                               activation_pool=OLD_ACTIVATION_POOL)
    # 未知框架: 使用完整配置
    return FrameworkConfig(name)


# 兼容: 旧代码导入的默认层配置
def default_layer_types():
    return list(layer_types)


def default_layer_conditions():
    return dict(layer_conditions)


if __name__ == '__main__':
    for fw in NEW_FRAMEWORKS + OLD_FRAMEWORKS:
        cfg = get_framework_config(fw)
        print(cfg.describe())
