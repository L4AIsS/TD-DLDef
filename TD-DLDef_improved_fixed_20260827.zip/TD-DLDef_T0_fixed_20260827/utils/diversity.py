# -*- coding: utf-8 -*-
"""
四多样性空间 (Diversity Spaces) 与多样性评估 Div(layer)

对应论文 Section IV-B (Diversity Metric 1-4):
    * Layer Space (S_l):          层类型集合
    * Edge Space (S_e):           层间有向边 <layer_i, layer_j> 的集合
    * Input Shape Space (S_s):    (层, 输入形状) 的集合
    * Input Dimension Space (S_d): (层, 输入维度) 的集合

模型空间 M = (S_l, S_e, S_s, S_d)。若加入候选层后
    (S'_l - S_l) ∪ (S'_e - S_e) ∪ (S'_s - S_s) ∪ (S'_d - S_d) != 空集
则 Div(M'_a) = true, 即候选层带来了新的多样性元素。

--------------------------------------------------------------------------------
重要 (统计口径): 四个空间的多样性评估是在**一次测试任务中基于生成的全部模型**
上进行的, 而不是只在单个模型内部评估。即四个空间在整个测试任务期间持续累积:
第 k 个模型的候选层只有引入了**此前 k-1 个模型都未覆盖过**的元素
(新层类型 / 新层间边 / 新 (层,输入形状) / 新 (层,输入维度)) 才记为新的多样性
贡献。这与 COMET "new layer inputs ... that previously generated models have
not covered" 的口径一致。

因此:
    * DiversityEvaluator 的空间在**任务开始时初始化一次**, 模型之间**不重置**;
    * begin_model()/end_model() 只用于记录"每个模型各贡献了多少新元素"
      (per-model contribution), 不影响空间本身;
    * 消融支持: enabled_spaces 指定参与评估的空间集合, 被禁用的空间既不参与
      评估也不记录, 用于"去掉每个多样性评估空间"的独立贡献实验。
--------------------------------------------------------------------------------
"""


class DiversityEvaluator(object):
    """四多样性空间评估器 (任务级: 跨一次测试任务中的全部模型累积)"""

    SPACES = ('layer', 'edge', 'shape', 'dim')
    SPACE_NAMES = {
        'layer': 'layer_space',
        'edge': 'edge_space',
        'shape': 'input_shape_space',
        'dim': 'input_dim_space',
    }

    def __init__(self, enabled_spaces=None):
        """
        :param enabled_spaces: 参与评估的空间名集合, 默认全部启用
        """
        self.enabled = set(enabled_spaces) if enabled_spaces is not None else set(self.SPACES)
        for s in self.enabled:
            if s not in self.SPACES:
                raise ValueError('unknown diversity space: %s' % s)
        # 任务级四空间 (跨全部模型累积, 模型之间不重置)
        self.spaces = {s: set() for s in self.SPACES}
        # 每个模型的新元素贡献记录: [{space: int, 'new_total': int}, ...]
        self.model_contributions = []
        self.__pending = None        # 当前模型的新元素计数缓存

    # ------------------------------------------------------------------ #
    # 任务/模型生命周期
    # ------------------------------------------------------------------ #
    def reset(self):
        """重置整个测试任务的四空间 (仅在一个新测试任务开始时调用;
        模型之间禁止调用, 否则会退化为单模型内评估)"""
        self.spaces = {s: set() for s in self.SPACES}
        self.model_contributions = []
        self.__pending = None

    def begin_model(self):
        """开始记录一个新模型的多样性贡献 (每个模型生成/评估前调用)"""
        self.__pending = {s: 0 for s in self.SPACES}

    def end_model(self):
        """结束当前模型的贡献记录 (模型评估完成后调用)"""
        if self.__pending is not None:
            rec = dict(self.__pending)
            rec['new_total'] = sum(rec[s] for s in self.SPACES)
            self.model_contributions.append(rec)
            self.__pending = None

    # ------------------------------------------------------------------ #
    # 空间访问
    # ------------------------------------------------------------------ #
    def get_spaces(self):
        """返回任务级四空间副本 {space: set} (跨全部已评估模型)"""
        return {s: set(v) for s, v in self.spaces.items()}

    def space_sizes(self):
        """返回各空间当前累积的元素数量"""
        return {s: len(v) for s, v in self.spaces.items()}

    # ------------------------------------------------------------------ #
    # 多样性评估
    # ------------------------------------------------------------------ #
    def evaluate_and_record(self, layer_type, input_shape=None, pre_layer_type=None,
                            input_dim=None, input_num=None):
        """评估并记录一个层对**任务级四空间**的多样性贡献

        只有该层引入了此前全部生成模型都未覆盖的新元素时, 才记为新的多样性。

        :param layer_type:      层类型 (如 'dense')
        :param input_shape:     该层输入形状 (含 batch 维, 可为 None)
        :param pre_layer_type:  直接前驱层类型 (构成边 <pre, layer>)
        :param input_dim:       输入维度
        :param input_num:       (合并层) 输入分支数
        :return: (is_new_diversity: bool, contributions: dict[space]->bool)
        """
        new = False
        contrib = {s: False for s in self.SPACES}

        # 1) Layer Space: 任务内未出现过的新层类型
        if 'layer' in self.enabled:
            if layer_type not in self.spaces['layer']:
                self.spaces['layer'].add(layer_type)
                new = True
                contrib['layer'] = True

        # 2) Edge Space: 任务内未出现过的新层间边 <pre_layer, layer>
        if 'edge' in self.enabled and pre_layer_type is not None:
            edge = (pre_layer_type, layer_type)
            if edge not in self.spaces['edge']:
                self.spaces['edge'].add(edge)
                new = True
                contrib['edge'] = True

        # 3) Input Shape Space: 任务内未出现过的新 (层, 输入形状)
        if 'shape' in self.enabled and input_shape is not None:
            key = (layer_type, tuple(input_shape))
            if key not in self.spaces['shape']:
                self.spaces['shape'].add(key)
                new = True
                contrib['shape'] = True

        # 4) Input Dimension Space: 任务内未出现过的新 (层, 输入维度)
        if 'dim' in self.enabled and input_dim is not None:
            key = (layer_type, int(input_dim))
            if key not in self.spaces['dim']:
                self.spaces['dim'].add(key)
                new = True
                contrib['dim'] = True

        # 记录到当前模型的贡献缓存
        if self.__pending is not None:
            for s, v in contrib.items():
                if v:
                    self.__pending[s] += 1

        return new, contrib

    def div(self, layer_type, input_shape=None, pre_layer_type=None, input_dim=None):
        """论文式 Div(layer): 只评估不记录, 判断该层是否会带来任务级新多样性元素"""
        new = False
        if 'layer' in self.enabled and layer_type not in self.spaces['layer']:
            new = True
        if 'edge' in self.enabled and pre_layer_type is not None and \
                (pre_layer_type, layer_type) not in self.spaces['edge']:
            new = True
        if 'shape' in self.enabled and input_shape is not None and \
                (layer_type, tuple(input_shape)) not in self.spaces['shape']:
            new = True
        if 'dim' in self.enabled and input_dim is not None and \
                (layer_type, int(input_dim)) not in self.spaces['dim']:
            new = True
        return new
