# -*- coding: utf-8 -*-
"""
TS-RCS: Thompson-Sampling-Based Reverse-Contribution Selection
(基于汤普森采样的逆向贡献选择)

对应论文 Algorithm 1 (Model Layer Selection Algorithm Based on Multi-Armed
Bandit and Thompson-Sampling-Based Reverse-Contribution Selection)：

    1. 对候选层池 Lp 中的每个臂 (layer) 初始化 Beta 后验 Beta(1, 1)；
    2. 每轮选择时，从每个候选臂的后验 Beta(alpha, beta) 中采样一个随机值 x，
       计算该采样值处的后验密度 f(x; alpha, beta)，并计算逆向贡献分数
           score = 1 / (f(x; alpha, beta) + eps)
       选择 score 最大的臂 (优先选择探索不足/后验较平缓的层)；
    3. 选中层加入当前部分模型后，依据四多样性空间评估 Div(M, M + layer)：
       若引入新的多样性元素 -> alpha += 1 (成功贡献)；
       否则                 -> beta  += 1 (未贡献)。

修复原实现的两个关键缺陷：
    * choose_arm 中 argmax 采样结果被 random 覆盖，导致 TS 完全退化为随机选择；
    * update 中 reward 语义反向 (reward=1 反而增加失败次数)，后验更新错误。
"""

import os
import numpy as np
from math import lgamma, exp


class ThompsonSampling(object):
    """多臂强盗 + 改进汤普森采样 (TS-RCS)

    每个臂维护 Beta 后验参数 [alpha, beta] (成功贡献次数 / 未贡献次数)。
    """

    def __init__(self, layers, alpha, beta, eps=1e-7, increment=1.0):
        super().__init__()
        self.__layers = list(layers)          # 候选层名字列表
        self.__dict = {}
        for layer in self.__layers:
            # alpha: 成功贡献次数; beta: 未贡献次数 (论文: UPDATE(layer, 1, 1) 先验)
            self.__dict[layer] = [float(alpha), float(beta)]

        self.eps = eps                        # 数值稳定常数
        self.increment = increment            # 每次观测的后验增量 (论文为 1)

        self.record = {}                      # 选择记录
        self.__single_record = {}             # 每层被选择的次数
        self.__pre = ""                       # 上一次的采样结果
        self.__cnt = 0                        # 总选择次数

        # 层对应的分支/行数 (用于 branch/line 覆盖率统计, 不存在时忽略)
        self.__layers_branch_lines = {}
        lb_path = os.path.join('utils', 'layer_branch_lines.npy')
        if os.path.exists(lb_path):
            try:
                self.__layers_branch_lines = np.load(lb_path, allow_pickle=True).item()
            except Exception:
                self.__layers_branch_lines = {}

    # ------------------------------------------------------------------ #
    # Beta 后验工具
    # ------------------------------------------------------------------ #
    @staticmethod
    def __beta_logpdf(x, a, b):
        """Beta(a, b) 在 x 处的对数概率密度 (含归一化常数)"""
        if a <= 0 or b <= 0:
            return 0.0
        if x <= 0.0 or x >= 1.0:
            # 边界处密度趋于 0 (a>1 或 b>1 时) 或为常数 (a=b=1 时)
            if a > 1.0 or b > 1.0:
                return -np.inf
            return 0.0
        logB = lgamma(a) + lgamma(b) - lgamma(a + b)
        return (a - 1.0) * np.log(x) + (b - 1.0) * np.log1p(-x) - logB

    def get_params(self, layer):
        """返回臂 (层) 当前的 (alpha, beta) 后验参数"""
        if layer not in self.__dict:
            return 1.0, 1.0
        return self.__dict[layer][0], self.__dict[layer][1]

    # ------------------------------------------------------------------ #
    # 核心: 选择臂
    # ------------------------------------------------------------------ #
    def choose_arm(self, candidates):
        """从候选臂中选一个

        对每个候选臂:
            1) 从存储的后验 Beta(alpha, beta) 采样 x
            2) 计算后验密度 f(x; alpha, beta)
            3) 逆向贡献分数 score = 1 / (f(x; alpha, beta) + eps)
        选择 score 最大的臂。
        """
        c_cnt = len(candidates)
        if c_cnt == 0:
            return None
        if c_cnt == 1:
            return candidates[0]

        scores = np.zeros(c_cnt)
        for i, candidate in enumerate(candidates):
            # P0 fix: self.__dict already stores the complete prior/posterior.
            # Adding one here made the first draw Beta(2,2), contradicting the
            # paper's Beta(1,1) prior.
            a = self.__dict[candidate][0]
            b = self.__dict[candidate][1]
            x = np.random.beta(a, b)              # 从后验采样
            logf = self.__beta_logpdf(x, a, b)
            logf = max(logf, -700.0)              # 数值稳定
            f = exp(logf)
            scores[i] = 1.0 / (f + self.eps)      # 逆向贡献分数

        idx = int(np.argmax(scores))
        return candidates[idx]

    # ------------------------------------------------------------------ #
    # 核心: 更新后验
    # ------------------------------------------------------------------ #
    def update(self, chosen_name, reward):
        """根据观测到的多样性贡献更新所选臂的后验

        :param chosen_name: 被选择的层
        :param reward: 奖励。1 -> 该层引入了新的多样性元素 (alpha += 1);
                       0 -> 未引入新元素 (beta += 1)
        """
        if chosen_name is None:
            return
        if chosen_name not in self.__dict:
            self.__dict[chosen_name] = [1.0, 1.0]

        if self.__single_record.get(chosen_name, None) is None:
            self.__single_record[chosen_name] = 1
        else:
            self.__single_record[chosen_name] += 1

        self.__pre = chosen_name
        self.__cnt += 1

        if reward == 1:
            self.__dict[chosen_name][0] += self.increment   # alpha += 1
        else:
            self.__dict[chosen_name][1] += self.increment   # beta  += 1

    # ------------------------------------------------------------------ #
    # 探索奖励 (兼容旧接口; 用于 "无多样性评估" 的消融配置)
    # ------------------------------------------------------------------ #
    def is_reward(self, selected_name):
        """基于探索程度的奖励: 被选择次数占比低于均匀水平时给予探索奖励"""
        selected_cnt = self.__single_record.get(selected_name, None)
        if selected_cnt is None:
            return 1
        if self.__cnt == 0:
            return 1
        if selected_cnt / self.__cnt < 1.0 / len(self.__layers):
            return 1
        return 0

    # ------------------------------------------------------------------ #
    # 统计接口
    # ------------------------------------------------------------------ #
    def print(self):
        for layer in self.__layers:
            print('{} 次数 {}  alpha={:.2f} beta={:.2f}'.format(
                layer,
                self.__single_record.get(layer, 0),
                self.__dict[layer][0],
                self.__dict[layer][1]))
        print(self.__single_record)

    def get_single_record(self):
        return self.__single_record

    def cal_coverage(self):
        """层类型覆盖率: 已选层类型数 / 层类型总数"""
        return round(100 * len(self.__single_record) / len(self.__layers), 2), self.__single_record

    def cal_branch_and_lines(self):
        """已覆盖分支数与代码行数 (基于 layer_branch_lines.npy)"""
        branch_cnt = 0
        lines_cnt = 0
        for layer in self.__single_record:
            branch_line = self.__layers_branch_lines.get(layer, None)
            if branch_line is not None:
                branch_cnt += branch_line[0]
                lines_cnt += branch_line[1]
        return branch_cnt, lines_cnt


if __name__ == '__main__':
    # 自测: TS-RCS 应显著优于随机
    import random
    layers = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']
    a_sampling = ThompsonSampling(layers=layers, alpha=1, beta=1)
    for i in range(200):
        cands = random.sample(layers, 4)
        re = a_sampling.choose_arm(cands)
        # 模拟奖励: 偏好未被充分探索的层
        a_sampling.update(re, a_sampling.is_reward(re))
    a_sampling.print()
    print('coverage:', a_sampling.cal_coverage())
