# -*- coding: utf-8 -*-
"""TD-DLDef mutation operators aligned with the paper definitions.

PV selects a least-used value from a legal, layer-aware candidate set. BV uses
explicit power/boundary sets. IT explores supported numeric input dtypes. NF
draws Laplace, centred-exponential, or sinusoidal noise. WS scales weights. WR
applies ``W' = W R`` on the last tensor axis, where ``R.T @ R = I``. All neuron
operators preserve every weight tensor's shape.
"""

from collections import Counter
import hashlib
import random

import numpy as np


MUTATION_OPERATORS = {
    'pv': 'Parameter Value Mutation',
    'bv': 'Boundary Value Mutation',
    'it': 'Input Type Mutation',
    'nf': 'Noise Fuzzing',
    'ws': 'Weight Scaling',
    'wr': 'Weight Rotation',
}


class MutationConfig(object):
    """Mutation switches and isolated RNGs used by one experiment."""

    def __init__(self, enabled=None, seed=None):
        if enabled is None:
            enabled = list(MUTATION_OPERATORS)
        self.enabled = set(enabled)
        unknown = self.enabled.difference(MUTATION_OPERATORS)
        if unknown:
            raise ValueError('unknown mutation operator(s): %s' % sorted(unknown))
        self.seed = seed
        self.py_rng = random.Random(seed)
        self.np_rng = np.random.RandomState(seed)

    def is_enabled(self, op):
        return op in self.enabled

    def describe(self):
        return '+'.join(sorted(self.enabled)) if self.enabled else 'none'


class ValueMutator(object):
    """Paper-aligned value mutation with legal-value usage tracking."""

    INPUT_DTYPES = (
        'float16', 'float32', 'float64',
        'int8', 'int16', 'int32', 'int64', 'uint8',
    )
    INTEGER_BOUNDARIES = (1, 2, 4, 8, 16, 32)
    RATE_BOUNDARIES = (0.0, 2.0 ** -16, 2.0 ** -8, 0.5, 1.0 - 2.0 ** -8)
    REAL_BOUNDARIES = (-16.0, -1.0, 0.0, 1.0, 16.0)

    _LEGAL_ENUMS = {
        'activation': ('linear', 'relu', 'sigmoid', 'tanh', 'elu', 'selu', 'softplus'),
        'data_format': ('channels_last', 'channels_first'),
        'padding': ('valid', 'same'),
    }
    _POSITIVE_INTEGER_PARAMS = {
        'units', 'filters', 'depth_multiplier', 'input_dim', 'output_dim',
        'n', 'size', 'rank', 'max_value',
    }
    _SPATIAL_PARAMS = {'kernel_size', 'strides', 'pool_size', 'dilation_rate'}
    _RATE_PARAMS = {'dropout', 'recurrent_dropout', 'rate', 'momentum'}
    _REAL_PARAMS = {'alpha', 'theta', 'negative_slope', 'threshold', 'mask_value'}
    _EPSILON_PARAMS = {'epsilon'}

    def __init__(self, config, weight_range=(-10.0, 10.0),
                 small_value_range=(0, 1), ele_size_range=(2, 5),
                 mutation_probability=0.30):
        self.config = config
        self.weight_range = tuple(weight_range)
        self.small_value_range = tuple(small_value_range)
        self.ele_size_range = tuple(ele_size_range)
        self.mutation_probability = float(mutation_probability)
        self.last_changes = {}
        self._usage = Counter()

    @staticmethod
    def _value_key(value):
        if isinstance(value, list):
            value = tuple(value)
        return repr(value)

    def _least_used(self, layer_type, param, candidates, current):
        unique = []
        seen = set()
        for value in candidates:
            key = self._value_key(value)
            if key not in seen:
                seen.add(key)
                unique.append(value)
        candidates = unique
        alternatives = [v for v in candidates if v != current]
        if not alternatives:
            return current
        counts = [self._usage[(layer_type, param, self._value_key(v))] for v in alternatives]
        minimum = min(counts)
        least_used = [v for v, count in zip(alternatives, counts) if count == minimum]
        chosen = self.config.py_rng.choice(least_used)
        self._usage[(layer_type, param, self._value_key(chosen))] += 1
        return chosen

    def _legal_values(self, layer_type, param, current):
        if param == 'padding':
            values = list(self._LEGAL_ENUMS[param])
            if layer_type == 'conv1D':
                values.append('causal')
            return values
        if param in self._LEGAL_ENUMS:
            return self._LEGAL_ENUMS[param]
        if isinstance(current, bool):
            return (False, True)
        if param in self._SPATIAL_PARAMS:
            scalar = (1, 2, 3, 4)
            if isinstance(current, (tuple, list)):
                typ = tuple if isinstance(current, tuple) else list
                return [typ([v] * len(current)) for v in scalar]
            return scalar
        if param in self._POSITIVE_INTEGER_PARAMS and isinstance(current, int):
            return self.INTEGER_BOUNDARIES
        if param in self._RATE_PARAMS and isinstance(current, (int, float)):
            return self.RATE_BOUNDARIES
        return (current,)

    def parameter_value(self, layer_type, args):
        """PV: choose the least-used legal value for selected parameters."""
        if not self.config.is_enabled('pv'):
            return args
        result = dict(args)
        changed = self.last_changes.setdefault('pv', {})
        for param, current in list(result.items()):
            legal = self._legal_values(layer_type, param, current)
            if len(legal) <= 1 or self.config.py_rng.random() >= self.mutation_probability:
                continue
            new_value = self._least_used(layer_type, param, legal, current)
            if new_value != current:
                result[param] = new_value
                changed[param] = (current, new_value)
        return result

    def _boundary_values(self, param, current):
        if param in self._SPATIAL_PARAMS:
            values = self.INTEGER_BOUNDARIES
            if isinstance(current, (tuple, list)):
                typ = tuple if isinstance(current, tuple) else list
                return [typ([v] * len(current)) for v in values]
            return values
        if isinstance(current, bool):
            return (False, True)
        if isinstance(current, int):
            return self.INTEGER_BOUNDARIES
        if isinstance(current, float):
            if param in self._RATE_PARAMS:
                return self.RATE_BOUNDARIES
            if param in self._EPSILON_PARAMS:
                return tuple(v for v in self.RATE_BOUNDARIES if v > 0.0)
            if param in self._REAL_PARAMS:
                return self.REAL_BOUNDARIES
        return (current,)

    def boundary_value(self, layer_type, args, input_shape=None):
        """BV: select from explicit powers-of-two and numeric boundary sets."""
        del input_shape
        if not self.config.is_enabled('bv'):
            return args
        result = dict(args)
        changed = self.last_changes.setdefault('bv', {})
        supported = (self._POSITIVE_INTEGER_PARAMS | self._SPATIAL_PARAMS |
                     self._RATE_PARAMS | self._REAL_PARAMS | self._EPSILON_PARAMS)
        numeric = [(p, v) for p, v in result.items()
                   if p in supported and
                   isinstance(v, (int, float, tuple, list)) and not isinstance(v, bool)]
        if not numeric:
            return result
        param, current = self.config.py_rng.choice(numeric)
        candidates = self._boundary_values(param, current)
        new_value = self._least_used(layer_type, 'BV:' + param, candidates, current)
        if new_value != current:
            result[param] = new_value
            changed[param] = (current, new_value)
        return result

    def input_type(self, dtype=None):
        """IT: select a least-used supported numeric input dtype."""
        current = dtype or 'float32'
        if not self.config.is_enabled('it'):
            return current
        return self._least_used('input_object', 'dtype', self.INPUT_DTYPES, current)

    def mutate_layer_args(self, layer_type, args, input_shape=None):
        self.last_changes = {}
        result = self.parameter_value(layer_type, args)
        result = self.boundary_value(layer_type, result, input_shape)
        self.last_changes = {op: changes for op, changes in self.last_changes.items() if changes}
        return result

    def pop_last_changes(self):
        changes = self.last_changes
        self.last_changes = {}
        return changes


class NeuronMutator(object):
    """Shape-preserving neuron mutation with structured provenance."""

    def __init__(self, config, noise_scale=0.1, scale_range=(0.1, 10.0)):
        self.config = config
        self.noise_scale = float(noise_scale)
        self.scale_range = tuple(scale_range)
        self.last_report = None

    @staticmethod
    def _checksum(array):
        return hashlib.sha256(np.ascontiguousarray(array).view(np.uint8)).hexdigest()

    @staticmethod
    def _changed(before, after):
        return int(np.count_nonzero(np.asarray(before) != np.asarray(after)))

    def mutate_weights(self, weights):
        result, report = self.mutate_weights_with_report(weights)
        self.last_report = report
        return result

    def mutate_weights_with_report(self, weights):
        if not weights:
            report = {'operators': [], 'tensor_count': 0, 'changed_values': 0}
            self.last_report = report
            return weights, report
        original = [np.array(w, copy=True) for w in weights]
        result = [w.copy() for w in original]
        operators = []
        for op, func in (('nf', self.noise_fuzzing),
                         ('ws', self.weight_scaling),
                         ('wr', self.weight_rotation)):
            if not self.config.is_enabled(op):
                continue
            before = [w.copy() for w in result]
            result, details = func(result, return_details=True)
            changed_values = sum(self._changed(a, b) for a, b in zip(before, result))
            operators.append({
                'operator': op,
                'changed_tensors': sum(int(self._changed(a, b) > 0) for a, b in zip(before, result)),
                'changed_values': changed_values,
                'details': details,
            })
        actual_changed = [self._changed(a, b) for a, b in zip(original, result)]
        report = {
            'operators': operators,
            'tensor_count': len(result),
            'changed_tensors': sum(int(count > 0) for count in actual_changed),
            'changed_values': sum(actual_changed),
            'operator_change_events': sum(item['changed_values'] for item in operators),
            'shapes': [list(w.shape) for w in result],
            'checksums': [self._checksum(w) for w in result],
        }
        self.last_report = report
        return result, report

    def noise_fuzzing(self, weights, sigma=None, return_details=False):
        """NF using Laplace, centred-exponential, and sinusoidal noise."""
        sigma = self.noise_scale if sigma is None else float(sigma)
        result = []
        distributions = []
        for w in weights:
            if not np.issubdtype(w.dtype, np.floating):
                result.append(w.copy())
                distributions.append('skipped_non_float')
                continue
            distribution = self.config.py_rng.choice(('laplace', 'exponential', 'sinusoidal'))
            if distribution == 'laplace':
                noise = self.config.np_rng.laplace(0.0, sigma, size=w.shape)
            elif distribution == 'exponential':
                noise = self.config.np_rng.exponential(sigma, size=w.shape) - sigma
            else:
                phase = self.config.py_rng.uniform(0.0, 2.0 * np.pi)
                frequency = self.config.py_rng.uniform(0.5, 2.0)
                positions = np.arange(w.size, dtype=np.float64).reshape(w.shape)
                noise = sigma * np.sin(frequency * positions + phase)
            result.append((w + noise.astype(w.dtype, copy=False)).astype(w.dtype, copy=False))
            distributions.append(distribution)
        details = {'distributions': distributions, 'scale': sigma}
        return (result, details) if return_details else result

    def weight_scaling(self, weights, scale_range=None, return_details=False):
        scale_range = self.scale_range if scale_range is None else tuple(scale_range)
        scale = self.config.py_rng.uniform(*scale_range)
        result = [(w * np.asarray(scale, dtype=w.dtype)).astype(w.dtype, copy=False)
                  if np.issubdtype(w.dtype, np.number) else w.copy() for w in weights]
        details = {'scale': scale}
        return (result, details) if return_details else result

    def _orthogonal_matrix(self, size, dtype):
        raw = self.config.np_rng.normal(size=(size, size))
        q, r = np.linalg.qr(raw)
        signs = np.sign(np.diag(r))
        signs[signs == 0] = 1.0
        q = q * signs
        return q.astype(dtype, copy=False)

    def weight_rotation(self, weights, return_details=False):
        """WR: shape-preserving right multiplication ``W' = W R``."""
        result = []
        rotations = []
        for w in weights:
            if w.ndim < 2 or w.shape[-1] < 2 or not np.issubdtype(w.dtype, np.floating):
                result.append(w.copy())
                rotations.append({'applied': False, 'reason': 'rank_or_dtype'})
                continue
            size = int(w.shape[-1])
            rotation = self._orthogonal_matrix(size, w.dtype)
            flat = w.reshape((-1, size))
            rotated = np.matmul(flat, rotation).reshape(w.shape).astype(w.dtype, copy=False)
            orthogonality_error = float(np.linalg.norm(
                rotation.T.dot(rotation) - np.eye(size, dtype=rotation.dtype)))
            norm_error = float(abs(np.linalg.norm(rotated) - np.linalg.norm(w)))
            result.append(rotated)
            rotations.append({
                'applied': True,
                'axis_size': size,
                'orthogonality_error': orthogonality_error,
                'frobenius_norm_error': norm_error,
            })
        details = {'rotations': rotations}
        return (result, details) if return_details else result


if __name__ == '__main__':
    cfg = MutationConfig(seed=7)
    vm = ValueMutator(cfg, mutation_probability=1.0)
    nm = NeuronMutator(cfg)
    print(vm.mutate_layer_args('dense', {'units': 3, 'activation': 'relu'}))
    changed, provenance = nm.mutate_weights_with_report([
        np.arange(15, dtype=np.float32).reshape(3, 5),
        np.ones(5, dtype=np.float32),
    ])
    print([w.shape for w in changed], provenance)
