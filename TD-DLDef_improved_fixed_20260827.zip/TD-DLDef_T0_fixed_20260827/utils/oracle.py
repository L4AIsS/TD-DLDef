# -*- coding: utf-8 -*-
"""
Oracle 测试预言机制与缺陷统计模块

对应论文 Section IV-D (Test Oracles) 与实验 2 (各框架缺陷类型统计):

    Oracle 1 - Crash 缺陷:      模型生成 / 训练 / 推理阶段进程异常退出
                                 (退出码 255 / 1 / -1, 或子进程超时被杀);
    Oracle 2 - NaN/Inf 缺陷:    层输出 / 损失中出现 NaN 或 Inf (数值不稳定);
    Oracle 3 - Inconsistency:   同一模型在两个框架上输出 / 损失 / 损失梯度
                                 的差异 delta 超过阈值 (跨框架不一致)。

本模块提供:
    * classify_run_status():    按退出码判定 Crash 缺陷;
    * detect_nan_inf():         检查输出数组中的 NaN / Inf;
    * is_inconsistent():        delta 阈值判定 (Inconsistency);
    * DefectCollector:          跨模型聚合每个框架的缺陷计数,
                                 输出论文实验 2 所需的统计表。
"""

from typing import Dict, List, Optional
import numpy as np

# Crash 退出码 (论文中定义: 255 / 1 / -1)
CRASH_EXIT_CODES = (255, 1, -1)

# 缺陷类型
DEFECT_CRASH = 'crash'
DEFECT_NAN = 'nan'
DEFECT_INF = 'inf'
DEFECT_INCONSISTENCY = 'inconsistency'
DEFECT_TYPES = (DEFECT_CRASH, DEFECT_NAN, DEFECT_INF, DEFECT_INCONSISTENCY)

# Inconsistency 判定阈值 (与原论文 scripts/incons/*.py 中 delta_threshold=0.15 保持一致)
DEFAULT_THRESHOLD = 0.15


# ---------------------------------------------------------------------- #
# Oracle 判定函数
# ---------------------------------------------------------------------- #
def classify_run_status(exit_code: Optional[int]) -> str:
    """Oracle 1 (Crash): 按进程退出码判定是否发生 Crash 缺陷

    :param exit_code: 子进程退出码 (None 表示进程未运行/结果未知)
    :return: 'crash' / 'ok'
    """
    if exit_code is None:
        return 'ok'
    if exit_code in CRASH_EXIT_CODES:
        return DEFECT_CRASH
    return 'ok'


def detect_nan_inf(outputs_data: Optional[dict]) -> List[str]:
    """Oracle 2 (NaN/Inf): 检查各层输出中是否存在 NaN / Inf

    :param outputs_data: {layer_name: np.ndarray}
    :return: 检测到的缺陷类型列表, 如 ['nan', 'inf']
    """
    if not outputs_data:
        return []
    has_nan, has_inf = False, False
    for arr in outputs_data.values():
        try:
            arr = np.asarray(arr)
            if arr.dtype.kind in ('f', 'c') and arr.size:
                if np.isnan(arr).any():
                    has_nan = True
                if np.isinf(arr).any():
                    has_inf = True
        except Exception:
            continue
        if has_nan and has_inf:
            break
    defects = []
    if has_nan:
        defects.append(DEFECT_NAN)
    if has_inf:
        defects.append(DEFECT_INF)
    return defects


def is_inconsistent(delta, threshold: float = DEFAULT_THRESHOLD) -> bool:
    """Oracle 3 (Inconsistency): delta 超过阈值即判定为不一致

    :param delta:     跨框架差异 (model_output_delta / loss_delta / loss_grads_delta)
    :param threshold: 判定阈值, 默认 0 (任何非零差异)
    :return: True 表示存在不一致缺陷
    """
    if delta is None:
        return False
    try:
        return float(delta) > threshold
    except (TypeError, ValueError):
        return False


def has_nan_or_inf(value) -> bool:
    """辅助: 判断单个数值/数组是否含 NaN 或 Inf"""
    if value is None:
        return False
    try:
        arr = np.asarray(value)
        if arr.dtype.kind not in ('f', 'c'):
            return False
        return bool(np.isnan(arr).any() or np.isinf(arr).any())
    except Exception:
        return False


# ---------------------------------------------------------------------- #
# 缺陷聚合统计
# ---------------------------------------------------------------------- #
class DefectCollector(object):
    """跨模型聚合每个框架/后端对上的缺陷计数

    用于实验 2: 统计在各个框架上检测出多少 crash / NaN / Inf / Inconsistency 缺陷。
    计数语义 (与论文一致):
        * crash / nan / inf: 一个 (模型, 框架) 二元组记一次缺陷;
        * inconsistency: 一个 (模型, 后端对) 二元组记一次缺陷
          (即某模型在两个框架上的行为不一致)。
    """

    def __init__(self, backends: List[str], threshold: float = DEFAULT_THRESHOLD):
        self.__backends = list(backends)
        self.__threshold = threshold
        # backend -> {defect_type: count}
        self.__backend_defects = {bk: {d: 0 for d in (DEFECT_CRASH, DEFECT_NAN, DEFECT_INF)}
                                  for bk in backends}
        # backend_pair -> inconsistency count
        self.__pair_incons = {}
        # 统计过的模型数
        self.__model_cnt = 0

    @property
    def model_cnt(self):
        return self.__model_cnt

    @property
    def threshold(self):
        return self.__threshold

    # ------------------------------------------------------------------ #
    def record_generate_fail(self, backend: str):
        """记录模型生成阶段的 Crash 缺陷 (框架无法构建该模型)"""
        if backend in self.__backend_defects:
            self.__backend_defects[backend][DEFECT_CRASH] += 1

    def record_model(self, model_id: int, status: Dict[str, Optional[int]],
                     backends_outputs: Dict[str, dict],
                     pair_deltas: Optional[Dict[str, Dict[str, float]]] = None):
        """记录一个模型的训练/比较结果

        :param model_id:         模型 ID
        :param status:           {backend: exit_code}
        :param backends_outputs: {backend: {layer: array}}
        :param pair_deltas:      {backend_pair: {'output': delta, 'loss': delta, 'loss_grads': delta}}
        """
        self.__model_cnt += 1

        # Oracle 1 & 2: 每个框架
        for bk in self.__backends:
            exit_code = status.get(bk, None)
            if classify_run_status(exit_code) == DEFECT_CRASH:
                self.__backend_defects[bk][DEFECT_CRASH] += 1
            defects = detect_nan_inf(backends_outputs.get(bk, None))
            for d in defects:
                if d == DEFECT_NAN:
                    self.__backend_defects[bk][DEFECT_NAN] += 1
                elif d == DEFECT_INF:
                    self.__backend_defects[bk][DEFECT_INF] += 1

        # Oracle 3: 每个后端对
        if pair_deltas:
            for pair, deltas in pair_deltas.items():
                d1 = deltas.get('output')
                d2 = deltas.get('loss')
                d3 = deltas.get('loss_grads')
                if is_inconsistent(d1, self.__threshold) or \
                        is_inconsistent(d2, self.__threshold) or \
                        is_inconsistent(d3, self.__threshold):
                    self.__pair_incons[pair] = self.__pair_incons.get(pair, 0) + 1

    # ------------------------------------------------------------------ #
    def summary(self) -> dict:
        """返回实验 2 所需的统计结果"""
        return {
            'models': self.__model_cnt,
            'threshold': self.__threshold,
            'backend_defects': {bk: dict(c) for bk, c in self.__backend_defects.items()},
            'pair_inconsistency': dict(self.__pair_incons),
            'total': {
                DEFECT_CRASH: sum(c[DEFECT_CRASH] for c in self.__backend_defects.values()),
                DEFECT_NAN: sum(c[DEFECT_NAN] for c in self.__backend_defects.values()),
                DEFECT_INF: sum(c[DEFECT_INF] for c in self.__backend_defects.values()),
                DEFECT_INCONSISTENCY: sum(self.__pair_incons.values()),
            },
        }

    def to_table(self) -> str:
        """格式化为可读的统计表格文本"""
        s = self.summary()
        lines = []
        lines.append(f"{'Framework':<20}{'Crash':>8}{'NaN':>8}{'Inf':>8}")
        for bk, c in s['backend_defects'].items():
            lines.append(f"{bk:<20}{c['crash']:>8}{c['nan']:>8}{c['inf']:>8}")
        lines.append('')
        lines.append("Inconsistency (backend pairs, threshold={}):".format(self.__threshold))
        for pair, cnt in s['pair_inconsistency'].items():
            lines.append(f"  {pair:<20}{cnt:>8}")
        lines.append(f"  {'TOTAL':<20}{s['total'][DEFECT_INCONSISTENCY]:>8}")
        return '\n'.join(lines)


if __name__ == '__main__':
    # 自测
    col = DefectCollector(['tensorflow', 'torch'])
    col.record_model(1, {'tensorflow': 255, 'torch': 0},
                     {'torch': {'dense': np.ones((2, 3))}},
                     pair_deltas={'tensorflow_torch': {'output': None, 'loss': 1.5, 'loss_grads': None}})
    print(col.to_table())
