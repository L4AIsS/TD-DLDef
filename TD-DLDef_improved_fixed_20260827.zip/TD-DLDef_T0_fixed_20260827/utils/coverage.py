# -*- coding: utf-8 -*-
"""
覆盖率统计算法模块: LIC / LPC / LSC
(LPC / LSC 完全参考 COMET 的计算方法; LIC 按用户要求恢复为
TD-DLDef_improved_v3.zip (2026-08-18) 的 v3b「框架理论全集」口径)

--------------------------------------------------------------------------------
COMET (TOSEM'23, Li et al., "COMET: Coverage-guided Model Generation For Deep
Learning Library Testing") Section 3.2 式 (1)-(3) 与 Section 4.1 实验设置。
LPC / LSC 完全参考 COMET 并与其官方实现 (github.com/maybeLee/COMET,
implementations/scripts/coverage/architecture_coverage.py) 的统计口径一致;
LIC 恢复为 0818 v3b 口径 (对应论文 Section IV-C Measurements, 逐层平均):

    式 1  Layer Input Coverage (LIC), 对每个层类型 l:
        CovI(l) = (cov_type(l) + cov_dim(l) + cov_shape(l))
                  / (n_type(l) + n_dim(l) + n_shape(l))
        * n_type  = 8 (IT numeric input dtype universe),
          cov_type = 全部成功模型的输入 dtype 与全集的交集大小 (模型级,
          对各层相同);
        * n_dim   = |possible_input_dims(l)|   (层契约允许的输入维度数,
          0818 v3b 规则表);
        * n_shape = |possible_input_formats(l)| (层契约允许的 (维度数×数据
          布局) 组合; 有 data_format 参数的层为 2×|dims|, 无则 |dims|),
          cov_shape = 已覆盖 (维度数, 布局) 组合数;
        整体 LIC = 框架层池内全部层类型的 CovI(l) 平均值 (逐层平均, 不截断)。

    式 2  Layer Parameter Coverage (LPC), 对每个层类型 l:
        CovP(l) = (Σ_{i=1..N} cov_pi) / (Σ_{i=1..N} n_pi)
        N 为 l 中可变参数 (mutable parameters) 个数; 非数值型 (枚举/布尔)
        参数 n_pi = 文档取值数; 数值型参数取值空间巨大, COMET 用有限整数
        σ 近似其空间大小 (n_pi = σ), 实验中 σ = 5, cov_pi 为已覆盖的不同
        取值数 (不超过 σ)。
        整体 LPC = Σ_l Σ_i cov_pi / Σ_l Σ_i n_pi (COMET 官方实现
        config_coverage 的全局比值口径, 对应 Table 1 "25.9% (530/2049)")。

    式 3  Layer Sequence Coverage (LSC):
        CovS = cov_seq / Σ_i Σ_j sign(|sodim(layer_i) ∩ sidim(layer_j)|)
        分母为所有满足维度约束 (sodim(li) ∩ sidim(lj) ≠ ∅) 的有向层对数量,
        分子为已覆盖且满足同一维度约束的层序列数 (COMET: "all covered layer
        sequences are valid"); sidim/sodim 为层类型可能接受的输入/输出维度
        集合 (由框架文档人工整理, 对应 COMET 的 LayerInputNdim/LayerOutputNdim)。

--------------------------------------------------------------------------------
公式参数设置 (LPC / LSC 沿用 COMET Section 4.1; LIC 为 0818 v3b 理论全集口径):

  1. n_type(l) (LIC): n_type = 8, matching the implemented IT universe,
     ∀l; cov_type 为全部成功模型输入 dtype 与该全集的交集大小 (模型级统计,
     对各层取值相同 —— 0818 v3b 原版语义, 见 compute_lic)。

  2. n_dim(l) = |sidim(l)|: sidim 表按 Keras 3.10 / Keras 2.3.1 文档逐层
     人工整理 (见 SIDIM 表, 已修正原实现中 RNN={3,5}、time_distributed={3,5}、
     repeat_vector=任意维等错误), 与 COMET 的 LayerInputNdim 一致
     (Conv1D={3}, Conv2D={4}, LSTM/GRU/SimpleRNN={3}, RepeatVector={2},
     Flatten 多维, ...); 与生成器维度域 {2,3,4,5} 取交 (被测系统可测试的
     维度范围, COMET 的 LayerInputNdim 亦只含其模型可达维度)。
     注: 该修正表仅用于 LSC; LIC 按 0818 v3b 原版使用其自带的
     possible_input_dims/possible_input_formats 规则表 (见 _lic_input_dims)。

  3. n_shape(l) (LIC, 0818 v3b 口径): n_shape = |possible_input_formats(l)|,
     即层契约允许的 (输入维度数 × 数据布局) 组合数 —— 有 data_format 参数
     的层 (HAS_DATA_FORMAT) 为 2×|dims|, 无则 |dims|; cov_shape = 已覆盖
     的 (维度数, 布局) 组合数 (布局缺省按 channels_last 计)。

  4. LPC 的 N 只统计可变参数 (生成器会随机化或被 PV/BV 突变触及的参数),
     固定常量 (如 kernel_initializer='random_uniform'、regularizer=None)
     不计入; 参数空间分两类 (COMET 式 2 + 官方实现 api_config_pool 约定):
       * 非数值型 (布尔/枚举) 参数: n_pi = 文档取值池大小 (activation/padding
         池按新旧框架区分: 旧框架 (Keras 2.3.1 时代) 无 selu/softplus/causal
         padding, 见 utils/framework_config.py); cov_pi = 池内已覆盖取值数;
       * 数值型参数 (units/filters/kernel_size/momentum/epsilon/dropout/
         结构型 list/tuple 取值等): n_pi = σ = 5 (COMET 对巨大数值空间的
         有限近似), cov_pi = min(已覆盖的不同取值数, 5) —— 与官方实现
         _layer_config_coverage 对 [0] 型 (数值) 参数的计数方式一致
         (按不同原始取值计数, 封顶 σ; 不做等宽分桶, 不单独精确枚举有界整数)。

  5. LSC 分母: 在当前框架层池 (utils/framework_config 决定, 旧框架层池
     移除不受支持的层) 内统计满足维度约束的有向层对数, sidim/sodim 采用
     修正后的框架文档表; 分子只计满足同一约束的已覆盖边 (input_object 等
     池外层构成的边不计入), 与式 3 定义一致。

  6. 统计口径: 一次测试任务中基于生成的全部模型跨模型累积 (COMET
     "new layer inputs, parameter values, or sequences that previously
     generated models have not covered"), 分母为框架层池对应的全部可能
     取值空间 (未覆盖层按 0 覆盖计入, 空间仍计入分母), 与 COMET
     "measure the parts of layer API calls exercised by the generated
     models" 的定义一致。
--------------------------------------------------------------------------------
"""

import numpy as np
from collections import defaultdict

# ---------------------------------------------------------------------- #
# 覆盖率空间参数
# ---------------------------------------------------------------------- #
# COMET Section 4.1 的 LIC 空间参数 (v5 起 LIC 已恢复 0818 v3b 理论全集口径,
# 以下两个常量不再参与计算, 仅存档备查)
COMET_DTYPE_SPACE = ('bfloat16', 'double', 'float16', 'float32', 'float64', 'half')
SHAPE_SPACE = 5
# 数值型参数取值空间的有限近似 (COMET σ = 5, LPC 使用)
SIGMA = 5

# 输入数据类型全集 (Input Type Mutation 可产生的测试输入类型空间;
# Must remain identical to ValueMutator.INPUT_DTYPES.
INPUT_DTYPE_UNIVERSE = (
    'float16', 'float32', 'float64',
    'int8', 'int16', 'int32', 'int64', 'uint8',
)

# 拥有 data_format 参数 (channels_last / channels_first) 的层类型
# (0818 v3b LIC 口径, 按 Keras API 契约; 1D 池化/填充/上采样与 dense/RNN/BN 等无该参数)
HAS_DATA_FORMAT = {
    'conv1D', 'conv2D', 'conv3D',
    'separable_conv1D', 'separable_conv2D', 'depthwise_conv2D',
    'conv2D_transpose', 'conv3D_transpose',
    'max_pooling2D', 'max_pooling3D',
    'average_pooling2D', 'average_pooling3D',
    'global_max_pooling2D', 'global_max_pooling3D',
    'global_average_pooling2D', 'global_average_pooling3D',
    'zero_padding2D', 'zero_padding3D',
    'cropping2D', 'cropping3D',
    'up_sampling2D', 'up_sampling3D',
    'locally_connected1D', 'locally_connected2D',
    'convLSTM2D', 'flatten',
}

# 浮点计算层可接受的输入 dtype (int 输入会被框架拒绝 -> 属缺陷而非可覆盖取值)
FLOAT_DTYPES = ('float16', 'float32', 'float64')
# embedding index inputs accept the integer portion of the IT universe.
EMBEDDING_DTYPES = ('int8', 'int16', 'int32', 'int64', 'uint8')

# 生成器维度域 (config['var']['tensor_dimension_range'] 默认 (2, 5))
DEFAULT_DIM_RANGE = (2, 5)
# 生成器元素域 (config['var']['tensor_element_size_range'] 默认 (2, 5);
# 保留为构造参数兼容, 不参与覆盖率分母)
DEFAULT_ELEMENT_RANGE = (2, 5)

# 新框架 (Keras 3.10) 的枚举参数池 (旧框架由 framework_config 收窄)
NEW_ACTIVATION_POOL = ('relu', 'sigmoid', 'softmax', 'softplus',
                       'tanh', 'selu', 'elu', 'linear')
NEW_PADDING_POOL = ('valid', 'same')               # 一般卷积/池化层
NEW_PADDING_POOL_CONV1D = ('valid', 'same', 'causal')  # causal 仅 Conv1D 支持
DATA_FORMAT_POOL = ('channels_last', 'channels_first')
# axis 类参数的取值域: variable_generator.axis() 产生 -1 或 [1, dim-1], dim <= 5
AXIS_DOMAIN = (-1, 1, 2, 3, 4)
# RNN implementation 参数域
IMPLEMENTATION_DOMAIN = (1, 2)

# ---------------------------------------------------------------------- #
# 层维度支持表 (按 Keras 3.10 / Keras 2.3.1 文档整理, 与生成器维度域 {2..5} 取交)
# 对应 COMET 的 LayerInputNdim / LayerOutputNdim (人工收集的层输入/输出维度集)。
# 修正记录 (相对原实现):
#   * LSTM/GRU/simpleRNN 输入仅 3D (原 {3,5} 错误, 5D 是 ConvLSTM2D 的输入);
#   * time_distributed 接受 >=3D -> {3,4,5} (原 {3,5} 漏 4D);
#   * repeat_vector 输入仅 2D (原默认 {2..5} 错误);
#   * convLSTM2D 输出 {4,5} (return_sequences=True -> 5D, 否则 4D; 原仅 {5});
#   * flatten 输入 {2,3,4,5} (Keras 接受 >=2D);
#   * locally_connected1D/2D 输入/输出 {3}/{4} (原默认 {2..5} 错误)。
# ---------------------------------------------------------------------- #
_1D_SPATIAL = ('conv1D', 'separable_conv1D', 'max_pooling1D', 'average_pooling1D',
               'cropping1D', 'up_sampling1D', 'zero_padding1D')
_2D_SPATIAL = ('conv2D', 'separable_conv2D', 'depthwise_conv2D', 'conv2D_transpose',
               'max_pooling2D', 'average_pooling2D', 'cropping2D', 'up_sampling2D',
               'zero_padding2D')
_3D_SPATIAL = ('conv3D', 'conv3D_transpose', 'max_pooling3D', 'average_pooling3D',
               'cropping3D', 'up_sampling3D', 'zero_padding3D')
_GLOBAL_1D = ('global_max_pooling1D', 'global_average_pooling1D')
_GLOBAL_2D = ('global_max_pooling2D', 'global_average_pooling2D')
_GLOBAL_3D = ('global_max_pooling3D', 'global_average_pooling3D')
_RNN = ('LSTM', 'GRU', 'simpleRNN')
_ANY_DIM = ('dense', 'batch_normalization', 'reshape', 'permute',
            'activation', 'ReLU', 'softmax', 'leakyReLU', 'PReLU', 'ELU',
            'masking', 'concatenate', 'average', 'maximum', 'minimum',
            'add', 'subtract', 'multiply', 'dot')
_FULL_DIMS = frozenset(range(DEFAULT_DIM_RANGE[0], DEFAULT_DIM_RANGE[1] + 1))  # {2,3,4,5}


def _build_sidim():
    t = {}
    for lt in _1D_SPATIAL:
        t[lt] = {3}
    for lt in _2D_SPATIAL:
        t[lt] = {4}
    for lt in _3D_SPATIAL:
        t[lt] = {5}
    for lt in _GLOBAL_1D:
        t[lt] = {3}
    for lt in _GLOBAL_2D:
        t[lt] = {4}
    for lt in _GLOBAL_3D:
        t[lt] = {5}
    for lt in _RNN:
        t[lt] = {3}
    t['convLSTM2D'] = {5}
    t['time_distributed'] = {3, 4, 5}
    t['embedding'] = {2}
    t['flatten'] = set(_FULL_DIMS)
    t['repeat_vector'] = {2}
    for lt in _ANY_DIM:
        t[lt] = set(_FULL_DIMS)
    t['locally_connected1D'] = {3}
    t['locally_connected2D'] = {4}
    return t


def _build_sodim():
    t = {}
    for lt in _1D_SPATIAL:
        t[lt] = {3}
    for lt in _2D_SPATIAL:
        t[lt] = {4}
    for lt in _3D_SPATIAL:
        t[lt] = {5}
    for lt in _GLOBAL_1D + _GLOBAL_2D + _GLOBAL_3D:
        t[lt] = {2}
    for lt in _RNN:
        t[lt] = {2, 3}          # return_sequences=True -> 3D, 否则 2D
    t['convLSTM2D'] = {4, 5}    # return_sequences=True -> 5D, 否则 4D
    t['time_distributed'] = {3, 4, 5}
    t['embedding'] = {3}        # (batch, seq) -> (batch, seq, output_dim)
    t['flatten'] = {2}
    t['repeat_vector'] = {3}
    for lt in _ANY_DIM:
        t[lt] = set(_FULL_DIMS)
    t['locally_connected1D'] = {3}
    t['locally_connected2D'] = {4}
    return t


SIDIM = _build_sidim()
SODIM = _build_sodim()


def supported_dtypes(layer_type):
    """层类型在目标框架中可接受的输入 dtype 集合 (与全集 U 的交)

    仅用于记录阶段的 dtype 过滤与诊断 (0818 v3b LIC 口径不按层使用该
    过滤集做分母, 其 n_type=3 为模型级全集)。
    """
    if layer_type == 'input_object':
        return set(INPUT_DTYPE_UNIVERSE)
    if layer_type == 'embedding':
        return set(EMBEDDING_DTYPES)
    return set(FLOAT_DTYPES)


# ---------------------------------------------------------------------- #
# LPC 参数空间规范: layer_type -> {param: kind}
#   kind 说明 (对应 COMET 式 2 的 n_pi 取值, 与官方实现 api_config_pool 一致):
#     'bool'        -> 非数值型, n = 2
#     ('cat', pool) -> 非数值型 (枚举), n = len(pool); pool 为
#                      'activation'/'padding'/'padding1d'/'data_format' 时
#                      按新旧框架取对应池
#     ('cat_opt', pool) -> 可空枚举, None 具体化为框架默认值后按枚举计
#                      (COMET 经 get_config() 读取的是具体化后的值),
#                      n = len(pool)
#     'int'         -> 数值型, n = σ = 5, cov = min(不同取值数, 5)
#     'int_opt'     -> 可空数值型, None 计为一个不同取值, n = σ = 5
#     ('cont', lo, hi)     -> 数值型 (连续浮点), n = σ = 5,
#                      cov = min(不同取值数, 5); (lo, hi) 为采样区间, 仅存档,
#                      COMET 按不同原始取值计数, 不做等宽分桶
#     ('cont_opt', lo, hi) -> 可空连续浮点, None 计为一个不同取值, n = σ = 5
#     'struct'      -> 数值型 (list/tuple 结构, 取值随输入形状变化),
#                      n = σ = 5, cov = min(不同取值数, 5)
# 只统计可变参数; 固定常量 (initializer/regularizer/constraint=None 等) 不计入。
# ---------------------------------------------------------------------- #
_CONV_COMMON = {
    'filters': 'int', 'kernel_size': 'struct', 'strides': 'struct',
    'padding': ('cat', 'padding'), 'data_format': ('cat', 'data_format'),
    'dilation_rate': 'struct', 'activation': ('cat', 'activation'),
    'use_bias': 'bool',
}
_RNN_COMMON = {
    'units': 'int', 'activation': ('cat', 'activation'),
    'recurrent_activation': ('cat', 'activation'), 'use_bias': 'bool',
    'dropout': ('cont', 0.0, 1.0), 'recurrent_dropout': ('cont', 0.0, 1.0),
    'return_sequences': 'bool', 'go_backwards': 'bool', 'unroll': 'bool',
}

MUTABLE_PARAM_SPACE = {
    'dense': {'units': 'int', 'activation': ('cat', 'activation'), 'use_bias': 'bool'},
    'activation': {'activation': ('cat', 'activation')},
    'embedding': {'output_dim': 'int'},   # input_dim 固定为 vocabulary_size, 不可变
    'masking': {'mask_value': ('cont', -10.0, 10.0)},

    'conv1D': {**_CONV_COMMON, 'padding': ('cat', 'padding1d')},
    'conv2D': dict(_CONV_COMMON),
    'conv3D': dict(_CONV_COMMON),
    'separable_conv1D': {**_CONV_COMMON, 'depth_multiplier': 'int'},
    'separable_conv2D': {**_CONV_COMMON, 'depth_multiplier': 'int'},
    'depthwise_conv2D': {'kernel_size': 'struct', 'strides': 'struct',
                         'padding': ('cat', 'padding'), 'depth_multiplier': 'int',
                         'data_format': ('cat', 'data_format'),
                         'activation': ('cat', 'activation'), 'use_bias': 'bool'},
    'conv2D_transpose': {k: v for k, v in _CONV_COMMON.items() if k != 'dilation_rate'},
    'conv3D_transpose': {k: v for k, v in _CONV_COMMON.items() if k != 'dilation_rate'},

    'max_pooling1D': {'pool_size': 'int', 'strides': 'int_opt', 'padding': ('cat', 'padding')},
    'average_pooling1D': {'pool_size': 'int', 'strides': 'int_opt', 'padding': ('cat', 'padding')},
    'max_pooling2D': {'pool_size': 'struct', 'strides': 'struct', 'padding': ('cat', 'padding'),
                      'data_format': ('cat', 'data_format')},
    'average_pooling2D': {'pool_size': 'struct', 'strides': 'struct', 'padding': ('cat', 'padding'),
                          'data_format': ('cat', 'data_format')},
    'max_pooling3D': {'pool_size': 'struct', 'strides': 'struct', 'padding': ('cat', 'padding'),
                      'data_format': ('cat', 'data_format')},
    'average_pooling3D': {'pool_size': 'struct', 'strides': 'struct', 'padding': ('cat', 'padding'),
                          'data_format': ('cat', 'data_format')},
    'global_max_pooling1D': {},
    'global_average_pooling1D': {},
    'global_max_pooling2D': {'data_format': ('cat', 'data_format')},
    'global_average_pooling2D': {'data_format': ('cat', 'data_format')},
    'global_max_pooling3D': {'data_format': ('cat', 'data_format')},
    'global_average_pooling3D': {'data_format': ('cat', 'data_format')},

    'LSTM': {**_RNN_COMMON, 'unit_forget_bias': 'bool', 'implementation': ('cat', 'implementation')},
    'GRU': {**_RNN_COMMON, 'implementation': ('cat', 'implementation'), 'reset_after': 'bool'},
    'simpleRNN': {k: v for k, v in _RNN_COMMON.items()
                  if k not in ('recurrent_activation',)},
    'convLSTM2D': {**_CONV_COMMON, 'recurrent_activation': ('cat', 'activation'),
                   'unit_forget_bias': 'bool', 'return_sequences': 'bool',
                   'dropout': ('cont', 0.0, 1.0), 'recurrent_dropout': ('cont', 0.0, 1.0)},
    'time_distributed': {},   # 外层无可变参数; 内层作为独立层类型统计
    'bidirectional': {'merge_mode': ('cat', ('sum', 'mul', 'concat', 'ave'))},

    'batch_normalization': {'axis': ('cat', 'axis'), 'momentum': ('cont', 0.0, 1.0),
                            'epsilon': ('cont', 0.0, 1.0), 'center': 'bool', 'scale': 'bool'},
    'reshape': {'target_shape': 'struct'},
    'flatten': {'data_format': ('cat_opt', 'data_format')},   # None = 框架默认 channels_last
    'repeat_vector': {'n': 'int'},
    'permute': {'dims': 'struct'},
    'cropping1D': {'cropping': 'struct'},
    'cropping2D': {'cropping': 'struct', 'data_format': ('cat', 'data_format')},
    'cropping3D': {'cropping': 'struct', 'data_format': ('cat', 'data_format')},
    'up_sampling1D': {'size': 'int'},
    'up_sampling2D': {'size': 'struct', 'data_format': ('cat', 'data_format')},
    'up_sampling3D': {'size': 'struct', 'data_format': ('cat', 'data_format')},
    'zero_padding1D': {'padding': 'struct'},
    'zero_padding2D': {'padding': 'struct', 'data_format': ('cat', 'data_format')},
    'zero_padding3D': {'padding': 'struct', 'data_format': ('cat', 'data_format')},
    'locally_connected1D': {k: v for k, v in _CONV_COMMON.items() if k != 'dilation_rate'},
    'locally_connected2D': {k: v for k, v in _CONV_COMMON.items() if k != 'dilation_rate'},

    'ReLU': {'max_value': ('cont_opt', 0.0, 10.0)},
    'softmax': {'axis': ('cat', 'axis')},
    'leakyReLU': {'alpha': ('cont', 0.0, 1.0)},
    'PReLU': {'shared_axes': 'struct'},
    'ELU': {'alpha': ('cont', 0.0, 1.0)},

    'concatenate': {'axis': ('cat', 'axis')},
    'dot': {'axes': 'struct', 'normalize': 'bool'},
    'add': {}, 'subtract': {}, 'multiply': {},
    'average': {}, 'maximum': {}, 'minimum': {},
}


class CoverageTracker(object):
    """记录一次测试任务中生成的全部模型, 计算 LIC / LPC / LSC

    统计口径: 跨全部成功生成的模型累积 (COMET: "previously generated models
    have not covered"); 分母为框架层池对应的 COMET 可能取值空间
    (见模块 docstring, 完全参考 COMET Section 3.2 式 (1)-(3) 与
    Section 4.1 参数设置)。
    """

    def __init__(self, layer_types, layer_conditions=None,
                 dtype_universe=INPUT_DTYPE_UNIVERSE,
                 activation_pool=None, padding_pool=None,
                 element_range=DEFAULT_ELEMENT_RANGE,
                 dim_range=DEFAULT_DIM_RANGE, sigma=SIGMA):
        """
        :param layer_types:      当前框架层池 (framework_config 提供)
        :param layer_conditions: 层可用性条件 (保留兼容, 不直接参与计算)
        :param dtype_universe:   IT 突变的 datatype 全集 (仅记录阶段使用;
                                 LIC 分母为 COMET 6 元 dtype 集合)
        :param activation_pool:  该框架 activation 参数取值池 (默认新框架 8 值)
        :param padding_pool:     该框架 padding 取值池 (conv1D 自动附加 causal;
                                 旧框架池不含 causal 时 conv1D 也不附加)
        :param element_range:    生成器元素采样域 (保留兼容, 不参与 COMET 分母)
        :param dim_range:        生成器维度采样域 (sidim/sodim 与之取交)
        :param sigma:            数值型参数的空间近似粒度 (COMET σ, 默认 5)
        """
        self.layer_types = list(layer_types)
        self.layer_conditions = layer_conditions
        self.dtype_universe = list(dtype_universe)
        self.activation_pool = tuple(activation_pool) if activation_pool else NEW_ACTIVATION_POOL
        self.padding_pool = tuple(padding_pool) if padding_pool else NEW_PADDING_POOL_CONV1D
        self.element_range = tuple(element_range)
        self.dim_range = tuple(dim_range)
        self.sigma = int(sigma)

        # 维度域交集后的 sidim/sodim (缓存, 对应 COMET LayerInputNdim/LayerOutputNdim)
        dims = set(range(self.dim_range[0], self.dim_range[1] + 1))
        self._sidim = {lt: (set(SIDIM.get(lt, _FULL_DIMS)) & dims) for lt in self.layer_types}
        self._sodim = {lt: (set(SODIM.get(lt, _FULL_DIMS)) & dims) for lt in self.layer_types}

        # LIC (0818 v3b 理论全集口径) 专用覆盖记录:
        # 与 0818 原版 record_model 的 LIC 记录规则完全一致 —— 跳过
        # input_object、不展开包装层、仅记 len>=2 的输入形状
        self._lic_dtypes = set()                          # 模型级输入 dtype 集合
        self._lic_dims = defaultdict(set)                 # l -> {输入维度数}
        self._lic_formats = defaultdict(set)              # l -> {(维度数, 布局)}

        # 尝试记录 (保留接口, 仅用于诊断, 不参与分母)
        self.attempt_cnt = defaultdict(int)

        # 成功模型中的覆盖子集 (跨全部模型累积)
        self.covered_shapes = defaultdict(set)                 # l -> {shape tuple}
        self.covered_dims = defaultdict(set)                   # l -> {dim int}
        self.covered_dtypes = defaultdict(set)                 # l -> {dtype}
        self.covered_params = defaultdict(lambda: defaultdict(set))  # l -> p -> {value}
        self.covered_edges = set()                             # {(pre_type, type)}

        self.models = []
        self.model_cnt = 0

    # ------------------------------------------------------------------ #
    # 参数空间解析 (COMET 式 2: 枚举型 n_pi = 文档取值数; 数值型 n_pi = σ)
    # ------------------------------------------------------------------ #
    def _resolve_cat_pool(self, ref):
        """解析枚举池引用 ('activation'/'padding'/'padding1d'/'data_format'/'axis'/'implementation')"""
        if ref == 'activation':
            return list(self.activation_pool)
        if ref == 'padding':
            # 一般层: 框架 padding 池去掉 causal (causal 仅 Conv1D 支持)
            return [p for p in self.padding_pool if p != 'causal'] or list(NEW_PADDING_POOL)
        if ref == 'padding1d':
            return list(self.padding_pool)
        if ref == 'data_format':
            return list(DATA_FORMAT_POOL)
        if ref == 'axis':
            return list(AXIS_DOMAIN)
        if ref == 'implementation':
            return list(IMPLEMENTATION_DOMAIN)
        return list(ref)

    def _is_numeric_spec(self, spec):
        """COMET 式 2 的数值型参数 (n_pi = σ): int/float/结构型取值"""
        if spec in ('int', 'int_opt', 'struct'):
            return True
        return isinstance(spec, tuple) and spec[0] in ('cont', 'cont_opt')

    def _spec_domain_size(self, spec):
        """COMET 式 2 的 n_pi: 非数值型 = 文档取值池大小; 数值型 = σ"""
        if spec == 'bool':
            return 2
        if self._is_numeric_spec(spec):
            return self.sigma
        if isinstance(spec, tuple):
            if spec[0] == 'cat':
                return len(self._resolve_cat_pool(spec[1]))
            if spec[0] == 'cat_opt':
                return len(self._resolve_cat_pool(spec[1]))
        return None

    def _value_key(self, spec, value):
        """把观测到的参数值映射为取值空间中的 hashable key (None 表示不计入)

        与 COMET 官方实现 _layer_config_coverage 的计数方式一致:
          * 枚举型: 取值池内的不同取值 (池外取值不计入);
          * 数值型: 不同原始取值 (None 对可空参数计为一个取值)。
        """
        if value is None:
            # 可空参数: None (框架默认值) 计为一个不同取值
            #   - cat_opt: COMET 经 get_config() 读到的是具体化默认值
            #     (data_format 的 None 即 'channels_last'), 具体化后按枚举计
            #   - int_opt/cont_opt: None 作为数值型的一个不同取值
            if isinstance(spec, tuple) and spec[0] == 'cat_opt':
                pool = self._resolve_cat_pool(spec[1])
                if spec[1] == 'data_format':
                    value = 'channels_last'      # Keras get_config() 的具体化默认值
                else:
                    value = pool[0] if pool else None
            elif spec in ('int_opt',) or (isinstance(spec, tuple) and spec[0] == 'cont_opt'):
                return '<default>'
            else:
                return None                      # 规范外取值 (不应出现), 不计入
        if spec == 'bool':
            return bool(value)
        if self._is_numeric_spec(spec):
            return self._normalize(value)        # 数值型: 原始取值本身 (σ 近似空间)
        if isinstance(spec, tuple):
            if spec[0] in ('cat', 'cat_opt'):
                pool = self._resolve_cat_pool(spec[1])
                return value if value in pool else None
        return None

    @staticmethod
    def _normalize(value):
        """归一化参数值 (list->tuple, np 标量->python) 使其可哈希"""
        if isinstance(value, (list, tuple)):
            return tuple(CoverageTracker._normalize(v) for v in value)
        try:
            import numpy as _np
            if isinstance(value, _np.generic):
                return value.item()
        except Exception:
            pass
        return value

    # ------------------------------------------------------------------ #
    # 记录接口
    # ------------------------------------------------------------------ #
    def record_attempt(self, layer_type, input_shape=None, args=None):
        """记录一次层生成尝试 (仅诊断用途, 不参与覆盖率分母)"""
        if layer_type is not None:
            self.attempt_cnt[layer_type] += 1

    def record_model(self, model_info, input_dtype='float32'):
        """记录一个成功生成的模型结构 (跨模型累积覆盖子集)

        :param model_info: 模型结构 dict (与 model.json 同构, key 可为 int 或 str)
        :param input_dtype: 该模型输入的数据类型 (Input Type Mutation 决定)
        """
        self.models.append(model_info)
        self.model_cnt += 1
        self._lic_dtypes.add(input_dtype)     # LIC (0818 v3b): 模型级 dtype 记录

        structure = {str(k): v for k, v in model_info['model_structure'].items()}

        # dtype 传播: input_object 输出 = 模型输入 dtype; embedding 输出 = float32
        # (其 compute dtype); 其余层输出 dtype = 输入 dtype (Keras 3/2 默认
        # floatx 策略下的文档化近似, 用于 cov_type 统计)。
        out_dtype = {}
        for layer_id, layer_info in structure.items():
            layer_type = layer_info['type']
            pre_layers = [str(i) for i in layer_info.get('pre_layers', [])]
            if layer_type == 'input_object' or not pre_layers:
                in_dtype = input_dtype
            else:
                in_dtype = out_dtype.get(pre_layers[0], input_dtype)

            # 记录实际到达该层输入端的 dtype (仅诊断; LIC 的 cov_type 为
            # 模型级统计, 见 self._lic_dtypes / compute_lic)
            if in_dtype in supported_dtypes(layer_type):
                self.covered_dtypes[layer_type].add(in_dtype)

            if layer_type == 'embedding':
                out_dtype[layer_id] = 'float32'
            elif layer_type == 'input_object':
                out_dtype[layer_id] = input_dtype
            else:
                out_dtype[layer_id] = in_dtype

            # 输入形状/维度 (由直接前驱的输出形状决定)
            input_shapes = [structure[p]['output_shape'] for p in pre_layers if p in structure]
            if input_shapes:
                in_shape = tuple(input_shapes[0])
            else:
                in_shape = tuple(layer_info.get('output_shape', ()))
            if in_shape:
                self.covered_shapes[layer_type].add(in_shape)
                self.covered_dims[layer_type].add(len(in_shape))

            # LIC (0818 v3b) 专用记录: 跳过 input_object, 不展开包装层,
            # 仅记 len>=2 的输入形状; 布局取 args.data_format (缺省 channels_last)
            if layer_type != 'input_object' and in_shape and len(in_shape) >= 2:
                self._lic_dims[layer_type].add(len(in_shape))
                fmt = layer_info.get('args', {}).get('data_format', None) \
                    if layer_type in HAS_DATA_FORMAT else None
                if fmt is None:
                    fmt = 'channels_last' if layer_type in HAS_DATA_FORMAT else '-'
                self._lic_formats[layer_type].add((len(in_shape), fmt))

            # 可变参数覆盖 (COMET 式 2: 枚举按池内取值计, 数值按不同取值计)
            self._record_params(layer_type, layer_info.get('args', {}))

            # 包装层 (time_distributed / bidirectional): 内层作为独立层类型统计
            inner = layer_info.get('args', {}).get('layer')
            if isinstance(inner, dict) and 'type' in inner:
                inner_type = inner['type']
                self._record_params(inner_type, inner.get('args', {}))
                if in_shape and len(in_shape) >= 3:
                    inner_in_shape = (in_shape[0], *in_shape[2:])
                    self.covered_shapes[inner_type].add(inner_in_shape)
                    self.covered_dims[inner_type].add(len(inner_in_shape))
                if in_dtype in supported_dtypes(inner_type):
                    self.covered_dtypes[inner_type].add(in_dtype)

            # 边覆盖: pre_layers -> 本层
            for p in pre_layers:
                if p in structure:
                    self.covered_edges.add((structure[p]['type'], layer_type))

    def _record_params(self, layer_type, args):
        spec_map = MUTABLE_PARAM_SPACE.get(layer_type)
        if not spec_map or not args:
            return
        for param, spec in spec_map.items():
            if param not in args:
                continue
            b = self._value_key(spec, args[param])
            if b is not None:
                self.covered_params[layer_type][param].add(b)

    # ------------------------------------------------------------------ #
    # LIC: 层输入覆盖率 (0818 v3b「框架理论全集」口径, 逐层平均)
    # ------------------------------------------------------------------ #
    def compute_lic(self):
        """返回 (整体LIC, 逐层LIC dict)

        分母 (理论全集): n_type=8 (与 IT 实现的数值 dtype 全集一致),
        n_dim=|possible_input_dims(l)|, n_shape=|possible_input_formats(l)|
        —— 全部由框架契约决定, 固定统一; cov_type 为全部成功模型输入 dtype
        与全集的交集大小 (模型级, 对各层相同)。
        整体 LIC = 逐层 CovI(l) 的平均值 (不截断)。
        (2026-08-23 v5: 按用户要求恢复为 TD-DLDef_improved_v3.zip (0818) 的
        LIC 计算代码; LPC / LSC 仍为 COMET 原版口径。)
        """
        per_layer = {}
        cov_type = len([d for d in self.dtype_universe if d in self._lic_dtypes])
        n_type = len(self.dtype_universe)
        for l in self.layer_types:
            dims = self._lic_input_dims(l)
            fmts = self._lic_input_formats(l)
            if not dims and not fmts:
                continue
            n_dim = len(dims)
            n_shape = len(fmts)
            cov_dim = len(self._lic_dims.get(l, set()) & set(dims))
            cov_shape = len(self._lic_formats.get(l, set()) & set(fmts))
            per_layer[l] = (cov_type + cov_dim + cov_shape) / (n_type + n_dim + n_shape)
        if not per_layer:
            return 0.0, {}
        return float(np.mean(list(per_layer.values()))), per_layer

    # ------------------------------------------------------------------ #
    # LIC (0818 v3b) 维度/形状契约规则表 (框架理论全集, 原版逐字恢复;
    # 仅 LIC 使用 —— LSC 仍用修正后的 SIDIM/SODIM 表, 见 compute_lsc)
    # ------------------------------------------------------------------ #
    def _lic_input_dims(self, layer_type):
        """该层类型契约支持的输入维度集合 (0818 v3b 原版规则表)"""
        lt = layer_type
        if lt == 'embedding':
            return {2}
        if lt in ('conv1D', 'separable_conv1D', 'max_pooling1D', 'average_pooling1D',
                  'cropping1D', 'up_sampling1D', 'zero_padding1D',
                  'global_max_pooling1D', 'global_average_pooling1D'):
            return {3}
        if lt in ('conv2D', 'separable_conv2D', 'depthwise_conv2D', 'conv2D_transpose',
                  'max_pooling2D', 'average_pooling2D', 'cropping2D', 'up_sampling2D',
                  'zero_padding2D', 'global_max_pooling2D', 'global_average_pooling2D'):
            return {4}
        if lt in ('conv3D', 'conv3D_transpose', 'convLSTM2D', 'max_pooling3D',
                  'average_pooling3D', 'cropping3D', 'up_sampling3D', 'zero_padding3D',
                  'global_max_pooling3D', 'global_average_pooling3D'):
            return {5}
        if lt in ('LSTM', 'GRU', 'simpleRNN', 'time_distributed'):
            return {3, 5}
        if lt in ('flatten', 'permute', 'reshape', 'repeat_vector', 'locally_connected1D',
                  'locally_connected2D'):
            return set(range(2, 6))
        # dense / activation / norm / merging: 任意维度 (2..5)
        return set(range(2, 6))

    def _lic_input_formats(self, layer_type):
        """该层契约允许的 (输入维度数 × 数据布局) 组合全集 (0818 v3b 原版)"""
        dims = self._lic_input_dims(layer_type)
        if layer_type in HAS_DATA_FORMAT:
            return {(d, 'channels_last') for d in dims} | {(d, 'channels_first') for d in dims}
        return {(d, '-') for d in dims}

    # ------------------------------------------------------------------ #
    # LPC: 层参数覆盖率 (COMET 式 2 + 官方实现全局比值口径)
    # ------------------------------------------------------------------ #
    def compute_lpc(self):
        """返回 (整体LPC, 逐层LPC dict)

        逐层 (式 2):
            CovP(l) = (Σ_{i=1..N} cov_pi) / (Σ_{i=1..N} n_pi)
            N 为可变参数个数; 非数值型 n_pi = 文档取值池大小,
            数值型 n_pi = σ = 5, cov_pi = min(已覆盖不同取值数, n_pi)。
        整体 LPC (COMET 官方实现 config_coverage):
            Σ_l Σ_i cov_pi / Σ_l Σ_i n_pi
            (无可变参数的层分子分母均为 0, 不影响整体比值;
            未覆盖层贡献 0 覆盖值, 其参数空间仍计入分母)。
        """
        per_layer = {}
        cov_sum = 0
        total_sum = 0
        for l in self.layer_types:
            spec_map = MUTABLE_PARAM_SPACE.get(l)
            if not spec_map:
                continue                       # 无可变参数, 分子分母均为 0
            num = den = 0
            for param, spec in spec_map.items():
                n_p = self._spec_domain_size(spec)
                if not n_p:
                    continue
                cov_p = len(self.covered_params.get(l, {}).get(param, set()))
                num += min(cov_p, n_p)         # 覆盖数不超过空间大小 (COMET σ 近似)
                den += n_p
            if den == 0:
                continue
            per_layer[l] = num / den
            cov_sum += num
            total_sum += den
        if not per_layer or total_sum == 0:
            return 0.0, {}
        return cov_sum / total_sum, per_layer

    # ------------------------------------------------------------------ #
    # LSC: 层序列覆盖率 (COMET 式 3)
    # ------------------------------------------------------------------ #
    def compute_lsc(self):
        """返回 (整体LSC, 覆盖序列数, 分母)

        CovS = cov_seq / Σ_i Σ_j sign(|sodim(li) ∩ sidim(lj)|)
        分母为当前框架层池内满足维度约束的有向层对数量,
        分子为已覆盖且满足同一维度约束的层序列数 (COMET: all covered
        layer sequences are valid); sidim/sodim 采用修正后的框架文档表
        (对应 COMET LayerInputNdim/LayerOutputNdim)。
        """
        denom = 0
        for a in self.layer_types:
            sodim = self._sodim.get(a, set())
            if not sodim:
                continue
            for b in self.layer_types:
                sidim = self._sidim.get(b, set())
                if sodim & sidim:
                    denom += 1
        denom = denom or 1
        # 分子: 已覆盖且满足维度约束的层序列数 (input_object 等池外层
        # 构成的边不计入)
        cov_seq = 0
        pool = set(self.layer_types)
        for a, b in self.covered_edges:
            if a in pool and b in pool and (self._sodim.get(a, set()) & self._sidim.get(b, set())):
                cov_seq += 1
        return cov_seq / denom, cov_seq, denom

    # ------------------------------------------------------------------ #
    # 兼容接口 (旧代码调用): 维度支持估计
    # ------------------------------------------------------------------ #
    def possible_input_dims(self, layer_type):
        return set(self._sidim.get(layer_type, _FULL_DIMS))

    def possible_output_dims(self, layer_type):
        return set(self._sodim.get(layer_type, _FULL_DIMS))

    # ------------------------------------------------------------------ #
    def _lic_sums(self):
        """LIC 逐层分子/分母的合计 (0818 v3b 理论全集口径, 供统计明细)

        注意: 整体 LIC 为逐层 CovI(l) 的平均值 (见 compute_lic),
        并非该合计的比值。
        """
        cov_type = len([d for d in self.dtype_universe if d in self._lic_dtypes])
        n_type = len(self.dtype_universe)
        cov_sum = 0
        total_sum = 0
        for l in self.layer_types:
            dims = self._lic_input_dims(l)
            fmts = self._lic_input_formats(l)
            if not dims and not fmts:
                continue
            cov_dim = len(self._lic_dims.get(l, set()) & set(dims))
            cov_shape = len(self._lic_formats.get(l, set()) & set(fmts))
            cov_sum += cov_type + cov_dim + cov_shape
            total_sum += n_type + len(dims) + len(fmts)
        return cov_sum, total_sum

    def _lpc_sums(self):
        """LPC 全局分子/分母 (COMET 官方实现口径, 供统计明细)"""
        cov_sum = 0
        total_sum = 0
        for l in self.layer_types:
            spec_map = MUTABLE_PARAM_SPACE.get(l)
            if not spec_map:
                continue
            for param, spec in spec_map.items():
                n_p = self._spec_domain_size(spec)
                if not n_p:
                    continue
                cov_p = len(self.covered_params.get(l, {}).get(param, set()))
                cov_sum += min(cov_p, n_p)
                total_sum += n_p
        return cov_sum, total_sum

    def summary(self):
        lic, lic_map = self.compute_lic()
        lpc, lpc_map = self.compute_lpc()
        lsc, cov_seq, denom = self.compute_lsc()
        lic_cov, lic_total = self._lic_sums()
        lpc_cov, lpc_total = self._lpc_sums()
        return {
            'models': self.model_cnt,
            'LIC': round(lic * 100, 2),
            'LPC': round(lpc * 100, 2),
            'LSC': round(lsc * 100, 2),
            'LIC_cov': lic_cov,
            'LIC_denom': lic_total,
            'LPC_cov': lpc_cov,
            'LPC_denom': lpc_total,
            'LSC_cov_seq': cov_seq,
            'LSC_denom': denom,
            'covered_layer_types': len([l for l in self.layer_types
                                        if self.covered_shapes.get(l)]),
            'total_layer_types': len(self.layer_types),
        }

    def detail(self):
        """完整统计 (含逐层明细, 供消融实验落盘)"""
        lic, lic_map = self.compute_lic()
        lpc, lpc_map = self.compute_lpc()
        lsc, cov_seq, denom = self.compute_lsc()
        return {
            'summary': self.summary(),
            'LIC_per_layer': {k: round(v * 100, 2) for k, v in lic_map.items()},
            'LPC_per_layer': {k: round(v * 100, 2) for k, v in lpc_map.items()},
            'LSC_cov_seq': cov_seq,
            'LSC_denom': denom,
            'covered_edges': sorted([list(e) for e in self.covered_edges]),
        }


if __name__ == '__main__':
    # 自测
    from utils.utils import layer_types, layer_conditions
    tracker = CoverageTracker(layer_types, layer_conditions)
    tracker.record_attempt('dense', (None, 4), {'units': 3, 'activation': 'relu'})
    model_info = {
        'model_structure': {
            '0': {'type': 'input_object', 'args': {'name': '00_input_object'},
                  'pre_layers': [], 'output_shape': (None, 4)},
            '1': {'type': 'dense', 'args': {'name': '01_dense', 'units': 3, 'activation': 'relu'},
                  'pre_layers': [0], 'output_shape': (None, 3)},
            '2': {'type': 'dense', 'args': {'name': '02_dense', 'units': 5, 'activation': 'sigmoid'},
                  'pre_layers': [1], 'output_shape': (None, 5)},
        },
        'input_id_list': [0], 'output_id_list': [2],
    }
    tracker.record_model(model_info, input_dtype='float32')
    tracker.record_model(model_info, input_dtype='float64')
    import json
    print(json.dumps(tracker.summary(), indent=2, ensure_ascii=False))
    lic, lic_map = tracker.compute_lic()
    print('dense CovI = {:.4f}'.format(lic_map['dense']))
