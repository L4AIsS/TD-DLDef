from typing import List, Optional
import numpy as np
import random
import sys
from pathlib import Path
from utils.utils import losses, optimizers, CmdProcess
from utils.oracle import classify_run_status, CRASH_EXIT_CODES


class Trainer(object):

    def __init__(self, db_manager, timeout, python_path: Optional[str] = None,
                 defect_reporter=None):
        super().__init__()
        self.__db_manager = db_manager
        self.__timeout = timeout
        # 跨平台: 默认使用当前解释器; 可为每个框架指定 conda 环境中的 python
        self.__python_path = python_path if python_path is not None else sys.executable
        self.__defect_reporter = defect_reporter   # 缺陷记录器 (训练阶段 crash/NaN/Inf)

    def train(self, model_id: int, exp_dir: str, ok_backends: List[str], loss: Optional[str] = None, optimizer: Optional[str] = None):
        # 位置
        model_dir = Path(exp_dir) / 'models'
        training_inputs_path = Path(exp_dir) / 'dataset' / 'inputs.npz'
        ground_truths_path = Path(exp_dir) / 'dataset' / 'ground_truths.npz'

        outputs_dir = Path(exp_dir) / 'layer_outputs'
        loss_dir = Path(exp_dir) / 'loss'
        loss_grads_dir = Path(exp_dir) / 'loss_gradients'
        gradients_dir = Path(exp_dir) / 'layer_gradients'

        outputs_dir.mkdir(parents=True, exist_ok=True)
        loss_dir.mkdir(parents=True, exist_ok=True)
        loss_grads_dir.mkdir(parents=True, exist_ok=True)
        gradients_dir.mkdir(parents=True, exist_ok=True)

        if loss is None:
            loss = random.choice(losses)
        if optimizer is None:
            optimizer = random.choice(optimizers)
        self.__db_manager.record_loss_optimizer(model_id, loss, optimizer)

        # 开始train
        crash_backends, nan_backends, inf_backends = [], [], []
        backends_outputs, backends_losses, backends_loss_grads, backends_grads, backends_weights = {}, {}, {}, {}, {}

        cmd_processes = {
            bk: CmdProcess(f'"{self.__python_path}" -m src.incons_detection.train'
                           f' --backend {bk}'
                           f' --loss {loss}'
                           f' --optimizer {optimizer}'
                           f' --model_path "{str(model_dir / f"{bk}.keras")}"'
                           f' --model_info_path "{str(model_dir / "model.json")}"'
                           f' --training_instances_path "{str(training_inputs_path)}"'
                           f' --ground_truths_path "{str(ground_truths_path)}"'
                           f' --outputs_dir "{str(outputs_dir / bk)}"'
                           f' --loss_path "{str(loss_dir / f"{bk}.txt")}"'
                           f' --loss_grads_dir "{str(loss_grads_dir / bk)}"'
                           f' --gradients_dir "{str(gradients_dir / bk)}"')
                           # f" --weights_dir {str(weights_dir / bk)}")
            for bk in ok_backends
        }
        status = {}
        defect_counts = {bk: {'crash': 0, 'nan': 0, 'inf': 0} for bk in ok_backends}
        for bk, p in cmd_processes.items():  # 改为顺序执行
            extract_status = p.run(self.__timeout)

            print(f"{bk}_status: {extract_status}")
            status[bk] = extract_status
            if extract_status and extract_status in CRASH_EXIT_CODES:  # 发生了output crash
                crash_backends.append(bk)
                defect_counts[bk]['crash'] = 1

            else:
                outputs_data = loss_value = loss_grads_data = grads_data = None  # weights_data = None

                if extract_status == 0 or extract_status >= 2:
                    outputs_data = {fn.stem: np.load(str(fn)) for fn in (outputs_dir / bk).glob("*.npy")}
                if extract_status == 0 or extract_status >= 3:
                    with open(str(loss_dir / f'{bk}.txt'), 'r') as f:
                        loss_value = float(f.read())
                if extract_status == 0 or extract_status >= 4:
                    loss_grads_data = {fn.stem: np.load(str(fn)) for fn in (loss_grads_dir / bk).glob("*.npy")}
                if extract_status == 0 or extract_status >= 5:
                    grads_data = {fn.stem: np.load(str(fn)) for fn in (gradients_dir / bk).glob("*.npy")}
                # if extract_status == 0 or extract_status >= 6:
                #     weights_data = {fn.stem: np.load(str(fn)) for fn in (weights_dir / bk).glob("*.npy")}

                backends_outputs[bk] = outputs_data
                backends_losses[bk] = loss_value
                backends_loss_grads[bk] = loss_grads_data
                backends_grads[bk] = grads_data
                # backends_weights[bk] = weights_data

            if extract_status == 0 or (extract_status != 255 and extract_status >= 2):
                if self.__check(outputs_data, np.isnan):  # 如果存在nan
                    nan_backends.append(bk)
                    defect_counts[bk]['nan'] = 1
                if self.__check(outputs_data, np.isinf):  # 如果存在inf
                    inf_backends.append(bk)
                    defect_counts[bk]['inf'] = 1

        # 记录异常到数据库
        if crash_backends:  # 存在crash
            self.__db_manager.update_model_crash_backends(model_id, crash_backends)
            for bk in crash_backends:
                self.__db_manager.record_crash_defect(model_id, bk)
        if nan_backends:  # 存在nan
            self.__db_manager.update_model_nan_backends(model_id, nan_backends)
            for bk in nan_backends:
                self.__db_manager.record_nan_defect(model_id, bk)
        if inf_backends:  # 存在inf
            self.__db_manager.update_model_inf_backends(model_id, inf_backends)
            for bk in inf_backends:
                self.__db_manager.record_inf_defect(model_id, bk)

        # 缺陷明细记录 (定位到造成缺陷的模型源码片段)
        if self.__defect_reporter is not None and \
                (crash_backends or nan_backends or inf_backends):
            try:
                self.__report_defects(model_id, model_dir, status,
                                      backends_outputs, crash_backends,
                                      nan_backends, inf_backends)
            except Exception:
                import traceback
                traceback.print_exc()

        return status, backends_outputs, backends_losses, backends_loss_grads, backends_grads, [bk for bk in ok_backends if bk not in crash_backends], defect_counts

    def __report_defects(self, model_id, model_dir, status, backends_outputs,
                         crash_backends, nan_backends, inf_backends):
        """把 crash / NaN / Inf 缺陷连同源码片段定位写入 DefectReporter 与数据库"""
        import json
        model_info_path = Path(model_dir) / 'model.json'
        model_info = None
        if model_info_path.exists():
            with open(str(model_info_path), 'r') as f:
                model_info = json.load(f)

        for bk in crash_backends:
            rec = self.__defect_reporter.record(
                model_id, 'crash', bk, model_info, layer_name=None, stage='training',
                detail='training process exited abnormally on %s (exit=%s)'
                       % (bk, status.get(bk)))
            self.__safe_detail(model_id, 'crash', bk, 'training', None,
                               rec.get('model_snippet'), rec.get('detail'))

        # NaN / Inf: 每个后端只做一次层定位, extend_from_localization 会同时记录两者
        for bk in dict.fromkeys(list(nan_backends) + list(inf_backends)):
            if model_info is not None:
                loc = self.__defect_reporter.extend_from_localization(
                    model_id, model_info, bk, backends_outputs.get(bk))
            else:
                loc = {'nan_layer': None, 'inf_layer': None, 'nan_layers': [], 'inf_layers': []}
                if bk in nan_backends:
                    self.__defect_reporter.record(model_id, 'nan', bk, None,
                                                  stage='training', detail='nan in outputs')
                if bk in inf_backends:
                    self.__defect_reporter.record(model_id, 'inf', bk, None,
                                                  stage='training', detail='inf in outputs')
            snippet_of = {}
            if model_info is not None:
                from utils.model_snippet import layer_source_snippet
                for lt in (loc['nan_layer'], loc['inf_layer']):
                    if lt is not None:
                        snippet_of[lt] = layer_source_snippet(model_info, lt)
            if bk in nan_backends:
                self.__safe_detail(model_id, 'nan', bk, 'training', loc['nan_layer'],
                                   snippet_of.get(loc['nan_layer']),
                                   'nan_layers=%s' % loc['nan_layers'])
            if bk in inf_backends:
                self.__safe_detail(model_id, 'inf', bk, 'training', loc['inf_layer'],
                                   snippet_of.get(loc['inf_layer']),
                                   'inf_layers=%s' % loc['inf_layers'])

    def __safe_detail(self, model_id, defect_type, backend, stage, layer, snippet, detail):
        try:
            self.__db_manager.record_defect_detail(model_id, defect_type, backend,
                                                   stage, layer, snippet, detail)
        except Exception:
            pass

    def __check(self, weights, f):
        for w in weights.values():
            if f(w).any():
                return True
        return False
