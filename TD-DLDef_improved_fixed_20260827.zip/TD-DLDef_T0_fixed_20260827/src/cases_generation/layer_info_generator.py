from typing import Tuple, Optional

from .variable_generator import VariableGenerator
from .output_shape_calculator import OutputShapeCalculator
from utils.selection import Selector
from utils.mutation import ValueMutator, MutationConfig
from utils.utils import seq_layer_types, RNN_layer_types, activation_layer_types, merging_layer_types

def _jsonable(v):
    """把 numpy 标量/list 转为可 JSON 序列化的 python 值"""
    try:
        import numpy as _np
        if isinstance(v, _np.generic):
            return v.item()
    except Exception:
        pass
    if isinstance(v, (list, tuple)):
        return [_jsonable(x) for x in v]
    return v


# 值突变后重算输出形状所需的映射: layer_type -> (OutputShapeCalculator 方法名, 额外 kwargs)
SHAPE_RECALC_MAP = {
    'dense': ('dense_layer', {}),
    'embedding': ('embedding_layer', {}),
    'conv1D': ('conv_layer', {'dim_num': 1}),
    'conv2D': ('conv_layer', {'dim_num': 2}),
    'conv3D': ('conv_layer', {'dim_num': 3}),
    'separable_conv1D': ('conv_layer', {'dim_num': 1}),
    'separable_conv2D': ('conv_layer', {'dim_num': 2}),
    'depthwise_conv2D': ('depthwise_conv2D_layer', {}),
    'conv2D_transpose': ('conv_transpose_layer', {'dim_num': 2}),
    'conv3D_transpose': ('conv_transpose_layer', {'dim_num': 3}),
    'max_pooling1D': ('pooling1D_layer', {}),
    'max_pooling2D': ('pooling_layer', {'dim_num': 2}),
    'max_pooling3D': ('pooling_layer', {'dim_num': 3}),
    'average_pooling1D': ('pooling1D_layer', {}),
    'average_pooling2D': ('pooling_layer', {'dim_num': 2}),
    'average_pooling3D': ('pooling_layer', {'dim_num': 3}),
    'global_max_pooling1D': ('global_pooling1D_layer', {}),
    'global_max_pooling2D': ('global_pool_layer', {'dim_num': 2}),
    'global_max_pooling3D': ('global_pool_layer', {'dim_num': 3}),
    'global_average_pooling1D': ('global_pooling1D_layer', {}),
    'global_average_pooling2D': ('global_pool_layer', {'dim_num': 2}),
    'global_average_pooling3D': ('global_pool_layer', {'dim_num': 3}),
    'LSTM': ('RNN', {}),
    'GRU': ('RNN', {}),
    'simpleRNN': ('RNN', {}),
    'convLSTM2D': ('convLSTM2D_layer', {}),
    'repeat_vector': ('repeat_vector_layer', {}),
    'cropping1D': ('cropping_layer', {'dim_num': 1}),
    'cropping2D': ('cropping_layer', {'dim_num': 2}),
    'cropping3D': ('cropping_layer', {'dim_num': 3}),
    'up_sampling1D': ('up_sampling_layer', {'dim_num': 1}),
    'up_sampling2D': ('up_sampling_layer', {'dim_num': 2}),
    'up_sampling3D': ('up_sampling_layer', {'dim_num': 3}),
    'zero_padding1D': ('zero_padding_layer', {'dim_num': 1}),
    'zero_padding2D': ('zero_padding_layer', {'dim_num': 2}),
    'zero_padding3D': ('zero_padding_layer', {'dim_num': 3}),
    # 形状不随值突变改变的层 (保持输入形状)
    'activation': ('activation_layer', {}),
    'ReLU': ('activation_layer', {}),
    'softmax': ('activation_layer', {}),
    'leakyReLU': ('activation_layer', {}),
    'PReLU': ('activation_layer', {}),
    'ELU': ('activation_layer', {}),
    'masking': ('masking_layer', {}),
    'batch_normalization': ('batch_normalization_layer', {}),
    'flatten': ('flatten_layer', {}),
    'permute': ('permute_layer', {}),
    'time_distributed': None,    # 外层参数不参与值突变, 形状由内层决定
}


class LayerInfoGenerator(object):

    def __init__(self, variable_generator: VariableGenerator, selector: Selector,
                 mutation_config: Optional[MutationConfig] = None,
                 coverage_tracker=None,
                 layer_types: Optional[list] = None,
                 selection_max_retries: int = 8):
        super().__init__()
        self.layer_infos = LayerInfo(variable_generator, self)

        # 可选层 (默认全量; 可由 framework_config 指定)
        if layer_types is None:
            from utils.utils import layer_types as _default_layer_types
            layer_types = _default_layer_types
        self.__layer_types = list(layer_types)
        self.__layer_funcs = {name: getattr(self.layer_infos, name + '_layer') for name in self.__layer_types}

        # 值变异器
        self.__mutation_config = mutation_config if mutation_config is not None else MutationConfig()
        self.__value_mutator = ValueMutator(self.__mutation_config,
                                            weight_range=variable_generator.weight_range,
                                            small_value_range=variable_generator.small_value_range,
                                            ele_size_range=variable_generator.ele_size_range)

        # 覆盖率追踪器 (LIC/LPC/LSC)
        self.__coverage_tracker = coverage_tracker

        # Roulette处理器
        self.__selector = selector
        self.__selection_max_retries = max(1, int(selection_max_retries))

        # 值突变后的形状重算器 (无状态纯函数类)
        self.__shape_calc = OutputShapeCalculator()

    def pop_last_mutation(self):
        """取出最近一次值突变 (PV/BV) 的实际改动记录, 无改动返回 None

        记录格式: {'pv': {param: [old, new]}, 'bv': {...}}, 随模型结构落盘
        (layer_info['mutations']), 用于缺陷归因 (标注缺陷由哪段突变代码造成)。
        """
        changes = self.__value_mutator.pop_last_changes()
        if not changes:
            return None
        rec = {}
        for op, ch in changes.items():
            rec[op] = {p: [_jsonable(o), _jsonable(n)] for p, (o, n) in ch.items()}
        return rec

    def generate(self, input_shape: Tuple[Optional[int]], last_layer: Optional[str] = None, pool: Optional[list] = None):
        """Generate one admitted layer with immediate DIV feedback.

        A non-contributing candidate updates its Beta failure parameter and is
        removed from this position's candidate pool.  Retrying is bounded so a
        saturated/over-constrained space cannot loop forever.
        """
        input_dim = len(input_shape)
        allowed = set(self.__layer_types)
        source_pool = self.__layer_types if pool is None else pool
        remaining = [name for name in source_pool if name in allowed]

        for _ in range(min(self.__selection_max_retries, len(remaining))):
            element = self.__selector.choose_element(
                pool=remaining, e1=last_layer, input_dim=input_dim,
                input_shape=input_shape)
            if element is None:
                break
            layer_type, layer_args, cur_shape = self.__layer_funcs[element](input_shape=input_shape)
            original_args, original_shape = dict(layer_args), cur_shape
            layer_args = self.__value_mutator.mutate_layer_args(layer_type, layer_args, input_shape)
            new_shape = self.__recompute_output_shape(layer_type, input_shape, layer_args, cur_shape)
            if new_shape is None:
                layer_args, cur_shape = original_args, original_shape
                self.__value_mutator.pop_last_changes()
            else:
                cur_shape = new_shape

            if self.__coverage_tracker is not None:
                self.__coverage_tracker.record_attempt(layer_type, input_shape, layer_args)

            admitted = self.__selector.admit_candidate(
                layer_type, input_shape=input_shape, pre_layer=last_layer,
                input_dim=input_dim)
            if admitted:
                return layer_type, layer_args, cur_shape

            # The rejected candidate is not committed to the partial model.
            self.__value_mutator.pop_last_changes()
            remaining = [name for name in remaining if name != element]

        return None, None, input_shape

    def __recompute_output_shape(self, layer_type, input_shape, layer_args, fallback):
        """值突变后, 用突变后的参数重新计算输出形状

        :return: 重算后的输出形状; 对不参与突变的层返回原形状 (fallback);
                 参数非法 (shape 计算异常, 或形状含非正维度/元素数爆炸,
                 例如 BV 边界值突变把 units/filters/n/size 置 0) 时返回 None,
                 由调用方回退到原参数, 保证模型可构建。
        """
        spec = SHAPE_RECALC_MAP.get(layer_type)
        if spec is None:
            return fallback                      # time_distributed 等: 形状不受外层参数突变影响
        method, extra = spec
        try:
            if layer_type == 'reshape':          # reshape 输出形状不依赖 input_shape
                new_shape = self.__shape_calc.reshape_layer(target_shape=layer_args.get('target_shape'))
            else:
                new_shape = getattr(self.__shape_calc, method)(input_shape, **layer_args, **extra)
        except Exception:
            return None                          # 突变参数非法 (如 kernel_size 超过输入尺寸)
        if not self.__shape_valid(new_shape):
            return None                          # 突变参数导致形状非法 (含 0/负维度或爆炸)
        return new_shape

    @staticmethod
    def __shape_valid(shape):
        """形状合法性校验 (与 ModelInfoGenerator.__shape_too_big 同一标准):
        所有维度必须为正整数, 且累积元素数不超过 1e8。
        """
        if not shape:
            return False
        temp = 1
        for e in shape[1:]:
            if e is None or not isinstance(e, int) or e <= 0 or e > 1e6:
                return False
            temp *= e
        return temp <= 1e8

    def generate_merging_layer(self, input_num: int = 2, pool: Optional[list] = None, output_shape: Optional[tuple] = None):
        '''随机返回一个merging layer的name、参数字典、期望输入形状列表、理论输出形状
        '''
        source = merging_layer_types if pool is None else pool
        remaining = [name for name in source if name in set(merging_layer_types)]
        for _ in range(min(self.__selection_max_retries, len(remaining))):
            element = self.__selector.choose_element(
                pool=remaining, input_num=input_num,
                output_shape=output_shape, input_shape=None)
            if element is None:
                break
            layer_type, layer_args, input_shape_list, out_shape = self.__layer_funcs[element](
                input_num=input_num, output_shape=output_shape)
            layer_args = self.__value_mutator.mutate_layer_args(layer_type, layer_args, None)
            first_shape = tuple(input_shape_list[0]) if input_shape_list else None
            if self.__coverage_tracker is not None and first_shape:
                self.__coverage_tracker.record_attempt(layer_type, first_shape, layer_args)
            if self.__selector.admit_candidate(
                    layer_type, input_shape=first_shape, pre_layer=None,
                    input_dim=len(first_shape) if first_shape else None,
                    input_num=input_num):
                return layer_type, layer_args, input_shape_list, out_shape
            self.__value_mutator.pop_last_changes()
            remaining = [name for name in remaining if name != element]
        raise RuntimeError('no merging-layer candidate contributed diversity within retry limit')

    def generate_RNN_layer(self, input_shape: Tuple[Optional[int]], pool: Optional[list] = None):
        '''RNN类的layer(用于bidirectional)
        '''
        input_dim = len(input_shape)
        source = RNN_layer_types if pool is None else pool
        remaining = [name for name in source if name in set(RNN_layer_types)]
        for _ in range(min(self.__selection_max_retries, len(remaining))):
            element = self.__selector.choose_element(pool=remaining, input_dim=input_dim,
                                                     input_shape=input_shape)
            if element is None:
                break
            layer_type, layer_args, cur_shape = self.__layer_funcs[element](input_shape=input_shape)
            original_args, original_shape = dict(layer_args), cur_shape
            layer_args = self.__value_mutator.mutate_layer_args(layer_type, layer_args, input_shape)
            new_shape = self.__recompute_output_shape(layer_type, input_shape, layer_args, cur_shape)
            if new_shape is None:
                layer_args, cur_shape = original_args, original_shape
                self.__value_mutator.pop_last_changes()
            else:
                cur_shape = new_shape
            if self.__coverage_tracker is not None:
                self.__coverage_tracker.record_attempt(layer_type, input_shape, layer_args)
            if self.__selector.admit_candidate(layer_type, input_shape=input_shape,
                                               input_dim=input_dim):
                return layer_type, layer_args, cur_shape
            self.__value_mutator.pop_last_changes()
            remaining = [name for name in remaining if name != element]
        return None, None, input_shape


class LayerInfo(object):

    def __init__(self, variable_generator: VariableGenerator, generator):
        super().__init__()
        self.__random = variable_generator
        self.__output_shape = OutputShapeCalculator()
        self.__generator = generator

    def dense_layer(self, input_shape: Tuple[Optional[int]], units: Optional[int] = None):
        if units is None:
            units = self.__random.ele_size()
        args = dict(
            units=units,
            activation='linear',
            use_bias=self.__random.boolean(),
            kernel_initializer='random_uniform',
            bias_initializer='random_uniform',
            kernel_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            kernel_constraint=None,
            bias_constraint=None,
        )
        return 'dense', args, self.__output_shape.dense_layer(input_shape, **args)

    def activation_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(activation=self.__random.activation_func())
        return 'activation', args, self.__output_shape.activation_layer(input_shape)

    def embedding_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            input_dim=self.__random.vocabulary_size(),
            output_dim=self.__random.ele_size(),
            embeddings_initializer='random_uniform',
            embeddings_regularizer=None,
            activity_regularizer=None,
            embeddings_constraint=None,
            mask_zero=False,  # 暂不支持mask
            input_length=None,
        )
        return 'embedding', args, self.__output_shape.embedding_layer(input_shape, **args)

    def masking_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(mask_value=self.__random.val_size())
        return 'masking', args, self.__output_shape.masking_layer(input_shape)

    def conv1D_layer(self, input_shape: Tuple[Optional[int]]):
        padding = self.__random.choice(["valid", "same", "causal"])
        is_channels_last = True if padding == "causal" else self.__random.boolean()
        kernel_size, strides, data_format, dilation_rate = self.__random.conv_args(input_shape, dim_num=1, is_channels_last=is_channels_last)
        args = dict(
            filters=self.__random.ele_size(),
            kernel_size=kernel_size,
            strides=strides,
            padding=padding,
            data_format=data_format,
            dilation_rate=dilation_rate,
            activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            kernel_initializer='random_uniform',
            bias_initializer='random_uniform',
            kernel_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            kernel_constraint=None,
            bias_constraint=None,
        )
        return 'conv1D', args, self.__output_shape.conv_layer(input_shape=input_shape, dim_num=1, **args)

    def conv2D_layer(self, input_shape: Tuple[Optional[int]]):
        kernel_size, strides, data_format, dilation_rate = self.__random.conv_args(input_shape, dim_num=2)
        args = dict(
            filters=self.__random.ele_size(),
            kernel_size=kernel_size,
            strides=strides,
            padding=self.__random.choice(["valid", "same"]),
            data_format=data_format,
            dilation_rate=dilation_rate,
            activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            kernel_initializer='random_uniform',
            bias_initializer='random_uniform',
            kernel_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            kernel_constraint=None,
            bias_constraint=None,
        )
        return 'conv2D', args, self.__output_shape.conv_layer(input_shape=input_shape, dim_num=2, **args)

    def conv3D_layer(self, input_shape: Tuple[Optional[int]]):
        kernel_size, strides, data_format, dilation_rate = self.__random.conv_args(input_shape, dim_num=3)
        args = dict(
            filters=self.__random.ele_size(),
            kernel_size=kernel_size,
            strides=strides,
            padding=self.__random.choice(["valid", "same"]),
            data_format=data_format,
            dilation_rate=dilation_rate,
            activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            kernel_initializer='random_uniform',
            bias_initializer='random_uniform',
            kernel_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            kernel_constraint=None,
            bias_constraint=None,
        )
        return 'conv3D', args, self.__output_shape.conv_layer(input_shape=input_shape, dim_num=3, **args)

    def separable_conv1D_layer(self, input_shape: Tuple[Optional[int]]):
        kernel_size, strides, data_format, dilation_rate = self.__random.conv_args(input_shape, dim_num=1)
        args = dict(
            filters=self.__random.ele_size(),
            kernel_size=kernel_size,
            strides=strides,
            padding=self.__random.choice(["valid", "same"]),
            data_format=data_format,
            dilation_rate=dilation_rate,
            depth_multiplier=self.__random.ele_size(),
            activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            depthwise_initializer='random_uniform',
            pointwise_initializer='random_uniform',
            bias_initializer='random_uniform',
            depthwise_regularizer=None,
            pointwise_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            depthwise_constraint=None,
            pointwise_constraint=None,
            bias_constraint=None,
        )
        return 'separable_conv1D', args, self.__output_shape.conv_layer(input_shape=input_shape, dim_num=1, **args)

    def separable_conv2D_layer(self, input_shape: Tuple[Optional[int]]):
        kernel_size, strides, data_format, dilation_rate = self.__random.conv_args(input_shape, dim_num=2)
        args = dict(
            filters=self.__random.ele_size(),
            kernel_size=kernel_size,
            strides=strides,
            padding=self.__random.choice(["valid", "same"]),
            data_format=data_format,
            dilation_rate=dilation_rate,
            depth_multiplier=self.__random.ele_size(),
            activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            depthwise_initializer='random_uniform',
            pointwise_initializer='random_uniform',
            bias_initializer='random_uniform',
            depthwise_regularizer=None,
            pointwise_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            depthwise_constraint=None,
            pointwise_constraint=None,
            bias_constraint=None,
        )
        return 'separable_conv2D', args, self.__output_shape.conv_layer(input_shape=input_shape, dim_num=2, **args)

    def depthwise_conv2D_layer(self, input_shape: Tuple[Optional[int]]):
        is_channels_last = self.__random.boolean()
        window_limitation = input_shape[1:3] if is_channels_last else input_shape[2:4]
        _strides = self.__random.sizes_with_limitation(window_limitation)
        v = min(_strides)
        args = dict(
            kernel_size=self.__random.kernel_size(window_limitation),
            strides=[v] * len(_strides),
            padding=self.__random.choice(["valid", "same"]),
            depth_multiplier=self.__random.ele_size(),
            data_format="channels_last" if is_channels_last else "channels_first",
            activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            depthwise_initializer='random_uniform',
            bias_initializer='random_uniform',
            depthwise_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            depthwise_constraint=None,
            bias_constraint=None,
        )
        return 'depthwise_conv2D', args, self.__output_shape.depthwise_conv2D_layer(input_shape=input_shape, **args)

    def conv2D_transpose_layer(self, input_shape: Tuple[Optional[int]]):
        is_channels_last = self.__random.boolean()
        window_limitation = input_shape[1:3] if is_channels_last else input_shape[2:4]
        args = dict(
            filters=self.__random.ele_size(),
            kernel_size=self.__random.kernel_size(window_limitation),
            strides=self.__random.sizes_with_limitation(window_limitation),
            padding=self.__random.choice(["valid", "same"]),
            data_format="channels_last" if is_channels_last else "channels_first",
            activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            kernel_initializer='random_uniform',
            bias_initializer='random_uniform',
            kernel_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            kernel_constraint=None,
            bias_constraint=None,
        )
        return 'conv2D_transpose', args, self.__output_shape.conv_transpose_layer(input_shape=input_shape, dim_num=2, **args)

    def conv3D_transpose_layer(self, input_shape: Tuple[Optional[int]]):
        is_channels_last = self.__random.boolean()
        window_limitation = input_shape[1:4] if is_channels_last else input_shape[2:5]
        args = dict(
            filters=self.__random.ele_size(),
            kernel_size=self.__random.kernel_size(window_limitation),
            strides=self.__random.sizes_with_limitation(window_limitation),
            padding=self.__random.choice(["valid", "same"]),
            data_format="channels_last" if is_channels_last else "channels_first",
            activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            kernel_initializer='random_uniform',
            bias_initializer='random_uniform',
            kernel_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            kernel_constraint=None,
            bias_constraint=None,
        )
        return 'conv3D_transpose', args, self.__output_shape.conv_transpose_layer(input_shape=input_shape, dim_num=3, **args)

    def max_pooling1D_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            pool_size=self.__random.kernel_size(input_shape[1:2])[0],
            strides=self.__random.sizes_with_limitation(input_shape[1:2])[0] if self.__random.boolean() else None,
            padding=self.__random.choice(["valid", "same"]),
        )
        return 'max_pooling1D', args, self.__output_shape.pooling1D_layer(input_shape=input_shape, **args)

    def max_pooling2D_layer(self, input_shape: Tuple[Optional[int]]):
        is_channels_last = self.__random.boolean()
        window_limitation = input_shape[1:3] if is_channels_last else input_shape[2:4]
        args = dict(
            pool_size=self.__random.kernel_size(window_limitation),
            strides=self.__random.sizes_with_limitation(window_limitation) if self.__random.boolean() else None,
            padding=self.__random.choice(["valid", "same"]),
            data_format="channels_last" if is_channels_last else "channels_first",
        )
        return 'max_pooling2D', args, self.__output_shape.pooling_layer(input_shape=input_shape, dim_num=2, **args)

    def max_pooling3D_layer(self, input_shape: Tuple[Optional[int]]):
        is_channels_last = self.__random.boolean()
        window_limitation = input_shape[1:4] if is_channels_last else input_shape[2:5]
        args = dict(
            pool_size=self.__random.kernel_size(window_limitation),
            strides=self.__random.sizes_with_limitation(window_limitation) if self.__random.boolean() else None,
            padding=self.__random.choice(["valid", "same"]),
            data_format="channels_last" if is_channels_last else "channels_first",
        )
        return 'max_pooling3D', args, self.__output_shape.pooling_layer(input_shape=input_shape, dim_num=3, **args)

    def average_pooling1D_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            pool_size=self.__random.kernel_size(input_shape[1:2])[0],
            strides=self.__random.sizes_with_limitation(input_shape[1:2])[0] if self.__random.boolean() else None,
            padding=self.__random.choice(["valid", "same"]),
        )
        return 'average_pooling1D', args, self.__output_shape.pooling1D_layer(input_shape=input_shape, **args)

    def average_pooling2D_layer(self, input_shape: Tuple[Optional[int]]):
        is_channels_last = self.__random.boolean()
        window_limitation = input_shape[1:3] if is_channels_last else input_shape[2:4]
        args = dict(
            pool_size=self.__random.kernel_size(window_limitation),
            strides=self.__random.sizes_with_limitation(window_limitation) if self.__random.boolean() else None,
            padding=self.__random.choice(["valid", "same"]),
            data_format="channels_last" if is_channels_last else "channels_first",
        )
        return 'average_pooling2D', args, self.__output_shape.pooling_layer(input_shape=input_shape, dim_num=2, **args)

    def average_pooling3D_layer(self, input_shape: Tuple[Optional[int]]):
        is_channels_last = self.__random.boolean()
        window_limitation = input_shape[1:4] if is_channels_last else input_shape[2:5]
        args = dict(
            pool_size=self.__random.kernel_size(window_limitation),
            strides=self.__random.sizes_with_limitation(window_limitation) if self.__random.boolean() else None,
            padding=self.__random.choice(["valid", "same"]),
            data_format="channels_last" if is_channels_last else "channels_first",
        )
        return 'average_pooling3D', args, self.__output_shape.pooling_layer(input_shape=input_shape, dim_num=3, **args)

    def global_max_pooling1D_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict()
        return 'global_max_pooling1D', args, self.__output_shape.global_pooling1D_layer(input_shape=input_shape, **args)

    def global_max_pooling2D_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            data_format=self.__random.choice(["channels_last", "channels_first"]),
        )
        return 'global_max_pooling2D', args, self.__output_shape.global_pool_layer(input_shape=input_shape, dim_num=2, **args)

    def global_max_pooling3D_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            data_format=self.__random.choice(["channels_last", "channels_first"]),
        )
        return 'global_max_pooling3D', args, self.__output_shape.global_pool_layer(input_shape=input_shape, dim_num=3, **args)

    def global_average_pooling1D_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict()
        return 'global_average_pooling1D', args, self.__output_shape.global_pooling1D_layer(input_shape=input_shape, **args)

    def global_average_pooling2D_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            data_format=self.__random.choice(["channels_last", "channels_first"]),
        )
        return 'global_average_pooling2D', args, self.__output_shape.global_pool_layer(input_shape=input_shape, dim_num=2, **args)

    def global_average_pooling3D_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            data_format=self.__random.choice(["channels_last", "channels_first"]),
        )
        return 'global_average_pooling3D', args, self.__output_shape.global_pool_layer(input_shape=input_shape, dim_num=3, **args)

    def LSTM_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            units=self.__random.ele_size(),
            activation=self.__random.activation_func(),
            recurrent_activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            kernel_initializer='random_uniform',
            recurrent_initializer='random_uniform',
            bias_initializer='random_uniform',
            unit_forget_bias=self.__random.boolean(),
            kernel_regularizer=None,
            recurrent_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            kernel_constraint=None,
            recurrent_constraint=None,
            bias_constraint=None,
            dropout=0.0,
            recurrent_dropout=0.0,
            implementation=self.__random.choice([1, 2]),
            return_sequences=self.__random.boolean(),
            return_state=False,
            go_backwards=self.__random.boolean(),
            stateful=False,  # 如果为True, batch_size需要给出
            unroll=self.__random.boolean(),
        )
        return 'LSTM', args, self.__output_shape.RNN(input_shape=input_shape, **args)

    def GRU_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            units=self.__random.ele_size(),
            activation=self.__random.activation_func(),
            recurrent_activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            kernel_initializer='random_uniform',
            recurrent_initializer='random_uniform',
            bias_initializer='random_uniform',
            kernel_regularizer=None,
            recurrent_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            kernel_constraint=None,
            recurrent_constraint=None,
            bias_constraint=None,
            dropout=0.0,
            recurrent_dropout=0.0,
            implementation=self.__random.choice([1, 2]),
            return_sequences=self.__random.boolean(),
            return_state=False,
            go_backwards=self.__random.boolean(),
            stateful=False,
            unroll=self.__random.boolean(),
            reset_after=self.__random.boolean(),
        )
        return 'GRU', args, self.__output_shape.RNN(input_shape=input_shape, **args)

    def simpleRNN_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            units=self.__random.ele_size(),
            activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            kernel_initializer='random_uniform',
            recurrent_initializer='random_uniform',
            bias_initializer='random_uniform',
            kernel_regularizer=None,
            recurrent_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            kernel_constraint=None,
            recurrent_constraint=None,
            bias_constraint=None,
            dropout=0.0,
            recurrent_dropout=0.0,
            return_sequences=self.__random.boolean(),
            return_state=False,
            go_backwards=self.__random.boolean(),
            stateful=False,
            unroll=self.__random.boolean(),
        )
        return 'simpleRNN', args, self.__output_shape.RNN(input_shape=input_shape, **args)

    def time_distributed_layer(self, input_shape: Tuple[Optional[int]]):
        inner_layer_type, inner_layer_args, inner_layer_output_shape = self.__generator.generate((input_shape[0], *input_shape[2:],))
        inner_mut = self.__generator.pop_last_mutation()   # 内层值突变记录 (随模型落盘)
        inner = dict(type=inner_layer_type, args=inner_layer_args)  # 由json生成模型时注意递归生成
        if inner_mut:
            inner['mutations'] = inner_mut
        args = dict(layer=inner)
        return 'time_distributed', args, self.__output_shape.time_distributed_layer(input_shape=input_shape, inner_layer_output_shape=inner_layer_output_shape)

    def bidirectional_layer(self, input_shape: Tuple[Optional[int]]):
        inner_layer_type, inner_layer_args, inner_layer_output_shape = self.__generator.generate_RNN_layer(input_shape)
        inner_mut = self.__generator.pop_last_mutation()
        inner = dict(type=inner_layer_type, args=inner_layer_args)
        if inner_mut:
            inner['mutations'] = inner_mut
        args = dict(
            layer=inner,
            merge_mode=self.__random.choice(['sum', 'mul', 'concat', 'ave']),  # None的话会返回list，链式模型中不适合
            weights=None,  # 未知用途的参数
        )
        return 'bidirectional', args, self.__output_shape.bidirectional_layer(inner_layer_output_shape=inner_layer_output_shape, **args)

    def convLSTM2D_layer(self, input_shape: Tuple[Optional[int]]):
        kernel_size, strides, data_format, dilation_rate = self.__random.conv_args((*input_shape[:1], *input_shape[2:]), dim_num=2)
        args = dict(
            filters=self.__random.ele_size(),
            kernel_size=kernel_size,
            strides=strides,
            padding=self.__random.choice(["valid", "same"]),
            data_format=data_format,
            dilation_rate=dilation_rate,
            activation=self.__random.activation_func(),
            recurrent_activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            kernel_initializer='random_uniform',
            recurrent_initializer='random_uniform',
            bias_initializer='random_uniform',
            unit_forget_bias=self.__random.boolean(),
            kernel_regularizer=None,
            recurrent_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            kernel_constraint=None,
            recurrent_constraint=None,
            bias_constraint=None,
            return_sequences=self.__random.boolean(),
            go_backwards=False,
            stateful=False,
            dropout=0.0,
            recurrent_dropout=0.0,
        )
        return 'convLSTM2D', args, self.__output_shape.convLSTM2D_layer(input_shape=input_shape, **args)

    def batch_normalization_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            axis=self.__random.axis(len(input_shape)),
            momentum=self.__random.small_val(),
            epsilon=self.__random.small_val(),
            center=self.__random.boolean(),
            scale=self.__random.boolean(),
            beta_initializer='random_uniform',
            gamma_initializer='random_uniform',
            moving_mean_initializer='random_uniform',
            moving_variance_initializer='random_uniform',
            beta_regularizer=None,
            gamma_regularizer=None,
            beta_constraint=None,
            gamma_constraint=None,
        )
        return 'batch_normalization', args, self.__output_shape.batch_normalization_layer(input_shape=input_shape)

    def reshape_layer(self, input_shape: Tuple[Optional[int]], output_shape: Optional[Tuple[Optional[int]]] = None):
        if output_shape is None:
            output_shape = self.__random.target_shape(input_shape[1:])
        else:
            output_shape = output_shape[1:]
        args = dict(
            target_shape=output_shape
        )
        return 'reshape', args, self.__output_shape.reshape_layer(**args)

    def flatten_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            data_format=self.__random.choice(["channels_last", "channels_first"]) if self.__random.boolean() else None,
        )
        return 'flatten', args, self.__output_shape.flatten_layer(input_shape=input_shape)

    def repeat_vector_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            n=self.__random.ele_size()
        )
        return 'repeat_vector', args, self.__output_shape.repeat_vector_layer(input_shape=input_shape, **args)

    def permute_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            dims=self.__random.permute_dim_list(len(input_shape)),
        )
        return 'permute', args, self.__output_shape.permute_layer(input_shape=input_shape, **args)

    def cropping1D_layer(self, input_shape: Tuple[Optional[int]]):
        a = self.__random.randint_in_range([0, input_shape[1]-1])
        b = self.__random.randint_in_range([0, input_shape[1]-1-a])
        args = dict(
            cropping=self.__random.choice([min(a, b), (a, b)]),
        )
        return 'cropping1D', args, self.__output_shape.cropping_layer(input_shape=input_shape, dim_num=1, data_format="channels_last", **args)

    def cropping2D_layer(self, input_shape: Tuple[Optional[int]]):
        channels_last = self.__random.boolean()
        idx = 1 if channels_last else 2
        a = self.__random.randint_in_range([0, input_shape[idx]-1])
        b = self.__random.randint_in_range([0, input_shape[idx]-1-a])
        c = self.__random.randint_in_range([0, input_shape[idx+1]-1])
        d = self.__random.randint_in_range([0, input_shape[idx+1]-1-c])
        args = dict(
            cropping=self.__random.choice([min(min(a, b), min(c, d)),
                                          (min(a, b), min(c, d)),
                                          ((a, b), (c, d))]),
            data_format='channels_last' if channels_last else 'channels_first',
        )
        return 'cropping2D', args, self.__output_shape.cropping_layer(input_shape=input_shape, dim_num=2, **args)

    def cropping3D_layer(self, input_shape: Tuple[Optional[int]]):
        channels_last = self.__random.boolean()
        idx = 1 if channels_last else 2
        a = self.__random.randint_in_range([0, input_shape[idx]-1])
        b = self.__random.randint_in_range([0, input_shape[idx]-1-a])
        c = self.__random.randint_in_range([0, input_shape[idx+1]-1])
        d = self.__random.randint_in_range([0, input_shape[idx+1]-1-c])
        e = self.__random.randint_in_range([0, input_shape[idx+2]-1])
        f = self.__random.randint_in_range([0, input_shape[idx+2]-1-e])
        args = dict(
            cropping=self.__random.choice([min(min(a, b), min(c, d), min(e, f)),
                                           (min(a, b), min(c, d), min(e, f)),
                                           ((a, b), (c, d), (e, f))]),
            data_format='channels_last' if channels_last else 'channels_first',
        )
        return 'cropping3D', args, self.__output_shape.cropping_layer(input_shape=input_shape, dim_num=3, **args)

    def up_sampling1D_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            size=self.__random.ele_size()
        )
        return 'up_sampling1D', args, self.__output_shape.up_sampling_layer(input_shape=input_shape, dim_num=1, data_format="channels_last", **args)

    def up_sampling2D_layer(self, input_shape: Tuple[Optional[int]]):
        a = self.__random.ele_size()
        b = self.__random.ele_size()
        args = dict(
            size=self.__random.choice([a, (a, b)]),
            data_format=self.__random.choice(["channels_last", "channels_first"]),
        )
        return 'up_sampling2D', args, self.__output_shape.up_sampling_layer(input_shape=input_shape, dim_num=2, **args)

    def up_sampling3D_layer(self, input_shape: Tuple[Optional[int]]):
        a = self.__random.ele_size()
        b = self.__random.ele_size()
        c = self.__random.ele_size()
        args = dict(
            size=self.__random.choice([a, (a, b, c)]),
            data_format=self.__random.choice(["channels_last", "channels_first"]),
        )
        return 'up_sampling3D', args, self.__output_shape.up_sampling_layer(input_shape=input_shape, dim_num=3, **args)

    def zero_padding1D_layer(self, input_shape: Tuple[Optional[int]]):
        a = self.__random.ele_size()
        b = self.__random.ele_size()
        args = dict(
            padding=self.__random.choice([a, (a, b)]),
        )
        return 'zero_padding1D', args, self.__output_shape.zero_padding_layer(input_shape=input_shape, dim_num=1, data_format="channels_last", **args)

    def zero_padding2D_layer(self, input_shape: Tuple[Optional[int]]):
        a = self.__random.ele_size()
        b = self.__random.ele_size()
        c = self.__random.ele_size()
        d = self.__random.ele_size()
        args = dict(
            padding=self.__random.choice([a, (a, c), ((a, b), (c, d))]),
            data_format=self.__random.choice(["channels_last", "channels_first"]),
        )
        return 'zero_padding2D', args, self.__output_shape.zero_padding_layer(input_shape=input_shape, dim_num=2, **args)

    def zero_padding3D_layer(self, input_shape: Tuple[Optional[int]]):
        a = self.__random.ele_size()
        b = self.__random.ele_size()
        c = self.__random.ele_size()
        d = self.__random.ele_size()
        e = self.__random.ele_size()
        f = self.__random.ele_size()
        args = dict(
            padding=self.__random.choice([a, (a, c, e), ((a, b), (c, d), (e, f))]),
            data_format=self.__random.choice(["channels_last", "channels_first"]),
        )
        return 'zero_padding3D', args, self.__output_shape.zero_padding_layer(input_shape=input_shape, dim_num=3, **args)

    def locally_connected1D_layer(self, input_shape: Tuple[Optional[int]]):
        is_channels_last = self.__random.boolean()
        window_limitation = input_shape[1:2]  # if is_channels_last else input_shape[2:3]
        args = dict(
            filters=self.__random.ele_size(),
            kernel_size=self.__random.kernel_size(window_limitation),
            strides=self.__random.sizes_with_limitation(window_limitation),  # 貌似不支持dilation_rate
            padding='valid',  # 不支持其它
            data_format="channels_last" if is_channels_last else "channels_first",
            activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            kernel_initializer='random_uniform',
            bias_initializer='random_uniform',
            kernel_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            kernel_constraint=None,
            bias_constraint=None,
        )
        return 'locally_connected1D', args, self.__output_shape.locally_connected_layer(input_shape=input_shape, dim_num=1, **args)

    def locally_connected2D_layer(self, input_shape: Tuple[Optional[int]]):
        is_channels_last = self.__random.boolean()
        window_limitation = input_shape[1:3] if is_channels_last else input_shape[2:4]
        args = dict(
            filters=self.__random.ele_size(),
            kernel_size=self.__random.kernel_size(window_limitation),
            strides=self.__random.sizes_with_limitation(window_limitation),  # 貌似不支持dilation_rate
            padding='valid',  # 不支持其它
            data_format="channels_last" if is_channels_last else "channels_first",
            activation=self.__random.activation_func(),
            use_bias=self.__random.boolean(),
            kernel_initializer='random_uniform',
            bias_initializer='random_uniform',
            kernel_regularizer=None,
            bias_regularizer=None,
            activity_regularizer=None,
            kernel_constraint=None,
            bias_constraint=None,
        )
        return 'locally_connected2D', args, self.__output_shape.locally_connected_layer(input_shape=input_shape, dim_num=2, **args)

    def ReLU_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            max_value=self.__random.val_size(must_positive=True) if self.__random.boolean() else None,
        )
        return 'ReLU', args, self.__output_shape.activation_layer(input_shape)

    def softmax_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            axis=self.__random.axis(len(input_shape)),
        )
        return 'softmax', args, self.__output_shape.activation_layer(input_shape)

    def leakyReLU_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            alpha=self.__random.small_val(),
        )
        return 'leakyReLU', args, self.__output_shape.activation_layer(input_shape)

    def PReLU_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            alpha_initializer='random_uniform',
            alpha_regularizer=None,
            alpha_constraint=None,
            shared_axes=self.__random.axis_list(len(input_shape)) if self.__random.boolean() else None,
        )
        return 'PReLU', args, self.__output_shape.activation_layer(input_shape)

    def ELU_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            alpha=self.__random.small_val(),
        )
        return 'ELU', args, self.__output_shape.activation_layer(input_shape)

    def thresholded_ReLU_layer(self, input_shape: Tuple[Optional[int]]):
        args = dict(
            theta=self.__random.small_val(),
        )
        return 'thresholded_ReLU', args, self.__output_shape.activation_layer(input_shape)

    def concatenate_layer(self, input_num: int, output_shape):
        input_shape_list, output_shape, axis = self.__random.concatenate_shapes(input_num=input_num, output_shape=output_shape)
        args = dict(
            axis=axis
        )
        return 'concatenate', args, input_shape_list, output_shape

    def average_layer(self, input_num: int, output_shape):
        input_shape_list, output_shape, _ = self.__random.normal_merge_shapes(input_num=input_num, output_shape=output_shape)
        return 'average', dict(), input_shape_list, output_shape

    def maximum_layer(self, input_num: int, output_shape):
        input_shape_list, output_shape, _ = self.__random.normal_merge_shapes(input_num=input_num, output_shape=output_shape)
        return 'maximum', dict(), input_shape_list, output_shape

    def minimum_layer(self, input_num: int, output_shape):
        input_shape_list, output_shape, _ = self.__random.normal_merge_shapes(input_num=input_num, output_shape=output_shape)
        return 'minimum', dict(), input_shape_list, output_shape

    def add_layer(self, input_num: int, output_shape):
        input_shape_list, output_shape, _ = self.__random.normal_merge_shapes(input_num=input_num, output_shape=output_shape)
        return 'add', dict(), input_shape_list, output_shape

    def subtract_layer(self, input_num: int, output_shape):
        input_shape_list, output_shape, _ = self.__random.normal_merge_shapes(input_num=input_num, output_shape=output_shape)
        return 'subtract', dict(), input_shape_list, output_shape

    def multiply_layer(self, input_num: int, output_shape):
        input_shape_list, output_shape, _ = self.__random.normal_merge_shapes(input_num=input_num, output_shape=output_shape)
        return 'multiply', dict(), input_shape_list, output_shape

    def dot_layer(self, input_num: int, output_shape):
        input_shape_list, output_shape, axes = self.__random.dot_shapes()
        args = dict(
            axes=axes,
            normalize=self.__random.boolean(),
        )
        return 'dot', args, input_shape_list, output_shape


if __name__ == '__main__':
    pass
