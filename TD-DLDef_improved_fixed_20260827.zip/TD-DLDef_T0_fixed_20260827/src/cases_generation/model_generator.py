from typing import List, Optional
from pathlib import Path
import json
import sys

from utils.utils import CmdProcess


class ModelGenerator(object):
    '''模型生成器
    '''

    def __init__(self, weight_val_range: tuple, backends: List[str], db_manager, selector, timeout,
                 python_path: Optional[str] = None, coverage_tracker=None,
                 input_dtype='float32', neuron_mutator=None, defect_reporter=None,
                 mutation_seed=0):
        super().__init__()
        self.__weight_val_range = weight_val_range
        self.__backends = backends
        self.__db_manager = db_manager
        self.__selector = selector
        self.__timeout = timeout
        # 可执行 python 路径: 默认使用当前解释器 (跨平台), 可指定 conda 环境
        self.__python_path = python_path if python_path is not None else sys.executable
        self.__coverage_tracker = coverage_tracker
        self.__input_dtype = input_dtype
        self.__neuron_mutator = neuron_mutator
        self.__defect_reporter = defect_reporter   # 缺陷记录器 (生成阶段 crash)
        self.__last_dtype = input_dtype            # 最近一次生成使用的输入 dtype
        self.__mutation_seed = int(mutation_seed)

    def generate(self, json_path: str, exp_dir: str, model_id: int,
                 initial_weight_dir: Optional[str] = None, input_dtype: Optional[str] = None):
        model_dir = Path(exp_dir) / 'models'

        # 每次生成可指定输入 dtype (IT 突变); 未指定时用构造时默认值
        dtype = input_dtype if input_dtype is not None else self.__input_dtype
        self.__last_dtype = dtype

        # 用不同后端分别生成相同的model
        fail_backends = []
        first_bk = None

        if initial_weight_dir is None:
            # 先用一个后端生成模型，并保存其weights
            for bk in self.__backends:
                p = CmdProcess(f'"{self.__python_path}" -m src.cases_generation.generate_one'
                               f' --backend {bk}'
                               f' --json_path "{str(json_path)}"'
                               f' --weight_minv {self.__weight_val_range[0]}'
                               f' --weight_maxv {self.__weight_val_range[1]}'
                               f' --output_dir "{str(model_dir)}"'
                               f' --mutation {self.__mutation_flags_str()}'
                               f' --input_dtype {dtype if dtype else "float32"}'
                               f' --seed {self.__mutation_seed + int(model_id)}')
                generate_status = p.run(self.__timeout)

                if generate_status:  # 生成失败
                    fail_backends.append(bk)
                else:
                    first_bk = bk
                    break
        else:
            import shutil
            shutil.copytree(initial_weight_dir, str(Path(model_dir) / 'initial_weights'))

        # 剩下的模型可以并行生成，加载之前保存的weights
        cmd_processes = {
            bk: CmdProcess(f'"{self.__python_path}" -m src.cases_generation.generate_other'
                           f' --backend {bk}'
                           f' --json_path "{str(json_path)}"'
                           f' --output_dir "{str(model_dir)}"')
            for bk in self.__backends if bk != first_bk and bk not in fail_backends
        }
        for bk, p in cmd_processes.items():
            generate_status = p.run(self.__timeout)

            if generate_status:  # 生成失败
                fail_backends.append(bk)

        # 层选择在部分模型生成期间已即时反馈；此处只记录覆盖率。
        self.__record_model(json_path)

        # 记录生成失败到数据库 + 缺陷报告 (生成阶段 crash 缺陷, 定位到整模型源码)
        if fail_backends:  # 存在crash
            self.__db_manager.update_model_generate_fail_backends(model_id, fail_backends)
            if self.__defect_reporter is not None:
                try:
                    with open(json_path, 'r') as f:
                        _mi = json.load(f)
                    from utils.model_snippet import render_model_snippet
                    for bk in fail_backends:
                        rec = self.__defect_reporter.record(
                            model_id, 'crash', bk, _mi, layer_name=None,
                            stage='generation',
                            detail='model build failed on backend %s (exit!=0)' % bk)
                        try:
                            self.__db_manager.record_defect_detail(
                                model_id, 'crash', bk, 'generation', None,
                                render_model_snippet(_mi), rec.get('detail'))
                        except Exception:
                            pass
                except Exception:
                    pass

        return [bk for bk in self.__backends if bk not in fail_backends]

    def __mutation_flags_str(self):
        """将神经元突变配置传给 generate_one 子进程"""
        if self.__neuron_mutator is None:
            return 'all'
        enabled = sorted(set(self.__neuron_mutator.config.enabled).intersection({'nf', 'ws', 'wr'}))
        return ','.join(enabled) if enabled else 'none'

    def __record_model(self, json_path):
        with open(json_path, 'r') as f:
            model_info = json.load(f)

        # 覆盖率追踪 (LIC/LPC/LSC 的"已覆盖"部分)
        # 修正: 使用本次生成实际的输入 dtype (IT 突变), 而非构造默认值
        if self.__coverage_tracker is not None:
            self.__coverage_tracker.record_model(model_info, input_dtype=self.__last_dtype)

        # P0: do not perform delayed model-level TS feedback here.  It would
        # duplicate the immediate select -> DIV -> accept/reject updates.


if __name__ == '__main__':
    pass
