import argparse
import sys
import json
import numpy as np
from pathlib import Path
from typing import Tuple
import warnings

from utils.utils import switch_backend, get_layer_func
from utils.mutation import MutationConfig, NeuronMutator

warnings.filterwarnings("ignore")


def __parse_mutation_flag(mutation: str):
    """解析 --mutation 参数: 'all'/'none' 或逗号分隔的算子名列表 (nf/ws/wr)"""
    if mutation is None or mutation == '' or mutation == 'all':
        return ['nf', 'ws', 'wr']
    if mutation == 'none':
        return []
    return [op.strip() for op in mutation.split(',') if op.strip()]


def __generate_layer(layer_info: dict, weight_range: Tuple[float], input_dtype=None):
    # 解析层信息
    layer_type, layer_args, pre_layers, ouput_shape = tuple(map(layer_info.get, ['type', 'args', 'pre_layers', 'output_shape']))
    layer = get_layer_func(layer_type)

    # 解析参数
    for k, v in layer_args.items():
        if k == 'layer':
            layer_args[k], _, _ = __generate_layer(v, weight_range, input_dtype)  # 嵌套层需要递归生成
        elif k[-12:] == '_initializer':
            a, b = weight_range
            if k == 'moving_variance_initializer':
                layer_args[k] = keras.initializers.random_uniform(0, b)
            else:
                layer_args[k] = keras.initializers.random_uniform(a, b)  # initializer

    # Input Type Mutation (IT): 指定输入层的数据类型
    if layer_type == 'input_object' and input_dtype is not None:
        layer_args['dtype'] = input_dtype

    return layer(**layer_args), pre_layers, ouput_shape


def apply_neuron_mutation(model, neuron_mutator: NeuronMutator):
    """Apply NF/WS/WR and return auditable layer-level provenance.

    This function is deliberately public so the end-to-end wiring can be unit
    tested without invoking a backend subprocess.
    """
    summary = {
        'enabled_operators': sorted(neuron_mutator.config.enabled) if neuron_mutator else [],
        'layers': [],
        'mutated_layers': 0,
        'mutated_weight_tensors': 0,
        'changed_values': 0,
        'skipped_layers': [],
    }
    if neuron_mutator is None:
        return summary
    for layer in model.layers:
        try:
            weights = layer.get_weights()
            if not weights:
                summary['skipped_layers'].append({'layer': layer.name, 'reason': 'no_weights'})
                continue
            mutated, report = neuron_mutator.mutate_weights_with_report(weights)
            if [w.shape for w in mutated] != [w.shape for w in weights]:
                raise ValueError('neuron mutation changed a weight shape')
            layer.set_weights(mutated)
            layer_record = {'layer': layer.name, **report}
            summary['layers'].append(layer_record)
            if report['changed_values']:
                summary['mutated_layers'] += 1
            summary['mutated_weight_tensors'] += report['changed_tensors']
            summary['changed_values'] += report['changed_values']
        except Exception as e:
            print(f"[NeuronMutation] skip layer {layer.name}: {e}")
            summary['skipped_layers'].append({'layer': layer.name, 'reason': str(e)})
            continue
    return summary


def __generate_model(json_path: str, weight_range: Tuple[float], input_dtype=None):
    # 加载模型结构数据
    with open(json_path, 'r') as f:
        model_info = json.load(f)

    input_id_list, output_id_list = model_info['input_id_list'], model_info['output_id_list']

    input_list, output_list, layer_dict = [], [], {}
    for layer_id, layer_info in model_info['model_structure'].items():  # 按拓扑排序遍历
        layer_id = int(layer_id)
        # 生成层
        layer, inbound_layers_idx, ouput_shape = __generate_layer(layer_info, weight_range, input_dtype)

        # 层拼接
        if layer_id in input_id_list:
            layer_dict[layer_id] = layer  # input_object
            input_list.append(layer_dict[layer_id])

        else:
            inbound_layers = [layer_dict[i] for i in inbound_layers_idx]
            layer_dict[layer_id] = layer(inbound_layers[0] if len(inbound_layers) == 1 else inbound_layers)  # 对layers进行连接

        if layer_id in output_id_list:
            output_list.append(layer_dict[layer_id])

        # 检查形状 keras verison
        import keras
        if keras.__version__ == "2.15.0":
            from keras import backend as K
            if K.int_shape(layer_dict[layer_id]) != tuple(ouput_shape):
                raise Exception(f"[Debug] layer_id: {layer_id} expected shape: {tuple(ouput_shape)}  actual shape: {K.int_shape(layer_dict[layer_id])}")

        else:
            from keras import ops
            if ops.shape(layer_dict[layer_id]) != tuple(ouput_shape):
                raise Exception(f"[Debug] layer_id: {layer_id} expected shape: {tuple(ouput_shape)}  actual shape: {ops.shape(layer_dict[layer_id])}")


    return keras.Model(inputs=input_list, outputs=output_list)


def __save_weights(model, weights_dir, bk):
    if bk == 'theano':
        keras.utils.convert_all_kernels_in_model(model)
    for layer in model.layers:
        save_path = Path(weights_dir) / f'{layer.name}.npz'
        np.savez(save_path, *layer.get_weights())


if __name__ == "__main__":
    # 获取参数
    parse = argparse.ArgumentParser()
    parse.add_argument("--backend", type=str)
    parse.add_argument("--json_path", type=str)
    parse.add_argument("--weight_minv", type=float)
    parse.add_argument("--weight_maxv", type=float)
    parse.add_argument("--output_dir", type=str)
    parse.add_argument("--mutation", type=str, default='all', help="neuron mutation ops: all/none/nf,ws,wr")
    parse.add_argument("--input_dtype", type=str, default=None,
                       help="input dtype: float16/32/64, int8/16/32/64, or uint8")
    parse.add_argument("--seed", type=int, default=None, help="isolated neuron-mutation RNG seed")
    flags, _ = parse.parse_known_args(sys.argv[1:])

    try:
        switch_backend(flags.backend)  # 切换后端
        import keras

        # 神经元突变配置
        neuron_mutator = None
        ops = __parse_mutation_flag(flags.mutation)
        if ops:
            from utils.mutation import MutationConfig as _MC
            neuron_mutator = NeuronMutator(_MC(enabled=ops, seed=flags.seed))

        model = __generate_model(flags.json_path, (flags.weight_minv, flags.weight_maxv),
                                 input_dtype=flags.input_dtype)

        # P0 fix: neuron mutation is part of the actual end-to-end path.  The
        # first backend mutates once; all remaining backends load the exact same
        # saved tensors from initial_weights.
        mutation_provenance = apply_neuron_mutation(model, neuron_mutator)
        mutation_provenance['backend'] = flags.backend
        mutation_provenance['seed'] = flags.seed
        print('[NeuronMutation] mutated_layers={mutated_layers} '
              'mutated_weight_tensors={mutated_weight_tensors} '
              'changed_values={changed_values}'.format(**mutation_provenance))

        # 保存模型
        model_path = Path(flags.output_dir) / f'{flags.backend}.keras'
        model.save(str(model_path), include_optimizer=False)

        # # 保存图片
        # pic_path = Path(flags.output_dir) / f'{flags.backend}.png'
        # keras.utils.plot_model(model, str(pic_path), show_shapes=True)

        # 保存模型权重
        weights_dir = Path(flags.output_dir) / 'initial_weights'
        weights_dir.mkdir(parents=True, exist_ok=True)
        __save_weights(model, weights_dir, flags.backend)

        provenance_path = Path(flags.output_dir) / 'mutation_provenance.json'
        with provenance_path.open('w', encoding='utf-8') as f:
            json.dump(mutation_provenance, f, ensure_ascii=False, indent=2)

    except Exception:
        import traceback

        # 创建log文件
        log_dir = Path(flags.output_dir).parent / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)

        with (log_dir / 'generation.log').open(mode='a', encoding='utf-8') as f:
            f.write(f"[ERROR] Fail when generating model with {flags.backend}\n")
            traceback.print_exc(file=f)
            f.write("\n\n")

        sys.exit(-1)
