# TD-DLDef (Improved)

> **T0/P0 repair status (2026-08-27):** the five blockers in the supplied
> consistency audit are repaired. See `T0_FIXES.md` and run
> `python -m unittest discover -s tests -v` before an experiment. Existing
> mutation/selection-dependent files under `data/` predate these repairs and
> are historical only; regenerate coverage, ablation, defect, and runtime
> results before using them in the paper.

TD-DLDef: A Test Method for Deep Learning Frameworks via Model-Level
Diversity Enhancement (基于模型级多样性增强的深度学习框架测试方法).

本仓库为论文 *TD-DLDef* 的改进实现, 在原代码基础上完成以下增强:

1. **TS-RCS 选择算法** (`utils/Thompson.py`): 将候选层选择建模为多臂老虎机问题,
   实现基于汤普森采样的逆向贡献选择。每个候选臂维护 Beta 后验,
   选择时从后验采样 x 并计算后验密度 f(x; α, β), 以逆向贡献分数
   `score = 1 / (f(x; α, β) + ε)` 优先选择探索不足的层。
   修复了原实现中 argmax 被覆盖、reward 语义颠倒两个关键缺陷。
2. **Oracle 测试预言机制与缺陷统计** (`utils/oracle.py`):
   - Oracle 1 (Crash): 进程退出码 255/1/-1 判定崩溃;
   - Oracle 2 (NaN/Inf): 层输出中的数值不稳定检测;
   - Oracle 3 (Inconsistency): 同一模型在两个框架上的输出/损失/损失梯度
     差异 delta 超过阈值 (0.15, 与原论文 scripts/incons 一致) 判定不一致。
3. **覆盖率统计算法** (`utils/coverage.py`): 基于 COMET 式 1-3 的算法原理,
   针对目标框架实际情况适配公式参数 (不是照抄 COMET 参数):
   - LIC (式1): `CovI(l) = (cov_type + cov_dim + cov_shape) / (n_type + n_dim + n_shape)`
     * `n_type(l)` = 层 l 在框架中支持的 dtype 数与 IT 数值类型全集的交集；
     * `cov_type(l)` 按 dtype 传播规则逐层统计 (input_object=模型输入 dtype,
       embedding 输出 float32, 其余层透传);
     * `n_dim(l)` = 修正后的 sidim 表 (按 Keras 3.10 / Keras 2.3.1 文档整理,
       修正了原实现 RNN={3,5}、repeat_vector=任意维等错误) ∩ 生成器维度域 {2..5};
     * `n_shape(l)` = Σ_{d∈sidim(l)} |E|^(d-1), |E|=4 为生成器元素采样域 {2..5};
     * 整体 LIC = **框架层池全部层类型**的平均 (未覆盖层计 0; 原实现只对出现过
       的层取平均且分母用"尝试∪覆盖"自参照集合, 系统性高估, 已修正)。
   - LPC (式2): `CovP(l) = Σcov_pi / Σn_pi`, N 只计**可变参数**:
     * 布尔 n=2; 枚举 n=框架取值池 (activation/padding 池按新旧框架区分,
       旧框架无 selu/softplus/causal padding);
     * 有界整数 (units/filters/...): PV 从合法候选集中选择历史使用最少的值，
       BV 使用显式二次幂边界集合；
     * 连续浮点: 采样区间等分 σ=5 桶 (沿用 COMET 近似粒度);
     * 结构型 (kernel_size 列表/strides/cropping/...): n=σ=5, cov=min(不同取值数,5)。
   - LSC (式3): `CovS = cov_seq / ΣΣ sign(|sodim(li) ∩ sidim(lj)|)`,
     sidim/sodim 用修正后的框架文档表, 分母在当前框架层池内统计。
4. **多样性评估四空间** (`utils/diversity.py`, `utils/selection.py`):
   层空间 (S_l)、边空间 (S_e)、输入形状空间 (S_s)、输入维度空间 (S_d)。
   **统计口径: 一次测试任务中基于生成的全部模型累积评估** (不是单模型内部):
   第 k 个模型的候选层只有引入此前 k-1 个模型都未覆盖的新元素才计为新的
   多样性贡献 (与 COMET "previously generated models have not covered" 一致);
   每个模型的新元素贡献逐模型记录 (model_contributions), 支持消融开关。
5. **突变策略** (`utils/mutation.py`): PV 采用 least-used legal value，BV
   采用二次幂/数值边界集合，IT 覆盖八种数值输入类型；NF 使用 Laplace、
   中心化指数或正弦噪声，WS 执行权重缩放，WR 执行形状保持的正交右乘
   `W'=WR, R^TR=I`。值突变记录在 model.json，神经元突变记录在
   `mutation_provenance.json`，全部算子支持消融开关。
6. **缺陷明细记录** (`utils/defect_report.py`, `utils/model_snippet.py`):
   所有符合 oracle 检查的缺陷均记录: 缺陷类型、框架、触发阶段、定位层
   (NaN/Inf 取拓扑序首个异常层; Inconsistency 取 output_delta 最大层;
   crash 为模型级)、**造成缺陷的模型源码片段** (该层 Keras 构建语句,
   含 PV/BV 突变行内标注)、完整模型源码与各 delta 值;
   落盘 JSONL + CSV, 并写入数据库 defect_detail 表。
7. **模型可构建性修复**:
   - 值突变后输出形状重算 (`SHAPE_RECALC_MAP` + `__recompute_output_shape`);
   - 突变参数产生非法形状时自动回退到原参数 (回退时丢弃突变记录);
   - `padding='causal'` 仅注入 Conv1D;
   - 兼容 model_structure 的 int/str key;
   - 数据库 model/inconsistency/localization_map/defect/defect_detail 五张表。
8. **子进程命令路径引号修复** (0821 执行中发现):
   `ModelGenerator` / `Trainer` 拼接子进程命令时为所有路径参数
   (json_path / output_dir / model_path / 数据与输出目录等) 补加双引号,
   修复工作目录含空格 (如 `F:\workbuddy workspace\...`) 时 argparse 参数被
   截断导致全部子进程异常退出 (退出码 -1) 的问题。

---

## Environment

- 新框架: tensorflow 2.16.1 / pytorch 2.2.0 / keras 3.10
- 旧框架: tensorflow 2.0.0 / keras 2.3.1 / cntk 2.7.0 / theano 1.0.4
  (实验 1 在结构生成层面统计覆盖率, 无需安装全部框架;
   实验 2 需在可用 Keras 3 后端上运行, 见 `scripts/run_ablation_exp2.py`)

```
pip install tensorflow==2.16.1            # TensorFlow 后端
pip install torch==2.2.0 torchvision==0.17.0 torchaudio==2.2.0 --index-url https://download.pytorch.org/whl/cpu
pip install numpy==1.26
```

## Experiments

### 消融实验 1: 多样性空间与突变算子的独立贡献 (LIC/LPC/LSC)

统计在 6 个框架下, 分别去掉每个多样性评估空间 (突变算子不变) 和去掉每种
突变算子 (多样性空间评估不变) 时, Layer Input Coverage / Layer Parameter
Coverage / Layer Sequence Coverage 各是多少 (基于全部生成模型跨模型累积)。

```
python scripts/run_ablation_exp1.py --models 200 --out data/ablation_exp1_c200.json  # CASE_NUM=200
python scripts/run_ablation_exp1.py --models 500 --out data/ablation_exp1_c500.json  # CASE_NUM=500
```

- 空间消融: `full / no_layer / no_edge / no_shape / no_dim`;
- 算子消融: `full / no_pv / no_bv / no_it / no_nf / no_ws / no_wr`;
- 结果含逐层 LIC/LPC 明细与任务级多样性统计, 写入 JSON。

### 消融实验 2: 各多样性空间 / 突变算子对缺陷检测与覆盖率的贡献
(Crash/NaN/Inf/Inconsistency + LIC/LPC/LSC)

在可用 Keras 3 后端 (tensorflow/torch) 上对同一批随机模型执行训练与跨框架
比较, 依据 Oracle 统计各框架检测出的缺陷数量, 同时统计 LIC/LPC/LSC;
按 11 种消融配置分别统计, 得到每个多样性评估空间 / 每种突变算子的独立贡献
(相对 full 的缺陷减少量与覆盖率下降量)。

```
python scripts/run_ablation_exp2.py --models 200 --workers 6 --seed 200 \
       --out data/ablation_exp2_c200_tf16.json   # CASE_NUM=200
```

- 每个 (层池, 配置) 的缺陷明细 (定位层 + 造成缺陷的源码片段) 落盘到
  `data/exp2_defects_<seed>/`;
- 分析: `python scripts/analyze_exp2_abl.py data/ablation_exp2_final.json`
  输出缺陷计数 CSV、覆盖率 CSV 与贡献度排名;
- 缺陷明细汇总: `python scripts/summarize_defects.py data/exp2_defects_200/`
  输出各框架缺陷计数、定位层类型分布、缺陷源码片段明细、突变关联统计。

### 主流程 (含缺陷明细记录)

`main.py`: `CASE_NUM = 200`, `DATASET_NAME = 'sinewave'`, 双后端
(tensorflow + torch) 训练比对, 结束输出 LIC/LPC/LSC、任务级多样性统计与
缺陷统计表, 缺陷明细落盘 `data/sinewave_defect_records.{jsonl,csv}`:

```
python main.py
```

## Directory

```
utils/Thompson.py                     # TS-RCS 多臂老虎机 + 汤普森采样
utils/selection.py                    # 四多样性空间选择 (任务级)
utils/diversity.py                    # 多样性评估 (跨全部模型累积)
utils/coverage.py                     # LIC/LPC/LSC 统计 (COMET原理+框架适配)
utils/mutation.py                     # 值/神经元突变策略 (含突变改动追踪)
utils/oracle.py                       # Oracle 预言 + 缺陷统计
utils/defect_report.py                # 缺陷明细记录 (定位层+源码片段)
utils/model_snippet.py                # 模型源码片段渲染
utils/framework_config.py             # 新/旧框架层池配置
src/cases_generation/                 # 模型结构生成 (含值突变与形状重算)
src/incons_detection/                 # 训练与跨框架比较 (含缺陷定位)
scripts/run_ablation_exp1.py          # 消融实验 1 (LIC/LPC/LSC)
scripts/run_ablation_exp2.py          # 消融实验 2 (缺陷+覆盖率消融, 支持并行)
scripts/analyze_exp2_abl.py           # 缺陷消融贡献度分析
scripts/summarize_defects.py          # 缺陷明细汇总
scripts/gen_report.py                 # 生成 HTML 实验报告
scripts/incons/                       # 原论文不一致性判定脚本
data/                                 # 实验结果与数据库
```
