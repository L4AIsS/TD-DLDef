from pathlib import Path
from typing import List, Optional
import datetime

from utils.db_manager import DbManager
from utils.utils import get_HH_mm_ss
from src.cases_generation.model_info_generator import ModelInfoGenerator
from src.cases_generation.model_generator import ModelGenerator
from src.cases_generation.data_generator import DataGenerator
from src.incons_detection.trainer import Trainer
from src.incons_detection.comparator import Comparator
from utils.selection import Selector


class TrainingDebugger(object):

    def __init__(self, config: dict, generate_mode: str = 'template', timeout: float = 300):
        super().__init__()
        self.__output_dir = config['output_dir']
        self.__db_manager = DbManager(config['db_path'])
        # Selector 处理器
        from utils.utils import layer_types, layer_conditions
        from utils.mutation import MutationConfig, NeuronMutator, ValueMutator
        from utils.coverage import CoverageTracker
        from utils.defect_report import DefectReporter
        self.__selector = Selector(layer_types=layer_types,
                                   layer_conditions=layer_conditions)
        # 突变配置与覆盖率追踪器 (支持消融实验)
        self.__mutation_config = MutationConfig(enabled=config.get('mutation_ops', None),
                                                seed=config.get('seed', 0))
        self.__input_dtype = config.get('input_dtype', 'float32')
        self.__input_type_mutator = ValueMutator(self.__mutation_config)
        self.__coverage_tracker = CoverageTracker(layer_types, layer_conditions)
        # 缺陷记录器 (统计所有符合 oracle 检查的缺陷信息 + 源码片段定位)
        self.__defect_reporter = DefectReporter(framework='main')
        self.__model_info_generator = ModelInfoGenerator(config['model'], self.__db_manager, self.__selector, generate_mode,
                                                         mutation_config=self.__mutation_config,
                                                         coverage_tracker=self.__coverage_tracker)
        self.__model_generator = ModelGenerator(config['model']['var']['weight_value_range'], config['backends'], self.__db_manager, self.__selector, timeout,
                                                coverage_tracker=self.__coverage_tracker,
                                                input_dtype=self.__input_dtype,
                                                neuron_mutator=NeuronMutator(self.__mutation_config),
                                                defect_reporter=self.__defect_reporter,
                                                mutation_seed=config.get('seed', 0))
        self.__training_data_generator = DataGenerator(config['training_data'])
        self.__weights_trainer = Trainer(self.__db_manager, timeout, python_path=config.get('python_path', None),
                                         defect_reporter=self.__defect_reporter)
        self.__weights_comparator = Comparator(self.__db_manager, threshold=config.get('distance_threshold', 0),
                                               defect_reporter=self.__defect_reporter)


    def run_generation_for_dataset(self, dataset_name: str):
        # 随机生成model
        print('model生成开始...')
        json_path, _, _, model_id, exp_dir = self.__model_info_generator.generate_for_dataset(save_dir=self.__output_dir, dataset_name=dataset_name)
        input_dtype = self.__input_type_mutator.input_type(self.__input_dtype)
        ok_backends = self.__model_generator.generate(json_path=json_path,
                                                      model_id=model_id,
                                                      exp_dir=exp_dir,
                                                      input_dtype=input_dtype)
        print(f'model生成完毕: model_id={model_id} dtype={input_dtype} ok_backends={ok_backends}')

        if len(ok_backends) >= 2:  # 否则没有继续实验的必要
            # 复制数据集
            print('training data生成开始...')
            import shutil
            shutil.copytree(str(Path('dataset') / dataset_name), str(Path(exp_dir) / 'dataset'))
            print('training data生成完毕.')

        return model_id, exp_dir, ok_backends

    def run_detection(self, model_id: int, exp_dir: str, ok_backends: List[str],  loss: Optional[str] = None, optimizer: Optional[str] = None):
        if len(ok_backends) >= 2:
            print('Training开始...')
            status, backends_outputs, backends_losses, backends_loss_grads, backends_grads, ok_backends, defect_counts = self.__weights_trainer.train(model_id=model_id,
                                                                                                                                                     exp_dir=exp_dir,
                                                                                                                                                     ok_backends=ok_backends,
                                                                                                                                                     loss=loss,
                                                                                                                                                     optimizer=optimizer)
            print(f'Training结束: ok_backends={ok_backends}')

            self.__db_manager.record_status(model_id, status)

        pair_deltas = {}
        if len(ok_backends) >= 2:
            print('Compare开始...')
            pair_deltas = self.__weights_comparator.compare(model_id=model_id,
                                                            exp_dir=exp_dir,
                                                            backends_outputs=backends_outputs,
                                                            backends_losses=backends_losses,
                                                            backends_loss_grads=backends_loss_grads,
                                                            backends_grads=backends_grads,
                                                            # backends_weights=backends_weights,
                                                            ok_backends=ok_backends)
            print('Compare结束.')

        return ok_backends, defect_counts, pair_deltas

    def get_coverage(self):
        return self.__selector.coverage()

    def get_branch_lines(self):
        return self.__selector.branch_lines()

    def get_single_record(self):
        return self.__selector.get_single_record()

    def get_coverage_tracker(self):
        """LIC/LPC/LSC 覆盖率追踪器 (跨全部模型累积)"""
        return self.__coverage_tracker

    def get_diversity_summary(self):
        """任务级四多样性空间统计 (跨全部模型)"""
        return self.__selector.diversity_summary()

    def get_defect_reporter(self):
        return self.__defect_reporter

def main(dataset_name: str, case_num: int, generate_mode: str, model_gen_only: int):
    config = {
        'model': {
            'var': {
                'tensor_dimension_range': (2, 5),
                'tensor_element_size_range': (2, 5),
                'weight_value_range': (-10.0, 10.0),
                'small_value_range': (0, 1),
                'vocabulary_size': 1001,
            },
            'node_num_range': (8, 8),
            'dag_io_num_range': (1, 3),
            'dag_max_branch_num': 2,
            'cell_num': 3,
            'node_num_per_normal_cell': 10,
            'node_num_per_reduction_cell': 2,
        },
        'training_data': {
            'instance_num': 10,
            'element_val_range': (0, 100),
        },
        'db_path': str(Path.cwd() / 'data' / f'{dataset_name}.db'),
        'output_dir': str(Path.cwd() / 'data' / f'{dataset_name}_output'),
        'report_dir': str(Path.cwd() / 'data' / f'{dataset_name}_report'),
        'backends': ['tensorflow', 'torch'], # Keras 3 可用后端: "jax"、"tensorflow"、"torch"
        'distance_threshold': 0.15,
    }


    debugger = TrainingDebugger(config, generate_mode, 300)

    start_time = datetime.datetime.now()
    # 现成数据集 + 随机模型
    for i in range(case_num):
        if model_gen_only == 1:
            print(f"********** Model {i} **********")
            try:
                model_id, exp_dir, ok_backends = debugger.run_generation_for_dataset(dataset_name)
            except Exception:
                import traceback
                traceback.print_exc()
        else:
            print(f"********** Model {i} **********")
            try:
                print(f"------------- Generating model {i}  -------------")
                model_id, exp_dir, ok_backends = debugger.run_generation_for_dataset(dataset_name)
                print(f"------------- Detecting Model {i}  -------------")
                ok_backends, defect_counts, pair_deltas = debugger.run_detection(model_id, exp_dir, ok_backends)
            except Exception:
                import traceback
                traceback.print_exc()

    end_time = datetime.datetime.now()
    time_delta = round(end_time.timestamp() - start_time.timestamp(), 2)
    print(f"All is done: Time used: {time_delta} sec")
    percent, _ = debugger.get_coverage()
    branch_cnt, lines_cnt = debugger.get_branch_lines()
    single_record = debugger.get_single_record()
    print(f"Coverage: {percent} %, Branch: {branch_cnt}, lines: {lines_cnt}")

    # LIC / LPC / LSC (COMET 原理 + 目标框架适配参数, 跨全部模型统计)
    cov_summary = debugger.get_coverage_tracker().summary()
    print(f"LIC={cov_summary['LIC']}% LPC={cov_summary['LPC']}% LSC={cov_summary['LSC']}% "
          f"(cov_seq={cov_summary['LSC_cov_seq']}/{cov_summary['LSC_denom']})")

    # 任务级四多样性空间统计 (跨全部模型)
    div_summary = debugger.get_diversity_summary()
    print(f"Diversity spaces (task-level): {div_summary['space_sizes']}, "
          f"avg_new_per_model={div_summary['avg_new_per_model']:.2f}")

    # 缺陷统计: 所有符合 oracle 检查的缺陷 (含源码片段定位)
    reporter = debugger.get_defect_reporter()
    print('\n================= Defect Summary (oracle-checked) =================')
    print(reporter.to_table())
    defect_jsonl, defect_csv = reporter.dump(
        Path.cwd() / 'data' / f'{dataset_name}_defect_records.jsonl')
    print(f'Defect records saved: {defect_jsonl} , {defect_csv}')

    return time_delta, percent, branch_cnt, lines_cnt, single_record, cov_summary

if __name__ == '__main__':
    DATASET_NAME = 'sinewave' # `cifar10`, `mnist`, `sinewave`
    CASE_NUM = 200
    GENERATE_MODE = 'seq'  # `seq`, `merging`, `dag`
    MODEL_GEN_ONLY = 0

    A, B, C, D, single_records, cov_summary = main(DATASET_NAME, CASE_NUM, GENERATE_MODE, MODEL_GEN_ONLY)
    with open('result.txt', 'a+') as f:
        f.write('\n节点参数: 8 汤普森采样 (CASE_NUM=200, sinewave)\n')
        f.write('模型个数, 时间, 覆盖率%, branch, lines\n')
        f.write(f'{CASE_NUM}, {A}, {B}, {C}, {D}\n')
        f.write(f'LIC/LPC/LSC: {cov_summary}\n')
        f.write(f'Records: {single_records}\n')
