# Verification record

Date: 2026-08-27 (UTC)

## Completed checks

- `python -m compileall -q main.py src utils scripts tests`: passed.
- `python -m unittest discover -s tests -v`: 7/7 passed.
- `python scripts/quick_gen_test.py`: passed; produced a valid eight-layer model JSON.
- `python scripts/run_ablation_exp1.py --fw keras3.10 --models 2 ...`: all 11
  full/ablation configurations completed, 22/22 structure generations succeeded.
- `python test.py`: passed.
- All Python sources parsed successfully with `ast.parse`.

## Environment boundary

The verification container did not include TensorFlow, PyTorch, or Keras, so a
real backend model-save/train run was not claimed. The neuron-mutation wiring,
shape preservation, orthogonality, provenance, immediate feedback, retry bound,
and TS posterior semantics are covered by backend-independent automated tests.
Run the full backend experiment in the pinned environments documented in
`README.md` before using new quantitative paper results.
