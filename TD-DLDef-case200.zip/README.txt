TD-DLDef case_num=200 复现实验交付

主运行：full 单配置、keras3.10 层池，共 200 个模型尝试；TensorFlow 与 Torch 分别运行同一批模型。
原始观测 221 条，精确去重 221 条，严格触发条件去重 221 组，描述性问题类型 95 组。
原预言机候选触发 8 组；复核排除 1 组工具可比性误报，保留 7 组待调查候选。没有维护者确认的独立缺陷数。

目录
code_frozen/  实际执行本轮200模型的冻结代码，源码SHA与run200/run_manifest.json一致。
code_hardened/  运行后修补了包装层内随机层递归检查的代码。仅对保存案例做针对性验证，并非在该修补版下重新完整生成200模型。
run200/  主运行原始数据、逐例输入权重和日志、重放、人工复核和所有统计。
run200/alerts/report.html  全部告警类型、逐条问题详情、模型代码、后端诊断代码、日志和复现入口。
analysis_tools/  可重运行的后处理和独立参考诊断脚本及测试。
TD-DLDef_case200_实验结果与告警统计.docx  中文统计报告。

安装及新运行（在所选代码目录下）
python -m venv .venv
.venv/Scripts/python.exe -m pip install -r requirements.txt
.venv/Scripts/python.exe scripts/run_ablation_exp2.py --pool keras3.10 --ablation full --models 200 --seed 20261010 --workers 1 --out ../new_run/backend_200.json

--models 是每配置的数量；--ablation full 才是总200，--ablation all会运行11×200。新输出目录不能复用旧运行。
本次使用Python3.12.14、NumPy1.26.4、Keras3.10.0、TF2.16.1、Torch2.2.0+cpu。CPU Torch轮子可从https://download.pytorch.org/whl/cpu安装。

重放一个保存案例（在代码目录下；输出必须新建且为空）
.venv/Scripts/python.exe scripts/reproduce_case.py --case ../run200/backend_200_cases/keras3.10/full/000053 --out ../new_replay/000053

重新统计（在analysis_tools目录下）
../code_frozen/.venv/Scripts/python.exe summarize_alerts.py --input ../run200/backend_200.json --out-dir ../new_statistics --runtime-review ../run200/runtime_review.json
../code_frozen/.venv/Scripts/python.exe -m unittest discover -s . -p test_summarize_alerts.py -v
若环境建立在code_hardened内，把以上解释器路径中的code_frozen替换为code_hardened。

记录中的原机器绝对路径是追溯信息。脚本与HTML也提供相对案例路径；重放会使用指定目录中的保存产物。
原始类别与复核类别均保留。000174被复核排除为随机掩码不可比；000160的原consistent也不计为有效比较。
源码历史文档仅解释该版本的开发验证，本轮结论以run200及case200统计报告为准。
