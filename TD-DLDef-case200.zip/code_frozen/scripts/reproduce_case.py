"""Replay saved cases using recorded settings and compare reproduction conditions."""
import argparse
import json
import math
from pathlib import Path
import shutil
import sys
import tempfile
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from utils.reproducibility import (verify_case, capture_case, replay_configuration,
    validate_replay_configuration, validate_generation_configuration, compare_replay_evidence)
from utils.runtime import collect_process_status, write_json
from utils.utils import CmdProcess
from utils.db_manager import DbManager
from utils.defect_report import DefectReporter
from src.incons_detection.trainer import Trainer
from src.incons_detection.comparator import Comparator


def validate_destination(case, out):
    case, out = Path(case).resolve(), Path(out).resolve()
    if out == case or case in out.parents:
        raise ValueError('--out must be outside the entire --case directory')
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise ValueError('--out must be an empty directory separate from --case')
    return out


def resolve_configuration(manifest, threshold_override=None):
    captured = manifest.get('replay_config')
    if captured is None:
        captured = replay_configuration(manifest.get('metadata', {}), manifest.get('execution_equivalence', {}))
    config = dict(captured.get('values', {}))
    overrides = {}
    if threshold_override is not None:
        overrides['threshold'] = {'original': config.get('threshold'), 'replay': threshold_override}
        config['threshold'] = threshold_override
    return validate_replay_configuration(config), overrides


def replay_generation(out, config, timeout):
    """Re-run the original producer/follower protocol with a recorded seed."""
    root = Path(out)
    config = validate_generation_configuration(config)
    write_json(root/'models/generation_config.json', config)
    status, first_backend, failed = {}, None, set()
    def execute(backend, producer):
        status_path = root/'logs'/('generation_%s.json' % backend)
        module = 'src.cases_generation.generate_one' if producer else 'src.cases_generation.generate_other'
        argv = [sys.executable, '-m', module, '--backend', backend,
                '--json_path', str(root/'models/model.json'), '--output_dir', str(root/'models'),
                '--status_path', str(status_path), '--input_dtype', config['input_dtype']]
        if producer:
            argv.extend(['--weight_minv', str(config['weight_range'][0]), '--weight_maxv', str(config['weight_range'][1]),
                         '--mutation', config['mutation'], '--seed', str(config['seed'])])
        process = CmdProcess(argv, cwd=str(Path(__file__).resolve().parents[1]), log_prefix=status_path.with_suffix(''))
        process.run(timeout)
        result = collect_process_status(process, status_path, backend, 'generation')
        if result['status'] == 'ok' and not (root/'models'/(backend+'.keras')).is_file():
            result.update(status='tool_error', message='successful generation worker did not write a model')
            write_json(status_path, result)
        status[backend] = result
        return result['status'] == 'ok'
    for backend in config['backends']:
        if execute(backend, True):
            first_backend = backend
            break
        failed.add(backend)
    if first_backend is not None:
        for backend in config['backends']:
            if backend != first_backend and backend not in failed:
                execute(backend, False)
    return status


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--case', required=True)
    ap.add_argument('--out')
    ap.add_argument('--timeout', type=float, default=120)
    ap.add_argument('--threshold', type=float, default=None, help='Explicit override of the saved comparison threshold')
    ap.add_argument('--generation-only', action='store_true', help='Re-run saved model generation without creating new test data')
    args = ap.parse_args(argv)
    if not math.isfinite(args.timeout) or args.timeout <= 0:
        ap.error('--timeout must be positive and finite')
    case = Path(args.case).resolve()
    try:
        manifest = verify_case(case)
        generation_mode = args.generation_only or any(not (case/'models'/(b+'.keras')).is_file() for b in ('tensorflow', 'torch'))
        if generation_mode:
            for name in ('models/model.json', 'models/generation_config.json'):
                if name not in manifest['artifacts']:
                    raise ValueError('Generation replay requires saved and hashed ' + name)
            generation_config = validate_generation_configuration(json.loads((case/'models/generation_config.json').read_text(encoding='utf-8')))
            config, overrides = None, {}
        else:
            config, overrides = resolve_configuration(manifest, args.threshold)
        required = ['models/model.json', 'models/tensorflow.keras', 'models/torch.keras',
                    'dataset/inputs.npz', 'dataset/ground_truths.npz']
        missing = [p for p in required if p not in manifest['artifacts'] or not (case/p).is_file()]
        if missing and not generation_mode:
            raise ValueError('Differential replay requires saved and hashed artifacts: ' + ', '.join(missing))
        if not generation_mode and not any(p.startswith('models/initial_weights/') for p in manifest['artifacts']):
            raise ValueError('Differential replay requires saved and hashed initial weights')
        out = Path(args.out).resolve() if args.out else Path(tempfile.mkdtemp(prefix='tddldef-replay-'))
        out = validate_destination(case, out)
    except (ValueError, OSError) as exc:
        ap.error(str(exc))
    out.mkdir(parents=True, exist_ok=True)
    if generation_mode:
        (out/'models').mkdir()
        shutil.copy2(case/'models/model.json', out/'models/model.json')
        statuses = replay_generation(out, generation_config, args.timeout)
        metadata = dict(manifest.get('metadata', {}))
        metadata.update(replay_of=str(case), generation_status=statuses,
                        replay_stage='generation_only', input_dtype=generation_config['input_dtype'])
        current = capture_case(out, metadata=metadata)
        original_status = manifest.get('metadata', {}).get('generation_status', {})
        old = {bk: st.get('status') for bk, st in original_status.items()}
        new = {bk: st.get('status') for bk, st in statuses.items()}
        summary = {'execution_status': 'generation_replayed', 'replay_stage': 'generation_only',
                   'generation_configuration': generation_config, 'generation_status': statuses,
                   'original_statuses': old, 'replay_statuses': new,
                   'generation_statuses_match': old == new if old else None,
                   'reproduction_evidence': compare_replay_evidence(manifest, current),
                   'confirmed_defect': False,
                   'note': 'No training or new dataset generation is performed. Success after regeneration is a changed observation, not proof that the original issue was a framework bug or was fixed.'}
        write_json(out/'replay_summary.json', summary)
        print(str(out/'replay_summary.json'))
        return 0
    for sub in ('models', 'dataset'):
        shutil.copytree(case/sub, out/sub)
    db = DbManager(':memory:')
    info = json.loads((out/'models/model.json').read_text(encoding='utf-8'))
    model_id = db.register_model('saved_case_replay', len(info['model_structure']))
    reporter = DefectReporter(framework=manifest.get('metadata', {}).get('framework_pool', 'saved_case'),
                              ablation=manifest.get('metadata', {}).get('ablation', 'replay'))
    status, outputs, losses, loss_grads, grads, ok, counts = Trainer(db, args.timeout, defect_reporter=reporter).train(
        model_id=model_id, exp_dir=str(out), ok_backends=['tensorflow', 'torch'],
        loss=config['loss'], optimizer=config['optimizer'], seed=config['seed'])
    comparisons = Comparator(db, threshold=config['threshold'], defect_reporter=reporter).compare(
        model_id=model_id, exp_dir=str(out), backends_outputs=outputs, backends_losses=losses,
        backends_loss_grads=loss_grads, backends_grads=grads, ok_backends=ok)
    reporter.dump(out/'observations.jsonl')
    metadata = dict(manifest.get('metadata', {}))
    metadata.update(config)
    metadata.update(replay_of=str(case), status=status, comparisons=comparisons,
                    configuration_overrides=overrides)
    current = capture_case(out, metadata=metadata)
    evidence_comparison = compare_replay_evidence(manifest, current,
        manifest.get('metadata', {}).get('comparisons'), comparisons)
    summary = {'execution_status': 'completed' if len(ok) == 2 else 'incomplete',
        'status': status, 'comparisons': comparisons, 'summary': reporter.summary(),
        'replay_configuration': config, 'configuration_overrides': overrides,
        'reproduction_evidence': evidence_comparison, 'confirmed_defect': False}
    (out/'replay_summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    print(str(out/'replay_summary.json'))
    return 0 if len(ok) == 2 else 2


if __name__ == '__main__':
    raise SystemExit(main())
