#!/usr/bin/env python3
"""Audit archived TD-DLDef results without importing or executing a DL backend.

This is an evidence audit, not a repaired-pipeline experiment. JSONL is the
primary record format; matching CSV projections are checked and never added to
the record count. Summaries and logs remain separate evidence inventories.
No record is discarded because its provenance or cause is uncertain.
"""
from __future__ import annotations

import argparse
import ast
import collections
import csv
import hashlib
import html
import json
import math
from pathlib import Path
import re
from typing import Any

AUDIT_VERSION = "1.0"
CATEGORIES = {
    "tool_error": "有直接证据的工具错误",
    "environment_error": "有直接证据的环境错误",
    "invalid_test": "有直接证据的无效测试",
    "insufficient_evidence": "证据不足，保留待核验",
    "candidate_anomaly": "待复验候选异常",
}
METRICS = ("output_delta", "loss_delta", "loss_grads_delta")
CSV_FIELDS = ("model_id", "framework", "backend", "defect_type", "stage",
              "located_layer", "causing_snippet", "detail")


def strict_value(value: Any) -> Any:
    """Represent legacy NaN/Infinity as strings so generated JSON is RFC8259."""
    if isinstance(value, float) and not math.isfinite(value):
        return "NaN" if math.isnan(value) else ("Infinity" if value > 0 else "-Infinity")
    if isinstance(value, dict):
        return {str(k): strict_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [strict_value(v) for v in value]
    return value


def canonical(value: Any) -> str:
    # Hash non-finite values with a type tag; do not collide with literal strings.
    def typed(v):
        if isinstance(v, float) and not math.isfinite(v):
            return {"__audit_nonfinite_float__": strict_value(v)}
        if isinstance(v, dict):
            return {str(k): typed(x) for k, x in v.items()}
        if isinstance(v, (list, tuple)):
            return [typed(x) for x in v]
        return v
    return json.dumps(typed(value), sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def digest(value: Any, prefix: str = "") -> str:
    return prefix + hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()[:20]


def write_json(path: Path, value: Any):
    path.write_text(json.dumps(strict_value(value), ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8-sig", errors="replace")


def scalar(v):
    return "" if v is None else str(v)


def finite(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def exception_classification(text: str):
    """Classify explicit exception evidence only; exit codes are insufficient."""
    low = text.lower()
    if "could not interpret loss identifier" in low:
        return "tool_error", "unsupported_loss_alias", "测试器使用当前 Keras 无法解析的损失函数名称；属于接口适配失败。"
    if "modulenotfounderror" in low or "no module named" in low or "dll load failed" in low:
        return "environment_error", "missing_dependency", "运行环境缺少依赖或动态库，不能据此认定框架缺陷。"
    if "out of memory" in low or "resourceexhaustederror" in low:
        return "environment_error", "resource_exhaustion", "日志明确记录资源不足，需在受控资源条件下复验。"
    if "has type float32 that does not match type int32" in low:
        return "invalid_test", "conv_input_filter_dtype_mismatch", "Conv2D 收到 int32 输入与 float32 权重，违反本次算子的 dtype 契约。"
    if "valueerror: shape too big!!" in low and "model_info_generator.py" in low:
        return "invalid_test", "generator_resource_guard", "模型生成器主动拒绝超过大小上限的形状；这是生成阶段的资源保护，不是框架执行崩溃。"
    if any(s in low for s in ("negative dimension size", "computed output size would be negative", "output size is too small", "total size of the tensor must be unchanged")):
        return "invalid_test", "invalid_shape_contract", "异常文本明确指出形状约束不满足；模型合法性需在执行前检查。"
    return "insufficient_evidence", "unresolved_exception", "现有异常文本不足以区分工具问题、无效模型和框架异常。"


def snippet_status(record):
    source = record.get("model_snippet") or ""
    if not source:
        return {"present": False, "syntax_valid": False, "note": "未保存模型片段"}
    try:
        ast.parse(source)
        return {"present": True, "syntax_valid": True,
                "note": "仅验证 Python 语法；没有验证导入、API、输入与权重，不能据此声明可复现。"}
    except SyntaxError as exc:
        return {"present": True, "syntax_valid": False, "line": exc.lineno,
                "note": "历史片段不是合法 Python，保留原文作为模型结构证据：" + exc.msg}


def find_case_dir(data_dir: Path, source: Path, record):
    """Only deterministic same-run association; never match a model ID globally."""
    match = re.fullmatch(r"exp2_defects_(\w+)", source.parent.name)
    if not match or "__" not in source.stem:
        return None
    pool, ablation = source.stem.rsplit("__", 1)
    try:
        number = int(record["model_id"])
    except (ValueError, TypeError, KeyError):
        return None
    case = data_dir / ("exp2_abl_out_" + match.group(1)) / pool / ablation / f"{number:06d}"
    return case if case.is_dir() else None


def associated_evidence(data_dir: Path, source: Path, record):
    case = find_case_dir(data_dir, source, record)
    evidence = {"case_directory": None, "log_sources": [], "model_json": None,
                "input_files": [], "weight_files": [], "output_files": [],
                "environment_manifest": None}
    log_text = ""
    if case:
        evidence["case_directory"] = case.relative_to(data_dir).as_posix()
        for log in sorted((case / "logs").glob("*.log")):
            text = read_text(log)
            # A shared detection.log may contain multiple backends. Extract only
            # error blocks explicitly naming the record's backend.
            blocks = list(re.finditer(r"(?m)^\[ERROR\][\s\S]*?(?=^\[ERROR\]|\Z)", text))
            selected = []
            for match in blocks:
                block = match.group(0)
                first = block.splitlines()[0] if block.splitlines() else ""
                if record.get("backend") and re.search(r"\b" + re.escape(str(record["backend"])) + r"\b", first):
                    selected.append(block)
                    evidence["log_sources"].append({"path": log.relative_to(data_dir).as_posix(),
                        "line_start": text.count("\n", 0, match.start()) + 1,
                        "line_end": text.count("\n", 0, match.end()) + (not block.endswith("\n")),
                        "match": "same_run_pool_configuration_model_and_backend"})
            if selected:
                log_text += "\n".join(selected)
        mj = case / "models" / "model.json"
        if mj.is_file():
            evidence["model_json"] = mj.relative_to(data_dir).as_posix()
        for name, folder, pattern in (("input_files", "dataset", "*.npz"),
                                      ("weight_files", "models/initial_weights", "*.npz"),
                                      ("output_files", "layer_outputs", "*.npy")):
            evidence[name] = [p.relative_to(data_dir).as_posix() for p in sorted((case / folder).rglob(pattern))]
        manifest = case / "environment.json"
        if manifest.is_file():
            evidence["environment_manifest"] = manifest.relative_to(data_dir).as_posix()
    return evidence, log_text


def classify_record(record: dict, log_text: str = ""):
    """Conservative archive triage. A candidate is not a confirmed defect."""
    if log_text:
        category, rule, description = exception_classification(log_text)
        if category != "insufficient_evidence":
            return category, rule, description
    kind = record.get("defect_type")
    if kind == "crash":
        # Only explicit exception text, not model source, may support triage.
        category, rule, description = exception_classification(str(record.get("detail", "")))
        if category != "insufficient_evidence":
            return category, rule, description
        return "insufficient_evidence", "exit_without_root_cause", "仅记录构建或训练进程非零退出；缺少匹配异常栈，无法判定原因，不能直接统计为框架崩溃缺陷。"
    if kind in ("nan", "inf"):
        layers = record.get(kind + "_layers")
        if layers or record.get("located_layer"):
            return "candidate_anomaly", "recorded_nonfinite_output", "历史记录声称指定层出现非有限输出；需核验输入、权重、前置非有限值与算子定义域后复验。"
        return "insufficient_evidence", "nonfinite_without_location", "记录未提供非有限值出现的层或原始数组。"
    if kind == "inconsistency":
        match = re.search(r"threshold\s*=\s*([0-9.eE+-]+)", str(record.get("detail", "")))
        threshold = float(match.group(1)) if match else None
        if threshold is not None and finite(record.get("output_delta")) and record["output_delta"] > threshold:
            return "candidate_anomaly", "legacy_output_threshold_exceeded", "历史有限输出差值超过记录中的旧绝对阈值；尚未经过修复后的相对容差、输入/权重对齐与重复运行验证。"
        return "insufficient_evidence", "loss_gradient_or_nonfinite_metric_unverified", "输出未满足可核验的旧阈值告警；其余损失/梯度或非有限指标缺少一致语义和原始张量证据，保留待复验。"
    return "insufficient_evidence", "unknown_record_type", "记录类型不属于已知历史 oracle 输出，保留原文待核验。"


def operation_name(record):
    snippet = record.get("causing_snippet") or ""
    match = re.search(r"keras\.layers\.([A-Za-z_][A-Za-z_0-9]*)", snippet)
    if match:
        return match.group(1)
    layer = record.get("located_layer")
    return re.sub(r"^\d+_", "", layer) if layer else "<unlocalized>"


def audit_one(data_dir, source, line_number, record):
    relative = source.relative_to(data_dir).as_posix()
    origin = {"path": relative, "line": line_number}
    evidence, log_text = associated_evidence(data_dir, source, record)
    category, rule, description = classify_record(record, log_text)
    ablation = source.stem.rsplit("__", 1)[1] if "__" in source.stem else record.get("ablation", "unknown")
    missing = []
    for key, label in (("model_json", "原始 model.json"), ("input_files", "输入与标签"),
                       ("weight_files", "初始权重"), ("output_files", "逐层原始输出"),
                       ("environment_manifest", "运行环境及实际版本清单")):
        if not evidence[key]:
            missing.append(label)
    if record.get("defect_type") == "crash" and not log_text:
        missing.append("同一运行/配置/模型/后端的异常栈")
    missing.extend(["修复后的重复运行结果", "确认根因或上游缺陷单"])
    pool = record.get("framework_pool") or record.get("framework") or "unknown"
    backend = record.get("backend", "unknown")
    cluster_key = {"category": category, "rule": rule, "backend": backend,
                   "stage": record.get("stage"), "defect_type": record.get("defect_type"),
                   "operation": operation_name(record)}
    return {
        "record_id": digest({"run_configuration": relative, "record": record}, "R-"),
        "payload_id": digest(record, "P-"),
        "symptom_cluster_id": digest(cluster_key, "S-"), "symptom_cluster_key": cluster_key,
        "origin": origin, "framework_pool": pool, "actual_backend": backend,
        "backend_version": "unknown (pool/version labels are not runtime evidence)",
        "ablation": ablation, "model_id": record.get("model_id"),
        "classification": category, "classification_zh": CATEGORIES[category], "rule": rule,
        "description": description, "framework_bug_confirmed": False,
        "evidence": evidence, "missing_evidence": missing,
        "source_fragment_validation": snippet_status(record),
        "original_record": strict_value(record),
        "linked_exception_excerpt": log_text[-6000:] if log_text else None,
    }


def csv_projection_check(path: Path, json_records: list[dict] | None):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        rows = []
        for row in reader:
            rows.append((reader.line_num, row))
    result = {"rows": len(rows), "paired_jsonl": json_records is not None,
              "status": "summary_or_unpaired_csv", "discrepancies": []}
    if json_records is None:
        return result
    if not all(k in (rows[0][1] if rows else CSV_FIELDS) for k in CSV_FIELDS):
        result["status"] = "unsupported_projection_schema"
        return result
    expected = collections.Counter(tuple(scalar(r.get(k)) for k in CSV_FIELDS) for r in json_records)
    actual = collections.Counter(tuple(scalar(r.get(k)) for k in CSV_FIELDS) for _, r in rows)
    result["status"] = "matching_projection_not_additional_records" if expected == actual else "projection_mismatch"
    if expected != actual:
        result["discrepancies"] = [{"kind": "only_in_csv", "count": n, "projection": list(k)} for k, n in (actual - expected).items()]
        result["discrepancies"] += [{"kind": "missing_from_csv", "count": n, "projection": list(k)} for k, n in (expected - actual).items()]
    return result


def inspect_json(path, data_dir, records_by_file):
    obj = json.loads(read_text(path))
    result = {"shape": type(obj).__name__}
    if isinstance(obj, list):
        result.update({"role": "aggregate_table", "rows": len(obj)})
    elif isinstance(obj, dict):
        result["keys"] = sorted(obj)
        result["role"] = "model" if "model_structure" in obj else "aggregate_or_metadata"
        if "meta" in obj:
            result["meta"] = strict_value(obj["meta"])
        if isinstance(obj.get("total"), dict):
            result["declared_totals"] = obj["total"]
            result["declared_defect_records"] = obj.get("defect_records")
            numeric_totals = [v for v in obj["total"].values() if isinstance(v, int)]
            if len(numeric_totals) == len(obj["total"]):
                result["declared_total_sum"] = sum(numeric_totals)
                if isinstance(obj.get("defect_records"), int):
                    result["declared_total_matches_defect_records"] = sum(numeric_totals) == obj["defect_records"]
            # Check only an exact run suffix and configuration, never guesses.
            match = re.fullmatch(r"exp2_abl_summaries_(\w+)", path.parent.name)
            paired = data_dir / ("exp2_defects_" + match.group(1)) / path.with_suffix(".jsonl").name if match else None
            if paired in records_by_file:
                counts = dict(collections.Counter(r.get("defect_type") for r in records_by_file[paired]))
                result["paired_jsonl"] = paired.relative_to(data_dir).as_posix()
                result["observed_totals"] = counts
                result["total_matches_jsonl"] = all(counts.get(k, 0) == obj["total"].get(k, 0) for k in set(counts) | set(obj["total"]))
                if isinstance(obj.get("defect_records"), int):
                    result["defect_record_count_matches_jsonl"] = obj["defect_records"] == len(records_by_file[paired])
            else:
                result["record_traceability"] = "no_exact_paired_jsonl_in_archive"
    return result


def inspect_log(path, data_dir):
    lines = read_text(path).splitlines()
    result = {"path": path.relative_to(data_dir).as_posix(), "line_count": len(lines),
              "versions_observed": sorted(set(re.findall(r"(tensorflow version:\s*\S+)", "\n".join(lines)))),
              "model_sections": sum(bool(re.match(r"\*+ Model \d+", line)) for line in lines),
              "generation_completion_lines": sum("model生成完毕:" in line for line in lines),
              "findings": []}
    starts = [i for i, line in enumerate(lines) if line.startswith("Traceback (most recent call last):")]
    for start in starts:
        # Stop after final exception and its argument text, before another model
        # or traceback; retain exact line numbers and a bounded excerpt.
        stop = min(len(lines), start + 90)
        for i in range(start + 1, stop):
            if lines[i].startswith(("********** Model", "Traceback (", "WARNING:", "tensorflow version:")):
                stop = i
                break
        excerpt = "\n".join(lines[start:stop])
        category, rule, description = exception_classification(excerpt)
        excs = re.findall(r"^([A-Za-z_][\w.]*?(?:Error|Exception):.*)$", excerpt, re.MULTILINE)
        result["findings"].append({"line_start": start + 1, "line_end": stop,
            "classification": category, "rule": rule, "description": description,
            "exception": excs[-1] if excs else None, "excerpt": excerpt})
    return result


def counts(rows, key):
    return dict(sorted(collections.Counter(r[key] for r in rows).items()))


def render_html(summary, unique, clusters, inventory, logs):
    esc = lambda x: html.escape(str(x))
    parts = ['<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>历史结果证据审计</title>',
      '<style>body{font:15px/1.65 system-ui,sans-serif;max-width:1180px;margin:32px auto;padding:0 24px;color:#172838}h1,h2{color:#164867}table{border-collapse:collapse;width:100%;margin:20px 0}th,td{border:1px solid #c7d5df;text-align:left;padding:7px;vertical-align:top}th{background:#e8f0f5}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f2f5f7;padding:14px;font:12px/1.6 Consolas,monospace}details{border:1px solid #ccd9e1;padding:10px;margin:8px 0}summary{cursor:pointer;font-weight:600}.note{background:#fff5dc;padding:16px}.tag{color:#46647b;font-size:13px}input{padding:9px;width:75%;margin:12px 0}</style>',
      '<h1>TD-DLDef 历史结果证据审计</h1>',
      '<p class="note">本页审计的是压缩包内历史产物，不是修复后重新运行的检测结果。候选、症状簇和非零退出均不能直接等同于已确认框架缺陷。所有证据不足的记录均保留。</p>',
      '<h2>统计口径</h2><table><tr><th>口径</th><th>数量</th></tr>']
    for key, title in (("raw_jsonl_records", "JSONL 原始条目"), ("unique_run_records", "同一运行配置内精确记录去重"),
                       ("unique_payloads_across_runs", "跨来源完整载荷唯一数（不合并独立运行）"),
                       ("symptom_clusters", "症状簇（不是根因或 bug 数）"), ("confirmed_framework_bugs", "现有证据可确认的框架缺陷")):
        parts.append(f"<tr><td>{title}</td><td>{summary[key]}</td></tr>")
    parts.append('</table><p>同一运行配置内的记录身份包含来源文件、完整原始载荷；跨文件只提供载荷相同性检查。症状簇按分类、规则、实际后端、阶段、异常类型和可定位算子分组；保留簇内所有池标签、模型和来源。池标签中的版本不视为实际运行版本。</p>')
    parts.append('<h2>去重记录分类</h2><table><tr><th>分类</th><th>条数</th></tr>')
    for category in CATEGORIES:
        parts.append(f'<tr><td>{CATEGORIES[category]}</td><td>{summary["classifications_unique_records"].get(category, 0)}</td></tr>')
    parts.append('</table><p>候选数表示历史记录的保守筛选结果，并非修复后工具的新发现。证据不足的条目不归为误报；缺少证据时不作根因判断。</p>')
    parts.append('<h2>池标签与实际后端</h2><table><tr><th>生成池标签</th><th>去重记录</th><th>候选</th><th>证据不足</th><th>无效测试</th></tr>')
    for pool, values in summary['pool_by_classification'].items():
        parts.append(f'<tr><td>{esc(pool)}</td><td>{sum(values.values())}</td><td>{values.get("candidate_anomaly", 0)}</td><td>{values.get("insufficient_evidence", 0)}</td><td>{values.get("invalid_test", 0)}</td></tr>')
    parts.append('</table><p>记录中的执行后端：' + esc(json.dumps(summary['actual_backends_unique_records'], ensure_ascii=False)) + '。tensorflow_torch 表示两后端比较。池名称 cntk2.7.0 / theano1.0.4 不证明运行过 CNTK / Theano。</p>')
    mismatches = [i for i in inventory if i.get('inspection', {}).get('total_matches_jsonl') is False or i.get('inspection', {}).get('declared_total_matches_defect_records') is False or i.get('check', {}).get('status') == 'projection_mismatch']
    parts.append('<h2>历史汇总与明细核对</h2><p>CSV 只有在逐字段、保留重复次数的核对通过后才视为 JSONL 投影。本次配对 CSV 行数 ' + str(summary['inventory_summary']['paired_csv_rows_not_additional_records']) + '，不重复计入原始记录数。汇总 JSON 也不与明细累加。</p>')
    if mismatches:
        for item in mismatches:
            parts.append('<details open><summary>' + esc(item['path']) + '</summary><pre>' + esc(json.dumps(item.get('inspection') or item.get('check'), ensure_ascii=False, indent=2)) + '</pre></details>')
    else:
        parts.append('<p>有配对证据的文件未发现计数差异；无配对明细的汇总仍不能用于追加缺陷计数。</p>')
    parts.append('<h2>归类后的症状簇</h2><table><tr><th>簇</th><th>分类 / 实际后端 / 算子</th><th>记录数</th><th>规则</th></tr>')
    for cluster in clusters:
        key = cluster["key"]
        parts.append(f'<tr><td>{esc(cluster["cluster_id"])}</td><td>{esc(CATEGORIES[key["category"]])} / {esc(key["backend"])} / {esc(key["operation"])}</td><td>{cluster["unique_records"]}</td><td>{esc(key["rule"])}</td></tr>')
    parts.append('</table><h2>逐条记录：问题描述、代码片段与证据缺口</h2><input id="filter" placeholder="搜索编号、池、后端、规则或片段"><span id="visible"></span>')
    for r in unique:
        original = r["original_record"]
        title = f'{r["record_id"]} | {r["classification_zh"]} | {r["framework_pool"]} / {r["ablation"]} / model {r["model_id"]} | {r["actual_backend"]}'
        parts.append(f'<details class="record"><summary>{esc(title)}</summary><p>{esc(r["description"])}</p><p class="tag">来源：{esc(r["origin"]["path"])} : {r["origin"]["line"]}；症状簇 {esc(r["symptom_cluster_id"])}；精确重复来源数 {len(r["origins"])}</p>')
        parts.append(f'<p>原始描述：{esc(original.get("detail", ""))}</p><p>证据缺失：{esc("；".join(r["missing_evidence"]))}</p><p>片段状态：{esc(r["source_fragment_validation"]["note"])}</p>')
        if original.get("causing_snippet"):
            parts.append('<p>历史定位层片段（定位是线索，不是根因证明）：</p><pre>' + esc(original["causing_snippet"]) + '</pre>')
        parts.append('<p>原样保留的历史模型片段：</p><pre>' + esc(original.get("model_snippet", "未保存")) + '</pre>')
        if r["linked_exception_excerpt"]:
            parts.append('<p>匹配日志：</p><pre>' + esc(r["linked_exception_excerpt"]) + '</pre>')
        parts.append('</details>')
    parts.append('<h2>日志证据（独立清点，不与 JSONL 相加）</h2>')
    for log in logs:
        parts.append(f'<details><summary>{esc(log["path"])}：{len(log["findings"])} 个 traceback</summary>')
        for finding in log["findings"]:
            parts.append(f'<p>行 {finding["line_start"]}–{finding["line_end"]} | {esc(CATEGORIES[finding["classification"]])} | {esc(finding["description"])}</p><pre>{esc(finding["excerpt"])}</pre>')
        parts.append('</details>')
    parts.append('<h2>文件清单与投影校验</h2><pre>' + esc(json.dumps(summary["inventory_summary"], ensure_ascii=False, indent=2)) + '</pre><p>完整逐文件 SHA-256、JSON 汇总溯源检查、CSV 投影差异见 inventory.json；详细机器可读记录见 records.jsonl 与 unique_records.json。</p>')
    parts.append('''<script>const q=document.querySelector('#filter'),d=[...document.querySelectorAll('.record')];function f(){let n=0;for(const e of d){const show=e.textContent.toLowerCase().includes(q.value.toLowerCase());e.style.display=show?'':'none';n+=show;}document.querySelector('#visible').textContent=n+' 条';}q.addEventListener('input',f);f();</script></html>''')
    return "\n".join(parts)


def run_audit(data_dir: Path, output_dir: Path):
    data_dir, output_dir = data_dir.resolve(), output_dir.resolve()
    if output_dir == data_dir or data_dir in output_dir.parents:
        raise ValueError("Output must be outside the audited data directory to avoid recursive self-auditing.")
    files = sorted(p for p in data_dir.rglob("*") if p.is_file())
    records_by_file, errors, records = {}, [], []
    for path in (p for p in files if p.suffix.lower() == ".jsonl"):
        raw = []
        for lineno, line in enumerate(read_text(path).splitlines(), 1):
            if not line.strip():
                continue
            try:
                record = json.loads(line)
                if not isinstance(record, dict):
                    raise ValueError("JSONL record is not an object")
                raw.append(record)
                records.append(audit_one(data_dir, path, lineno, record))
            except (ValueError, TypeError) as exc:
                errors.append({"path": path.relative_to(data_dir).as_posix(), "line": lineno, "error": str(exc)})
        records_by_file[path] = raw
    inventory, logs = [], []
    for path in files:
        item = {"path": path.relative_to(data_dir).as_posix(), "bytes": path.stat().st_size,
                "extension": path.suffix.lower(), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        try:
            if path.suffix.lower() == ".jsonl":
                item.update({"role": "primary_records", "records": len(records_by_file[path])})
            elif path.suffix.lower() == ".csv":
                item.update({"role": "csv_projection_or_summary", "check": csv_projection_check(path, records_by_file.get(path.with_suffix(".jsonl")))})
            elif path.suffix.lower() == ".json":
                item["inspection"] = inspect_json(path, data_dir, records_by_file)
            elif path.suffix.lower() == ".log":
                log = inspect_log(path, data_dir)
                logs.append(log)
                item.update({"role": "log_evidence_not_additional_records", "tracebacks": len(log["findings"])})
            elif path.suffix.lower() == ".html":
                item["role"] = "legacy_rendered_report_not_additional_records"
            else:
                item["role"] = "supporting_artifact"
        except (ValueError, OSError, csv.Error) as exc:
            item["inspection_error"] = str(exc)
            errors.append({"path": item["path"], "error": str(exc)})
        inventory.append(item)
    by_id = {}
    for record in records:
        if record["record_id"] not in by_id:
            by_id[record["record_id"]] = dict(record, origins=[])
        by_id[record["record_id"]]["origins"].append(record["origin"])
    unique = list(by_id.values())
    clustered = collections.defaultdict(list)
    for record in unique:
        clustered[record["symptom_cluster_id"]].append(record)
    clusters = []
    for cid, items in sorted(clustered.items()):
        clusters.append({"cluster_id": cid, "key": items[0]["symptom_cluster_key"],
            "unique_records": len(items), "raw_occurrences": sum(len(x["origins"]) for x in items),
            "framework_pools": sorted(set(x["framework_pool"] for x in items)),
            "record_ids": [x["record_id"] for x in items],
            "interpretation": "Symptom grouping only; not unique bugs or established common root cause."})
    paired_csv = [i for i in inventory if i.get("check", {}).get("paired_jsonl")]
    summary = {
        "audit_version": AUDIT_VERSION, "scope": "archived_artifact_evidence_audit_only",
        "input_directory": str(data_dir), "raw_jsonl_records": len(records),
        "unique_run_records": len(unique), "exact_duplicates_within_run": len(records) - len(unique),
        "unique_payloads_across_runs": len(set(x["payload_id"] for x in records)),
        "symptom_clusters": len(clusters), "confirmed_framework_bugs": 0,
        "confirmed_framework_bugs_note": "Zero confirmed by available evidence; this is not a claim that no actual framework bug exists.",
        "classifications_unique_records": {k: counts(unique, "classification").get(k, 0) for k in CATEGORIES},
        "classifications_symptom_clusters": dict(collections.Counter(c["key"]["category"] for c in clusters)),
        "raw_defect_types": dict(collections.Counter(x["original_record"].get("defect_type") for x in records)),
        "actual_backends_unique_records": counts(unique, "actual_backend"),
        "framework_pools_unique_records": counts(unique, "framework_pool"),
        "rules_unique_records": counts(unique, "rule"),
        "historical_snippets_syntax_invalid": sum(not r["source_fragment_validation"]["syntax_valid"] for r in unique),
        "records_with_linked_exception_log": sum(bool(r["evidence"]["log_sources"]) for r in unique),
        "records_with_saved_model_json": sum(bool(r["evidence"]["model_json"]) for r in unique),
        "pool_by_classification": {pool: dict(collections.Counter(r["classification"] for r in unique if r["framework_pool"] == pool)) for pool in sorted(set(r["framework_pool"] for r in unique))},
        "backend_by_classification": {backend: dict(collections.Counter(r["classification"] for r in unique if r["actual_backend"] == backend)) for backend in sorted(set(r["actual_backend"] for r in unique))},
        "inventory_summary": {
            "files": len(files), "by_extension": dict(sorted(collections.Counter(p.suffix.lower() for p in files).items())),
            "csv_rows": sum(i.get("check", {}).get("rows", 0) for i in inventory),
            "matching_csv_projections": sum(i["check"]["status"] == "matching_projection_not_additional_records" for i in paired_csv),
            "paired_csv_rows_not_additional_records": sum(i["check"]["rows"] for i in paired_csv),
            "csv_projection_mismatches": sum(i["check"]["status"] != "matching_projection_not_additional_records" for i in paired_csv),
            "summary_json_with_paired_records": sum("paired_jsonl" in i.get("inspection", {}) for i in inventory),
            "summary_json_total_mismatches": sum(i.get("inspection", {}).get("total_matches_jsonl") is False for i in inventory),
            "summary_json_without_paired_records": sum("record_traceability" in i.get("inspection", {}) for i in inventory),
        },
        "log_tracebacks_separate_count": sum(len(log["findings"]) for log in logs),
        "log_classifications_separate_count": dict(collections.Counter(f["classification"] for log in logs for f in log["findings"])),
        "errors": errors,
        "definitions": {
            "raw": "Every parsed nonblank JSONL object, retaining relative source path and 1-based line.",
            "record_dedup": "SHA-256 of full original payload plus source file (run/configuration); identical payloads from separate runs remain separate occurrences.",
            "payload_dedup": "Full original payload only, with typed NaN/Inf canonicalization; content equality does not establish identical execution or root cause.",
            "symptom_cluster": "classification + rule + actual backend + stage + defect type + localized operation. Pool, model ID and numeric magnitudes are deliberately omitted only for descriptive grouping.",
            "candidate": "Recorded output threshold or NaN/Inf symptom merits a controlled rerun; not independently confirmed and not a framework bug count.",
            "insufficient": "Unresolved evidence is preserved; it must not be reclassified as a false positive or silently filtered.",
            "pool": "Framework pool labels describe generation constraints. Actual backend names come from records; absent package-version manifests stay unknown.",
        },
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    write_json(output_dir / "summary.json", summary)
    write_json(output_dir / "inventory.json", inventory)
    write_json(output_dir / "log_findings.json", logs)
    write_json(output_dir / "symptom_clusters.json", clusters)
    write_json(output_dir / "unique_records.json", unique)
    with (output_dir / "records.jsonl").open("w", encoding="utf-8") as stream:
        for record in records:
            stream.write(json.dumps(strict_value(record), ensure_ascii=False, allow_nan=False) + "\n")
    with (output_dir / "unique_records.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        names = ["record_id", "payload_id", "symptom_cluster_id", "framework_pool", "actual_backend", "ablation", "model_id", "classification", "rule", "description", "source_path", "source_line", "defect_type", "missing_evidence", "detail", "causing_snippet", "model_snippet"]
        writer = csv.DictWriter(stream, fieldnames=names)
        writer.writeheader()
        for record in unique:
            row = {k: record.get(k, "") for k in names}
            row.update(source_path=record["origin"]["path"], source_line=record["origin"]["line"], missing_evidence="; ".join(record["missing_evidence"]))
            for k in ("defect_type", "detail", "causing_snippet", "model_snippet"):
                row[k] = record["original_record"].get(k, "")
            writer.writerow(row)
    (output_dir / "report.html").write_text(render_html(summary, unique, clusters, inventory, logs), encoding="utf-8")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parents[1] / "data")
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    summary = run_audit(args.data_dir, args.output_dir)
    print(json.dumps({k: summary[k] for k in ("raw_jsonl_records", "unique_run_records", "unique_payloads_across_runs", "symptom_clusters", "classifications_unique_records", "confirmed_framework_bugs", "errors")}, ensure_ascii=False, indent=2))
    return 1 if summary["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
