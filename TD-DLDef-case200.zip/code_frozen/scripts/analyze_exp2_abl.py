"""Export v2 observations by generator pool; never duplicate backend counts into versions."""
import argparse
import csv
import json
from pathlib import Path


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('input')
    ap.add_argument('--out')
    args=ap.parse_args()
    path=Path(args.input)
    doc=json.loads(path.read_text(encoding='utf-8'))
    if 'by_pool' not in doc:
        ap.error('Legacy reports have ambiguous framework attribution. Use scripts/audit_results.py on the raw data directory.')
    rows=[]
    for pool, configs in doc['by_pool'].items():
        for ablation, result in configs.items():
            counts=result['total']
            rows.append({'framework_pool':pool,'ablation':ablation,'models':result['total_models'],
                         'ok_models':result['ok_models'], 'generation_failures':result['gen_fail'],
                         'crash_candidates':counts['crash'],'nan_candidates':counts['nan'],
                         'inf_candidates':counts['inf'],'inconsistency_candidates':counts['inconsistency'],
                         'LIC':result.get('LIC'),'LPC':result.get('LPC'),'LSC':result.get('LSC')})
    output=Path(args.out) if args.out else path.with_suffix('.csv')
    output.parent.mkdir(parents=True,exist_ok=True)
    fields=list(rows[0]) if rows else ['framework_pool','ablation']
    with output.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    print('Saved '+str(output)+'; candidate observations are not confirmed unique defects.')


if __name__=='__main__':main()
