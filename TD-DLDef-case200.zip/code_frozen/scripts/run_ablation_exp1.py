# -*- coding: utf-8 -*-
"""Reproducible structure-only ablations of DIV and PV/BV/IT.

Framework names select compatibility tables; no target backend is executed.
LIC/LPC/LSC describe generated structures, not successful runtime coverage.
NF/SW/WR are not exercised here and their ablations are explicitly unevaluable.
This script does not reproduce the paper's measured backend/defect results.
Use identical seeds for paired configuration comparisons and inspect the source
hash, declared approximations, per-model records and failure classifications.
"""

import argparse
import contextlib
import io
import json
import hashlib
import platform
import random
import sys
from collections import Counter
from pathlib import Path

import numpy as np

PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
sys.path.insert(0, PROJECT_ROOT)

from utils.framework_config import NEW_FRAMEWORKS, OLD_FRAMEWORKS, get_framework_config
from utils.selection import Selector
from utils.mutation import MutationConfig, ValueMutator
from utils.coverage import CoverageTracker
from utils.db_manager import DbManager
from src.cases_generation.model_info_generator import ModelInfoGenerator

# ---------------------------------------------------------------------- #
# 消融配置
# ---------------------------------------------------------------------- #
ALL_SPACES = ['layer', 'edge', 'shape', 'dim']
ALL_OPS = ['pv', 'bv', 'it', 'nf', 'ws', 'wr']

SPACE_ABLATIONS = {
    'full': ALL_SPACES,
    'no_layer': [s for s in ALL_SPACES if s != 'layer'],
    'no_edge': [s for s in ALL_SPACES if s != 'edge'],
    'no_shape': [s for s in ALL_SPACES if s != 'shape'],
    'no_dim': [s for s in ALL_SPACES if s != 'dim'],
}

MUTATION_ABLATIONS = {
    'full': ALL_OPS,
    'no_pv': [o for o in ALL_OPS if o != 'pv'],
    'no_bv': [o for o in ALL_OPS if o != 'bv'],
    'no_it': [o for o in ALL_OPS if o != 'it'],
    'no_nf': [o for o in ALL_OPS if o != 'nf'],
    'no_ws': [o for o in ALL_OPS if o != 'ws'],
    'no_wr': [o for o in ALL_OPS if o != 'wr'],
}

# 全部消融配置: 空间消融 4 组 + 算子消融 6 组 (+ 基准 full 在两组中重复, 只统计一次)
ABLATION_ORDER = (['full'] + list(SPACE_ABLATIONS)[1:] + list(MUTATION_ABLATIONS)[1:])

MODEL_CONFIG = {
    'var': {
        'tensor_dimension_range': (2, 5),
        'tensor_element_size_range': (2, 5),
        'weight_value_range': (-10.0, 10.0),
        'small_value_range': (0, 1),
        'vocabulary_size': 1001,
    },
    'node_num_range': (8, 8),
    'dag_io_num_range': (1, 3),
    'dag_max_branch_num': 2,
    'cell_num': 3,
    'node_num_per_normal_cell': 10,
    'node_num_per_reduction_cell': 2,
}

INPUT_SHAPE = (None, 6, 6, 3)
OUTPUT_SHAPE = (None, 4)
NODE_NUM = 8
INPUT_DTYPES = ValueMutator.INPUT_DTYPES
CASE_NUM = 200          # 默认每个消融配置生成 200 个模型


def run_single_ablation(fw, ablation, n_models, seed):
    """Generate a seeded structural corpus; return labelled coverage/evidence."""
    if n_models <= 0:
        raise ValueError('n_models must be positive')
    random.seed(seed)
    np.random.seed(seed)
    fw_cfg = get_framework_config(fw)

    # 依据消融配置解析启用的空间与算子
    if ablation in SPACE_ABLATIONS:
        enabled_spaces = SPACE_ABLATIONS[ablation]
        enabled_ops = ALL_OPS                       # 空间消融: 突变算子不变
    else:
        enabled_spaces = ALL_SPACES                 # 算子消融: 空间评估不变
        enabled_ops = MUTATION_ABLATIONS[ablation]

    # 覆盖率追踪器: 框架适配的参数空间 (activation/padding 池按新旧框架区分)
    tracker = CoverageTracker(fw_cfg.layer_types, fw_cfg.layer_conditions,
                              activation_pool=fw_cfg.activation_pool,
                              padding_pool=fw_cfg.padding_pool,
                              element_range=MODEL_CONFIG['var']['tensor_element_size_range'],
                              dim_range=MODEL_CONFIG['var']['tensor_dimension_range'])
    selector = Selector(fw_cfg.layer_types, fw_cfg.layer_conditions,
                        diversity_spaces=enabled_spaces)
    mutation_cfg = MutationConfig(enabled=enabled_ops, seed=seed)
    value_mutator = ValueMutator(mutation_cfg)

    db = DbManager(':memory:')
    gen = ModelInfoGenerator(MODEL_CONFIG, db, selector, 'seq',
                             mutation_config=mutation_cfg,
                             coverage_tracker=tracker,
                             layer_types=fw_cfg.layer_types,
                             layer_conditions=fw_cfg.layer_conditions)

    success, fail = 0, 0
    records = []
    for i in range(n_models):
        # Input Type Mutation (IT): 启用时随机选择输入 dtype
        dtype = value_mutator.input_type('float32') if 'it' in enabled_ops else 'float32'
        try:
            selector.reset_model_state()
            with contextlib.redirect_stdout(io.StringIO()):
                model_info, _, _, node_num = gen.generate_seq_model(
                    node_num=NODE_NUM, input_shape=INPUT_SHAPE, output_shape=OUTPUT_SHAPE)
            model_info = gen.canonical_model_info(model_info)
            selector.finish_model_state()
            tracker.record_model(model_info, input_dtype=dtype)
            encoded = json.dumps(model_info, sort_keys=True, separators=(',', ':')).encode('utf-8')
            records.append({'model_index': i, 'status': 'structure_generated',
                            'input_dtype': dtype, 'node_count': node_num,
                            'model_sha256': hashlib.sha256(encoded).hexdigest()})
            success += 1
        except Exception as exc:
            fail += 1
            records.append({'model_index': i, 'status': 'tool_resource_rejection'
                            if 'Shape too big' in str(exc) else 'tool_generation_error',
                            'exception_type': type(exc).__name__, 'message': str(exc)})
        finally:
            selector.finish_model_state()

    summary = tracker.summary()
    summary['framework'] = fw
    summary['ablation'] = ablation
    summary['enabled_spaces'] = enabled_spaces
    summary['enabled_ops'] = enabled_ops
    summary['success_models'] = success
    summary['fail_models'] = fail
    summary.update({
        'seed': seed,
        'coverage_scope': 'generated_structure_only',
        'structural_only': True,
        'framework_execution_performed': False,
        'framework_label_is_configuration_only': True,
        'neuron_mutations_executed': False,
        'actually_exercised_ops': [op for op in enabled_ops if op in ('pv', 'bv', 'it')],
        'not_evaluated_ops': [op for op in enabled_ops if op in ('nf', 'ws', 'wr')],
        'ablation_effect_evaluable': ablation not in ('no_nf', 'no_ws', 'no_wr'),
        'framework_defects': 0,
        'failures_by_type': dict(Counter(r['status'] for r in records if r['status'] != 'structure_generated')),
        'model_records': records,
        'source_sha256': source_digest(),
        'environment': {'python': platform.python_version(), 'numpy': np.__version__},
        'limitations': [
            'Generated structures are not proven valid by backend execution.',
            'NF/SW/WR are not executed; their ablations cannot establish neuron-mutation contributions.',
            'Layer coverage is structural and uses the reported finite-domain approximation.',
            'Target version labels do not attest to installed or executed framework versions.',
        ],
    })
    # 任务级多样性统计 (跨全部模型)
    summary['diversity'] = selector.diversity_summary()
    # 逐层 LIC/LPC 明细 (供论文细粒度分析)
    detail = tracker.detail()
    summary['LIC_per_layer'] = detail['LIC_per_layer']
    summary['LPC_per_layer'] = detail['LPC_per_layer']
    return summary


def source_digest():
    """Hash source paths and bytes, excluding generated outputs and caches."""
    digest = hashlib.sha256()
    root = Path(PROJECT_ROOT)
    paths = list(root.glob('*.py'))
    for folder in ('src', 'utils', 'scripts'):
        paths.extend((root / folder).rglob('*.py'))
    for path in sorted(paths, key=lambda p: p.relative_to(root).as_posix()):
        digest.update(path.relative_to(root).as_posix().encode('utf-8') + b'\0')
        digest.update(path.read_bytes() + b'\0')
    return digest.hexdigest()


def main():
    parse = argparse.ArgumentParser()
    parse.add_argument('--fw', type=str, default=None, help='只运行指定框架 (默认全部)')
    parse.add_argument('--models', type=int, default=CASE_NUM,
                       help='每个配置生成的模型数 (默认 CASE_NUM=%d)' % CASE_NUM)
    parse.add_argument('--out', type=str, default=str(Path(PROJECT_ROOT) / 'data' / 'ablation_exp1.json'),
                       help='结果输出 json 路径')
    parse.add_argument('--seed', type=int, default=2024)
    flags = parse.parse_args()

    if flags.fw:
        frameworks = [flags.fw]
    else:
        frameworks = NEW_FRAMEWORKS + OLD_FRAMEWORKS

    results = []
    for fw in frameworks:
        for ablation in ABLATION_ORDER:
            print(f'[Exp1] framework={fw} ablation={ablation} ...', flush=True)
            try:
                summary = run_single_ablation(fw, ablation, flags.models,
                                              seed=flags.seed)
            except Exception as e:
                summary = {'framework': fw, 'ablation': ablation, 'seed': flags.seed,
                           'error': str(e), 'status': 'tool_configuration_error',
                           'structural_only': True, 'framework_defects': 0,
                           'coverage_scope': 'generated_structure_only', 'source_sha256': source_digest()}
            results.append(summary)
            print(f'    -> LIC={summary.get("LIC")}% LPC={summary.get("LPC")}% '
                  f'LSC={summary.get("LSC")}% (models={summary.get("success_models")})', flush=True)

    out = Path(flags.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(str(out), 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f'\nResults saved to {out}')


if __name__ == '__main__':
    main()
