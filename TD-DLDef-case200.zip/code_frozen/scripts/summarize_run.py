"""Summarize v2 runs without treating diagnostic groups as independent bugs."""
import argparse
import collections
import hashlib
import html
import json
from pathlib import Path


def summarize(path):
    path = Path(path)
    data = json.loads(path.read_text(encoding='utf-8'))
    cases_root = path.parent / (path.stem + '_cases')
    rows, observations = [], []
    statuses = collections.Counter()
    for pool, ablations in data['by_pool'].items():
        for ab, value in ablations.items():
            rows.append({'pool': pool, 'ablation': ab, 'requested_models': value['total_models'],
                         'both_backends_completed': value['ok_models'],
                         'generation_failures': value['gen_fail'], 'candidates': value['total'],
                         'LIC': value['LIC'], 'LPC': value['LPC'], 'LSC': value['LSC']})
            file = cases_root / pool / ab / 'observations.jsonl'
            for line, text in enumerate(file.read_text(encoding='utf-8').splitlines(), 1):
                record = json.loads(text)
                observations.append({'source': file.relative_to(path.parent).as_posix(), 'line': line,
                                     'record': record})
            for case in value['cases']:
                statuses.update(case.get('status', {}).values())
    unique = {}
    groups = collections.Counter()
    for item in observations:
        record = item['record']
        digest = hashlib.sha256(json.dumps(record, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        unique[digest] = item
    categories = collections.Counter(item['record']['defect_type'] for item in unique.values())
    for item in unique.values():
        r = item['record']
        runtime = r.get('runtime_status', {})
        groups[(r.get('backend'), r.get('defect_type'), runtime.get('exception_type'),
                r.get('located_layer'), runtime.get('message', r.get('detail')))] += 1
    candidate_groups = {}
    for item in unique.values():
        r = item['record']
        if r.get('evidence_status') != 'candidate':
            continue
        case = Path(r.get('case_dir', ''))
        # Locate moved/extracted case using the declared pool/config + basename.
        if not case.exists():
            case = cases_root / r.get('framework_pool', '') / r.get('ablation', '') / case.name
        manifest = json.loads((case/'case_manifest.json').read_text(encoding='utf-8'))
        identity = {'category':r['defect_type'], 'backend':r['backend'],
                    'runtime_identities':manifest['runtime_identities'],
                    'execution_equivalence':manifest['execution_equivalence']}
        # Executable paths/platform text are provenance, not the trigger identity.
        for bk, value in identity['runtime_identities'].items():
            identity['runtime_identities'][bk] = {k:value.get(k) for k in ('actual_backend','versions')}
        key=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()
        if key not in candidate_groups:
            candidate_groups[key]={'trigger_id':key, 'classification':'candidate_not_confirmed_bug',
                'occurrences':[], 'description':r.get('description',r.get('detail')),
                'suspect_layer':r.get('located_layer'), 'model_snippet':r.get('model_snippet'),
                'evidence':identity}
        candidate_groups[key]['occurrences'].append({'source':item['source'],'line':item['line'],
            'case':case.name,'ablation':r.get('ablation'),'output_delta':r.get('output'),
            'loss_delta':r.get('loss'),'gradient_delta':r.get('loss_grads')})
    total = collections.Counter()
    for row in rows:
        total.update(row['candidates'])
    return {'scope': 'fresh_backend_run', 'source_sha256': data['meta']['source_sha256'],
            'environment': data['meta']['environment'], 'rows': rows,
            'requested_models': sum(r['requested_models'] for r in rows),
            'both_backends_completed': sum(r['both_backends_completed'] for r in rows),
            'training_status_events': dict(statuses), 'candidate_observations': dict(total),
            'raw_observation_records': len(observations), 'unique_exact_observation_records': len(unique),
            'observation_categories': dict(categories), 'diagnostic_groups': len(groups),
            'group_definition': 'backend, event category, exception type, layer, exact message; descriptive only',
            'unique_candidate_triggers':len(candidate_groups), 'candidate_trigger_groups':list(candidate_groups.values()),
            'trigger_dedup_definition':'exact same actual versions, backend, oracle, architecture, input/target/initial-weight fingerprints and execution config; not root-cause equivalence',
            'confirmed_framework_bugs': 0,
            'note': 'Neither candidate observations nor diagnostic groups establish independent root causes.'}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('input')
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    result = summarize(args.input)
    Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    sections=[]
    for group in result['candidate_trigger_groups']:
        sections.append('<h2>'+html.escape(group['trigger_id'][:16])+'</h2><p>'+html.escape(group['description'] or '')+'</p><pre>'+html.escape(group['model_snippet'] or '')+'</pre><pre>'+html.escape(json.dumps(group,ensure_ascii=False,indent=2))+'</pre>')
    Path(args.out).with_suffix('.html').write_text('<!doctype html><meta charset="utf-8"><title>New candidate triggers</title><style>body{max-width:1100px;margin:30px auto;font:16px sans-serif}pre{white-space:pre-wrap;background:#f3f4f6;padding:15px}</style><h1>New candidate triggers</h1><p>Same-trigger deduplication, not confirmed root causes.</p>'+''.join(sections),encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('requested_models','both_backends_completed','candidate_observations')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
