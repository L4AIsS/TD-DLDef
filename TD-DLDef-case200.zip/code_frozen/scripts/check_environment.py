"""Import each backend in an isolated process and record actual identities."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys


def probe_environment(timeout=90):
    results = {}
    code = """import importlib, json, platform
import keras
b=keras.backend.backend()
module=importlib.import_module(b)
x=keras.ops.ones((2,2))
y=keras.ops.convert_to_numpy(keras.ops.sum(x))
print('TD_ENV_JSON='+json.dumps({'actual_backend':b,'keras':keras.__version__,
'framework_version':module.__version__,'python':platform.python_version(),'smoke_sum':float(y)}))
"""
    for backend in ('tensorflow', 'torch'):
        env = dict(os.environ, KERAS_BACKEND=backend, TF_CPP_MIN_LOG_LEVEL='2', PYTHONHASHSEED='0')
        try:
            p = subprocess.run([sys.executable, '-c', code], env=env, capture_output=True,
                               text=True, errors='replace', timeout=timeout)
            line = next((s for s in p.stdout.splitlines() if s.startswith('TD_ENV_JSON=')), None)
            if p.returncode == 0 and line:
                r = json.loads(line.split('=',1)[1])
                r['status'] = 'ok' if r['actual_backend'] == backend else 'environment_error'
                results[backend] = r
            else:
                results[backend] = {'status':'environment_error', 'exit_code':p.returncode,
                                    'message':(p.stderr or p.stdout)[-8000:]}
        except subprocess.TimeoutExpired:
            results[backend] = {'status':'timeout', 'message':'backend import/probe timeout'}
    return {'python_executable': sys.executable, 'backends': results,
            'ready': all(x['status']=='ok' for x in results.values())}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out')
    args=ap.parse_args()
    result=probe_environment()
    content=json.dumps(result, ensure_ascii=False, indent=2)
    print(content)
    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(content, encoding='utf-8')
    return 0 if result['ready'] else 2


if __name__=='__main__':
    raise SystemExit(main())
