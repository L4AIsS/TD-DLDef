# -*- coding: utf-8 -*-
"""Reproducible model-pool ablations on actual TensorFlow / PyTorch backends.

Pool labels describe generation constraints, never an executed framework version.
All observations are candidates or diagnostics, not confirmed unique defects.
Outputs are fresh, with source/config/environment metadata and per-case replay.
"""

import argparse
import contextlib
import io
import json
import os
import random
import sys
import time
from pathlib import Path

PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
sys.path.insert(0, PROJECT_ROOT)


# ---------------------------------------------------------------------- #
# 消融配置 (与 run_ablation_exp1.py 完全一致)
# ---------------------------------------------------------------------- #
ALL_SPACES = ['layer', 'edge', 'shape', 'dim']
ALL_OPS = ['pv', 'bv', 'it', 'nf', 'ws', 'wr']

SPACE_ABLATIONS = {
    'full': ALL_SPACES,
    'no_layer': [s for s in ALL_SPACES if s != 'layer'],
    'no_edge': [s for s in ALL_SPACES if s != 'edge'],
    'no_shape': [s for s in ALL_SPACES if s != 'shape'],
    'no_dim': [s for s in ALL_SPACES if s != 'dim'],
}

MUTATION_ABLATIONS = {
    'full': ALL_OPS,
    'no_pv': [o for o in ALL_OPS if o != 'pv'],
    'no_bv': [o for o in ALL_OPS if o != 'bv'],
    'no_it': [o for o in ALL_OPS if o != 'it'],
    'no_nf': [o for o in ALL_OPS if o != 'nf'],
    'no_ws': [o for o in ALL_OPS if o != 'ws'],
    'no_wr': [o for o in ALL_OPS if o != 'wr'],
}

ABLATION_ORDER = ['full'] + list(SPACE_ABLATIONS)[1:] + list(MUTATION_ABLATIONS)[1:]

# 新框架共享 Keras 3 全量层池 (framework_config 中三者为同一层池), 只实际运行一次;
# 老框架各用独立受限层池。
FRAMEWORK_POOLS = {
    'tensorflow2.16.1': 'keras3.10',
    'pytorch2.2.0': 'keras3.10',
    'keras3.10': 'keras3.10',
    'tensorflow2.0.0': 'tensorflow2.0.0',
    'cntk2.7.0': 'cntk2.7.0',
    'theano1.0.4': 'theano1.0.4',
}
UNIQUE_POOLS = ['keras3.10', 'tensorflow2.0.0', 'cntk2.7.0', 'theano1.0.4']
NEW_FRAMEWORKS = ['tensorflow2.16.1', 'pytorch2.2.0', 'keras3.10']
OLD_FRAMEWORKS = ['tensorflow2.0.0', 'cntk2.7.0', 'theano1.0.4']

MODEL_CONFIG = {
    'var': {
        'tensor_dimension_range': (2, 5),
        'tensor_element_size_range': (2, 5),
        'weight_value_range': (-10.0, 10.0),
        'small_value_range': (0, 1),
        'vocabulary_size': 1001,
    },
    'node_num_range': (8, 8),
    'dag_io_num_range': (1, 3),
    'dag_max_branch_num': 2,
    'cell_num': 3,
    'node_num_per_normal_cell': 10,
    'node_num_per_reduction_cell': 2,
}

INPUT_SHAPE = (None, 6, 6, 3)
OUTPUT_SHAPE = (None, 4)
NODE_NUM = 8
INPUT_DTYPES = ('float16', 'float32', 'float64', 'int8', 'int16', 'int32', 'int64', 'uint8')
BACKENDS = ('tensorflow', 'torch')
CASE_NUM = 200          # 默认每个消融配置生成 200 个模型


def run_one(pool_name: str, ablation: str, n_models: int, seed: int, threshold: float,
            timeout: float, out_root: str) -> dict:
    """运行一个 (层池, 消融配置) 组合, 返回缺陷 + LIC/LPC/LSC 统计 summary"""
    from utils.framework_config import get_framework_config
    from utils.selection import Selector
    from utils.mutation import MutationConfig, NeuronMutator, ValueMutator
    from utils.coverage import CoverageTracker
    from utils.oracle import DefectCollector
    from utils.defect_report import DefectReporter
    from utils.db_manager import DbManager
    from src.cases_generation.model_info_generator import ModelInfoGenerator
    from src.cases_generation.model_generator import ModelGenerator
    from src.cases_generation.data_generator import DataGenerator
    from src.incons_detection.trainer import Trainer
    from src.incons_detection.comparator import Comparator

    import numpy as np
    from utils.reproducibility import capture_case, source_digest
    np.random.seed(seed)
    random.seed(seed)   # 同时固定模块级 random (值突变/神经元突变内部使用)
    fw_cfg = get_framework_config(pool_name)
    source_hash = source_digest(PROJECT_ROOT)

    # 依据消融配置解析启用的空间与算子 (与实验 1 相同)
    if ablation in SPACE_ABLATIONS:
        enabled_spaces = SPACE_ABLATIONS[ablation]
        enabled_ops = ALL_OPS                       # 空间消融: 突变算子不变
    else:
        enabled_spaces = ALL_SPACES                 # 算子消融: 空间评估不变
        enabled_ops = MUTATION_ABLATIONS[ablation]

    db = DbManager(':memory:')
    selector = Selector(fw_cfg.layer_types, fw_cfg.layer_conditions,
                        diversity_spaces=enabled_spaces)
    mutation_cfg = MutationConfig(enabled=enabled_ops, seed=seed)
    value_mutator = ValueMutator(mutation_cfg)
    # 覆盖率追踪器: 框架适配的参数空间
    tracker = CoverageTracker(fw_cfg.layer_types, fw_cfg.layer_conditions,
                              activation_pool=fw_cfg.activation_pool,
                              padding_pool=fw_cfg.padding_pool,
                              element_range=MODEL_CONFIG['var']['tensor_element_size_range'],
                              dim_range=MODEL_CONFIG['var']['tensor_dimension_range'])
    # 缺陷明细记录器 (定位层 + 源码片段)
    reporter = DefectReporter(framework=pool_name, ablation=ablation)
    gen = ModelInfoGenerator(MODEL_CONFIG, db, selector, 'seq',
                             mutation_config=mutation_cfg, coverage_tracker=tracker,
                             layer_types=fw_cfg.layer_types,
                             layer_conditions=fw_cfg.layer_conditions)
    neuron_ops = [o for o in enabled_ops if o in ('nf', 'ws', 'wr')]
    model_gen = ModelGenerator(MODEL_CONFIG['var']['weight_value_range'], list(BACKENDS), db, selector,
                               timeout, coverage_tracker=tracker, input_dtype='float32',
                               neuron_mutator=NeuronMutator(MutationConfig(enabled=neuron_ops, seed=seed)),
                               defect_reporter=reporter, mutation_seed=seed)
    data_gen = DataGenerator({'instance_num': 10, 'element_val_range': (0, 100)})
    trainer = Trainer(db, timeout, defect_reporter=reporter)
    comparator = Comparator(db, threshold=threshold, defect_reporter=reporter)
    collector = DefectCollector(list(BACKENDS), threshold=threshold)

    output_dir = Path(out_root) / pool_name / ablation
    output_dir.mkdir(parents=True, exist_ok=True)

    ok_total, gen_fail = 0, 0
    case_summaries = []
    for i in range(n_models):
        # Input Type Mutation (IT): 启用时随机选择输入 dtype, 禁用时固定 float32
        dtype = value_mutator.input_type() if 'it' in enabled_ops else 'float32'
        exp_dir = None
        model_info = None
        status, generation_status, pair_deltas = {}, {}, {}
        try:
            selector.reset_model_state()
            with contextlib.redirect_stdout(io.StringIO()):
                model_info, ins_shapes, out_shapes, _ = gen.generate_seq_model(
                    node_num=NODE_NUM, input_shape=INPUT_SHAPE, output_shape=OUTPUT_SHAPE)
                selector.finish_model_state()
                json_path, _, _, model_id, exp_dir = gen.generate(
                    str(output_dir), model_info=model_info,
                    selection_already_recorded=True)
            # 各后端生成模型 (神经元突变 + 输入类型突变)
            # 注: ModelGenerator 会以本次实际 dtype 记录覆盖率与多样性 (跨模型累积)
            ok_backends = model_gen.generate(json_path=json_path, exp_dir=exp_dir,
                                             model_id=model_id, input_dtype=dtype)
            generation_status = dict(model_gen.last_status)
            for bk in BACKENDS:
                if bk not in ok_backends:
                    collector.record_generate_fail(bk, generation_status.get(bk))
            if len(ok_backends) < 2:
                gen_fail += 1
                continue
            data_gen.generate(ins_shapes, exp_dir, out_shapes)
            status, outputs, losses, loss_grads, grads, ok_backends2, defect_counts = trainer.train(
                model_id=model_id, exp_dir=exp_dir, ok_backends=ok_backends, loss='mean_squared_error', optimizer='sgd', seed=seed)
            pair_deltas = comparator.compare(model_id=model_id, exp_dir=exp_dir,
                                             backends_outputs=outputs, backends_losses=losses,
                                             backends_loss_grads=loss_grads, backends_grads=grads,
                                             ok_backends=ok_backends2)
            collector.record_model(model_id, status, outputs, pair_deltas)
            ok_total += int(len(ok_backends2) >= 2)
        except Exception as exc:
            import traceback
            gen_fail += 1
            reporter.record(i + 1, 'tool_error', 'harness', model_info, stage='orchestration',
                            detail=str(exc), extra={'traceback': traceback.format_exc()})
        finally:
            if exp_dir is not None:
                try:
                    capture_case(exp_dir, metadata={'seed': seed, 'case_index': i,
                        'framework_pool': pool_name, 'ablation': ablation, 'input_dtype': dtype,
                        'loss': 'mean_squared_error', 'optimizer': 'sgd', 'threshold': threshold,
                        'source_sha256': source_hash, 'generation_status': generation_status,
                        'status': status, 'comparisons': pair_deltas})
                except Exception as exc:
                    reporter.record(i + 1, 'tool_error', 'harness', stage='evidence_capture',
                                    detail=str(exc), extra={'case_dir': str(exp_dir)})
                case_summaries.append({'case': str(Path(exp_dir).relative_to(Path(out_root))),
                    'generation_status': {bk: st.get('status') for bk, st in generation_status.items()},
                    'status': {bk: st.get('status') if isinstance(st, dict) else st for bk, st in status.items()},
                    'comparisons': pair_deltas})

    s = collector.summary()
    s['framework_pool'] = pool_name
    s['ablation'] = ablation
    s['enabled_spaces'] = enabled_spaces
    s['enabled_ops'] = sorted(enabled_ops)
    s['total_models'] = n_models
    s['ok_models'] = ok_total
    s['gen_fail'] = gen_fail
    s['cases'] = case_summaries
    s['coverage_scope'] = 'structures built successfully by at least one backend; not framework source coverage'
    s['coverage_detail'] = tracker.summary()

    # LIC / LPC / LSC (基于本配置全部生成模型, 跨模型累积)
    cov = tracker.summary()
    s['LIC'] = cov['LIC']
    s['LPC'] = cov['LPC']
    s['LSC'] = cov['LSC']
    s['LSC_cov_seq'] = cov['LSC_cov_seq']
    s['LSC_denom'] = cov['LSC_denom']
    s['diversity'] = selector.diversity_summary()

    reporter.dump(output_dir / 'observations.jsonl')
    s['observations'] = reporter.summary()
    s['defect_records'] = len(reporter.records)
    (output_dir / 'summary.json').write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding='utf-8')
    return s


def main():
    from scripts.check_environment import probe_environment
    from utils.reproducibility import source_digest
    parse = argparse.ArgumentParser(description=__doc__)
    parse.add_argument('--ablation', choices=['all']+ABLATION_ORDER, default='all')
    parse.add_argument('--pool', choices=UNIQUE_POOLS, default='keras3.10')
    parse.add_argument('--models', type=int, default=CASE_NUM)
    parse.add_argument('--threshold', type=float, default=0.15)
    parse.add_argument('--out', required=True, help='Fresh summary file; sibling <stem>_cases stores evidence')
    parse.add_argument('--timeout', type=float, default=120)
    parse.add_argument('--seed', type=int, default=2024)
    parse.add_argument('--workers', type=int, default=1)
    flags = parse.parse_args()
    if flags.models < 1 or flags.workers < 1 or flags.timeout <= 0 or flags.threshold < 0:
        parse.error('models/workers/timeout must be positive and threshold nonnegative')
    out = Path(flags.out).resolve()
    out_root = out.parent / (out.stem + '_cases')
    if out.exists() or (out_root.exists() and any(out_root.iterdir())):
        parse.error('Output exists. Choose a fresh --out; stale summaries are never reused.')
    out.parent.mkdir(parents=True, exist_ok=True)
    environment = probe_environment()
    meta = {'experiment':'ablation_exp2_v2', 'source_sha256':source_digest(PROJECT_ROOT),
            'models_per_config':flags.models, 'threshold':flags.threshold, 'seed':flags.seed,
            'framework_pool': flags.pool, 'environment':environment,
            'backend_identity_rule':'Only environment.backends identifies executed frameworks; pool is a generator domain.',
            'count_unit':'candidate observations, not confirmed bugs or unique root causes',
            'loss':'mean_squared_error', 'optimizer':'sgd', 'phase':'single forward/backward evaluation; no optimizer update',
            'comparison_threshold':'dtype-aware allclose gate and MAD > threshold',
            'historical_results_reused':False}
    if not environment['ready']:
        out.write_text(json.dumps({'meta':meta, 'status':'environment_error', 'by_pool':{}},
                                 ensure_ascii=False, indent=2), encoding='utf-8')
        raise SystemExit('Backend preflight failed; see ' + str(out))
    ablations = ABLATION_ORDER if flags.ablation == 'all' else [flags.ablation]
    tasks = [(flags.pool, ab, flags.models, flags.seed, flags.threshold, flags.timeout, str(out_root))
             for ab in ablations]
    start = time.time()
    if flags.workers > 1 and len(tasks)>1:
        import multiprocessing as mp
        with mp.get_context('spawn').Pool(flags.workers) as pool:
            results = pool.starmap(run_one, tasks)
    else:
        results=[]
        for task in tasks:
            print('Running ' + task[0] + '/' + task[1], flush=True)
            results.append(run_one(*task))
    meta['elapsed_sec']=round(time.time()-start, 3)
    result={'meta':meta, 'status':'completed', 'by_pool':{flags.pool:{s['ablation']:s for s in results}}}
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Saved '+str(out))


if __name__ == '__main__':
    main()
