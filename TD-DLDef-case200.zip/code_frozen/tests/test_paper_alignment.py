"""Regression tests for manuscript semantics and generator-caused false alarms."""
import contextlib
import io
import random
import json
import tempfile
from pathlib import Path
import unittest
from unittest import mock

import numpy as np

from utils.Thompson import ThompsonSampling
from utils.coverage import CoverageTracker
from utils.diversity import DiversityEvaluator
from utils.mutation import MutationConfig, ValueMutator
from utils.selection import Selector
from utils.utils import layer_conditions, layer_types, merging_layer_types
from src.cases_generation.layer_info_generator import LayerInfoGenerator
from src.cases_generation.model_info_generator import ModelInfoGenerator
from src.cases_generation.output_shape_calculator import OutputShapeCalculator
from src.cases_generation.variable_generator import VariableGenerator
from src.cases_generation.data_generator import DataGenerator
from scripts.run_ablation_exp1 import run_single_ablation


VAR = dict(tensor_dimension_range=(2, 5), tensor_element_size_range=(2, 5),
           weight_value_range=(-10.0, 10.0), small_value_range=(0, 1), vocabulary_size=101)
MODEL = dict(var=VAR, node_num_range=(10, 10), dag_io_num_range=(1, 2),
             dag_max_branch_num=2, cell_num=3, node_num_per_normal_cell=10,
             node_num_per_reduction_cell=2)


def model_dense(width=4, dtype=None):
    dense = dict(type='dense', args=dict(units=3), pre_layers=[0], output_shape=[None, 3])
    if dtype:
        dense['input_dtypes'] = [dtype]
    return dict(model_structure={
        '0': dict(type='input_object', args={}, pre_layers=[], output_shape=[None, width]),
        '1': dense}, input_id_list=[0], output_id_list=[1])


class PaperAlignmentTests(unittest.TestCase):
    def test_div_resets_model_not_suite(self):
        selector = Selector(['dense'], {'dense': None})
        for _ in range(2):
            selector.reset_model_state()
            self.assertTrue(selector.admit_candidate('dense', (None, 4), 'input_object', 2))
            self.assertFalse(selector.admit_candidate('dense', (None, 4), 'input_object', 2))
            selector.finish_model_state()
        self.assertEqual(selector.get_diversity().model_contributions[1]['new_total'], 0)
        self.assertEqual(selector.posterior_params('dense'), (3, 3))

    def test_shape_rank_novelty_is_not_credited_again_for_other_layer(self):
        div = DiversityEvaluator(['shape', 'dim'])
        div.begin_model()
        self.assertTrue(div.evaluate_and_record('dense', (None, 4))[0])
        self.assertFalse(div.evaluate_and_record('activation', (None, 4))[0])
        self.assertTrue(div.div('activation', (None, 5)))

    def test_merge_records_all_edges_shapes_and_ranks(self):
        div = DiversityEvaluator()
        div.begin_model()
        div.evaluate_and_record('dot', [(None, 3), (None, 2, 3)], ['dense', 'conv1D'])
        spaces = div.get_spaces()
        self.assertEqual(spaces['edge'], {('dense', 'dot'), ('conv1D', 'dot')})
        self.assertEqual(spaces['shape'], {(None, 3), (None, 2, 3)})
        self.assertEqual(spaces['dim'], {2, 3})
        self.assertEqual(div.space_sizes()['shape'], 2)

    def test_import_model_uses_all_merge_predecessors(self):
        selector = Selector(['dense', 'conv1D', 'dot'], {})
        model = model_dense()
        model['model_structure']['2'] = dict(type='conv1D', args={}, pre_layers=[0], output_shape=[None, 2, 3])
        model['model_structure']['3'] = dict(type='dot', args={}, pre_layers=[1, 2], output_shape=[None, 2])
        selector.update_with_model(model)
        self.assertIn(('conv1D', 'dot'), selector.get_global_spaces()['edge'])

    def test_ts_uniform_prior_ties_do_not_always_choose_first(self):
        ts = ThompsonSampling(['a', 'b'], 1, 1)
        with mock.patch('utils.Thompson.np.random.beta', return_value=0.5), \
                mock.patch('utils.Thompson.np.random.choice', return_value=1):
            self.assertEqual(ts.choose_arm(['a', 'b']), 'b')

    def test_ts_endpoint_logpdf_and_inverse_ranking(self):
        ts = ThompsonSampling(['a', 'b'], 1, 1)
        logpdf = ts._ThompsonSampling__beta_logpdf
        self.assertAlmostEqual(logpdf(0.0, 1, 2), np.log(2))
        self.assertAlmostEqual(logpdf(1.0, 2, 1), np.log(2))
        ts.update('a', 1)  # Beta(2,1), density at .9 is 1.8
        with mock.patch('utils.Thompson.np.random.beta', return_value=0.9):
            self.assertEqual(ts.choose_arm(['a', 'b']), 'b')

    def test_invalid_sampler_parameters_and_rewards_fail_early(self):
        with self.assertRaises(ValueError):
            ThompsonSampling(['a'], 0, 1)
        with self.assertRaises(ValueError):
            ThompsonSampling(['a'], 1, 1).update('a', 0.5)

    def test_pv_does_not_enable_state_or_multiple_outputs(self):
        vm = ValueMutator(MutationConfig(['pv'], 4), mutation_probability=1)
        for _ in range(30):
            args = vm.mutate_layer_args('LSTM', dict(units=4, stateful=False, return_state=False, return_sequences=False))
            self.assertFalse(args['stateful'])
            self.assertFalse(args['return_state'])

    def test_shape_alone_cannot_validate_conv_mutation(self):
        args = dict(filters=2, kernel_size=(2, 2), strides=(2, 2), dilation_rate=(2, 2))
        self.assertFalse(ValueMutator.valid_layer_args('conv2D', args, (None, 8, 8, 3)))
        args['dilation_rate'] = (1, 1)
        self.assertTrue(ValueMutator.valid_layer_args('conv2D', args, (None, 8, 8, 3)))

    def test_invalid_mutation_rolls_back_without_false_provenance(self):
        vm = ValueMutator(MutationConfig(['bv'], 4))
        original = dict(kernel_size=(2, 2), strides=(1, 1), dilation_rate=(2, 2))
        with mock.patch.object(vm, 'boundary_value', return_value=dict(original, strides=(2, 2))):
            self.assertEqual(vm.mutate_layer_args('conv2D', original), original)
            self.assertEqual(vm.pop_last_changes(), {})

    def test_cancelled_high_order_mutation_is_not_reported(self):
        vm = ValueMutator(MutationConfig(['pv', 'bv'], 4))
        def pv(layer, args):
            vm.last_changes['pv'] = {'units': (4, 8)}
            return dict(units=8)
        def bv(layer, args, shape):
            vm.last_changes['bv'] = {'units': (8, 4)}
            return dict(units=4)
        with mock.patch.object(vm, 'parameter_value', side_effect=pv), \
                mock.patch.object(vm, 'boundary_value', side_effect=bv):
            self.assertEqual(vm.mutate_layer_args('dense', {'units': 4}), {'units': 4})
            self.assertEqual(vm.pop_last_changes(), {})

    def test_shape_invariant_layer_parameter_mutation_is_retained(self):
        selector = Selector(['ELU'], {})
        gen = LayerInfoGenerator(VariableGenerator(VAR), selector,
                                 MutationConfig(['bv'], 2), layer_types=['ELU'])
        selector.reset_model_state()
        kind, args, shape = gen.generate((None, 4), 'dense')
        self.assertEqual(kind, 'ELU')
        self.assertEqual(shape, (None, 4))
        self.assertTrue(gen.pop_last_mutation())

    def test_upsampling_1d_mutation_recalculates_output(self):
        selector = Selector(['up_sampling1D'], {})
        gen = LayerInfoGenerator(VariableGenerator(VAR), selector,
                                 MutationConfig(['bv'], 2), layer_types=['up_sampling1D'])
        selector.reset_model_state()
        _, args, shape = gen.generate((None, 4, 3), 'dense')
        self.assertEqual(shape, (None, 4 * args['size'], 3))
        self.assertTrue(gen.pop_last_mutation())

    def test_depthwise_dilation_has_correct_shape(self):
        calc = OutputShapeCalculator()
        shape = calc.depthwise_conv2D_layer((None, 9, 9, 3), 'channels_last', 2,
            kernel_size=(3, 3), dilation_rate=(2, 2), strides=(1, 1), padding='valid')
        self.assertEqual(shape, (None, 5, 5, 6))

    def test_concatenate_target_partition_preserves_sum(self):
        var = VariableGenerator(VAR)
        shapes, output, axis = var.concatenate_shapes(3, (None, 12))
        self.assertEqual(len(shapes), 3)
        self.assertTrue(all(shape[axis] > 0 for shape in shapes))
        self.assertEqual(sum(shape[axis] for shape in shapes), output[axis])

    def test_never_executed_layer_has_zero_lic(self):
        tracker = CoverageTracker(['dense', 'conv2D'])
        tracker.record_model(model_dense(), 'int32')
        _, detail = tracker.compute_lic()
        self.assertEqual(detail['conv2D'], 0)
        self.assertGreater(detail['dense'], 0)
        self.assertEqual(tracker.summary()['metric_mode'], 'paper_v2')

    def test_lic_uses_distinct_full_shapes_and_caps_approximation(self):
        tracker = CoverageTracker(['dense'], sigma=5)
        for width in range(2, 12):
            tracker.record_model(model_dense(width))
        # dtype=1, rank=1, shape=min(10,5); denominator=8+4+5.
        self.assertEqual(tracker._paper_lic_counts('dense'), (7, 17))
        self.assertEqual(len(tracker.covered_shapes['dense']), 10)

    def test_runtime_dtype_metadata_overrides_input_estimate(self):
        tracker = CoverageTracker(['dense'])
        tracker.record_model(model_dense(dtype='float64'), 'int32')
        self.assertEqual(tracker.covered_dtypes['dense'], {'float64'})
        self.assertEqual(tracker.dtype_evidence['observed_layers'], 1)

    def test_legacy_lic_is_explicitly_labelled(self):
        tracker = CoverageTracker(['dense', 'conv2D'], metric_mode='legacy_0818')
        tracker.record_model(model_dense())
        self.assertGreater(tracker.compute_lic()[1]['conv2D'], 0)
        self.assertEqual(tracker.summary()['shape_space_approximation'], 'rank_layout')

    def test_template_unimplemented_mode_is_configuration_error(self):
        with self.assertRaisesRegex(ValueError, 'unsupported generation mode'):
            ModelInfoGenerator(MODEL, None, Selector(['dense'], {}), 'template')

    def test_canonical_order_does_not_depend_on_json_key_order(self):
        model = model_dense()
        model['model_structure'] = dict(reversed(list(model['model_structure'].items())))
        canonical = ModelInfoGenerator.canonical_model_info(model)
        self.assertEqual(canonical['canonical_layer_order'], ['0', '1'])
        model['model_structure']['0']['pre_layers'] = [1]
        with self.assertRaisesRegex(ValueError, 'cyclic'):
            ModelInfoGenerator.canonical_model_info(model)

    def test_structural_ablation_seed_replays_and_neuron_scope_is_explicit(self):
        a = run_single_ablation('keras3.10', 'full', 8, 42)
        random.seed(999)
        np.random.seed(999)
        b = run_single_ablation('keras3.10', 'full', 8, 42)
        c = run_single_ablation('keras3.10', 'no_nf', 8, 42)
        self.assertEqual(a['model_records'], b['model_records'])
        self.assertEqual(a['model_records'], c['model_records'])
        self.assertEqual(a['coverage_scope'], 'generated_structure_only')
        self.assertFalse(c['ablation_effect_evaluable'])
        self.assertFalse(a['neuron_mutations_executed'])
        self.assertEqual(a['framework_defects'], 0)

    def test_structure_resource_rejections_are_not_framework_defects(self):
        with mock.patch.object(ModelInfoGenerator, 'generate_seq_model', side_effect=ValueError('Shape too big!!')):
            result = run_single_ablation('keras3.10', 'full', 3, 42)
        self.assertEqual(result['failures_by_type'], {'tool_resource_rejection': 3})
        self.assertEqual(result['framework_defects'], 0)
        self.assertEqual(result['success_models'], 0)

    def test_data_inputs_follow_actual_it_dtype_and_embedding_bounds(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'models').mkdir()
            (root / 'models' / 'generation_config.json').write_text(json.dumps({'input_dtype': 'int8'}))
            model = {'model_structure': {
                '0': {'type': 'input_object', 'args': {'name': 'x'}, 'pre_layers': []},
                '1': {'type': 'embedding', 'args': {'input_dim': 4}, 'pre_layers': [0]}}}
            generator = DataGenerator({'instance_num': 5, 'element_val_range': (-1000, 1000), 'seed': 4})
            generator.generate({'x': (None, 32)}, directory, {'y': (None, 2)}, model_info=model)
            with np.load(root / 'dataset' / 'inputs.npz') as arrays:
                self.assertEqual(arrays['x'].dtype, np.dtype('int8'))
                self.assertGreaterEqual(arrays['x'].min(), 0)
                self.assertLess(arrays['x'].max(), 4)
            with np.load(root / 'dataset' / 'ground_truths.npz') as arrays:
                self.assertEqual(arrays['y'].dtype, np.dtype('float32'))

    def test_float16_embedding_indices_do_not_round_out_of_domain(self):
        generator = DataGenerator({'instance_num': 4, 'element_val_range': (0, 100), 'seed': 3})
        values = generator._DataGenerator__generate((None, 2000), np.dtype('float16'), 2050)
        self.assertTrue(np.isfinite(values).all())
        self.assertLess(values.max(), 2050)
        self.assertTrue(np.equal(values, np.floor(values)).all())

    def test_integer_input_range_cannot_wrap_on_cast(self):
        generator = DataGenerator({'instance_num': 8, 'element_val_range': (0, 1000), 'seed': 1})
        values = generator._DataGenerator__generate((None, 100), np.dtype('int8'))
        self.assertGreaterEqual(values.min(), 0)
        self.assertLessEqual(values.max(), 127)

    def test_dag_structure_smoke_and_merge_edges(self):
        pool = list(dict.fromkeys(layer_types + merging_layer_types))
        selector = Selector(pool, layer_conditions)
        gen = ModelInfoGenerator(MODEL, None, selector, 'merging',
                                 MutationConfig([], 2), layer_types=pool)
        random.seed(8)
        np.random.seed(8)
        selector.reset_model_state()
        with contextlib.redirect_stdout(io.StringIO()):
            model, _, _, _ = gen.generate_merge_model(12)
        selector.finish_model_state()
        structure = model['model_structure']
        for node in structure.values():
            for parent in node['pre_layers']:
                self.assertIn(parent, structure)
                self.assertIn((structure[parent]['type'], node['type']),
                              selector.get_global_spaces()['edge'])


if __name__ == '__main__':
    unittest.main()
