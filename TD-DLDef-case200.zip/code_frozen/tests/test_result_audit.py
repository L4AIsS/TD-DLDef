"""Evidence-preserving audit tests; no TensorFlow/PyTorch dependency."""
import csv
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location("audit_results", Path(__file__).resolve().parents[1] / "scripts" / "audit_results.py")
audit = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(audit)


def record(**kwargs):
    result = {"model_id": 1, "framework": "cntk2.7.0", "backend": "tensorflow",
              "defect_type": "crash", "stage": "training", "located_layer": None,
              "causing_snippet": None, "detail": "training process exited abnormally on tensorflow (exit=1)",
              "model_snippet": "00_input = keras.Input(shape=(3,))"}
    result.update(kwargs)
    return result


class AuditTests(unittest.TestCase):
    def test_exit_status_does_not_establish_framework_bug_or_tool_error(self):
        self.assertEqual(audit.classify_record(record())[0:2], ("insufficient_evidence", "exit_without_root_cause"))

    def test_explicit_loss_adapter_error_is_tool_error(self):
        text = "ValueError: Could not interpret loss identifier: huber_loss"
        self.assertEqual(audit.classify_record(record(), text)[0], "tool_error")

    def test_environment_and_invalid_test_require_explicit_evidence(self):
        self.assertEqual(audit.exception_classification("ModuleNotFoundError: No module named tensorflow")[0], "environment_error")
        self.assertEqual(audit.exception_classification("Input 'filter' of 'Conv2D' Op has type float32 that does not match type int32 of argument 'input'.")[0], "invalid_test")
        self.assertEqual(audit.exception_classification("ValueError: Shape too big!!")[0], "insufficient_evidence")
        self.assertEqual(audit.exception_classification("model_info_generator.py\nValueError: Shape too big!!")[1], "generator_resource_guard")

    def test_loss_only_alarm_is_not_silently_filtered(self):
        rec = record(defect_type="inconsistency", output_delta=0.0, loss_delta=100.0,
                     loss_grads_delta=float("inf"), detail="(threshold=0.15)")
        self.assertEqual(audit.classify_record(rec)[0], "insufficient_evidence")
        rec["output_delta"] = 0.16
        self.assertEqual(audit.classify_record(rec)[0], "candidate_anomaly")

    def test_legacy_snippet_is_not_misrepresented_as_executable(self):
        self.assertFalse(audit.snippet_status(record())["syntax_valid"])
        self.assertTrue(audit.snippet_status(record(model_snippet="x = 1"))["syntax_valid"])

    def test_nan_json_is_strict_and_fingerprint_is_typed(self):
        obj = audit.strict_value({"x": float("nan"), "y": float("inf")})
        self.assertEqual(obj, {"x": "NaN", "y": "Infinity"})
        json.dumps(obj, allow_nan=False)
        self.assertNotEqual(audit.digest({"x": float("nan")}), audit.digest({"x": "NaN"}))

    def test_record_dedup_preserves_runs_csv_and_source_lines(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data, output = root / "data", root / "out"
            data.mkdir()
            rec = record()
            source = data / "pool__full.jsonl"
            source.write_text(json.dumps(rec) + "\n\n" + json.dumps(rec) + "\n", encoding="utf8")
            (data / "other_run").mkdir()
            (data / "other_run" / "pool__full.jsonl").write_text(json.dumps(rec) + "\n", encoding="utf8")
            with source.with_suffix(".csv").open("w", newline="", encoding="utf8") as stream:
                writer = csv.DictWriter(stream, fieldnames=audit.CSV_FIELDS)
                writer.writeheader()
                writer.writerows([{k: rec.get(k) for k in audit.CSV_FIELDS}] * 2)
            summary = audit.run_audit(data, output)
            self.assertEqual(summary["raw_jsonl_records"], 3)
            self.assertEqual(summary["unique_run_records"], 2)
            self.assertEqual(summary["unique_payloads_across_runs"], 1)
            self.assertEqual(summary["symptom_clusters"], 1)
            self.assertEqual(summary["inventory_summary"]["matching_csv_projections"], 1)
            self.assertEqual(summary["confirmed_framework_bugs"], 0)
            unique = json.loads((output / "unique_records.json").read_text(encoding="utf8"))
            source_rec = next(x for x in unique if x["origin"]["path"] == source.name)
            self.assertEqual([x["line"] for x in source_rec["origins"]], [1, 3])
            self.assertEqual(source_rec["actual_backend"], "tensorflow")
            self.assertEqual(source_rec["framework_pool"], "cntk2.7.0")

    def test_model_ids_do_not_link_unrelated_run_logs(self):
        with tempfile.TemporaryDirectory() as temp:
            data = Path(temp)
            case = data / "exp2_abl_out_2" / "cntk2.7.0" / "full" / "000001" / "logs"
            case.mkdir(parents=True)
            (case / "detection.log").write_text("[ERROR] tensorflow\nValueError: Could not interpret loss identifier: huber_loss", encoding="utf8")
            source = data / "exp2_defects_1" / "cntk2.7.0__full.jsonl"
            result = audit.audit_one(data, source, 1, record())
            self.assertEqual(result["classification"], "insufficient_evidence")
            self.assertEqual(result["evidence"]["log_sources"], [])

    def test_backend_selection_does_not_take_another_backends_error(self):
        with tempfile.TemporaryDirectory() as temp:
            data = Path(temp)
            case = data / "exp2_abl_out_1" / "cntk2.7.0" / "full" / "000001" / "logs"
            case.mkdir(parents=True)
            (case / "detection.log").write_text("[ERROR] torch\nModuleNotFoundError: missing\n[ERROR] tensorflow\nValueError: Could not interpret loss identifier: huber_loss\n", encoding="utf8")
            source = data / "exp2_defects_1" / "cntk2.7.0__full.jsonl"
            result = audit.audit_one(data, source, 1, record())
            self.assertEqual(result["classification"], "tool_error")
            self.assertEqual(result["evidence"]["log_sources"][0]["line_start"], 3)

    def test_malformed_json_and_csv_mismatch_are_reported(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data = root / "data"
            data.mkdir()
            rec = record()
            source = data / "pool__full.jsonl"
            source.write_text(json.dumps(rec) + "\nnot json\n", encoding="utf8")
            with source.with_suffix(".csv").open("w", newline="", encoding="utf8") as stream:
                writer = csv.DictWriter(stream, fieldnames=audit.CSV_FIELDS)
                writer.writeheader()
                writer.writerow({k: ("changed" if k == "detail" else rec.get(k)) for k in audit.CSV_FIELDS})
            summary = audit.run_audit(data, root / "out")
            self.assertEqual(summary["raw_jsonl_records"], 1)
            self.assertEqual(summary["errors"][0]["line"], 2)
            self.assertEqual(summary["inventory_summary"]["csv_projection_mismatches"], 1)


if __name__ == "__main__":
    unittest.main()
