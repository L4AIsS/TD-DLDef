import ast
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
from utils.oracle import classify_run_status, is_inconsistent, DefectCollector
from utils.gradient_oracle import check_gradient
from utils.model_snippet import render_model_snippet, layer_source_snippet
from utils.reproducibility import capture_case, verify_case
from utils.defect_report import DefectReporter


def model_info():
    return {'model_structure': {
        '0': {'type':'input_object','args':{'name':'00_input','shape':(4,)},'pre_layers':[]},
        '1': {'type':'dense','args':{'name':'01_dense','units':1,'kernel_initializer':'random_uniform'},'pre_layers':[0]}},
        'input_id_list':[0], 'output_id_list':[1], 'input_dtype':'float64'}


class ReportingTests(unittest.TestCase):
    def test_numerical_bounds_must_fail_at_same_coordinate(self):
        from src.incons_detection.comparator import tensor_metric
        left=np.array([1e6,0.],dtype='float32')
        right=np.array([1e6+1.,1e-5],dtype='float32')
        self.assertFalse(tensor_metric(left,right,.15)['candidate'])
        right[1]=1.
        self.assertTrue(tensor_metric(left,right,.15)['candidate'])

    def test_gradient_storage_dtype_does_not_imply_computation_precision(self):
        from src.incons_detection.comparator import tensor_metric
        a=np.array([1e6],dtype='float64');b=a+1
        self.assertTrue(tensor_metric(a,b,.15)['candidate'])
        self.assertFalse(tensor_metric(a,b,.15,precision_dtype='float32')['candidate'])
        self.assertTrue(tensor_metric(np.array([0.]),np.array([1.]),.15,precision_dtype='float32')['candidate'])

    def test_report_uses_saved_input_dtype(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);(root/'models').mkdir()
            (root/'models/generation_config.json').write_text(json.dumps({'input_dtype':'int16'}))
            reporter=DefectReporter()
            record=reporter.record(1,'unknown','tensorflow',model_info(),extra={'case_dir':str(root)})
            self.assertIn("dtype='int16'",record['model_snippet'])

    def test_generic_exit_and_timeout_are_not_crashes(self):
        for code in (1, 255, -1, 2, -9):
            self.assertEqual(classify_run_status(code), 'unknown')
        self.assertEqual(classify_run_status(None),'not_run')
        self.assertEqual(classify_run_status({'status':'timeout','exit_code':-1}),'timeout')
        self.assertEqual(classify_run_status(0),'ok')

    def test_nonfinite_delta_is_not_inconsistency(self):
        for value in (None, float('nan'), float('inf'), 'bad'):
            self.assertFalse(is_inconsistent(value))
        self.assertTrue(is_inconsistent(0.16))

    def test_nan_requires_finite_peer_and_idempotent_model_accounting(self):
        c=DefectCollector(['tensorflow','torch'])
        status={b:{'status':'ok'} for b in ('tensorflow','torch')}
        both={b:{'layer':np.array([np.nan])} for b in status}
        c.record_model(1,status,both)
        self.assertEqual(c.summary()['total']['nan'],0)
        one={'tensorflow':{'layer':np.array([np.nan])},'torch':{'layer':np.array([1.])}}
        status['tensorflow']['numerical_evidence'] = {'eligible':True,'finite_peers':['torch'],
            'affected_tensors':{'nan':['output/layer']}}
        c.record_model(2,status,one)
        c.record_model(2,status,one)
        self.assertEqual(c.summary()['models'],2)
        self.assertEqual(c.summary()['total']['nan'],1)

    def test_candidate_comparison_enum_is_counted(self):
        c=DefectCollector(['tensorflow','torch'])
        c.record_model(1,{}, {}, {'tensorflow_torch':{'classification':'candidate','output':1.0}})
        self.assertEqual(c.summary()['total']['inconsistency'],1)

    def test_generated_source_uses_identifiers_and_preserves_tuple_dtype_names(self):
        source=render_model_snippet(model_info())
        ast.parse(source)
        self.assertIn('shape=(4,)',source)
        self.assertIn("dtype='float64'",source)
        self.assertIn("name='01_dense'",source)
        self.assertIn('model = keras.Model',source)
        ast.parse(layer_source_snippet(model_info(),'01_dense'))

    def test_manifest_detects_changed_inputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            (root/'models').mkdir();(root/'dataset').mkdir()
            (root/'models/model.json').write_text(json.dumps(model_info()))
            np.savez(root/'dataset/inputs.npz', x=np.ones(4))
            capture_case(root)
            ast.parse((root/'model_source.py').read_text(encoding='utf-8'))
            verify_case(root)
            np.savez(root/'dataset/inputs.npz',x=np.zeros(4))
            with self.assertRaises(ValueError):verify_case(root)

    def test_report_keeps_tool_observations_out_of_defect_totals(self):
        reporter=DefectReporter('cntk2.7.0')
        record=reporter.record(1,'tool_error','tensorflow',model_info(),detail='shape < mismatch')
        self.assertEqual(record['framework_pool'],'cntk2.7.0')
        self.assertFalse(record['confirmed_defect'])
        self.assertEqual(sum(reporter.summary()['total'].values()),0)
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'result.jsonl';reporter.dump(out)
            self.assertIn('shape &lt; mismatch',out.with_suffix('.html').read_text(encoding='utf-8'))


class GradientOracleTests(unittest.TestCase):
    def test_smooth_gradient_and_injected_wrong_gradient(self):
        x=np.array([.7,-.3],dtype='float64')
        kwargs={'pure':True,'synchronized':True,'smooth_mask':np.ones(2,dtype=bool)}
        self.assertEqual(check_gradient(lambda z:(z*z).sum(),x,2*x,**kwargs)['classification'],'consistent')
        self.assertTrue(check_gradient(lambda z:(z*z).sum(),x,np.zeros(2),**kwargs)['candidate'])

    def test_last_step_instability_not_misclassified(self):
        x=np.array([1.],dtype='float64')
        r=check_gradient(lambda z:np.exp(z).sum(),x,np.exp(x),pure=True,synchronized=True,
                         smooth_mask=[True],steps=(1e-2,1e-3,1e-4,1e-15))
        self.assertEqual(r['classification'],'excluded')

    def test_relu_boundary_excluded(self):
        x=np.zeros(3)
        r=check_gradient(lambda z:np.maximum(z,0).sum(),x,np.zeros(3),pure=True,synchronized=True,
                         smooth_mask=np.abs(x)>1e-2)
        self.assertEqual(r['classification'],'excluded')

    def test_impure_complex_low_precision_excluded(self):
        f=lambda x:(x*x).sum()
        self.assertEqual(check_gradient(f,np.ones(2),np.ones(2))['classification'],'excluded')
        for dt in ('complex128','float16'):
            r=check_gradient(f,np.ones(2,dtype=dt),np.ones(2),pure=True,synchronized=True,smooth_mask=[True,True])
            self.assertEqual(r['classification'],'excluded')

    def test_inplace_excluded(self):
        def f(x):
            x[0]+=1
            return x.sum()
        r=check_gradient(f,np.ones(2),np.ones(2),pure=True,synchronized=True,smooth_mask=[True,True])
        self.assertEqual(r['reason'],'in_place_mutation')

    def test_unstable_steps_excluded(self):
        # Near a discontinuity the central slopes diverge as h decreases.
        f=lambda x:float(x[0]>=0)
        r=check_gradient(f,np.zeros(1),np.zeros(1),pure=True,synchronized=True,smooth_mask=[True])
        self.assertEqual(r['reason'],'finite_difference_instability')


if __name__=='__main__':unittest.main()
