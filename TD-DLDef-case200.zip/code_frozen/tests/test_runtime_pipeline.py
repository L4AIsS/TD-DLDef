"""Regression tests for concrete harness false-positive mechanisms."""
import json
import sys
import tempfile
import unittest
from pathlib import Path
import numpy as np
from src.incons_detection.comparator import Comparator, tensor_metric, gradient_exclusions
from src.incons_detection.trainer import _load_arrays, equivalent_records
from src.incons_detection.train import canonical_loss, validate_loss_domain, validate_layer_contracts
from utils.runtime import (InvalidTest, UnsupportedTest, exception_record, load_named_arrays,
                           collect_process_status, write_json)
from utils.utils import CmdProcess, switch_backend


class DummyDB:
    def __init__(self): self.defects = []
    def add_training_incons(self, *args): return 1
    def add_localization_map(self, rows): self.rows = rows
    def record_inconsistency(self, *args): self.defects.append(args)


class RuntimeTests(unittest.TestCase):
    def test_argv_metacharacters_are_literal(self):
        literal = 'a b & echo unexpected; $(bad)'
        p = CmdProcess([sys.executable, '-c', 'import sys;print(sys.argv[1])', literal])
        self.assertEqual(p.run(15), 0)
        self.assertEqual(p.get_result()['stdout'].strip(), literal)
        with self.assertRaises(TypeError): CmdProcess('echo unsafe')

    def test_timeout_distinct_from_crash(self):
        p = CmdProcess([sys.executable, '-c', 'import time; time.sleep(10)'])
        self.assertEqual(p.run(.05), 124)
        self.assertEqual(p.get_result()['status'], 'timeout')

    def test_missing_executable_is_environment_failure(self):
        p = CmdProcess(['___no_such_executable___'])
        self.assertEqual(p.run(1), 127)
        self.assertEqual(p.get_result()['status'], 'environment_error')

    def test_worker_without_manifest_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            p = CmdProcess([sys.executable, '-c', 'pass'])
            p.run(10)
            record = collect_process_status(p, Path(d)/'run.json', 'torch', 'training')
            self.assertEqual(record['status'], 'tool_error')

    def test_nonzero_exit_cannot_be_overridden_by_success_manifest(self):
        with tempfile.TemporaryDirectory() as d:
            manifest = Path(d) / 'run.json'
            write_json(manifest, {'status': 'ok'})
            p = CmdProcess([sys.executable, '-c', 'import sys;sys.exit(2)'])
            p.run(10)
            self.assertEqual(collect_process_status(p, manifest, 'torch', 'training')['status'], 'unknown')

    def test_finite_float64_difference_overflow_is_observation(self):
        result = tensor_metric(np.array([1e308]), np.array([-1e308]))
        self.assertFalse(result['candidate'])
        self.assertEqual(result['classification'], 'extreme_scale_observation')

    def test_exception_never_proves_framework_crash(self):
        for exc, status in [(ValueError('unknown origin'),'unknown'),(ModuleNotFoundError('dependency'),'environment_error'),
                            (InvalidTest('domain'),'invalid_test'),(UnsupportedTest('backend'),'unsupported')]:
            self.assertEqual(exception_record(exc,'training','torch')['status'],status)

    def test_unknown_backend_not_silently_torch(self):
        with self.assertRaises(UnsupportedTest): switch_backend('theano')
        with self.assertRaises(UnsupportedTest): switch_backend('misspelled')

    def test_integer_convolution_and_cpu_nchw_classified_before_execution(self):
        from types import SimpleNamespace
        layer = type('Conv2D', (), {})()
        layer.name = 'conv'
        layer.input = SimpleNamespace(dtype='int8')
        layer.weights = [SimpleNamespace(dtype='float32')]
        model = SimpleNamespace(layers=[layer])
        with self.assertRaises(InvalidTest): validate_layer_contracts(model, 'torch')
        layer.input.dtype = 'float16'
        validate_layer_contracts(model, 'torch')
        layer = type('DepthwiseConv2D', (), {})()
        layer.name = 'depthwise'
        layer.input = SimpleNamespace(dtype='float32')
        layer.weights = [SimpleNamespace(dtype='float32')]
        layer.data_format = 'channels_first'
        with self.assertRaises(UnsupportedTest): validate_layer_contracts(SimpleNamespace(layers=[layer]), 'tensorflow')
        validate_layer_contracts(SimpleNamespace(layers=[layer]), 'torch')

    def test_named_archive_not_insertion_order(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'data.npz'; np.savez(p, second=np.ones((1,2))*2, first=np.ones((1,2)))
            result=load_named_arrays(p,['first','second'])
            self.assertTrue(np.all(result[0]==1))
            self.assertTrue(np.all(result[1]==2))
            with self.assertRaises(InvalidTest): load_named_arrays(p,['first'])

    def test_missing_artifact_and_pickle_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError): _load_arrays(d, {'layer':{'shape':[1],'dtype':'float32'}})
            np.save(Path(d)/'layer.npy',np.array([object()],dtype=object))
            with self.assertRaises(ValueError): _load_arrays(d, {'layer':{'shape':[1],'dtype':'object'}})

    def test_probability_domains_and_shapes(self):
        with self.assertRaises(InvalidTest): validate_loss_domain('binary_crossentropy',[np.array([-1.])],[np.array([.5])])
        with self.assertRaises(InvalidTest): validate_loss_domain('mean_squared_error',[np.ones((2,1))],[np.ones((2,2))])
        with self.assertRaises(InvalidTest): validate_loss_domain('poisson',[np.ones(2)],[np.array([0.,1.])])
        self.assertEqual(canonical_loss('huber_loss'),'huber')

    def test_shape_broadcast_and_nonfinite_cannot_trigger(self):
        self.assertFalse(tensor_metric(np.ones((2,1)),np.zeros((2,3)))['candidate'])
        self.assertFalse(tensor_metric(np.array([np.nan]),np.zeros(1))['candidate'])

    def test_float16_rounding_filtered(self):
        a=np.array([1.],dtype='float16');b=np.array([1.001],dtype='float16')
        self.assertFalse(tensor_metric(a,b,threshold=0)['candidate'])
        self.assertEqual(tensor_metric(a,b)['atol'],5e-3)

    def test_extreme_scale_observation(self):
        a=np.array([2.565618352e34],dtype='float32');b=np.array([2.565617857e34],dtype='float32')
        self.assertEqual(tensor_metric(a,b)['classification'],'extreme_scale_observation')

    def test_real_finite_difference_retained(self):
        self.assertTrue(tensor_metric(np.zeros(4,dtype='float32'),np.ones(4,dtype='float32'))['candidate'])

    def test_relu_boundary_and_pool_tie_excluded(self):
        structure={'0':{'type':'input_object','args':{'name':'input'},'pre_layers':[]},
                   '1':{'type':'ReLU','args':{'name':'relu'},'pre_layers':[0]}}
        self.assertTrue(gradient_exclusions(structure,{'input':np.zeros(3),'relu':np.zeros(3)}))
        structure['1']={'type':'max_pooling2D','args':{'name':'pool','pool_size':[2,2]},'pre_layers':[0]}
        out={'input':np.array([[[[1.],[1.]],[[0.],[-1.]]]]),'pool':np.ones((1,1,1,1))}
        self.assertTrue(gradient_exclusions(structure,out))

    def test_equivalence_requires_initial_state_and_true_identity(self):
        a={'status':'ok','equivalence':{'initial_weights':'a'},'actual_backend':'tensorflow','versions':{'keras':'3'}}
        b={**a,'actual_backend':'torch'}
        self.assertTrue(equivalent_records(a,b))
        self.assertFalse(equivalent_records(a,a))
        self.assertFalse(equivalent_records(a,{**b,'equivalence':{'initial_weights':'different_bn_state'}}))

    def test_comparison_name_alignment_high_id_and_missing_manifest(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/'models').mkdir();(root/'logs').mkdir()
            info={'input_id_list':[0],'output_id_list':[101],'model_structure':{
                '0':{'type':'input_object','args':{'name':'00_input'},'pre_layers':[]},
                '101':{'type':'dense','args':{'name':'101_dense'},'pre_layers':[0]}}}
            write_json(root/'models/model.json',info)
            db=DummyDB();comp=Comparator(db)
            a={'00_input':np.zeros(1,dtype='float32'),'101_dense':np.ones(1,dtype='float32')}
            b={'101_dense':np.ones(1,dtype='float32'),'00_input':np.zeros(1,dtype='float32')}
            for backend in ['tensorflow','torch']:
                write_json(root/'logs'/('training_%s.json'%backend),{'status':'ok','actual_backend':backend,
                           'versions':{'keras':'3'},'equivalence':{'initial_weights':'same','config':{'loss':'mean_squared_error'}}})
            args=(1,str(root),{'tensorflow':a,'torch':b},{'tensorflow':0.,'torch':0.},
                  {'tensorflow':{'101_dense':np.zeros(1)},'torch':{'101_dense':np.zeros(1)}},{},['tensorflow','torch'])
            r=comp.compare(*args)['tensorflow_torch']
            self.assertFalse(r['inconsistent']);self.assertEqual(r['raw_output'],0.)
            b['101_dense']=np.array([2.],dtype='float32')
            r=comp.compare(*args)['tensorflow_torch']
            self.assertTrue(r['inconsistent']);self.assertEqual(r['suspect_layer'],'101_dense')
            (root/'logs/training_torch.json').unlink()
            self.assertEqual(comp.compare(*args)['tensorflow_torch']['classification'],'excluded')


if __name__=='__main__': unittest.main()
