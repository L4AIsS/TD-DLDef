"""Cross-backend comparison with explicit equivalence and numerical-validity gates."""
from itertools import combinations
from pathlib import Path
import json
import numpy as np
from utils.oracle import DEFAULT_THRESHOLD
from utils.runtime import write_json
from src.incons_detection.trainer import equivalent_records


def tensor_metric(first, second, threshold=DEFAULT_THRESHOLD, precision_dtype=None):
    a, b = np.asarray(first), np.asarray(second)
    result = {'max_abs': None, 'candidate': False, 'classification': 'excluded'}
    if a.shape != b.shape or a.dtype != b.dtype or not a.size or a.dtype.kind not in 'fiu':
        return {**result, 'reason': 'shape/dtype mismatch or unsupported/empty tensor'}
    if not np.isfinite(a).all() or not np.isfinite(b).all():
        return {**result, 'reason': 'nonfinite values are handled by the separate nonfinite oracle'}
    precision = np.dtype(precision_dtype) if precision_dtype is not None else a.dtype
    if a.dtype.kind == 'f':
        # A gradient can be cast back to float64 after a float32 forward path.
        # Its storage type does not establish float64 computation accuracy.
        if precision.kind != 'f' or precision.itemsize > a.dtype.itemsize:
            precision = a.dtype
        atol, rtol = (5e-3, 5e-2) if precision.itemsize <= 2 else ((1e-6, 1e-4) if precision.itemsize <= 4 else (1e-9, 1e-7))
        result['precision_dtype'] = str(precision)
    else:
        atol, rtol = 0., 0.
    left, right = a.astype(np.float64), b.astype(np.float64)
    scale = np.maximum(np.abs(left), np.abs(right))
    with np.errstate(over='ignore', invalid='ignore'):
        difference = np.abs(left - right)
    if not np.isfinite(difference).all():
        return {**result, 'classification': 'extreme_scale_observation',
                'reason': 'difference overflowed float64; numerical scale requires separate review'}
    maximum = float(difference.max())
    result.update(max_abs=maximum, mean_abs=float(difference.mean()), atol=atol, rtol=rtol,
                  max_relative=float(np.max(difference / np.maximum(scale, max(atol, 1e-300)))))
    if a.dtype.kind == 'f' and float(scale.max()) > float(np.sqrt(np.finfo(precision).max)):
        return {**result, 'classification': 'extreme_scale_observation', 'reason': 'magnitude exceeds sqrt(dtype max); inspect scaling separately'}
    # The SAME coordinate must exceed both bounds. Separate any/max gates
    # can combine ordinary large-scale roundoff with a tiny near-zero error.
    candidate = bool(np.any((difference > threshold) & (difference > atol + rtol * scale)))
    result.update(candidate=candidate, classification='candidate' if candidate else 'consistent')
    return result


def _pool_has_tie(array, args, global_pool=False):
    x = np.asarray(array)
    channels_first = args.get('data_format') == 'channels_first'
    if channels_first:
        x = np.moveaxis(x, 1, -1)
    dimensions = x.ndim - 2
    if dimensions < 1:
        return True
    if global_pool:
        windows = np.moveaxis(x.reshape(x.shape[0], -1, x.shape[-1]), -1, 1)
    else:
        pool = args.get('pool_size', 2)
        pool = (pool,) * dimensions if isinstance(pool, int) else tuple(pool)
        strides = args.get('strides') or pool
        strides = (strides,) * dimensions if isinstance(strides, int) else tuple(strides)
        if args.get('padding', 'valid') == 'same':
            padding = [(0, 0)]
            for size, win, step in zip(x.shape[1:-1], pool, strides):
                total = max(0, (int(np.ceil(size / step)) - 1) * step + win - size)
                padding.append((total // 2, total - total // 2))
            x = np.pad(x.astype(float), padding + [(0, 0)], constant_values=-np.inf)
        if any(size < win for size, win in zip(x.shape[1:-1], pool)):
            return True
        windows = np.lib.stride_tricks.sliding_window_view(x, pool, axis=tuple(range(1, dimensions + 1)))
        windows = windows[(slice(None),) + tuple(slice(None, None, s) for s in strides) + (slice(None),) * (dimensions + 1)]
        windows = windows.reshape(*windows.shape[:-dimensions], -1)
    if windows.shape[-1] < 2:
        return False
    largest = np.partition(windows, -2, axis=-1)[..., -2:]
    return bool(np.any(np.isclose(largest[..., 0], largest[..., 1], atol=1e-7, rtol=1e-6)))


def gradient_exclusions(structure, outputs):
    """Conservative case-wide exclusion when a branch boundary may affect gradients.

    This does not pretend to perform coordinate-level finite-difference filtering;
    the standalone gradient oracle exposes an explicit smooth-coordinate mask.
    """
    reasons = []
    for node in structure.values():
        kind, args = node['type'].lower(), node['args']
        name = args['name']
        predecessors = [structure[str(i)]['args']['name'] for i in node.get('pre_layers', [])]
        incoming = [outputs[n] for n in predecessors if n in outputs]
        activation = str(args.get('activation', '')).lower()
        if kind in ('relu', 'leakyrelu', 'prelu', 'elu') or activation in ('relu', 'leaky_relu', 'elu'):
            tested = incoming if kind in ('relu', 'leakyrelu', 'prelu', 'elu') else [outputs[name]]
            boundaries = [args.get('threshold', 0.)]
            if args.get('max_value') is not None:
                boundaries.append(args['max_value'])
            if any(np.any(np.isclose(v, edge, atol=1e-7, rtol=1e-6)) for v in tested for edge in boundaries):
                reasons.append('activation branch boundary: ' + name)
        if 'max_pooling' in kind and incoming:
            if _pool_has_tie(incoming[0], args, kind.startswith('global')):
                reasons.append('max-pooling tied/near-tied extrema: ' + name)
        if kind in ('maximum', 'minimum') and len(incoming) > 1:
            if any(np.any(np.isclose(a, b, atol=1e-7, rtol=1e-6)) for a, b in combinations(incoming, 2)):
                reasons.append('merge tied extrema: ' + name)
    return reasons


class Comparator:
    def __init__(self, db_manager, threshold=DEFAULT_THRESHOLD, defect_reporter=None):
        self.db, self.threshold, self.reporter = db_manager, threshold, defect_reporter

    def compare(self, model_id, exp_dir, backends_outputs, backends_losses, backends_loss_grads, backends_grads, ok_backends):
        root = Path(exp_dir)
        info = json.loads((root / 'models' / 'model.json').read_text(encoding='utf-8'))
        structure = info['model_structure']
        output_names = [structure[str(i)]['args']['name'] for i in info['output_id_list']]
        expected_names = {n['args']['name'] for n in structure.values()}
        pairs = {}
        for a, b in combinations(ok_backends, 2):
            pair = a + '_' + b
            result = {'output': None, 'loss': None, 'loss_grads': None, 'raw_output': None,
                      'raw_loss': None, 'raw_loss_grads': None, 'inconsistent': False,
                      'classification': 'excluded', 'metrics': {}}
            pairs[pair] = result
            first, second = backends_outputs.get(a), backends_outputs.get(b)
            try:
                states = [json.loads((root / 'logs' / ('training_%s.json' % bk)).read_text(encoding='utf-8')) for bk in (a, b)]
                if not equivalent_records(*states):
                    raise ValueError('backend identity, initial state, input/target, or execution configuration is not equivalent')
                if first is None or second is None or set(first) != expected_names or set(second) != expected_names:
                    raise ValueError('missing or mismatched named layer outputs')
                # Reject the whole comparison if any layer contract differs, even
                # when final outputs happen to have matching shapes.
                for name in expected_names:
                    if first[name].shape != second[name].shape or first[name].dtype != second[name].dtype:
                        raise ValueError('shape/dtype mismatch at ' + name)
                metrics = result['metrics']
                metrics['outputs'] = {n: tensor_metric(first[n], second[n], self.threshold) for n in output_names}
                # Loss is written as a Python scalar; compare at the actual model
                # computation dtype, not the text parser's artificial float64.
                dtype = np.result_type(*[first[n].dtype for n in output_names])
                metrics['loss'] = tensor_metric(np.asarray(backends_losses[a], dtype=dtype),
                                                np.asarray(backends_losses[b], dtype=dtype), self.threshold)
                excluded = list(dict.fromkeys(gradient_exclusions(structure, first) + gradient_exclusions(structure, second)))
                if states[0].get('missing_gradients') or states[1].get('missing_gradients'):
                    excluded.append('some layer/input gradients unavailable; full backward equivalence not established')
                if states[0]['equivalence']['config']['loss'] == 'mean_absolute_error':
                    with np.load(root / 'dataset' / 'ground_truths.npz', allow_pickle=False) as targets:
                        if any(np.any(np.isclose(first[n], targets[n], atol=1e-7, rtol=1e-6)) for n in output_names):
                            excluded.append('absolute-error loss at nondifferentiable zero residual')
                result['gradient_exclusions'] = excluded
                g1, g2 = backends_loss_grads.get(a), backends_loss_grads.get(b)
                forward_dtypes = [arr.dtype for values in (first, second) for arr in values.values()
                                  if arr.dtype.kind == 'f']
                gradient_precision = min(forward_dtypes, key=lambda dt: dt.itemsize) if forward_dtypes else None
                result['gradient_precision_basis'] = {'dtype': str(gradient_precision),
                    'rule': 'lowest observed forward floating precision; storage dtype alone is insufficient'}
                metrics['loss_gradients'] = {}
                if not excluded and g1 and g2 and set(g1) == set(g2) == set(output_names):
                    metrics['loss_gradients'] = {n: tensor_metric(g1[n], g2[n], self.threshold, precision_dtype=gradient_precision) for n in output_names}
                metrics['layer_gradients'] = {}
                lg1, lg2 = backends_grads.get(a), backends_grads.get(b)
                if not excluded and lg1 and lg2 and set(lg1) == set(lg2):
                    metrics['layer_gradients'] = {n: tensor_metric(lg1[n], lg2[n], self.threshold, precision_dtype=gradient_precision) for n in lg1}
                for key, collection in [('output', list(metrics['outputs'].values())),
                                        ('loss', [metrics['loss']]),
                                        ('loss_grads', list(metrics['loss_gradients'].values()) + list(metrics['layer_gradients'].values()))]:
                    raw = [m['max_abs'] for m in collection if m['max_abs'] is not None]
                    result['raw_' + key] = max(raw) if raw else None
                    valid = [m for m in collection if m['classification'] in ('consistent', 'candidate')]
                    result[key] = max((m['max_abs'] for m in valid if m['candidate']), default=0.) if valid else None
                result['inconsistent'] = any(result[k] is not None and result[k] > self.threshold for k in ('output', 'loss', 'loss_grads'))
                result['classification'] = 'candidate' if result['inconsistent'] else (
                    'consistent' if any(result[k] is not None for k in ('output', 'loss', 'loss_grads')) else 'excluded')
                if any(m['classification'] == 'extreme_scale_observation' for group in (metrics['outputs'], metrics['loss_gradients'], metrics['layer_gradients']) for m in group.values()) or metrics['loss']['classification'] == 'extreme_scale_observation':
                    result['observations'] = ['extreme_scale_observation']
                # Localization uses name-indexed tensors and actual graph parents.
                localization = {}
                gradient_metrics = metrics['layer_gradients']
                for node in structure.values():
                    name = node['args']['name']
                    parents = [structure[str(i)]['args']['name'] for i in node.get('pre_layers', [])]
                    delta = tensor_metric(first[name], second[name], self.threshold)['max_abs']
                    previous = [tensor_metric(first[n], second[n], self.threshold)['max_abs'] for n in parents]
                    previous = [x for x in previous if x is not None]
                    base = max(previous, default=0.)
                    rate = (delta - base) / (base + 1e-7) if delta is not None else None
                    grad_delta = gradient_metrics.get(name, {}).get('max_abs')
                    localization[name] = (delta, rate, grad_delta, None, str(parents))
                result['localization'] = {n: {'output_delta': x[0], 'output_R': x[1], 'gradient_delta': x[2]} for n, x in localization.items()}
                incons_id = self.db.add_training_incons(model_id, pair, result['output'], result['loss'], result['loss_grads'])
                self.db.add_localization_map([(incons_id, n, *v) for n, v in localization.items()])
                if result['inconsistent']:
                    self.db.record_inconsistency(model_id, pair)
                    suspect = next((node['args']['name'] for node in structure.values()
                                    if tensor_metric(first[node['args']['name']], second[node['args']['name']], self.threshold)['candidate']), None)
                    if suspect is None:
                        suspect = next((n for n, m in gradient_metrics.items() if m['candidate']), output_names[0])
                    result['suspect_layer'] = suspect
                    if self.reporter:
                        self.reporter.record(model_id, 'inconsistency', pair, info, layer_name=suspect,
                                             stage='comparison', detail='equivalent finite backend runs exceed MAD and dtype-aware tolerances',
                                             extra={**result, 'evidence_status': 'candidate', 'case_dir': str(root)})
            except (KeyError, OSError, ValueError, TypeError) as exc:
                result['reason'] = str(exc)
                if self.reporter:
                    self.reporter.record(model_id, 'comparison_excluded', pair, info, stage='comparison',
                                         detail=str(exc), extra={'classification': 'excluded', 'case_dir': str(root)})
        write_json(root / 'logs' / 'comparison.json', pairs)
        return pairs
