"""Execute one deterministic training-mode forward/backward pass on a verified backend.

Every compared tensor comes from this same pass. No optimizer update is performed;
optimizer selection is recorded for reproducibility, not claimed as tested behavior.
"""
import argparse
import json
import hashlib
import sys
from pathlib import Path
import numpy as np
from utils.utils import switch_backend
from utils.runtime import (InvalidTest, UnsupportedTest, array_fingerprint,
                           exception_record, load_named_arrays, write_json)


def canonical_loss(name):
    return {'huber_loss': 'huber', 'kullback_leibler_divergence': 'kl_divergence'}.get(name, name)


def validate_loss_domain(name, targets, predictions):
    for target, pred in zip(targets, predictions):
        if target.shape != pred.shape:
            raise InvalidTest('target and output shapes must match exactly; broadcasting is excluded')
        if name in ('categorical_crossentropy', 'binary_crossentropy', 'kl_divergence'):
            if np.any(target < 0) or np.any(target > 1):
                raise InvalidTest('probability loss requires targets in [0, 1]')
            if name in ('categorical_crossentropy', 'kl_divergence') and not np.allclose(target.sum(axis=-1), 1, atol=1e-5):
                raise InvalidTest('categorical/probability targets must sum to one')
            if np.isfinite(pred).all() and (np.any(pred < 0) or np.any(pred > 1)):
                raise InvalidTest('probability loss requires output probabilities in [0, 1]')
        if name == 'poisson' and (np.any(target < 0) or (np.isfinite(pred).all() and np.any(pred <= 0))):
            raise InvalidTest('Poisson loss requires nonnegative targets and positive predictions')


def weight_map(model):
    return {'%s/%d' % (layer.name, i): value for layer in model.layers
            for i, value in enumerate(layer.get_weights())}


def validate_equivalent_weights(model, directory):
    for layer in model.layers:
        path = Path(directory) / (layer.name + '.npz')
        if not path.is_file():
            raise InvalidTest('missing shared initial weight archive: %s' % path)
        with np.load(path, allow_pickle=False) as archive:
            expected = [archive['arr_%d' % i] for i in range(len(archive.files))]
        actual = layer.get_weights()
        if len(expected) != len(actual) or any(a.dtype != b.dtype or a.shape != b.shape or not np.array_equal(a, b, equal_nan=True)
                                              for a, b in zip(expected, actual)):
            raise InvalidTest('initial weights/state differ from shared tensors for %s' % layer.name)
        if any(not np.isfinite(a).all() for a in actual):
            raise InvalidTest('nonfinite initial weights/state for %s' % layer.name)
        if layer.__class__.__name__ == 'BatchNormalization' and any(
                'moving_variance' in str(w.name) and np.any(np.asarray(w) < 0) for w in layer.weights):
            raise InvalidTest('BatchNorm moving variance must be nonnegative')


def validate_layer_contracts(model, backend):
    """Known kernel contracts, checked before a failing forward call."""
    convolution_types = {'Conv1D', 'Conv2D', 'Conv3D', 'Conv1DTranspose',
                         'Conv2DTranspose', 'Conv3DTranspose', 'SeparableConv1D',
                         'SeparableConv2D', 'DepthwiseConv1D', 'DepthwiseConv2D',
                         'ConvLSTM2D'}
    for layer in model.layers:
        kind = layer.__class__.__name__
        if kind in convolution_types:
            symbolic = layer.input if isinstance(layer.input, (list, tuple)) else [layer.input]
            integer_input = any(np.dtype(str(t.dtype)).kind in 'iu' for t in symbolic)
            floating_weights = any(np.dtype(str(w.dtype)).kind == 'f' for w in layer.weights)
            if integer_input and floating_weights:
                raise InvalidTest('integer convolution input with floating-point filter violates kernel dtype contract: %s' % layer.name)
        if backend == 'tensorflow' and kind in ('DepthwiseConv2D', 'Conv2DTranspose') and getattr(layer, 'data_format', None) == 'channels_first':
            raise UnsupportedTest('TensorFlow CPU %s requires NHWC/channels_last in this adapter' % kind)


def run(flags):
    identity = switch_backend(flags.backend)
    import keras
    keras.utils.set_random_seed(flags.seed)
    if flags.backend == 'torch':
        import torch
        torch.set_num_threads(1)
        torch.use_deterministic_algorithms(True)
    else:
        import tensorflow as tf
        tf.config.experimental.enable_op_determinism()
    model_info = json.loads(Path(flags.model_info_path).read_text(encoding='utf-8'))
    structure = model_info['model_structure']
    input_names = [structure[str(i)]['args']['name'] for i in model_info['input_id_list']]
    output_names = [structure[str(i)]['args']['name'] for i in model_info['output_id_list']]
    model = keras.models.load_model(flags.model_path, compile=False)
    validate_equivalent_weights(model, Path(flags.model_path).parent / 'initial_weights')
    validate_layer_contracts(model, flags.backend)
    initial_hash = array_fingerprint(weight_map(model))
    # Initializers differ intentionally: the first backend samples weights and
    # peers initialize zeros before loading the identical verified tensors.
    # They cannot affect this pass and must not reject equivalent executions.
    def semantic_config(value):
        if isinstance(value, dict):
            return {k: semantic_config(v) for k, v in value.items()
                    if not k.endswith('_initializer')}
        if isinstance(value, (tuple, list)):
            return [semantic_config(v) for v in value]
        return value
    architecture_hash = hashlib.sha256(json.dumps(semantic_config(model.get_config()),
        sort_keys=True, default=str).encode('utf-8')).hexdigest()
    x = load_named_arrays(flags.training_instances_path, input_names)
    y = load_named_arrays(flags.ground_truths_path, output_names)
    if len(model.inputs) != len(x) or len(model.outputs) != len(y):
        raise InvalidTest('model/data input-output arity mismatch')
    for index, (array, symbolic) in enumerate(zip(x, model.inputs)):
        if len(array.shape) != len(symbolic.shape) or any(b is not None and int(b) != a for a, b in zip(array.shape, symbolic.shape)):
            raise InvalidTest('input shape does not match declared model input')
        # The cast is identical and explicitly recorded on both backends.
        declared_dtype = np.dtype(str(symbolic.dtype))
        if declared_dtype.kind in 'iu':
            limits = np.iinfo(declared_dtype)
            if np.any(array < limits.min) or np.any(array > limits.max) or np.any(array != np.floor(array)):
                raise InvalidTest('integer input dtype requires integral values within its representable range')
        x[index] = array.astype(declared_dtype, copy=False)
        if not np.isfinite(x[index]).all():
            raise InvalidTest('declared input dtype cast overflowed')
    input_values = dict(zip(input_names, x))
    for node in structure.values():
        if node['type'].lower() == 'embedding':
            predecessors = node.get('pre_layers', [])
            if len(predecessors) != 1:
                raise InvalidTest('Embedding requires exactly one index input')
            source = structure[str(predecessors[0])]['args']['name']
            if source not in input_values:
                raise UnsupportedTest('transformed Embedding indices require a domain-validation adapter')
            indices = input_values[source]
            if np.any(indices != np.floor(indices)) or np.any(indices < 0) or np.any(indices >= int(node['args']['input_dim'])):
                raise InvalidTest('Embedding indices must be integers in [0, input_dim)')
    for layer in model.layers:
        name = layer.__class__.__name__
        if name in ('Dropout', 'AlphaDropout', 'GaussianDropout', 'GaussianNoise', 'SpatialDropout1D', 'SpatialDropout2D', 'SpatialDropout3D'):
            raise UnsupportedTest('cross-backend stochastic masks are not synchronized: %s' % layer.name)
        if getattr(layer, 'dropout', 0) or getattr(layer, 'recurrent_dropout', 0) or getattr(layer, 'stateful', False):
            raise UnsupportedTest('stochastic/stateful recurrent execution is not synchronized: %s' % layer.name)
    layers = [layer for layer in model.layers if layer.name not in input_names]
    layer_names = [layer.name for layer in layers]
    expected_names = {item['args']['name'] for item in structure.values()}
    if set(input_names + layer_names) != expected_names:
        raise UnsupportedTest('model structure contains unreachable or unrepresented layers')
    if any(isinstance(layer.output, (tuple, list, dict)) for layer in layers):
        raise UnsupportedTest('multi-tensor layer outputs require a dedicated adapter')
    probe = keras.Model(model.inputs, [layer.output for layer in layers])
    loss_name = canonical_loss(flags.loss)
    try:
        loss_fn = keras.losses.get(loss_name)
        optimizer_serialized = keras.optimizers.serialize(keras.optimizers.get(flags.optimizer))
        optimizer_config = {key: optimizer_serialized[key] for key in ('class_name', 'config')}
    except (ValueError, TypeError) as exc:
        raise UnsupportedTest(str(exc)) from exc

    def calculate(inputs):
        values = probe(inputs, training=True)
        values = list(values) if isinstance(values, (list, tuple)) else [values]
        named = dict(zip(layer_names, values))
        predictions = [named[name] for name in output_names]
        validate_loss_domain(loss_name, y, [keras.ops.convert_to_numpy(p) for p in predictions])
        losses = [keras.ops.mean(loss_fn(keras.ops.convert_to_tensor(target, dtype=pred.dtype), pred))
                  for target, pred in zip(y, predictions)]
        total = sum(losses)
        # Includes weight and activity regularizers from this exact call.
        if probe.losses:
            total = total + sum(probe.losses)
        return named, total

    if flags.backend == 'tensorflow':
        import tensorflow as tf
        inputs = [tf.convert_to_tensor(a) for a in x]
        with tf.GradientTape(persistent=True) as tape:
            for value in inputs:
                if value.dtype.is_floating:
                    tape.watch(value)
            named, total = calculate(inputs)
        all_values = dict(zip(input_names, inputs)) | named
        differentiable = {n: v for n, v in all_values.items() if v.dtype.is_floating}
        grads = tape.gradient(total, list(differentiable.values()))
        del tape
    else:
        import torch
        inputs = [torch.as_tensor(a.copy()) for a in x]
        for value in inputs:
            if value.is_floating_point():
                value.requires_grad_(True)
        named, total = calculate(inputs)
        all_values = dict(zip(input_names, inputs)) | named
        differentiable = {n: v for n, v in all_values.items() if v.is_floating_point() and v.requires_grad}
        if differentiable and total.requires_grad:
            grads = torch.autograd.grad(total, list(differentiable.values()), allow_unused=True)
        else:
            grads = [None] * len(differentiable)
    arrays = {n: np.asarray(keras.ops.convert_to_numpy(v)) for n, v in all_values.items()}
    gradients = {n: np.asarray(keras.ops.convert_to_numpy(g)) for n, g in zip(differentiable, grads) if g is not None}
    loss_value = float(keras.ops.convert_to_numpy(total))
    output_gradients = {n: gradients[n] for n in output_names if n in gradients}
    artifacts = {}
    for kind, directory, values in [('outputs', flags.outputs_dir, arrays),
                                     ('loss_gradients', flags.loss_grads_dir, output_gradients),
                                     ('layer_gradients', flags.gradients_dir, gradients)]:
        Path(directory).mkdir(parents=True, exist_ok=True)
        for name, array in values.items():
            np.save(Path(directory) / (name + '.npy'), array, allow_pickle=False)
        artifacts[kind] = {n: {'shape': list(a.shape), 'dtype': str(a.dtype)} for n, a in values.items()}
    Path(flags.loss_path).parent.mkdir(parents=True, exist_ok=True)
    Path(flags.loss_path).write_text(repr(loss_value), encoding='utf-8')
    config = {'loss': loss_name, 'loss_reduction': 'mean_per_output_then_sum_plus_regularizers',
              'optimizer': optimizer_config, 'training': True, 'optimizer_steps': 0, 'seed': flags.seed,
              'device': 'CPU'}
    manifest = {'status': 'ok', 'stage': 'training', **identity, 'artifacts': artifacts,
                'equivalence': {'inputs': array_fingerprint(dict(zip(input_names, x))),
                                'targets': array_fingerprint(dict(zip(output_names, y))),
                                'initial_weights': initial_hash, 'architecture': architecture_hash, 'config': config},
                'missing_gradients': sorted(set(all_values) - set(gradients)),
                'loss_finite': bool(np.isfinite(loss_value)),
                'protocol': 'single_forward_backward_no_optimizer_update'}
    write_json(flags.status_path, manifest)
    return manifest


def main(argv=None):
    parser = argparse.ArgumentParser()
    for name in ('backend', 'loss', 'optimizer', 'model_path', 'model_info_path',
                 'training_instances_path', 'ground_truths_path', 'outputs_dir',
                 'loss_path', 'loss_grads_dir', 'gradients_dir'):
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--status_path')
    flags = parser.parse_args(argv)
    if not flags.status_path:
        flags.status_path = str(Path(flags.outputs_dir).parent.parent / 'logs' / ('training_%s.json' % flags.backend))
    try:
        run(flags)
        return 0
    except Exception as exc:
        record = exception_record(exc, 'training', flags.backend)
        write_json(flags.status_path, record)
        print(record['traceback'], file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
