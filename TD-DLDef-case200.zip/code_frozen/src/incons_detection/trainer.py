"""Orchestrate verified workers, reject incomplete artifacts, and retain triage evidence."""
import json
import random
import sys
from pathlib import Path
import numpy as np
from utils.utils import losses, optimizers, CmdProcess
from utils.runtime import collect_process_status, write_json


def _load_arrays(directory, specification):
    directory = Path(directory)
    expected = set(specification)
    actual = {p.stem for p in directory.glob('*.npy')}
    if actual != expected:
        raise ValueError('artifact names do not match manifest: %s versus %s' % (actual, expected))
    arrays = {}
    for name, spec in specification.items():
        arr = np.load(directory / (name + '.npy'), allow_pickle=False)
        if list(arr.shape) != spec['shape'] or str(arr.dtype) != spec['dtype'] or arr.dtype.kind not in 'fiu' or arr.size == 0:
            raise ValueError('invalid shape/dtype/content in artifact %s' % name)
        arrays[name] = arr
    return arrays


def equivalent_records(first, second):
    return (first.get('status') == second.get('status') == 'ok'
            and bool(first.get('equivalence'))
            and first['equivalence'] == second.get('equivalence')
            and first.get('actual_backend') != second.get('actual_backend')
            and first.get('versions', {}).get('keras') == second.get('versions', {}).get('keras'))


class Trainer:
    def __init__(self, db_manager, timeout, python_path=None, defect_reporter=None):
        self.db = db_manager
        self.timeout = timeout
        self.python = python_path or sys.executable
        self.reporter = defect_reporter
        self.last_status = {}

    def train(self, model_id, exp_dir, ok_backends, loss=None, optimizer=None, seed=0):
        root = Path(exp_dir)
        model_dir = root / 'models'
        info = json.loads((model_dir / 'model.json').read_text(encoding='utf-8'))
        expected = {v['args']['name'] for v in info['model_structure'].values()}
        loss, optimizer = loss or random.choice(losses), optimizer or random.choice(optimizers)
        self.db.record_loss_optimizer(model_id, loss, optimizer)
        status, outputs, values, loss_grads, gradients = {}, {}, {}, {}, {}
        counts = {bk: {'crash': 0, 'nan': 0, 'inf': 0} for bk in ok_backends}
        for bk in ok_backends:
            manifest = root / 'logs' / ('training_%s.json' % bk)
            manifest.unlink(missing_ok=True)
            # Remove only prior numeric outputs for this exact backend/case.
            for folder in ('layer_outputs', 'loss_gradients', 'layer_gradients'):
                directory = root / folder / bk
                directory.mkdir(parents=True, exist_ok=True)
                for stale in directory.glob('*.npy'):
                    stale.unlink()
            loss_path = root / 'loss' / (bk + '.txt')
            loss_path.parent.mkdir(parents=True, exist_ok=True)
            loss_path.unlink(missing_ok=True)
            argv = [self.python, '-m', 'src.incons_detection.train', '--backend', bk,
                    '--loss', loss, '--optimizer', optimizer,
                    '--model_path', str(model_dir / (bk + '.keras')),
                    '--model_info_path', str(model_dir / 'model.json'),
                    '--training_instances_path', str(root / 'dataset' / 'inputs.npz'),
                    '--ground_truths_path', str(root / 'dataset' / 'ground_truths.npz'),
                    '--outputs_dir', str(root / 'layer_outputs' / bk),
                    '--loss_path', str(loss_path),
                    '--loss_grads_dir', str(root / 'loss_gradients' / bk),
                    '--gradients_dir', str(root / 'layer_gradients' / bk),
                    '--status_path', str(manifest), '--seed', str(int(seed))]
            process = CmdProcess(argv, log_prefix=manifest.with_suffix(''))
            process.run(self.timeout)
            record = collect_process_status(process, manifest, bk, 'training')
            if record['status'] == 'ok':
                try:
                    spec = record['artifacts']
                    if set(spec['outputs']) != expected:
                        raise ValueError('missing layer outputs in manifest')
                    if not record.get('equivalence') or record.get('actual_backend') != bk:
                        raise ValueError('missing equivalence or backend identity evidence')
                    out = _load_arrays(root / 'layer_outputs' / bk, spec['outputs'])
                    lg = _load_arrays(root / 'loss_gradients' / bk, spec['loss_gradients'])
                    gr = _load_arrays(root / 'layer_gradients' / bk, spec['layer_gradients'])
                    value = float(loss_path.read_text(encoding='utf-8'))
                    outputs[bk], values[bk], loss_grads[bk], gradients[bk] = out, value, lg, gr
                except (KeyError, OSError, ValueError, TypeError) as exc:
                    record.update(status='tool_error', message='incomplete/invalid artifacts: %s' % exc)
                    write_json(manifest, record)
            status[bk] = record
            if record['status'] == 'candidate_crash' and record.get('validated_peer_evidence'):
                counts[bk]['crash'] = 1
                self.db.record_crash_defect(model_id, bk)
            if record['status'] != 'ok' and self.reporter:
                kind = record['status']
                self.reporter.record(model_id, 'crash' if kind == 'candidate_crash' else kind, bk,
                                     info, stage='training', detail=record.get('message') or record.get('stderr') or kind,
                                     extra={'runtime_status': record, 'classification': kind,
                                            'evidence_status': 'candidate' if kind == 'candidate_crash' else 'excluded',
                                            'case_dir': str(root)})

        def observed(bk):
            tensors = {'output/' + k: v for k, v in outputs[bk].items()}
            tensors['loss'] = np.asarray(values[bk])
            tensors.update({'loss_gradient/' + k: v for k, v in loss_grads[bk].items()})
            tensors.update({'gradient/' + k: v for k, v in gradients[bk].items()})
            return tensors

        for bk in outputs:
            own = observed(bk)
            issues = {kind: [name for name, arr in own.items() if name.startswith('output/') and predicate(arr).any()]
                      for kind, predicate in [('nan', np.isnan), ('inf', np.isinf)]}
            peers = []
            for other in outputs:
                if other == bk or not equivalent_records(status[bk], status[other]):
                    continue
                peer = observed(other)
                output_keys = [k for k in own if k.startswith('output/')]
                if all(k in peer and own[k].shape == peer[k].shape and np.isfinite(peer[k]).all() for k in output_keys):
                    peers.append(other)
            auxiliary = {kind: [name for name, arr in own.items() if not name.startswith('output/') and predicate(arr).any()]
                         for kind, predicate in [('nan', np.isnan), ('inf', np.isinf)]}
            if any(auxiliary.values()) and self.reporter:
                self.reporter.record(model_id, 'nonfinite_observation', bk, info, stage='training',
                                     detail='nonfinite loss/gradients (outside paper output oracle): %s' % auxiliary,
                                     extra={'classification': 'auxiliary_nonfinite', 'case_dir': str(root)})
            status[bk]['numerical_evidence'] = {'affected_tensors': issues, 'auxiliary_nonfinite': auxiliary, 'finite_peers': peers,
                                                'eligible': bool(peers)}
            for kind, names in issues.items():
                if not names:
                    continue
                candidate = bool(peers)
                if candidate:
                    counts[bk][kind] = 1
                    getattr(self.db, 'record_%s_defect' % kind)(model_id, bk)
                layer = next((v['args']['name'] for v in info['model_structure'].values()
                              if any(n.endswith('/' + v['args']['name']) for n in names)), None)
                if self.reporter:
                    self.reporter.record(model_id, kind if candidate else 'nonfinite_observation', bk,
                                         info, layer_name=layer, stage='training',
                                         detail='%s in %s; equivalent finite peers=%s' % (kind, names, peers),
                                         extra={'classification': 'candidate' if candidate else 'unconfirmed_nonfinite',
                                                'evidence_status': 'candidate' if candidate else 'observation',
                                                'affected_tensors': names, 'finite_peers': peers,
                                                'case_dir': str(root)})
            write_json(root / 'logs' / ('training_%s.json' % bk), status[bk])
        for kind in ('crash', 'nan', 'inf'):
            affected = [bk for bk in counts if counts[bk][kind]]
            if affected:
                getattr(self.db, 'update_model_%s_backends' % kind)(model_id, affected)
        self.last_status = status
        return status, outputs, values, loss_grads, gradients, list(outputs), counts
