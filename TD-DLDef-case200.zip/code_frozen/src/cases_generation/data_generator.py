"""Generate reproducible, dtype-correct inputs within known input contracts."""
from typing import Optional
from pathlib import Path
import json
import numpy as np


class DataGenerator:
    def __init__(self, config: dict):
        self.__instance_num = int(config['instance_num'])
        self.__ele_val_range = tuple(config['element_val_range'])
        self.__rng = np.random.RandomState(config['seed']) if 'seed' in config else np.random
        if self.__instance_num <= 0:
            raise ValueError('instance_num must be positive')

    def generate(self, input_shapes: dict, exp_dir: str,
                 output_shapes: Optional[dict] = None, input_dtype=None, model_info=None):
        root = Path(exp_dir)
        save_dir = root / 'dataset'
        save_dir.mkdir(parents=True, exist_ok=True)
        config_path = root / 'models' / 'generation_config.json'
        generation = json.loads(config_path.read_text(encoding='utf-8')) if config_path.exists() else {}
        model_path = root / 'models' / 'model.json'
        if model_info is None and model_path.exists():
            model_info = json.loads(model_path.read_text(encoding='utf-8'))
        structure = {str(k): v for k, v in (model_info or {}).get('model_structure', {}).items()}
        by_name = {v.get('args', {}).get('name'): (key, v) for key, v in structure.items()
                   if v['type'] == 'input_object'}
        inputs, metadata = {}, {}
        for name, shape in input_shapes.items():
            layer_id, info = by_name.get(name, (None, {}))
            dtype = np.dtype(input_dtype or generation.get('input_dtype') or
                             info.get('args', {}).get('dtype') or 'float32')
            vocabularies = [int(node['args']['input_dim']) for node in structure.values()
                            if node['type'] == 'embedding' and layer_id is not None and
                            layer_id in {str(p) for p in node.get('pre_layers', [])}]
            vocabulary = min(vocabularies) if vocabularies else None
            array = self.__generate(shape, dtype, vocabulary)
            inputs[name] = array
            metadata[name] = {'dtype': str(array.dtype), 'shape': list(array.shape),
                              'minimum': float(array.min()), 'maximum': float(array.max()),
                              'embedding_vocabulary_limit': vocabulary}
        np.savez(save_dir / 'inputs.npz', **inputs)
        if output_shapes:
            targets = {name: self.__generate(shape, np.dtype('float32'))
                       for name, shape in output_shapes.items()}
            np.savez(save_dir / 'ground_truths.npz', **targets)
        (save_dir / 'dataset_generation.json').write_text(json.dumps({
            'scope': 'generated_inputs', 'inputs': metadata,
            'target_dtype': 'float32', 'configured_value_range': list(self.__ele_val_range),
            'embedding_policy': 'nonnegative_integer_values_below_final_input_dim',
        }, ensure_ascii=False, indent=2), encoding='utf-8')

    def __generate(self, shape, dtype, vocabulary=None):
        dtype = np.dtype(dtype)
        if dtype.kind not in 'fiu':
            raise ValueError('unsupported generated input dtype: %s' % dtype)
        if not shape or any(not isinstance(d, (int, np.integer)) or d <= 0 for d in shape[1:]):
            raise ValueError('invalid data shape: %r' % (shape,))
        concrete = (self.__instance_num, *shape[1:])
        a, b = self.__ele_val_range
        if not np.isfinite(a) or not np.isfinite(b) or a >= b:
            raise ValueError('element_val_range must be finite and increasing')
        if vocabulary is not None:
            if vocabulary <= 0:
                raise ValueError('embedding input_dim must be positive')
            if dtype.kind in 'iu':
                high = min(vocabulary, int(np.iinfo(dtype).max) + 1)
            else:
                # Keep indices exactly representable after conversion, e.g.
                # float16 rounding must not turn vocabulary-1 into vocabulary.
                high = min(vocabulary, 2 ** (np.finfo(dtype).nmant + 1) + 1)
            values = self.__rng.randint(0, high, size=concrete).astype(dtype)
        elif dtype.kind in 'iu':
            limits = np.iinfo(dtype)
            low, high = max(int(np.ceil(a)), int(limits.min)), min(int(np.ceil(b)), int(limits.max) + 1)
            if low >= high:
                raise ValueError('configured value range has no representable values in %s' % dtype)
            values = self.__rng.randint(low, high, size=concrete, dtype=dtype)
        else:
            values = self.__rng.uniform(a, b, size=concrete).astype(dtype)
        if not np.isfinite(values).all():
            raise ValueError('generated values overflowed the requested dtype')
        return values
