"""Runtime evidence shared by subprocess workers; no framework imports here."""
import hashlib
import json
import platform
import sys
import traceback
from pathlib import Path

import numpy as np


class InvalidTest(ValueError):
    """The generated test violates its explicit input/shape/domain contract."""


class UnsupportedTest(RuntimeError):
    """No implemented equivalent execution exists for this configuration."""


class EnvironmentError(RuntimeError):
    """Requested framework could not be imported or did not match its identity."""


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    temporary.replace(path)


def array_fingerprint(arrays):
    digest = hashlib.sha256()
    items = sorted(arrays.items()) if isinstance(arrays, dict) else enumerate(arrays)
    for name, array in items:
        array = np.asarray(array)
        digest.update(str(name).encode())
        digest.update(str(array.shape).encode())
        digest.update(array.dtype.str.encode())
        digest.update(np.ascontiguousarray(array).tobytes())
    return digest.hexdigest()


def backend_identity(requested):
    import importlib
    import keras
    actual = keras.backend.backend()
    if actual != requested:
        raise EnvironmentError('requested backend %s, Keras is actually using %s' % (requested, actual))
    if int(keras.__version__.split('.')[0]) < 3:
        raise UnsupportedTest('this implementation requires Keras 3; legacy backends require separate adapters')
    framework = importlib.import_module(actual)
    return {'requested_backend': requested, 'actual_backend': actual,
            'versions': {'python': platform.python_version(), 'keras': keras.__version__,
                         actual: framework.__version__, 'numpy': np.__version__},
            'executable': sys.executable, 'platform': platform.platform()}


def exception_record(exc, stage, backend):
    if isinstance(exc, (ModuleNotFoundError, ImportError, EnvironmentError)):
        kind = 'environment_error'
    elif isinstance(exc, UnsupportedTest):
        kind = 'unsupported'
    elif isinstance(exc, InvalidTest):
        kind = 'invalid_test'
    else:
        # A Python traceback cannot establish a framework crash. Retain evidence
        # for triage rather than promote ordinary harness errors to defects.
        kind = 'unknown'
    return {'status': kind, 'stage': stage, 'requested_backend': backend,
            'exception_type': type(exc).__name__, 'message': str(exc),
            'traceback': traceback.format_exc()}


def collect_process_status(process, manifest, backend, stage):
    result = dict(process.get_result() or {})
    evidence = {}
    if Path(manifest).is_file():
        try:
            evidence = json.loads(Path(manifest).read_text(encoding='utf-8'))
        except (ValueError, OSError):
            pass
    status = result.get('status', 'unknown')
    if status == 'ok':
        status = evidence.get('status', 'tool_error')
    elif status == 'process_error':
        status = evidence.get('status', 'unknown')
        if status in ('ok', 'running'):
            status = 'unknown'  # a success manifest cannot override a nonzero exit
        code = result.get('exit_code')
        if not evidence and isinstance(code, int) and (code in (-6, -11) or (code & 0xffffffff) in (0xc0000005, 0xc000001d, 0xc0000409)):
            status = 'native_crash_observation'
    combined = {**evidence, **result, 'status': status, 'stage': evidence.get('stage', stage),
                'requested_backend': backend, 'manifest_path': str(manifest)}
    if status == 'tool_error' and not evidence:
        combined['message'] = 'worker exited without a valid completion manifest'
    write_json(manifest, combined)
    return combined


def load_named_arrays(path, names):
    with np.load(path, allow_pickle=False) as archive:
        if set(archive.files) != set(names):
            raise InvalidTest('named arrays differ: expected %s, got %s' % (names, archive.files))
        values = [np.asarray(archive[name]) for name in names]
    for name, value in zip(names, values):
        if not value.size or value.dtype.kind not in 'fiu' or not np.isfinite(value).all():
            raise InvalidTest('input/target %s must be a nonempty, real, finite numeric array' % name)
    return values
