"""Paper Eq. (3): marginal diversity of the current partial model.

Model-local sets drive DIV; separate suite sets are diagnostics only.
Shapes/ranks are elements themselves as defined in Section III-B.
"""


class DiversityEvaluator:
    SPACES = ('layer', 'edge', 'shape', 'dim')
    SPACE_NAMES = dict(layer='layer_space', edge='edge_space',
                       shape='input_shape_space', dim='input_dim_space')

    def __init__(self, enabled_spaces=None):
        self.enabled = set(self.SPACES if enabled_spaces is None else enabled_spaces)
        unknown = self.enabled.difference(self.SPACES)
        if unknown:
            raise ValueError('unknown diversity spaces: %s' % sorted(unknown))
        self.reset()

    def reset(self):
        self.spaces = {s: set() for s in self.SPACES}
        self.suite_spaces = {s: set() for s in self.SPACES}
        self.model_contributions = []
        self.__pending = None

    def begin_model(self):
        self.spaces = {s: set() for s in self.SPACES}
        self.__pending = {s: 0 for s in self.SPACES}

    def end_model(self):
        if self.__pending is not None:
            rec = dict(self.__pending)
            rec['new_total'] = sum(rec.values())
            self.model_contributions.append(rec)
            self.__pending = None

    def get_spaces(self):
        """Return current-model spaces for Eq. (3)."""
        return {s: set(v) for s, v in self.spaces.items()}

    def get_suite_spaces(self):
        return {s: set(v) for s, v in self.suite_spaces.items()}

    def space_sizes(self):
        return {s: len(v) for s, v in self.suite_spaces.items()}

    def _elements(self, layer_type, input_shape, pre_layer_type, input_dim):
        elements = {s: set() for s in self.SPACES}
        elements['layer'].add(layer_type)
        predecessors = pre_layer_type if isinstance(pre_layer_type, (list, tuple)) else [pre_layer_type]
        elements['edge'].update((pre, layer_type) for pre in predecessors if pre is not None)
        if input_shape is not None:
            shapes = input_shape if input_shape and isinstance(input_shape[0], (tuple, list)) else [input_shape]
            for shape in shapes:
                elements['shape'].add(tuple(shape))
                elements['dim'].add(len(shape))
        if input_dim is not None:
            dims = input_dim if isinstance(input_dim, (tuple, list)) else [input_dim]
            elements['dim'].update(int(dim) for dim in dims)
        return elements

    def evaluate_and_record(self, layer_type, input_shape=None, pre_layer_type=None,
                            input_dim=None, input_num=None):
        elements = self._elements(layer_type, input_shape, pre_layer_type, input_dim)
        contrib = {s: False for s in self.SPACES}
        for s in self.enabled:
            added = elements[s] - self.spaces[s]
            contrib[s] = bool(added)
            self.spaces[s].update(added)
            # Reports record suite novelty; candidate admission uses model novelty.
            suite_added = elements[s] - self.suite_spaces[s]
            self.suite_spaces[s].update(suite_added)
            if self.__pending is not None:
                self.__pending[s] += len(suite_added)
        return any(contrib.values()), contrib

    def div(self, layer_type, input_shape=None, pre_layer_type=None, input_dim=None):
        elements = self._elements(layer_type, input_shape, pre_layer_type, input_dim)
        return any(elements[s] - self.spaces[s] for s in self.enabled)
