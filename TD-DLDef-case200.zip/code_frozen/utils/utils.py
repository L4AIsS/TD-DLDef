import os


import subprocess
import platform


class CmdProcess:
    """Run argv without a shell and preserve failure evidence separately from exit codes."""

    def __init__(self, cmd, cwd=None, env=None, log_prefix=None):
        if isinstance(cmd, (str, bytes)):
            raise TypeError('CmdProcess requires a sequence of argv strings, never a shell command')
        self.argv = [str(part) for part in cmd]
        self.cwd, self.env, self.log_prefix = cwd, env, log_prefix
        self.result = None

    def run(self, timeout):
        import time
        from pathlib import Path
        started = time.monotonic()
        try:
            process = subprocess.Popen(self.argv, shell=False, cwd=self.cwd, env=self.env,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                stdout, stderr = process.communicate(timeout=timeout)
                status = 'ok' if process.returncode == 0 else 'process_error'
            except subprocess.TimeoutExpired:
                process.kill()
                stdout, stderr = process.communicate()
                status = 'timeout'
            code = process.returncode
        except OSError as exc:
            stdout, stderr, status, code = b'', str(exc).encode('utf-8'), 'environment_error', None
        self.result = {'status': status, 'exit_code': code, 'argv': self.argv,
                       'duration_seconds': time.monotonic() - started,
                       'stdout': stdout.decode('utf-8', errors='replace'),
                       'stderr': stderr.decode('utf-8', errors='replace')}
        if self.log_prefix:
            prefix = Path(self.log_prefix)
            prefix.parent.mkdir(parents=True, exist_ok=True)
            prefix.with_suffix('.stdout.log').write_text(self.result['stdout'], encoding='utf-8')
            prefix.with_suffix('.stderr.log').write_text(self.result['stderr'], encoding='utf-8')
        return 124 if status == 'timeout' else (127 if code is None else code)

    def get_result(self):
        return self.result


def construct_layer_name(layer_id, layer_type, cell_type=''):
    return str(layer_id).zfill(2) + '_' + layer_type + (('' if cell_type == '' else '_') + cell_type)


def get_HH_mm_ss(td):
    days, seconds = td.days, td.seconds
    hours = days * 24 + seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    return hours, minutes, secs


def switch_backend(bk):
    from utils.runtime import UnsupportedTest, EnvironmentError
    import sys
    if bk not in ('tensorflow', 'torch'):
        raise UnsupportedTest('supported verified adapters are tensorflow and torch, got %r' % bk)
    if 'keras' in sys.modules:
        import keras
        if keras.backend.backend() != bk:
            raise EnvironmentError('Keras was already imported with a different backend')
    os.environ['KERAS_BACKEND'] = bk
    os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
    os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
    os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '2')
    os.environ.setdefault('OMP_NUM_THREADS', '1')
    os.environ.setdefault('TF_NUM_INTEROP_THREADS', '1')
    os.environ.setdefault('TF_NUM_INTRAOP_THREADS', '1')
    # Import only after backend environment variables are final.
    import importlib
    importlib.import_module(bk)
    from utils.runtime import backend_identity
    return backend_identity(bk)


def get_layer_func(layer_type):
    import keras

    def _str2Str(s):
        res = ''
        i = 0
        while i < len(s):
            if i == 0:
                res += s[i].upper()
            elif s[i] == '_':
                i += 1
                res += s[i].upper()
            else:
                res += s[i]
            i += 1
        return res

    return keras.Input if layer_type == 'input_object' else getattr(keras.layers, _str2Str(layer_type))


seq_layer_types = [
    'dense',
    # 'masking',
    'embedding',

    'conv1D',
    'conv2D',
    'conv3D',
    'separable_conv1D',
    'separable_conv2D',
    'depthwise_conv2D',
    'conv2D_transpose',
    'conv3D_transpose',

    'max_pooling1D',
    'max_pooling2D',
    'max_pooling3D',
    'average_pooling1D',
    'average_pooling2D',
    'average_pooling3D',
    'global_max_pooling1D',
    'global_max_pooling2D',
    'global_max_pooling3D',
    'global_average_pooling1D',
    'global_average_pooling2D',
    'global_average_pooling3D',

    'time_distributed',
    # 'bidirectional', 3.0 unsupported

    'batch_normalization',

    'reshape',
    'flatten',
    'repeat_vector',
    'permute',
    'cropping1D',
    'cropping2D',
    'cropping3D',
    'up_sampling1D',
    'up_sampling2D',
    'up_sampling3D',
    'zero_padding1D',
    'zero_padding2D',
    'zero_padding3D',

    # 'locally_connected1D', 3.0 unsupported
    # 'locally_connected2D', 3.0 unsupported
] # 37

RNN_layer_types = [
    'LSTM',
    'GRU',
    'simpleRNN',
    'convLSTM2D',
] # 4

activation_layer_types = [
    'activation',

    'ReLU',
    'softmax',
    'leakyReLU',
    'PReLU',
    'ELU',
    # 'thresholded_ReLU', 3.0 不支持
] # 5

merging_layer_types = [
    'concatenate',
    'average',
    'maximum',
    'minimum',
    'add',
    'subtract',
    'multiply',
    'dot',
] # 8

# 所有layer类型
# layer_types = seq_layer_types + RNN_layer_types + activation_layer_types + merging_layer_types
# for seq
layer_types = seq_layer_types + RNN_layer_types + activation_layer_types

# layer的分类

conv_layer_types = [
    'conv1D',
    'conv2D',
    'conv3D',
    'separable_conv1D',
    'separable_conv2D',
    'depthwise_conv2D',
    'conv2D_transpose',
    'conv3D_transpose',
]

pooling_layer_types = [
    'max_pooling1D',
    'max_pooling2D',
    'max_pooling3D',
    'average_pooling1D',
    'average_pooling2D',
    'average_pooling3D',
]

recurrent_layer_types = [
    'time_distributed',
    'bidirectional',
    *RNN_layer_types
]

normalization_layers_types = [
    'batch_normalization',
]

reshape_layer_types = [
    'reshape',
    'flatten',
    'repeat_vector',
    'permute',
    'cropping1D',
    'cropping2D',
    'cropping3D',
    'up_sampling1D',
    'up_sampling2D',
    'up_sampling3D',
    'zero_padding1D',
    'zero_padding2D',
    'zero_padding3D',
]

locally_connected_layer_types = [
    'locally_connected1D',
    'locally_connected2D',
]

normal_layer_types = seq_layer_types + RNN_layer_types + activation_layer_types
reduction_layer_types = pooling_layer_types + merging_layer_types

activation_cond = (lambda **kwargs: kwargs['e1'] in ['dense', *conv_layer_types, *recurrent_layer_types])

dim_3_cond = (lambda **kwargs: kwargs.get('input_dim', None) == 3)
dim_4_cond = (lambda **kwargs: kwargs.get('input_dim', None) == 4)
dim_5_cond = (lambda **kwargs: kwargs.get('input_dim', None) == 5)

# layer的连接条件
layer_conditions = {
    **{layer_name: activation_cond for layer_name in activation_layer_types},
    'embedding': (lambda **kwargs: kwargs.get('e1', None) == 'input_object' and kwargs.get('input_dim', None) == 2),

    'conv1D': dim_3_cond,
    'conv2D': dim_4_cond,
    'conv3D': dim_5_cond,
    'separable_conv1D': dim_3_cond,
    'separable_conv2D': dim_4_cond,
    'depthwise_conv2D': dim_4_cond,
    'conv2D_transpose': dim_4_cond,
    'conv3D_transpose': dim_5_cond,

    'max_pooling1D': dim_3_cond,
    'max_pooling2D': dim_4_cond,
    'max_pooling3D': dim_5_cond,
    'average_pooling1D': dim_3_cond,
    'average_pooling2D': dim_4_cond,
    'average_pooling3D': dim_5_cond,
    'global_max_pooling1D': dim_3_cond,
    'global_max_pooling2D': dim_4_cond,
    'global_max_pooling3D': dim_5_cond,
    'global_average_pooling1D': dim_3_cond,
    'global_average_pooling2D': dim_4_cond,
    'global_average_pooling3D': dim_5_cond,

    'LSTM': dim_3_cond,
    'GRU': dim_3_cond,
    'simpleRNN': dim_3_cond,
    'time_distributed': (lambda **kwargs: kwargs.get('input_dim', None) >= 3),
    'bidirectional': (lambda **kwargs: kwargs.get('input_dim', None) == 3 or kwargs.get('input_dim', None) == 5),
    'convLSTM2D': dim_5_cond,

    'flatten': (lambda **kwargs: kwargs.get('input_dim', None) >= 3),
    'repeat_vector': (lambda **kwargs: kwargs.get('input_dim', None) == 2),
    'cropping1D': dim_3_cond,
    'cropping2D': dim_4_cond,
    'cropping3D': dim_5_cond,
    'up_sampling1D': dim_3_cond,
    'up_sampling2D': dim_4_cond,
    'up_sampling3D': dim_5_cond,
    'zero_padding1D': dim_3_cond,
    'zero_padding2D': dim_4_cond,
    'zero_padding3D': dim_5_cond,

    'locally_connected1D': dim_3_cond,
    'locally_connected2D': dim_4_cond,

    'subtract': (lambda **kwargs: kwargs.get('input_num', None) == 2),
    'dot': (lambda **kwargs: kwargs.get('input_num', None) == 2 and kwargs.get('output_shape', None) is None),
    'concatenate': (lambda **kwargs: kwargs.get('output_shape', None) is None)
}

losses = ['mean_squared_error', 'mean_absolute_error', 'huber']


optimizers = [
    'sgd',
    'rmsprop',
    'adagrad',
    'adadelta',
    'adam',
    'adamax',
    'nadam',
]

dataset_shape = {
    'cifar10': ((None, 32, 32, 3), (None, 10)),
    'mnist': ((None, 28, 28, 1), (None, 10)),
    'fashion_mnist': ((None, 28, 28, 1), (None, 10)),
    'imagenet': ((None, 224, 224, 3), (None, 1000)),
    'sinewave': ((None, 49, 1), (None, 1)),
    'price': ((None, 1, 240), (None,))
}
