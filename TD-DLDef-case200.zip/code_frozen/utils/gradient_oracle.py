"""Conservative finite-difference oracle for the paper's Appendix filters.

Callable must return a scalar objective. State/purity/differentiability are
explicit preconditions, not properties inferred from an arbitrary Python call.
This optional oracle is separate from cross-backend automatic differentiation.
"""
import numpy as np


def check_gradient(fn, x, analytic, *, pure=False, synchronized=False,
                   smooth_mask=None, steps=(1e-2, 1e-3, 1e-4),
                   atol=1e-5, rtol=1e-3, max_elements=4096):
    x, analytic = np.asarray(x), np.asarray(analytic)
    def excluded(reason):
        return {'classification': 'excluded', 'reason': reason, 'candidate': False}
    if not pure or not synchronized:
        return excluded('purity_and_state_equivalence_not_established')
    if x.dtype.kind == 'c' or analytic.dtype.kind == 'c':
        return excluded('complex_requires_separate_gradient_convention')
    if x.dtype.kind != 'f' or x.dtype.itemsize < 4:
        return excluded('nonfloating_or_low_precision_input')
    if x.shape != analytic.shape or x.size > max_elements:
        return excluded('shape_mismatch_or_budget')
    if not np.isfinite(x).all() or not np.isfinite(analytic).all():
        return excluded('nonfinite_input_or_analytic_gradient')
    if smooth_mask is None:
        return excluded('differentiability_not_established')
    mask = np.asarray(smooth_mask, dtype=bool)
    if mask.shape != x.shape or not mask.any():
        return excluded('no_comparable_smooth_coordinates')
    steps = tuple(float(h) for h in steps)
    if not np.isfinite(atol) or not np.isfinite(rtol) or atol < 0 or rtol < 0:
        raise ValueError('finite nonnegative tolerances required')
    if len(steps) < 3 or any(not np.isfinite(h) or h <= 0 for h in steps) or any(a <= b for a, b in zip(steps, steps[1:])):
        raise ValueError('at least three strictly decreasing positive steps required')
    before = x.copy()
    def evaluate(v):
        arg = v.copy()
        out = np.asarray(fn(arg))
        if not np.array_equal(arg, v):
            raise ValueError('in_place_mutation')
        if out.size != 1 or not np.isfinite(out).all():
            raise ValueError('objective_must_be_finite_scalar')
        return float(out.reshape(-1)[0])
    try:
        baseline = evaluate(x)
        if evaluate(x) != baseline:
            return excluded('stateful_or_nondeterministic_objective')
        if abs(baseline) > np.sqrt(np.finfo(x.dtype).max):
            return excluded('extreme_scale')
        estimates = []
        for h in steps:
            g = np.zeros(x.shape, dtype=np.float64)
            for idx in zip(*np.where(mask)):
                plus, minus = x.copy(), x.copy()
                plus[idx] += h
                minus[idx] -= h
                gap = float(plus[idx]) - float(minus[idx])
                if gap == 0:
                    return excluded('step_not_representable')
                g[idx] = (evaluate(plus) - evaluate(minus)) / gap
            estimates.append(g)
        if evaluate(x) != baseline or not np.array_equal(x, before):
            return excluded('state_changed_during_finite_differences')
    except (ValueError, TypeError, FloatingPointError) as exc:
        return excluded(str(exc))
    # Require agreement of the last two steps and no cancellation-driven growth.
    e0 = np.max(np.abs(estimates[-2][mask] - estimates[-3][mask]))
    e1 = np.max(np.abs(estimates[-1][mask] - estimates[-2][mask]))
    scale = max(float(np.max(np.abs(estimates[-1][mask]))), atol)
    if e1 > atol + rtol * scale or (scale <= atol and e1 > e0 * 4 and e1 > np.finfo(x.dtype).eps * 10):
        return excluded('finite_difference_instability')
    candidate = not np.allclose(analytic[mask], estimates[-1][mask], atol=atol, rtol=rtol)
    return {'classification': 'candidate_gradient_inconsistency' if candidate else 'consistent',
            'candidate': candidate, 'steps': list(steps), 'checked_elements': int(mask.sum()),
            'excluded_elements': int(mask.size-mask.sum()), 'atol': atol, 'rtol': rtol,
            'max_abs_error': float(np.max(np.abs(analytic[mask]-estimates[-1][mask])))}
