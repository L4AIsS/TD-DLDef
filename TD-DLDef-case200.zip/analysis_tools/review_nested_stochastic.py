"""Read active model configs only; never alter original case evidence."""
import argparse, hashlib, json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--cases-root', type=Path, required=True)
p.add_argument('--output-dir', type=Path, required=True)
a = p.parse_args()
base = a.cases_root.resolve()
a.output_dir.mkdir(parents=True, exist_ok=True)
records = []

def scan(value, path):
    found = []
    if isinstance(value, dict):
        for key, child in value.items():
            if key == 'mutations':
                continue  # Historical pre-mutation values are not active settings.
            here = path + '.' + key
            if key in ('dropout', 'recurrent_dropout', 'stateful') and child:
                found.append({'path': here, 'parameter': key, 'value': child,
                              'nested': here.count('.args') > 1})
            if isinstance(child, (dict, list)):
                found.extend(scan(child, here))
    elif isinstance(value, list):
        for i, child in enumerate(value):
            found.extend(scan(child, path + '[%d]' % i))
    return found

for manifest in sorted(base.glob('*/case_manifest.json')):
    case = manifest.parent
    model = json.loads((case/'models/model.json').read_text(encoding='utf-8'))
    observations = scan(model['model_structure'], 'model_structure')
    if not observations:
        continue
    meta = json.loads(manifest.read_text(encoding='utf-8'))['metadata']
    rel = case.relative_to(base.parents[2]).as_posix()
    comparable = bool(meta.get('comparisons')) and all(s['status']=='ok' for s in meta['status'].values())
    requires_exclusion = comparable and any(o['nested'] for o in observations)
    record = {'case':case.name, 'case_relative_path':rel, 'active_stochastic_settings': observations,
              'raw_training_status': {k:v['status'] for k,v in meta['status'].items()},
              'raw_comparisons': {k:{f:v.get(f) for f in ('classification','inconsistent','raw_output','raw_loss','raw_loss_grads')} for k,v in meta.get('comparisons',{}).items()},
              'requires_exclusion_from_audited_comparisons': requires_exclusion}
    records.append(record)
    if requires_exclusion:
        candidate = any(c['inconsistent'] for c in record['raw_comparisons'].values())
        detail = dict(record, classification='comparison_invalid_unsynchronized_nested_stochastic_layer',
            mechanism_group='harness_nested_stochastic_guard_omission', backend='tensorflow_torch', stage='comparison',
            requires_exclusion_from_audited_candidates=candidate, counts_as_confirmed_framework_defect=False,
            original_evidence_changed=False, source_sha256=meta['source_sha256'],
            manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
            analysis=('实际执行图包含 TimeDistributed 内嵌 LSTM 的非零 recurrent_dropout，而原 worker 只检查顶层 model.layers；training=True 时跨后端随机掩码未同步。相同种子和权重不证明随机路径等价，因此该例必须从有效差分比较中排除。' +
                      ('原始候选记录保留，但不能据此认定框架缺陷；重复运行重现也不能修复这一可比性缺口。' if candidate else '即使本次保存输出完全一致，也不能把它计为已满足同步前提的有效一致比较。')),
            causal_limit='已证明比较前提不满足；没有断言全部数值差异仅由随机掩码造成。',
            frozen_worker_source={'path':'src/incons_detection/train.py','top_level_guard_lines':[136,141],
                'top_level_guard_excerpt':'for layer in model.layers: ... getattr(layer, "recurrent_dropout", 0)',
                'training_forward_line':159,'training_forward_excerpt':'values = probe(inputs, training=True)'},
            model_info=model,
            evidence_relative_paths=[rel+'/models/model.json',rel+'/case_manifest.json',rel+'/logs/comparison.json'],
            postrun_fix={'source':'run200_hardened','patch':'analysis_tools/nested_stochastic_guard.patch',
                         'description':'递归检查实际 layer/forward_layer/backward_layer/layers/cell/cells，按对象身份防环；原始200例不改写。'})
        (a.output_dir/('case'+case.name+'_review.json')).write_text(json.dumps(detail,ensure_ascii=False,indent=2),encoding='utf-8')
summary={'completed_cases_scanned':len(list(base.glob('*/case_manifest.json'))),
         'scope':'active configuration only; mutation history is ignored; JSON scan is audit, runtime patch uses actual layer objects',
         'cases_with_active_stochastic_settings':records,
         'nested_stochastic_cases':[r['case'] for r in records if any(o['nested'] for o in r['active_stochastic_settings'])],
         'excluded_comparison_cases':[r['case'] for r in records if r['requires_exclusion_from_audited_comparisons']]}
(a.output_dir/'nested_stochastic_scan.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='cases_with_active_stochastic_settings'}))
