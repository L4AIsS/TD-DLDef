"""Read-only diagnostics for saved run200 candidates 49 and 53; no backend execution."""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
parser=argparse.ArgumentParser();parser.add_argument('--cases-root',type=Path,required=True);parser.add_argument('--output-dir',type=Path,required=True)
args=parser.parse_args();base=args.cases_root.resolve();out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
def load(case,folder,backend,name):return np.load(case/folder/backend/(name+'.npy'),allow_pickle=False)

def basics(case):
 comp=json.loads((case/'logs/comparison.json').read_text(encoding='utf-8'))['tensorflow_torch']
 return {'case_relative_path':case.relative_to(base.parents[2]).as_posix(),'backend':'tensorflow_torch','stage':'comparison',
  'classification':'retain_unconfirmed_numerical_candidate','original_evidence_changed':False,
  'trigger':{key:comp.get(key) for key in ['output','loss','loss_grads','raw_output','raw_loss','raw_loss_grads','gradient_exclusions','gradient_precision_basis']},
  'limitations':'diagnostic arithmetic on saved arrays only; not a new backend run, independent replay, maintainer confirmation or proof of a new defect'}

case=base/'000053';r=basics(case);x=load(case,'layer_outputs','tensorflow','00_input_object').astype('float32').astype('float64')
ref=x.mean(axis=(2,3),keepdims=True)
# The saved NCHW input is (N,6,6,3), kernel32 stride2 SAME, hence pads H=(15,15), W=(15,16).
padded=np.pad(x,[(0,0),(0,0),(15,15),(15,16)],mode='edge')
edge=np.zeros((x.shape[0],x.shape[1],3,2),dtype='float64')
for h in range(3):
 for w in range(2):edge[:,:,h,w]=padded[:,:,h*2:h*2+32,w*2:w*2+32].mean(axis=(2,3))
r['first_divergent_layer']='01_average_pooling2D';r['input_semantics']={'layout':'NCHW','shape':list(x.shape),'channels':6,'spatial':[6,3],'pool':[32,32],'strides':[2,2],'padding':'same','explicit_padding':[[15,15],[15,16]]}
r['reference_checks']={}
for backend in ['tensorflow','torch']:
 y=load(case,'layer_outputs',backend,'01_average_pooling2D')
 r['reference_checks'][backend]={'max_abs_error_valid_elements_average':float(np.abs(y-ref).max()),
   'max_abs_error_replicated_edge_average':float(np.abs(y-edge).max()),
   'max_spatial_variation_within_channel':float(np.ptp(y,axis=(2,3)).max())}
r['analysis']='Divergence begins at AveragePooling2D, before any learned layer. SAME windows cover all 18 valid spatial values, so valid-element averaging is spatially constant per channel. TensorFlow matches that reference; Torch matches explicit replicated-edge padding followed by average pooling. This is a Keras Torch adapter padding-semantics candidate, not a channel-layout mismatch or ordinary rounding.'
r['primary_source']={'url':'https://raw.githubusercontent.com/keras-team/keras/v3.10.0/keras/src/backend/torch/nn.py',
 'functions':['_apply_same_padding','average_pool'],'mechanism':'Asymmetric pooling padding uses replicate mode; average_pool then consumes the explicitly padded values.'}
r['evidence_relative_paths']=[r['case_relative_path']+'/models/model.json',r['case_relative_path']+'/logs/comparison.json']
(out/'case000053_review.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
print('53',r['reference_checks'])

case=base/'000049';r=basics(case)
r['first_divergent_forward_layer']='04_conv2D_transpose';r['channel_review']='Each layer keeps its explicitly configured data_format. The two backends have identical saved outputs through UpSampling2D, ZeroPadding2D and Permute; the first one-ULP forward discrepancy appears at Conv2DTranspose softmax. No evidence of a cross-backend channel-layout mismatch.'
r['forward_alignment']={}
for name in ['00_input_object','01_up_sampling2D','02_zero_padding2D','03_permute','04_conv2D_transpose','05_flatten']:
 a=load(case,'layer_outputs','tensorflow',name);b=load(case,'layer_outputs','torch',name)
 r['forward_alignment'][name]={'shape':list(a.shape),'same_shape':a.shape==b.shape,'max_abs':float(np.abs(a.astype('float64')-b).max())}
name='04_conv2D_transpose';pa=load(case,'layer_outputs','tensorflow',name);pb=load(case,'layer_outputs','torch',name)
ga=load(case,'layer_gradients','tensorflow',name);gb=load(case,'layer_gradients','torch',name)
r['softmax']={}
local=[]
for bk,p,g in [('tensorflow',pa,ga),('torch',pb,gb)]:
 dz=p*(g-(g*p).sum(axis=-1,keepdims=True));local.append(dz)
 r['softmax'][bk]={'max_normalization_error':float(np.abs(p.sum(axis=-1)-1).max()),
   'exact_one_hot_positions':int(np.count_nonzero((p.max(axis=-1)==1)&(np.count_nonzero(p,axis=-1)==1))),
   'nearly_saturated_positions':int(np.count_nonzero(p.max(axis=-1)>1-1e-6)),
   'uniform_positions':int(np.count_nonzero(np.all(p==np.float32(.25),axis=-1))),
   'local_vjp_max_abs':float(np.abs(dz).max()),'upstream_gradient_max_abs':float(np.abs(g).max())}
r['local_vjp_cross_backend_max_abs']=float(np.abs(local[0].astype('float64')-local[1]).max())
# Isolate the effect of the saved probabilities while holding the upstream VJP fixed.
common=gb.astype('float64');vjp=[]
for p in [pa,pb]:
 q=p.astype('float64');vjp.append(q*(common-(common*q).sum(axis=-1,keepdims=True)))
r['common_upstream_probability_only_vjp_max_abs_difference']=float(np.abs(vjp[0]-vjp[1]).max())
r['analysis']='Forward outputs align to one-ULP at the softmax and remain below output and loss gates. The transposed convolution has stride14 larger than kernel8, producing both uniform softmax regions (zero logits) and saturated regions. Saved probability normalization and downstream accumulation differences can propagate into backward discrepancies. Every reported gradient still passes the corrected same-coordinate and float32-precision gates; no proven harness root cause or unsupported channel contract was found.'
r['interpretation']='Retain as a reproduced numerical-discrepancy candidate. The arithmetic gives plausible precision/accumulation mechanisms but does not settle whether the implementation has a defect.'
r['evidence_relative_paths']=[r['case_relative_path']+'/models/model.json',r['case_relative_path']+'/logs/comparison.json']
(out/'case000049_review.json').write_text(json.dumps(r,indent=2),encoding='utf-8')
print('49',r['softmax'],'local_difference',r['local_vjp_cross_backend_max_abs'],'prob_only',r['common_upstream_probability_only_vjp_max_abs_difference'])
