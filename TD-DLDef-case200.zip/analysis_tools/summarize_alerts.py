#!/usr/bin/env python3
"""Evidence-preserving TD-DLDef observation audit, independent of tested code.

Usage: python summarize_alerts.py --input /results/backend_200.json
       --out-dir /results/alerts [--cases-root /results/backend_200_cases]
No frozen test source or original result is changed. NumPy is optional for array
metadata; without it trigger deduplication uses recorded execution fingerprints
or remains deliberately unmerged when evidence is incomplete.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter, defaultdict
import csv
import hashlib
import html
import json
import math
import os
from pathlib import Path
import re
from typing import Any

try:
    import numpy as np
except ImportError:
    np = None

SCHEMA = 1
METRIC_NAMES = ('output', 'loss', 'loss_grads', 'raw_output', 'raw_loss', 'raw_loss_grads')
REVIEW_COMPARISON_EXCLUSIONS = frozenset({
    'comparison_invalid_unsynchronized_nested_stochastic_layer',
})


def clean(value):
    if isinstance(value, float) and not math.isfinite(value):
        return {'nonfinite_float': 'NaN' if math.isnan(value) else ('Infinity' if value > 0 else '-Infinity')}
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(x) for x in value]
    return value


def canonical(value):
    return json.dumps(clean(value), sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def identity(value, prefix=''):
    return prefix + hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write_json(path, value):
    Path(path).write_text(json.dumps(clean(value), ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def rel(path, root):
    return Path(os.path.relpath(Path(path).resolve(), Path(root).resolve())).as_posix()


def normalized_message(message, case_path=None):
    """Remove only proven incidental identities. Keep numbers/shapes/tolerances."""
    text = str(message or '').replace('\r\n', '\n').strip()
    text = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', text)
    if case_path:
        path = str(Path(case_path).resolve())
        for form in (path, path.replace('\\', '/'), path.replace('/', '\\')):
            text = text.replace(form, '<CASE>')
    text = re.sub(r'\b0x[0-9a-fA-F]{6,}\b', '<ADDRESS>', text)
    text = re.sub(r'\b\d{2,}_(?=[A-Za-z])', '<LAYER>_', text)
    # Deliberately do not erase scalar values, shape dimensions, dtype widths,
    # seeds, signs, operator names, error codes, or all arbitrary paths.
    return text


def backend_names(record):
    name = str(record.get('backend', 'unknown'))
    if name in ('tensorflow_torch', 'torch_tensorflow'):
        return name.split('_')
    return [name] if name in ('tensorflow', 'torch') else []


def category(record):
    return str(record.get('defect_type') or record.get('classification') or 'unknown')


def is_candidate(record):
    return record.get('evidence_status') == 'candidate' or str(record.get('classification', '')).startswith('candidate')


def array_archive(path):
    """Hash exact named array values without treating NPZ ZIP timestamps as data."""
    if np is None:
        return {'available': False, 'reason': 'NumPy not installed'}, None
    if not Path(path).is_file():
        return {'available': False, 'reason': 'missing archive'}, None
    digest, details = hashlib.sha256(), {}
    try:
        with np.load(path, allow_pickle=False) as archive:
            for name in sorted(archive.files):
                a = np.asarray(archive[name])
                if a.dtype.kind not in 'fciu b'.replace(' ', ''):
                    raise ValueError('unsupported dtype: ' + str(a.dtype))
                descriptor = {'shape': list(a.shape), 'dtype': str(a.dtype), 'elements': int(a.size)}
                if a.dtype.kind in 'fciub':
                    descriptor['nonfinite_elements'] = int((~np.isfinite(a)).sum())
                digest.update(canonical([name, a.dtype.str, list(a.shape)]).encode())
                digest.update(np.ascontiguousarray(a).tobytes())
                details[name] = descriptor
        return {'available': True, 'arrays': details}, digest.hexdigest()
    except (OSError, ValueError, TypeError) as exc:
        return {'available': False, 'reason': str(exc)}, None


def read_case(case, results_root):
    result = {'path': rel(case, results_root), 'manifest_available': False,
              'manifest': {}, 'model_info': {}, 'source_code': None,
              'worker_records': {}, 'integrity': {'verified_artifacts': 0, 'errors': []},
              'missing_evidence': []}
    manifest_path = case/'case_manifest.json'
    if manifest_path.is_file():
        result['manifest'] = load(manifest_path)
        result['manifest_sha256'] = file_hash(manifest_path)
        result['manifest_available'] = True
        for name, item in result['manifest'].get('artifacts', {}).items():
            p = (case/name).resolve()
            if not p.is_relative_to(case.resolve()) or not p.is_file():
                result['integrity']['errors'].append('missing/outside case: ' + name)
            elif file_hash(p) != item.get('sha256') or (item.get('bytes') is not None and p.stat().st_size != item['bytes']):
                result['integrity']['errors'].append('changed artifact: ' + name)
            else:
                result['integrity']['verified_artifacts'] += 1
    else:
        result['missing_evidence'].append('case_manifest.json')
    model_path = case/'models/model.json'
    if model_path.is_file():
        result['model_info'] = load(model_path)
    else:
        result['missing_evidence'].append('models/model.json')
    source_path = case/'model_source.py'
    if source_path.is_file():
        result['source_code'] = source_path.read_text(encoding='utf-8')
        try:
            ast.parse(result['source_code'])
            result['source_syntax_valid'] = True
        except SyntaxError as exc:
            result['source_syntax_valid'] = False
            result['missing_evidence'].append('model_source.py syntax error: ' + str(exc))
    else:
        result['missing_evidence'].append('model_source.py')
    for phase in ('generation', 'training'):
        for bk in ('tensorflow', 'torch'):
            p = case/'logs'/f'{phase}_{bk}.json'
            if p.is_file():
                result['worker_records'][f'{phase}/{bk}'] = load(p)
    for key, name in (('inputs', 'inputs.npz'), ('targets', 'ground_truths.npz')):
        details, fingerprint = array_archive(case/'dataset'/name)
        result[key + '_description'] = details
        result[key + '_fingerprint'] = fingerprint
    weight_parts, weights = {}, {}
    weight_files = sorted((case/'models/initial_weights').glob('*.npz'))
    for path in weight_files:
        description, fingerprint = array_archive(path)
        weights[path.stem] = description
        weight_parts[path.stem] = fingerprint
    result['weights_description'] = weights
    result['weights_fingerprint'] = identity(weight_parts) if weight_parts and all(weight_parts.values()) else None
    manifest = result['manifest']
    result['input_dtype'] = manifest.get('source_input_dtype') or {'value': manifest.get('metadata', {}).get('input_dtype'), 'source': 'metadata'}
    generation_config_path = case/'models/generation_config.json'
    if generation_config_path.is_file():
        result['generation_config'] = load(generation_config_path)
        result['input_dtype'] = {'value': result['generation_config'].get('input_dtype'), 'source': 'models/generation_config.json'}
    comparison_path = case/'logs/comparison.json'
    result['comparisons'] = load(comparison_path) if comparison_path.is_file() else manifest.get('metadata', {}).get('comparisons', {})
    result['runtime_identities'] = dict(manifest.get('runtime_identities', {}))
    for phase in ('generation', 'training'):
        for bk in ('tensorflow', 'torch'):
            worker = result['worker_records'].get(phase+'/'+bk, {})
            if worker.get('actual_backend') == bk and worker.get('versions'):
                result['runtime_identities'][bk] = {k: worker.get(k) for k in ('actual_backend', 'versions', 'platform')}
    result['model_architecture_fingerprint'] = identity({'model_info': result['model_info'], 'input_dtype': result['input_dtype'].get('value')}) if result['model_info'] and result['input_dtype'].get('value') else None
    return result


def exact_fingerprint(record):
    """Full original record, including original IDs, paths, details and metrics."""
    return identity(record, 'R-')


def metric_rule(record):
    rules = {}
    def visit(value, path=''):
        if isinstance(value, dict):
            if any(k in value for k in ('candidate', 'classification', 'reason')):
                rules[path] = {k: value[k] for k in ('candidate', 'classification', 'reason', 'atol', 'rtol', 'precision_dtype') if k in value}
            for k, child in value.items():
                if isinstance(child, dict):
                    visit(child, path+'/'+k)
    visit(record.get('metrics', {}))
    return rules


AUXILIARY_NONFINITE_PREFIX = 'nonfinite loss/gradients (outside paper output oracle):'


def auxiliary_nonfinite_tensors(record):
    """Recover this version's literal-only auxiliary diagnostic payload."""
    detail = record.get('detail')
    if record.get('classification') != 'auxiliary_nonfinite' or not isinstance(detail, str) or not detail.startswith(AUXILIARY_NONFINITE_PREFIX):
        return {}
    literal = detail[len(AUXILIARY_NONFINITE_PREFIX):].strip()
    if len(literal) > 100000:
        return {}
    try:
        value = ast.literal_eval(literal)
    except (ValueError, SyntaxError, TypeError, RecursionError):
        return {}
    if not isinstance(value, dict) or set(value) - {'nan', 'inf'}:
        return {}
    for names in value.values():
        if not isinstance(names, list) or not all(isinstance(name, str) for name in names):
            return {}
    return value


def alert_channels(record):
    """Keep the actual oracle channel, including output-vs-layer gradients."""
    metrics = record.get('metrics', {})
    channels = []
    for name in ('outputs', 'loss', 'loss_gradients', 'layer_gradients'):
        group = metrics.get(name, {})
        values = [group] if name == 'loss' else list(group.values()) if isinstance(group, dict) else []
        if any(isinstance(x, dict) and x.get('candidate') is True for x in values):
            channels.append('output' if name == 'outputs' else name)
    if not metrics and is_candidate(record):
        for name, channel in (('output', 'output'), ('loss', 'loss'), ('loss_grads', 'gradients_unspecified')):
            value = record.get(name)
            if isinstance(value, (float, int)) and math.isfinite(value) and value > 0:
                channels.append(channel)
    auxiliary = auxiliary_nonfinite_tensors(record)
    tensors = list(record.get('affected_tensors', [])) + [name for names in auxiliary.values() for name in names]
    for tensor in tensors:
        if tensor == 'loss':
            channels.append('loss')
        elif tensor.startswith('output/'):
            channels.append('output')
        elif tensor.startswith('loss_gradient/'):
            channels.append('loss_gradients')
        elif tensor.startswith('gradient/'):
            channels.append('layer_gradients')
    if record.get('nan_layers') or record.get('inf_layers'):
        channels.append('output')
    return sorted(set(channels))


def nonfinite_kind(record):
    if category(record) in ('nan', 'inf'):
        return category(record)
    if category(record) == 'nonfinite_observation':
        auxiliary = auxiliary_nonfinite_tensors(record)
        present = [kind for kind in ('nan', 'inf') if auxiliary.get(kind)]
        if present:
            return '_and_'.join(present)
        match = re.match(r'\s*(nan|inf)\b', str(record.get('detail', '')), re.I)
        return match.group(1).lower() if match else 'unspecified_nonfinite'
    return None


def gradient_comparison_counts(comparisons):
    """Nonempty diagnostic metrics do not establish an eligible comparison."""
    attempted, eligible = 0, 0
    for comparison in (comparisons or {}).values():
        metrics = comparison.get('metrics', {})
        values = [item for channel in ('loss_gradients', 'layer_gradients')
                  for item in metrics.get(channel, {}).values() if isinstance(item, dict)]
        attempted += len(values)
        if comparison.get('gradient_exclusions') or comparison.get('classification') not in ('consistent', 'candidate'):
            continue
        eligible += sum(item.get('classification') in ('consistent', 'candidate') for item in values)
    return {'attempted_gradient_metrics': attempted, 'eligible_gradient_metrics': eligible,
            'attempted_gradient_comparison_cases': bool(attempted),
            'gradient_comparison_cases': bool(eligible)}


def strict_trigger(record, case, record_id):
    """Same trigger means proven same conditions, never merely similar symptoms."""
    manifest = case.get('manifest', {})
    names = backend_names(record)
    missing, states, versions = [], {}, {}
    if not names:
        missing.append('actual backend identity')
    for bk in names:
        actual = case.get('runtime_identities', {}).get(bk, {})
        ver = actual.get('versions', {})
        if actual.get('actual_backend') != bk or not all(ver.get(k) for k in ('python', 'keras', bk, 'numpy')):
            missing.append('actual versions/' + bk)
        else:
            versions[bk] = actual
        state = manifest.get('execution_equivalence', {}).get(bk)
        if not state:
            state = case.get('worker_records', {}).get('training/'+bk, {}).get('equivalence')
        if isinstance(state, dict) and state:
            # A partial worker state is evidence of an incomplete execution
            # contract, not permission to replace it with saved-file defaults.
            states[bk] = {'source': 'worker_execution_fingerprints', **{k: state.get(k) for k in ('architecture', 'inputs', 'targets', 'initial_weights', 'config')}}
            for key in ('architecture', 'inputs', 'targets', 'initial_weights'):
                if not isinstance(state.get(key), str) or not state[key]:
                    missing.append(bk + '/' + key)
            config = state.get('config')
            if not isinstance(config, dict):
                missing.append(bk + '/config')
                config = {}
            for key in ('loss', 'loss_reduction', 'device'):
                if not isinstance(config.get(key), str) or not config[key]:
                    missing.append(bk + '/config/' + key)
            if not isinstance(config.get('training'), bool):
                missing.append(bk + '/config/training')
            for key in ('optimizer_steps', 'seed'):
                if type(config.get(key)) is not int or (key == 'optimizer_steps' and config[key] < 0):
                    missing.append(bk + '/config/' + key)
            optimizer = config.get('optimizer')
            if not isinstance(optimizer, dict):
                missing.append(bk + '/config/optimizer')
            else:
                if not isinstance(optimizer.get('class_name'), str) or not optimizer['class_name']:
                    missing.append(bk + '/config/optimizer/class_name')
                if not isinstance(optimizer.get('config'), dict) or not optimizer['config']:
                    missing.append(bk + '/config/optimizer/config')
        else:
            config = manifest.get('replay_config', {}).get('values', {})
            fallback = {'source': 'saved_artifact_content_fingerprints',
                        'architecture': case.get('model_architecture_fingerprint'),
                        'inputs': case.get('inputs_fingerprint'), 'targets': case.get('targets_fingerprint'),
                        'initial_weights': case.get('weights_fingerprint'),
                        'config': config, 'declared_input_dtype': case.get('input_dtype', {}).get('value')}
            for k in ('architecture', 'inputs', 'targets', 'initial_weights', 'declared_input_dtype'):
                if not fallback[k]:
                    missing.append(bk + '/' + k)
            for k in ('loss', 'optimizer', 'seed', 'threshold'):
                if k not in config:
                    missing.append(bk + '/config/' + k)
            states[bk] = fallback
    if not case.get('manifest_available'):
        missing.append('evidence manifest')
    if case.get('integrity', {}).get('errors'):
        missing.append('artifact integrity validation')
    source_hash = manifest.get('metadata', {}).get('source_sha256') or manifest.get('source_sha256')
    if not source_hash:
        missing.append('tested source hash')
    if manifest.get('replay_config', {}).get('values', {}).get('threshold') is None:
        missing.append('comparison threshold')
    runtime = record.get('runtime_status', {})
    error_text = runtime.get('message') or record.get('detail') or record.get('description') or ''
    conditions = {
        'category': category(record), 'classification': record.get('classification'),
        'candidate': is_candidate(record), 'stage': record.get('stage'), 'backend': record.get('backend'),
        'located_layer': record.get('located_layer'), 'exception_type': runtime.get('exception_type'),
        'alert_channels': alert_channels(record), 'nonfinite_kind': nonfinite_kind(record),
        'rule': record.get('rule') or normalized_message(error_text),
        'metric_decision_rules': metric_rule(record), 'gradient_exclusions': record.get('gradient_exclusions', []),
        'affected_tensors': record.get('affected_tensors', []),
        'versions': versions, 'states': states, 'source_sha256': source_hash,
        'threshold': manifest.get('replay_config', {}).get('values', {}).get('threshold'),
    }
    # Missing evidence never causes two unrelated records to collapse. Exact
    # duplicates may still collapse in the independently defined exact layer.
    key = {'conditions': conditions, 'unmerged_record': record_id} if missing else conditions
    return identity(key, 'T-'), conditions, sorted(set(missing))


def operation(record, case):
    layer = record.get('located_layer')
    structure = case.get('model_info', {}).get('model_structure', {})
    for node in structure.values():
        if node.get('args', {}).get('name') == layer:
            return node.get('type'), node
    message = str(record.get('runtime_status', {}).get('message') or record.get('detail') or '')
    for node in structure.values():
        name = node.get('args', {}).get('name')
        if name and name in message:
            return node.get('type'), node
    return '<unlocalized>', None


def describe(record, operation_type):
    kind = category(record)
    message = str(record.get('runtime_status', {}).get('message') or record.get('detail') or '')
    if is_candidate(record) and kind == 'inconsistency':
        actual = alert_channels(record)
        channels = [label for present, label in [('output' in actual, '输出'), ('loss' in actual, '损失'), (any('gradient' in k for k in actual), '梯度')] if present]
        return '跨后端' + ('、'.join(channels) or '数值') + '差异候选', '相同输入、初始状态和配置下存在超过当前预言机容差的观测；定位层仅为诊断线索，仍需最小化和根因验证。'
    if kind in ('nan', 'inf', 'nonfinite_observation'):
        actual = alert_channels(record)
        labels = [label for present, label in [('output' in actual, '输出'), ('loss' in actual, '损失'), (any('gradient' in k for k in actual), '梯度')] if present]
        value_label = {'nan': 'NaN', 'inf': 'Inf', 'nan_and_inf': 'NaN 与 Inf', 'unspecified_nonfinite': '非有限值（种类未注明）'}.get(nonfinite_kind(record), '非有限值')
        return ('、'.join(labels) or '数值') + '的' + value_label + ('候选' if is_candidate(record) else '观察（未满足候选条件）'), '保存非有限值涉及的实际张量通道；候选需要等价且有限的对照，未满足条件的观察仍完整保留。'
    if kind == 'invalid_test':
        if 'integer convolution input' in message:
            return '卷积整数输入与浮点权重的类型契约不满足', '测试输入的 dtype 不满足当前卷积实现的输入/权重契约，按无效测试保留，不作为框架缺陷。'
        if 'variance' in message.lower():
            return '归一化状态不满足有效取值要求', '测试状态违反归一化算子的约束，需检查初始状态及突变结果。'
        return '测试前置约束不满足', '执行证据将该用例归为无效测试；具体约束、输入形状和异常原文见下方。'
    descriptions = {
        'unsupported': ('当前适配器不支持的测试条件', '当前执行路径未提供可比较语义，记录排除理由；不能统计为框架缺陷。'),
        'unknown': ('尚未分类的执行异常', '现有证据尚不能区分测试器问题、平台限制或框架异常，保留原始异常，不自动归为误报。'),
        'tool_error': ('测试工具执行或证据处理错误', '工具自身错误单独记录；详细失败位置以保存的异常栈为准。'),
        'environment_error': ('运行环境错误', '后端导入、身份或依赖条件不满足，不能从该状态推断框架缺陷。'),
        'timeout': ('执行超时', '超时是运行观察，尚不能据此认定框架崩溃。'),
        'nonfinite_observation': ('非有限数值观察，未满足候选条件', '保存 NaN/Inf 所在张量及排除理由；缺少等价且有限的对照时不升级为候选缺陷。'),
        'comparison_excluded': ('跨后端比较被排除', '输入、状态、形状、精度或梯度可比性条件不满足，保留排除证据。'),
        'native_crash_observation': ('原生进程异常退出观察', '保存退出码与日志；进程退出本身不能证明框架缺陷。'),
    }
    return descriptions.get(kind, ('运行告警：' + kind, '保留原始类型、细节及证据；该观察不代表已确认根因。'))


def issue_group(record, case):
    op, node = operation(record, case)
    runtime = record.get('runtime_status', {})
    message = runtime.get('message') or record.get('detail') or record.get('description') or ''
    key = {'category': category(record), 'candidate': is_candidate(record),
           'classification': record.get('classification'), 'stage': record.get('stage'),
           'backend': record.get('backend'), 'exception_type': runtime.get('exception_type'),
           'operation': op, 'message': normalized_message(message),
           'alert_channels': alert_channels(record), 'nonfinite_kind': nonfinite_kind(record),
           'exclusion_reasons': record.get('gradient_exclusions', [])}
    title, description = describe(record, op)
    return identity(key, 'G-'), key, title, description, node


def same_review_case_path(review_path, case_path):
    """Match a full portable case suffix, never a bare numeric case ID."""
    left = str(review_path or '').replace('\\', '/').rstrip('/')
    right = str(case_path or '').replace('\\', '/').rstrip('/')
    if len([part for part in right.split('/') if part]) < 4:
        return False
    return left == right or left.endswith('/' + right)


def review_detail_snapshots(manual_mappings, review_path):
    """Embed explicit review attachments so moving the report preserves them."""
    result, snapshots = [], {}
    review_root = Path(review_path).resolve().parent
    for mapping in manual_mappings:
        enriched = dict(mapping)
        reference = mapping.get('detail_file')
        relative_reference = mapping.get('detail_relative_path')
        if reference or relative_reference:
            key = (relative_reference, reference)
            if key not in snapshots:
                candidates = []
                if isinstance(relative_reference, str):
                    relative_path = Path(relative_reference.replace('\\', '/'))
                    direct = (review_root/relative_path).resolve()
                    if not relative_path.is_absolute() and direct.is_relative_to(review_root):
                        candidates.append(('detail_relative_path', direct))
                        # Bundles may collect attachments in diagnostics even
                        # when older snapshots used an analysis_tools prefix.
                        candidates.append(('diagnostics_basename', review_root/'diagnostics'/relative_path.name))
                if isinstance(reference, str):
                    original = Path(reference)
                    candidates.append(('detail_file_fallback', original if original.is_absolute() else review_root/original))
                errors, embedded = [], None
                for method, path in candidates:
                    try:
                        raw = path.read_bytes()
                        content = raw.decode('utf-8-sig')
                        try:
                            content = json.loads(content)
                        except ValueError:
                            pass
                        embedded = {'status': 'embedded', 'source': reference,
                                    'source_relative': relative_reference, 'resolved_from': method,
                                    'resolved_source': rel(path, review_root) if path.resolve().is_relative_to(review_root) else str(path),
                                    'sha256': hashlib.sha256(raw).hexdigest(), 'content': content}
                        break
                    except (OSError, UnicodeError) as exc:
                        errors.append({'source': str(path), 'error': str(exc)})
                snapshots[key] = embedded or {'status': 'unavailable', 'source': reference,
                                              'source_relative': relative_reference, 'attempts': errors}
            enriched['detail_file_snapshot'] = snapshots[key]
        result.append(enriched)
    return result


def review_annotation(record, case, review_cases, manual_mappings=None):
    """Apply external triage only to the exact reviewed manifest; never relabel."""
    matched = [r for r in review_cases if r.get('manifest_sha256') == case.get('manifest_sha256') and case.get('manifest_sha256')]
    if not matched:
        return {'matched': False, 'original_category': category(record), 'conclusion': '无匹配的独立复核记录；保留原始分类。', 'evidence': []}
    review = matched[0]
    if record.get('stage') == 'comparison':
        rows = [r for r in review.get('comparisons', []) if r.get('pair') == record.get('backend')]
    else:
        rows = [r for r in review.get('stages', []) if r.get('stage') == record.get('stage') and r.get('backend') == record.get('backend')]
    manual = [r for r in (manual_mappings or [])
              if same_review_case_path(r.get('case_path'), case.get('path'))
              and r.get('backend') == record.get('backend') and r.get('stage') == record.get('stage')
              and (not r.get('manifest_sha256') or r['manifest_sha256'] == case.get('manifest_sha256'))]
    # More detailed independent findings are shown first, while retaining the
    # generic reviewed worker status and every original observation unchanged.
    conclusions = list(dict.fromkeys(r.get('interpretation') for r in manual + rows if r.get('interpretation')))
    return {'matched': bool(rows or manual), 'original_category': category(record),
            'conclusion': '；'.join(conclusions) or '匹配案例尚无此观察的具体复核判定。',
            'review_case': review.get('case'), 'manifest_sha256': case.get('manifest_sha256'),
            'evidence': rows, 'manual_review_mappings': manual}


def review_exclusion_classes(annotation):
    """Only explicit, implemented review decisions may exclude a comparison."""
    return sorted({row.get('review_classification')
                   for row in annotation.get('manual_review_mappings', [])
                   if row.get('stage') == 'comparison'
                   and row.get('review_classification') in REVIEW_COMPARISON_EXCLUSIONS})


def reviewed_candidate_status(candidate, annotation):
    if not candidate:
        return 'not_candidate'
    return 'review_excluded' if review_exclusion_classes(annotation) else 'retained'


def reviewed_case_comparisons(case, review_cases, manual_mappings):
    """Review every saved comparison, including cases without alert records."""
    rows = []
    for pair, comparison in (case.get('comparisons') or {}).items():
        annotation = review_annotation({'stage': 'comparison', 'backend': pair}, case, review_cases, manual_mappings)
        exclusions = review_exclusion_classes(annotation)
        original = comparison.get('classification') in ('candidate', 'consistent')
        gradients = gradient_comparison_counts({pair: comparison})
        rows.append({'case_path': case['path'], 'manifest_sha256': case.get('manifest_sha256'),
                     'backend': pair, 'original_classification': comparison.get('classification'),
                     'original_comparison_eligible': original,
                     'review_retained_comparison': original and not exclusions,
                     'review_excluded_comparison': original and bool(exclusions),
                     'original_gradient_eligible': gradients['gradient_comparison_cases'],
                     'review_retained_gradient': gradients['gradient_comparison_cases'] and not exclusions,
                     'exclusion_classifications': exclusions, 'runtime_review': annotation})
    return rows


def reviewed_candidate_counts(records, unique, triggers):
    result = {'exclusion_classification_whitelist': sorted(REVIEW_COMPARISON_EXCLUSIONS)}
    for key, items in (('raw', records), ('exact', unique), ('strict', triggers)):
        candidates = [x for x in items if x['candidate']]
        excluded = sum(x['reviewed_candidate_status'] == 'review_excluded' for x in candidates)
        result[key] = {'original': len(candidates), 'retained': len(candidates) - excluded, 'review_excluded': excluded}
    result['retained_case_paths'] = sorted({x['case_path'] for x in unique if x['reviewed_candidate_status'] == 'retained'})
    result['review_excluded_case_paths'] = sorted({x['case_path'] for x in unique if x['reviewed_candidate_status'] == 'review_excluded'})
    result['mixed_strict_triggers'] = sum(x.get('mixed_review_status', False) for x in triggers if x['candidate'])
    original_types = {x['problem_type_id'] for x in unique if x['candidate']}
    retained_types = {x['problem_type_id'] for x in unique if x['reviewed_candidate_status'] == 'retained'}
    result['original_problem_types'] = len(original_types)
    result['retained_problem_types'] = len(retained_types)
    result['excluded_only_problem_types'] = len(original_types - retained_types)
    return result


def resolve_record_case(record, source_parent, cache):
    """Do not confuse attempt indices with allocated model IDs after failures."""
    source_parent = Path(source_parent).resolve()
    explicit = str(record.get('case_dir') or '').replace('\\', '/').rstrip('/')
    parts = explicit.split('/')
    if len(parts) >= 3 and parts[-3:-1] == [source_parent.parent.name, source_parent.name] and parts[-1].isdigit():
        return source_parent/parts[-1], 'record.case_dir suffix within same pool/configuration'
    if record.get('backend') == 'harness':
        try:
            attempt_index = int(record['model_id']) - 1
        except (TypeError, ValueError, KeyError):
            return source_parent/'__unresolved_case__', 'harness attempt has no recoverable case identity'
        matched = [path for path, value in cache.items() if path.parent == source_parent and value.get('manifest', {}).get('metadata', {}).get('case_index') == attempt_index]
        if len(matched) == 1:
            return matched[0], 'harness attempt index matched to manifest.metadata.case_index'
        return source_parent/f'__unresolved_attempt_{attempt_index}__', 'no unique manifest for harness attempt; numeric model-ID fallback deliberately excluded'
    try:
        return source_parent/f'{int(record["model_id"]):06d}', 'model_id within same pool/configuration'
    except (KeyError, ValueError, TypeError):
        return source_parent/'__unresolved_case__', 'record has no recoverable model identity'


def annotate(record, path, line, case, results_root, out_dir, review_cases=None, manual_mappings=None):
    record_id = exact_fingerprint(record)
    trigger_id, conditions, missing = strict_trigger(record, case, record_id)
    group_id, group_key, title, description, node = issue_group(record, case)
    source = case.get('source_code') or record.get('reproducer_source') or record.get('model_snippet')
    original_source = record.get('model_snippet')
    stage = record.get('stage', 'unknown')
    logs = []
    runtime = record.get('runtime_status', {})
    if runtime:
        logs.append({'source': 'original_record.runtime_status', 'exception_type': runtime.get('exception_type'),
                     'message': runtime.get('message'), 'excerpt': (runtime.get('traceback') or runtime.get('stderr') or runtime.get('stdout') or '')[-16000:]})
    for bk in backend_names(record):
        worker = case.get('worker_records', {}).get(stage+'/'+bk, {})
        if worker:
            logs.append({'source': case['path'] + '/logs/' + stage + '_' + bk + '.json',
                         'status': worker.get('status'), 'exception_type': worker.get('exception_type'),
                         'message': worker.get('message'),
                         'excerpt': (worker.get('traceback') or worker.get('stderr') or '')[-16000:]})
    metrics = {k: record[k] for k in METRIC_NAMES if k in record}
    metrics.update({k: record[k] for k in ('metrics', 'gradient_exclusions', 'gradient_precision_basis', 'localization', 'affected_tensors', 'finite_peers') if k in record})
    case_relative = case.get('path')
    replay_command = ('python scripts/reproduce_case.py --case "<RESULTS_ROOT>/' + case_relative + '" --out "<NEW_EMPTY_DIRECTORY>"') if case_relative else '未保存可关联案例目录'
    output_specs = {name: worker.get('artifacts') for name, worker in case.get('worker_records', {}).items() if worker.get('artifacts')}
    annotation = review_annotation(record, case, review_cases or [], manual_mappings)
    return {'record_id': record_id, 'trigger_id': trigger_id, 'problem_type_id': group_id,
            'source': {'path': rel(path, results_root), 'line': line},
            'case_path': case_relative, 'model_id': record.get('model_id'),
            'category': category(record), 'candidate': is_candidate(record), 'stage': stage,
            'alert_channels': alert_channels(record), 'nonfinite_kind': nonfinite_kind(record),
            'auxiliary_nonfinite_tensors': auxiliary_nonfinite_tensors(record),
            'backend': record.get('backend'), 'framework_pool': record.get('framework_pool') or record.get('framework'),
            'title_zh': title, 'description_zh': description, 'problem_type_key': group_key,
            'trigger_conditions': conditions, 'trigger_merge_eligible': not missing,
            'trigger_missing_evidence': missing, 'original_record': clean(record),
            'model_source': source, 'model_source_origin': 'case/model_source.py' if case.get('source_code') else 'record fallback',
            'model_source_differs_from_record': bool(source and original_source and source != original_source),
            'model_source_syntax_valid': case.get('source_syntax_valid'), 'located_layer_config': node,
            'runtime_identities': case.get('runtime_identities', {}), 'declared_input_dtype': case.get('input_dtype'),
            'saved_inputs': case.get('inputs_description'), 'saved_targets': case.get('targets_description'),
            'saved_weights': case.get('weights_description'), 'output_tensor_descriptors': output_specs,
            'metrics': metrics, 'exception_logs': logs,
            'case_artifact_integrity': case.get('integrity'),
            'case_missing_evidence': case.get('missing_evidence', []),
            'runtime_review': annotation,
            'reviewed_candidate_status': reviewed_candidate_status(is_candidate(record), annotation),
            'review_exclusion_classifications': review_exclusion_classes(annotation),
            'replay_command': replay_command,
            'replay_link': rel(results_root/case_relative/'reproduce.py', out_dir) if case_relative else None,
            'confirmed_framework_bug': False}


def write_csv(path, rows, fields):
    with Path(path).open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            output = {}
            for key in fields:
                value = row.get(key)
                if isinstance(value, (dict, list)):
                    value = canonical(value)
                # CSV is for inspection; JSON preserves exact original strings.
                if isinstance(value, str) and value.startswith(('=', '+', '-', '@')):
                    value = "'" + value
                output[key] = value
            writer.writerow(output)


def render_report(summary, groups, triggers, records):
    e = lambda x: html.escape(str(x))
    parts = ['<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>TD-DLDef 告警统计与证据</title>',
      '<style>body{font:15px/1.65 system-ui,sans-serif;color:#173045;max-width:1220px;margin:36px auto;padding:0 24px}h1,h2{color:#123b59}.cards{display:flex;gap:14px;flex-wrap:wrap}.card{padding:14px 22px;background:#eaf2f7;min-width:150px}.card b{font-size:30px;display:block}.note{padding:14px;background:#fff3d8}table{border-collapse:collapse;width:100%;margin:18px 0}td,th{border:1px solid #c9d5dd;padding:8px;text-align:left;vertical-align:top}th{background:#edf3f7}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f3f6f8;padding:14px;font:12px/1.6 Consolas,monospace}details{border:1px solid #ccd7df;padding:10px;margin:9px 0}summary{cursor:pointer;font-weight:650}input,select{padding:9px;margin:10px 8px 10px 0}small{color:#526d80}a{color:#165985}</style>',
      '<h1>TD-DLDef 新运行告警统计与证据</h1>',
      '<p class="note">候选告警、执行错误、无效测试和未决观察均保留。以下去重单位是记录、触发条件和描述性问题类型；它们不是已确认框架缺陷或独立根因数。</p><div class="cards">']
    for key, label in [('raw_observations', '原始观测'), ('unique_exact_records', '完整记录去重'), ('unique_strict_triggers', '严格触发条件去重'), ('descriptive_problem_types', '描述性问题类型')]:
        parts.append('<div class="card"><b>' + str(summary[key]) + '</b>' + label + '</div>')
    parts.append('</div><p>请求案例数 ' + str(summary['requested_models']) + '；保存案例数 ' + str(summary['saved_cases']) + '；双后端完成 ' + str(summary['both_backends_completed']) + '。候选与其他观察见下表；已确认框架缺陷为 0。</p>')
    parts.append('<h2>原始候选与独立复核后的候选</h2><table><tr><th>计数口径</th><th>原始候选</th><th>复核后保留</th><th>明确复核排除</th></tr>')
    for key, label in [('raw', '原始观测'), ('exact', '精确记录'), ('strict', '严格触发条件')]:
        row = summary['reviewed_candidates'][key]
        parts.append('<tr><td>'+label+'</td>'+''.join('<td>'+str(row[k])+'</td>' for k in ('original', 'retained', 'review_excluded'))+'</tr>')
    parts.append('</table><p>原始候选涉及 '+str(summary['reviewed_candidates']['original_problem_types'])+' 种描述性类型；复核后保留 '+str(summary['reviewed_candidates']['retained_problem_types'])+' 种，整组被明确排除 '+str(summary['reviewed_candidates']['excluded_only_problem_types'])+' 种。</p><p class="note">原始分类、候选数及全部去重数保持原样。只有明确的复核分类白名单会从新增的“复核后保留”集合中排除；保留表示尚未被该复核规则排除，不表示已确认框架缺陷。嵌套随机层未同步导致的比较不具备可比性，详见逐条人工证据。</p>')
    parts.append('<h2>四层计数及分类</h2><table><tr><th>原始类型</th><th>原始观测</th><th>精确记录</th><th>严格触发条件</th><th>描述性类型</th></tr>')
    for row in summary['category_counts']:
        parts.append('<tr>' + ''.join('<td>' + e(row[k]) + '</td>' for k in ['category','raw','exact','triggers','problem_types']) + '</tr>')
    parts.append('</table><p>完整记录去重保留所有原字段；严格触发条件包括类型、阶段、后端、规则、实际版本、模型/输入/标签/权重/执行配置指纹及源码指纹。缺少证据的 ' + str(summary['strict_trigger_ineligible_records']) + ' 条记录逐条保留，不能因错误文本相似而合并。</p><p>描述性归类仅去除层编号前缀和内存地址；保留形状、dtype、阈值及其他数值。即使属于同一类型也不意味着根因相同。</p>')
    parts.append('<h2>尝试、执行与比较阶段</h2><table><tr><th>阶段</th><th>案例数</th></tr>')
    for key, label in [('requested_attempts','请求生成尝试'),('saved_case_manifests','已保存案例'),('both_generation_ok','双后端构建完成'),('training_attempted_cases','已进入训练检查'),('both_training_ok','双后端训练检查完成'),('comparable_pair_cases','至少一组比较满足可比较门槛'),('attempted_gradient_comparison_cases','产生过梯度指标记录'),('gradient_comparison_cases','至少一个有效梯度指标'),('candidate_cases','至少一条候选的案例')]:
        parts.append('<tr><td>'+label+'</td><td>'+str(summary['funnel'][key])+'</td></tr>')
    parts.append('</table><p>有效梯度指标须明确分类为 consistent 或 candidate；extreme_scale_observation / excluded 指标不计有效。比较的“consistent”只覆盖实际参与比较的指标；被排除的梯度不构成梯度正确性证明。请求案例数不等于成功比较案例数。</p><h2>实际生成输入 dtype 分布</h2><table><tr><th>dtype</th><th>案例</th><th>双后端构建</th><th>双后端训练</th><th>可比较</th><th>候选案例 / 条目</th><th>训练状态事件</th></tr>')
    for row in summary['dtype_breakdown']:
        parts.append('<tr><td>'+e(row['dtype'])+'</td>'+''.join('<td>'+str(row[k])+'</td>' for k in ('cases','both_generation_ok','both_training_ok','comparable_pair_cases'))+'<td>'+str(row['candidate_cases'])+' / '+str(row['candidate_records'])+'</td><td>'+e(canonical(row['training_status_events']))+'</td></tr>')
    parts.append('</table><p>dtype 优先读取每案例 models/generation_config.json；原始数据数组的存储 dtype 和声明输入 dtype 在逐条证据中分别保存。</p>')
    parts.append('<h2>全部案例的人工复核比较集合</h2><p>本集合独立遍历每个案例的比较证据，包含没有告警记录的原始 consistent 案例；下方“保留”仅表示未被明确人工规则排除。</p><pre>'+e(json.dumps(summary['reviewed_comparisons'], ensure_ascii=False, indent=2))+'</pre><p><a href="reviewed_comparisons.json">全部案例与后端对的复核证据</a></p>')
    parts.append('<h2>实际执行环境与一致性核对</h2><pre>' + e(json.dumps(summary['run_environment'], ensure_ascii=False, indent=2)) + '</pre><pre>' + e(json.dumps(summary['reconciliation'], ensure_ascii=False, indent=2)) + '</pre>')
    parts.append('<h2>去重后的告警问题类型</h2><table><tr><th>类型编号与问题描述</th><th>原始分类 / 后端 / 算子</th><th>独立复核判定（不改写原分类）</th><th>原始 / 精确 / 严格触发</th><th>样例</th></tr>')
    for group in groups:
        key = group['key']
        parts.append('<tr><td>' + e(group['short_id']+' '+group['title_zh']) + '<br><small>' + e(group['description_zh']) + '</small></td><td>' + e(key['category']+' / '+str(key['backend'])+' / '+str(key['operation'])) + '</td><td>'+e('；'.join(group['review_conclusions']) or '尚无匹配复核')+'</td><td>' + str(group['raw_occurrences'])+' / '+str(group['exact_records'])+' / '+str(group['strict_triggers']) + '</td><td><a href="#'+e(group['record_ids'][0])+'">查看样例</a><br><small>' + e(key['message']) + '</small></td></tr>')
    parts.append('</table><h2>逐条证据与代码</h2><input id="q" placeholder="搜索分类、编号、层、异常或源码" size="55"><select id="kind"><option value="">所有观察</option><option value="yes">仅候选</option><option value="no">其他观察</option></select><span id="n"></span>')
    group_index = {x['group_id']: x['short_id'] for x in groups}
    for record in records:
        short = record['record_id'][:15]
        title = f'{short} | {group_index[record["problem_type_id"]]} | {record["title_zh"]} | {record["backend"]} | model {record["model_id"]}'
        parts.append('<details class="alert" id="'+e(record['record_id'])+'" data-candidate="'+('yes' if record['candidate'] else 'no')+'"><summary>'+e(title)+'</summary><p>'+e(record['description_zh'])+'</p>')
        parts.append('<p>来源：'+e(record['source']['path'])+' : '+str(record['source']['line'])+'；记录来源次数 '+str(len(record['origins']))+'；严格触发 '+e(record['trigger_id'][:15])+'。</p><p>原始描述：'+e(record['original_record'].get('detail',''))+'</p>')
        parts.append('<p>原始分类：'+e(record['category'])+'。复核后候选状态：'+e({'retained':'保留候选（未确认）','review_excluded':'明确复核排除（原始候选保留）','not_candidate':'原始非候选'}[record['reviewed_candidate_status']])+'。独立复核判定：'+e(record['runtime_review']['conclusion'])+'</p>')
        parts.append('<details><summary>独立复核完整证据、数值检验及后端源码（保持原始分类）</summary><pre>'+e(json.dumps(record['runtime_review'], ensure_ascii=False, indent=2))+'</pre></details>')
        if record['trigger_missing_evidence']:
            parts.append('<p class="note">严格合并证据不足：'+e('; '.join(record['trigger_missing_evidence']))+'</p>')
        parts.append('<p>复现命令（在代码根目录运行，替换两个路径占位符）：</p><pre>'+e(record['replay_command'])+'</pre>')
        parts.append('<details><summary>实际版本、输入 dtype / shape、状态与输出张量规格</summary><pre>'+e(json.dumps({k:record[k] for k in ('runtime_identities','declared_input_dtype','saved_inputs','saved_targets','output_tensor_descriptors')}, ensure_ascii=False, indent=2))+'</pre></details>')
        if record['located_layer_config']:
            parts.append('<p>相关层配置（来自保存的 model.json，定位不证明根因）：</p><pre>'+e(json.dumps(record['located_layer_config'], ensure_ascii=False, indent=2))+'</pre>')
        parts.append('<p>保存的完整模型代码（优先 case/model_source.py，包含权重恢复）：</p><pre>'+e(record['model_source'] or '未保存源码')+'</pre>')
        if record['exception_logs']:
            parts.append('<details><summary>异常日志节选</summary><pre>'+e(json.dumps(record['exception_logs'], ensure_ascii=False, indent=2))+'</pre></details>')
        parts.append('<details><summary>输出、损失、梯度指标及排除原因</summary><pre>'+e(json.dumps(record['metrics'], ensure_ascii=False, indent=2))+'</pre></details><details><summary>完整原始记录（未改写）</summary><pre>'+e(json.dumps(record['original_record'], ensure_ascii=False, indent=2))+'</pre></details></details>')
    parts.append('<h2>文件与口径</h2><p>summary.json：统计及核对；unique_records.json / .csv：去重记录；strict_triggers.json / .csv：严格条件去重；problem_types.json / .csv：描述性问题类型；records.jsonl：全部带来源的原始观测。源文件和行号相对于本次运行结果根目录，搬迁目录后仍有效。</p><pre>'+e(json.dumps(summary['definitions'], ensure_ascii=False, indent=2))+'</pre>')
    parts.append('''<script>const q=document.querySelector('#q'),k=document.querySelector('#kind'),rows=[...document.querySelectorAll('.alert')];function f(){let n=0;for(const r of rows){const show=(!k.value||k.value===r.dataset.candidate)&&r.textContent.toLowerCase().includes(q.value.toLowerCase());r.hidden=!show;n+=show;}document.querySelector('#n').textContent=n+' 条去重记录';}q.addEventListener('input',f);k.addEventListener('change',f);for(const a of document.querySelectorAll('a[href^="#R-"]'))a.addEventListener('click',()=>{const r=document.getElementById(a.hash.slice(1));if(r){r.open=true;r.hidden=false;}});f();</script></html>''')
    return '\n'.join(parts)


def summarize(input_path, out_dir, cases_root=None, runtime_review=None):
    input_path, out_dir = Path(input_path).resolve(), Path(out_dir).resolve()
    results_root = input_path.parent
    cases_root = Path(cases_root).resolve() if cases_root else input_path.with_name(input_path.stem+'_cases')
    if out_dir == cases_root or cases_root in out_dir.parents:
        raise ValueError('Output must be outside case evidence directories')
    main = load(input_path)
    review = load(runtime_review) if runtime_review else {}
    manual_mappings = review_detail_snapshots(review.get('manual_review_mappings', []), runtime_review) if runtime_review else []
    if not cases_root.is_dir():
        raise ValueError('Cases directory does not exist: ' + str(cases_root))
    records, case_cache, errors = [], {}, []
    for path in sorted(cases_root.rglob('case_manifest.json')):
        case_cache[path.parent] = read_case(path.parent, results_root)
    for path in sorted(cases_root.rglob('observations.jsonl')):
        for line, text in enumerate(path.read_text(encoding='utf-8-sig').splitlines(), 1):
            if not text.strip():
                continue
            try:
                record = json.loads(text)
                if not isinstance(record, dict):
                    raise ValueError('observation must be an object')
                case, association = resolve_record_case(record, path.parent, case_cache)
                if case not in case_cache:
                    case_cache[case] = read_case(case, results_root)
                annotated = annotate(record, path, line, case_cache[case], results_root, out_dir, review.get('cases', []), manual_mappings)
                annotated['case_association'] = association
                records.append(annotated)
            except (ValueError, OSError, TypeError) as exc:
                errors.append({'source': rel(path, results_root), 'line': line, 'error': str(exc)})
    exact = {}
    for record in records:
        rid = record['record_id']
        if rid not in exact:
            exact[rid] = dict(record, origins=[])
        exact[rid]['origins'].append(record['source'])
    unique = list(exact.values())
    trigger_map, group_map = defaultdict(list), defaultdict(list)
    for record in unique:
        trigger_map[record['trigger_id']].append(record)
        group_map[record['problem_type_id']].append(record)
    triggers = []
    for tid, items in sorted(trigger_map.items()):
        statuses = {x['reviewed_candidate_status'] for x in items}
        status = 'not_candidate' if not items[0]['candidate'] else ('retained' if 'retained' in statuses else 'review_excluded')
        triggers.append({'trigger_id': tid, 'category': items[0]['category'], 'candidate': items[0]['candidate'],
            'reviewed_candidate_status': status, 'mixed_review_status': len(statuses) > 1,
            'review_status_by_record': {x['record_id']: x['reviewed_candidate_status'] for x in items},
            'exact_records': len(items), 'raw_occurrences': sum(len(x['origins']) for x in items),
            'record_ids': [x['record_id'] for x in items], 'case_paths': sorted(set(x['case_path'] for x in items)),
            'merge_eligible': items[0]['trigger_merge_eligible'], 'missing_evidence': items[0]['trigger_missing_evidence'],
            'conditions': items[0]['trigger_conditions']})
    ordered = sorted(group_map.items(), key=lambda pair: (not pair[1][0]['candidate'], pair[1][0]['category'], pair[1][0]['title_zh'], pair[0]))
    groups = []
    for index, (gid, items) in enumerate(ordered, 1):
        groups.append({'group_id': gid, 'short_id': f'A{index:03d}', 'title_zh': items[0]['title_zh'],
            'description_zh': items[0]['description_zh'], 'key': items[0]['problem_type_key'],
            'candidate': items[0]['candidate'], 'raw_occurrences': sum(len(x['origins']) for x in items),
            'exact_records': len(items), 'strict_triggers': len(set(x['trigger_id'] for x in items)),
            'cases': len(set(x['case_path'] for x in items)), 'record_ids': [x['record_id'] for x in items],
            'reviewed_candidate_status_counts':dict(Counter(x['reviewed_candidate_status'] for x in items)),
            'review_conclusions':list(dict.fromkeys(x['runtime_review']['conclusion'] for x in items if x['runtime_review']['matched']))})
    config_rows = [(pool, ab, info) for pool, values in main.get('by_pool', {}).items() for ab, info in values.items()]
    requested = sum(v.get('total_models', 0) for _, _, v in config_rows)
    completed = sum(v.get('ok_models', 0) for _, _, v in config_rows)
    actual_cases = [c for c in case_cache.values() if c['manifest_available']]
    training_status, generation_status = Counter(), Counter()
    actual_completed = 0
    funnel = Counter(requested_attempts=requested, saved_case_manifests=len(actual_cases), both_generation_ok=0,
                     training_attempted_cases=0, both_training_ok=0, comparable_pair_cases=0,
                     attempted_gradient_comparison_cases=0, gradient_comparison_cases=0,
                     attempted_gradient_metrics=0, eligible_gradient_metrics=0, candidate_cases=0)
    by_dtype, comparison_reviews = {}, []
    for case in actual_cases:
        own = {}
        generation = {}
        for key, worker in case['worker_records'].items():
            target = training_status if key.startswith('training/') else generation_status
            target[worker.get('status', 'unknown')] += 1
            if key.startswith('training/'):
                own[key.split('/')[1]] = worker.get('status')
            else:
                generation[key.split('/')[1]] = worker.get('status')
        actual_completed += all(own.get(bk) == 'ok' for bk in ('tensorflow', 'torch'))
        compared = case.get('comparisons', {}) or {}
        reviewed_pairs = reviewed_case_comparisons(case, review.get('cases', []), manual_mappings)
        comparison_reviews.extend(reviewed_pairs)
        gradients = gradient_comparison_counts(compared)
        case_alerts = [x for x in records if x['case_path']==case['path']]
        flags = {'both_generation_ok':all(generation.get(bk)=='ok' for bk in ('tensorflow','torch')),
                 'training_attempted_cases':bool(own), 'both_training_ok':all(own.get(bk)=='ok' for bk in ('tensorflow','torch')),
                 'comparable_pair_cases':any(x.get('classification') in ('candidate','consistent') for x in compared.values()),
                 'attempted_gradient_comparison_cases':gradients['attempted_gradient_comparison_cases'],
                 'gradient_comparison_cases':gradients['gradient_comparison_cases'],
                 'candidate_cases':any(x['candidate'] for x in case_alerts)}
        for key,value in flags.items():
            funnel[key]+=bool(value)
        for key in ('attempted_gradient_metrics', 'eligible_gradient_metrics'):
            funnel[key] += gradients[key]
        dtype = case.get('input_dtype',{}).get('value') or 'unknown'
        if dtype not in by_dtype:
            by_dtype[dtype] = {'dtype':dtype,'cases':0, **{k:0 for k in flags},'candidate_records':0,'raw_observations':0,
                'attempted_gradient_metrics':0, 'eligible_gradient_metrics':0,
                'generation_status_events':Counter(),'training_status_events':Counter(),
                'generation_by_backend':defaultdict(Counter),'training_by_backend':defaultdict(Counter)}
        row = by_dtype[dtype];row['cases']+=1
        for key,value in flags.items():row[key]+=bool(value)
        for key in ('attempted_gradient_metrics', 'eligible_gradient_metrics'):
            row[key] += gradients[key]
        row['candidate_records']+=sum(x['candidate'] for x in case_alerts);row['raw_observations']+=len(case_alerts)
        row['generation_status_events'].update(generation.values());row['training_status_events'].update(own.values())
        for bk,state in generation.items():row['generation_by_backend'][bk][state]+=1
        for bk,state in own.items():row['training_by_backend'][bk][state]+=1
    candidate_total = Counter()
    for _, _, v in config_rows:
        candidate_total.update(v.get('total', {}))
    observed_candidates = Counter(x['category'] for x in records if x['candidate'])
    declared_observations = sum(v.get('defect_records', 0) for _, _, v in config_rows)
    reconciliation = {
        'main_status': main.get('status'), 'selected_configurations': [{'pool':p,'ablation':a,'requested_models':v.get('total_models')} for p,a,v in config_rows],
        'models_semantics': '--models applies per selected configuration; full with 200 means 200 total; all with 200 means 11*200.',
        'requested_models': requested, 'saved_manifests': len(actual_cases),
        'declared_both_backends_completed': completed, 'observed_both_backends_completed': actual_completed,
        'completion_matches': completed == actual_completed,
        'declared_observations': declared_observations, 'observed_records': len(records), 'observation_count_matches': declared_observations == len(records),
        'declared_candidates': dict(candidate_total), 'observed_candidates': dict(observed_candidates),
        'candidate_counts_match': all(candidate_total.get(k,0) == observed_candidates.get(k,0) for k in set(candidate_total)|set(observed_candidates)),
        'artifact_integrity_errors': {c['path']:c['integrity']['errors'] for c in actual_cases if c['integrity']['errors']},
        'manifest_source_hashes': dict(Counter(c['manifest'].get('source_sha256', 'unknown') for c in actual_cases)),
        'tested_source_hashes': dict(Counter(c['manifest'].get('metadata',{}).get('source_sha256', 'unknown') for c in actual_cases)),
        'model_source_syntax_valid': sum(c.get('source_syntax_valid') is True for c in actual_cases),
    }
    cats = sorted(set(x['category'] for x in records))
    category_counts = [{'category': k, 'raw': sum(x['category']==k for x in records), 'exact':sum(x['category']==k for x in unique),
                        'triggers':sum(x['category']==k for x in triggers), 'problem_types':sum(x['key']['category']==k for x in groups)} for k in cats]
    comparison_sets = {key: sorted({x['case_path'] for x in comparison_reviews if x[key]})
                       for key in ('original_comparison_eligible', 'review_retained_comparison',
                                   'review_excluded_comparison', 'original_gradient_eligible', 'review_retained_gradient')}
    summary = {
        'schema_version': SCHEMA, 'scope':'fresh_run_all_observations_with_separate_dedup_units',
        'input_source': input_path.name, 'cases_root':rel(cases_root, results_root),
        'requested_models':requested, 'saved_cases':len(actual_cases), 'both_backends_completed':completed,
        'raw_observations':len(records), 'unique_exact_records':len(unique), 'unique_strict_triggers':len(triggers),
        'descriptive_problem_types':len(groups), 'category_counts':category_counts,
        'candidate_raw_observations':sum(x['candidate'] for x in records),
        'candidate_exact_records':sum(x['candidate'] for x in unique), 'candidate_strict_triggers':sum(x['candidate'] for x in triggers),
        'candidate_problem_types':sum(x['candidate'] for x in groups),
        'reviewed_candidates':reviewed_candidate_counts(records, unique, triggers),
        'reviewed_comparisons':{
            'original_comparable_cases':len(comparison_sets['original_comparison_eligible']),
            'review_retained_comparable_cases':len(comparison_sets['review_retained_comparison']),
            'review_excluded_comparable_cases':len(set(comparison_sets['original_comparison_eligible'])-set(comparison_sets['review_retained_comparison'])),
            'original_gradient_cases':len(comparison_sets['original_gradient_eligible']),
            'review_retained_gradient_cases':len(comparison_sets['review_retained_gradient']),
            'review_excluded_gradient_cases':len(set(comparison_sets['original_gradient_eligible'])-set(comparison_sets['review_retained_gradient'])),
            'retained_case_paths':comparison_sets['review_retained_comparison'],
            'excluded_case_paths':sorted(set(comparison_sets['original_comparison_eligible'])-set(comparison_sets['review_retained_comparison'])),
            'pairs_with_explicit_review_exclusions':sum(bool(x['exclusion_classifications']) for x in comparison_reviews)},
        'strict_trigger_ineligible_records':sum(not x['trigger_merge_eligible'] for x in unique),
        'training_status_events':dict(training_status), 'generation_status_events':dict(generation_status),
        'funnel':dict(funnel), 'dtype_breakdown':[by_dtype[k] for k in sorted(by_dtype)],
        'runtime_review':{'provided':bool(runtime_review),'source_name':Path(runtime_review).name if runtime_review else None,
                          'sha256':file_hash(runtime_review) if runtime_review else None,
                          'reviewed_at_utc':review.get('reviewed_at_utc'),
                          'matched_exact_records':sum(x['runtime_review']['matched'] for x in unique),
                          'manual_mapping_records':sum(bool(x['runtime_review'].get('manual_review_mappings')) for x in unique),
                          'detail_snapshots_embedded':sum(x.get('detail_file_snapshot', {}).get('status') == 'embedded' for x in manual_mappings),
                          'detail_snapshots_unavailable':sum(x.get('detail_file_snapshot', {}).get('status') == 'unavailable' for x in manual_mappings),
                          'note':'External interpretations are annotations matched by manifest SHA256; original categories and all primary counts remain unchanged.'},
        'run_environment':main.get('meta',{}).get('environment',{}), 'run_metadata':main.get('meta',{}),
        'confirmed_framework_bugs':0, 'errors':errors, 'reconciliation':reconciliation,
        'definitions': {
            'raw':'每个非空 observations.jsonl 对象；CSV投影、主汇总、日志不重复累加。',
            'exact':'完整原始JSON载荷SHA256去重，不依赖可能陈旧的record_id；保留全部来源和1起始行号。',
            'strict_trigger':'类型/阶段/实际后端/规则/层/指标判定条件/实际版本/源码/架构/输入/标签/初始权重/执行配置相同才可合并。缺证据按精确记录ID单独保留。',
            'artifact_fallback':'早期失败无worker执行指纹时，只使用已保存数组内容、完整model.json+输入dtype、配置及实际generation身份的保守指纹；与worker指纹口径不混合。',
            'problem_type':'分类/阶段/后端/异常类型/相关算子/保守规范消息/排除理由分组。只去层序号和内存地址，保留数字、shape和dtype；不是唯一bug或根因数。',
            'candidate':'当前测试预言机的候选观测，未经上游确认或独立根因验证；不能把所有invalid/unsupported/unknown当误报删除。',
            'reviewed_candidate':'仅按manifest SHA+案例路径+后端+阶段匹配的人工mapping明确分类白名单排除；原候选字段不变。未获明确排除的候选保留，不能解释为缺陷已确认。严格触发组若人工判定混合则保守保留，并标mixed_review_status。',
            'reviewed_comparison':'独立遍历全部保存案例的比较而非仅告警记录；从原可比较集合排除明确无效的后端对。多后端案例至少一个对仍可比较才保留；集合之外未接受人工证明的案例不因此变成已验证正确。',
            'gradient_comparison_cases':'至少一个梯度指标明确分类consistent/candidate，所属比较未被排除且无gradient_exclusions；仅有extreme_scale_observation/excluded指标的案例不计。attempted指标计保留的所有梯度metric字典，eligible指标仅计有效项。',
            'paths':'派生路径相对于运行结果根目录；原始记录保持原文，可能包含执行机器绝对路径。复现命令的RESULTS_ROOT/NEW_EMPTY_DIRECTORY需由使用者替换。',
        }}
    out_dir.mkdir(parents=True, exist_ok=True)
    write_json(out_dir/'summary.json', summary)
    write_json(out_dir/'unique_records.json', unique)
    write_json(out_dir/'strict_triggers.json', triggers)
    write_json(out_dir/'problem_types.json', groups)
    write_json(out_dir/'reviewed_comparisons.json', comparison_reviews)
    if runtime_review:
        write_json(out_dir/'runtime_review_snapshot.json', review)
    with (out_dir/'records.jsonl').open('w', encoding='utf-8') as stream:
        for record in records:
            stream.write(canonical(record)+'\n')
    write_csv(out_dir/'unique_records.csv', unique, ['record_id','trigger_id','problem_type_id','category','candidate','reviewed_candidate_status','review_exclusion_classifications','backend','stage','model_id','case_path','source','title_zh','description_zh','runtime_review','trigger_merge_eligible','trigger_missing_evidence','located_layer_config','declared_input_dtype','metrics','model_source','replay_command'])
    write_csv(out_dir/'strict_triggers.csv', triggers, ['trigger_id','category','candidate','reviewed_candidate_status','mixed_review_status','raw_occurrences','exact_records','case_paths','merge_eligible','missing_evidence','record_ids'])
    write_csv(out_dir/'problem_types.csv', groups, ['short_id','group_id','title_zh','description_zh','candidate','raw_occurrences','exact_records','strict_triggers','cases','key','review_conclusions','record_ids'])
    write_csv(out_dir/'dtype_breakdown.csv', summary['dtype_breakdown'], ['dtype','cases','both_generation_ok','training_attempted_cases','both_training_ok','comparable_pair_cases','attempted_gradient_comparison_cases','gradient_comparison_cases','attempted_gradient_metrics','eligible_gradient_metrics','candidate_cases','candidate_records','raw_observations','generation_status_events','training_status_events'])
    (out_dir/'report.html').write_text(render_report(summary, groups, triggers, unique), encoding='utf-8')
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--out-dir', required=True, type=Path)
    parser.add_argument('--cases-root', type=Path)
    parser.add_argument('--runtime-review', type=Path, help='Optional independent review snapshot matched by exact case-manifest hash')
    args = parser.parse_args(argv)
    summary = summarize(args.input, args.out_dir, args.cases_root, args.runtime_review)
    print(json.dumps({k:summary[k] for k in ('requested_models','saved_cases','raw_observations','unique_exact_records','unique_strict_triggers','descriptive_problem_types','category_counts','strict_trigger_ineligible_records','errors')}, ensure_ascii=False, indent=2))
    return 1 if summary['errors'] or summary['reconciliation']['artifact_integrity_errors'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
