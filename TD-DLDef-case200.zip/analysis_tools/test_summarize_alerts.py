"""Deduplication regressions: missing evidence must never create equivalence."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
import summarize_alerts as audit


def record(**change):
    row = {'model_id': 1, 'backend': 'tensorflow_torch', 'defect_type': 'inconsistency',
           'classification': 'candidate', 'evidence_status': 'candidate', 'stage': 'comparison',
           'located_layer': '02_dense', 'detail': 'finite difference exceeds bounds',
           'metrics': {'layer_gradients': {'02_dense': {'candidate': True, 'classification': 'candidate', 'atol': 1e-6, 'rtol': 1e-4}}}}
    row.update(change)
    return row


def case():
    config = {'seed': 5, 'loss': 'mean_squared_error',
              'loss_reduction': 'mean_per_output_then_sum_plus_regularizers',
              'optimizer': {'class_name': 'SGD', 'config': {'learning_rate': 0.01}},
              'training': True, 'optimizer_steps': 0, 'device': 'CPU'}
    state = {'architecture': 'arch', 'inputs': 'in', 'targets': 'target', 'initial_weights': 'weights', 'config': config}
    versions = {b: {'actual_backend': b, 'versions': {'python': '3.12', 'keras': '3', b: '1', 'numpy': '1'}} for b in ('tensorflow', 'torch')}
    return {'manifest_available': True, 'integrity': {'errors': []}, 'runtime_identities': versions,
            'manifest': {'metadata': {'source_sha256': 'source'},
                         'execution_equivalence': {b: copy.deepcopy(state) for b in versions},
                         'replay_config': {'values': {'threshold': .15}}},
            'model_info': {'model_structure': {'2': {'type': 'dense', 'args': {'name': '02_dense'}}}}}


def trigger(row, evidence):
    return audit.strict_trigger(row, evidence, audit.exact_fingerprint(row))


class DedupTests(unittest.TestCase):
    def test_exact_payload_not_stale_record_id(self):
        a, b = record(record_id='same'), record(record_id='same', model_id=2)
        self.assertNotEqual(audit.exact_fingerprint(a), audit.exact_fingerprint(b))
        self.assertEqual(audit.exact_fingerprint(a), audit.exact_fingerprint(dict(reversed(list(a.items())))))

    def test_same_proven_conditions_merge_across_record_identity(self):
        a, b = record(model_id=1), record(model_id=2)
        self.assertEqual(trigger(a, case())[0], trigger(b, case())[0])
        self.assertEqual(trigger(a, case())[2], [])

    def test_missing_fingerprint_prevents_accidental_merge(self):
        incomplete = case()
        incomplete['manifest']['execution_equivalence']['tensorflow'].pop('inputs')
        first = trigger(record(model_id=1), incomplete)
        second = trigger(record(model_id=2), incomplete)
        self.assertNotEqual(first[0], second[0])
        self.assertTrue(first[2])

    def test_seed_only_worker_config_cannot_establish_equivalence(self):
        incomplete = case()
        incomplete['manifest']['execution_equivalence']['tensorflow']['config'] = {'seed': 20261010}
        first = trigger(record(model_id=1), incomplete)
        second = trigger(record(model_id=2), incomplete)
        self.assertNotEqual(first[0], second[0])
        self.assertIn('tensorflow/config/loss_reduction', first[2])
        self.assertIn('tensorflow/config/optimizer', first[2])
        self.assertIn('tensorflow/config/training', first[2])
        self.assertIn('tensorflow/config/device', first[2])
        self.assertIn('tensorflow/config/optimizer_steps', first[2])
        self.assertEqual(first[1]['states']['tensorflow']['config'], {'seed': 20261010})

    def test_complete_explicit_false_and_zero_config_values_are_preserved(self):
        complete = case()
        complete['manifest']['execution_equivalence']['tensorflow']['config']['training'] = False
        complete['manifest']['execution_equivalence']['tensorflow']['config']['seed'] = 0
        first = trigger(record(model_id=1), complete)
        self.assertEqual(first[2], [])
        self.assertNotEqual(first[0], trigger(record(model_id=1), case())[0])
        for key in ('loss', 'loss_reduction', 'optimizer', 'training', 'optimizer_steps', 'seed', 'device'):
            incomplete = copy.deepcopy(complete)
            incomplete['manifest']['execution_equivalence']['tensorflow']['config'].pop(key)
            self.assertTrue(trigger(record(), incomplete)[2], key)

    def test_backend_versions_and_weights_are_condition_identity(self):
        a = case(); b = copy.deepcopy(a)
        b['runtime_identities']['torch']['versions']['torch'] = '2'
        self.assertNotEqual(trigger(record(), a)[0], trigger(record(), b)[0])
        b = copy.deepcopy(a); b['manifest']['execution_equivalence']['torch']['initial_weights'] = 'changed'
        self.assertNotEqual(trigger(record(), a)[0], trigger(record(), b)[0])

    def test_alert_channels_prevent_loss_gradient_type_merging(self):
        a = record(); b = copy.deepcopy(a)
        b['metrics']['loss'] = {'candidate': True, 'classification': 'candidate'}
        self.assertNotEqual(trigger(a, case())[0], trigger(b, case())[0])
        self.assertNotEqual(audit.issue_group(a, case())[0], audit.issue_group(b, case())[0])
        self.assertEqual(audit.alert_channels(a), ['layer_gradients'])
        self.assertIn('损失、梯度', audit.describe(b, 'dense')[0])

    def test_nonfinite_channel_and_kind_are_preserved(self):
        a = record(defect_type='nonfinite_observation', classification='unconfirmed_nonfinite', evidence_status='observation', metrics={}, detail='nan in loss', affected_tensors=['loss'])
        b = dict(a, detail='inf in gradient', affected_tensors=['gradient/02_dense'])
        self.assertEqual(audit.alert_channels(a), ['loss'])
        self.assertNotEqual(audit.issue_group(a, case())[0], audit.issue_group(b, case())[0])

    def test_auxiliary_nonfinite_literal_recovers_gradient_inf_and_mixed_channels(self):
        a = record(defect_type='nonfinite_observation', classification='auxiliary_nonfinite',
                   evidence_status='observation', metrics={},
                   detail=audit.AUXILIARY_NONFINITE_PREFIX+" {'nan': [], 'inf': ['gradient/00_input_object']}")
        original = copy.deepcopy(a)
        self.assertEqual(audit.nonfinite_kind(a), 'inf')
        self.assertEqual(audit.alert_channels(a), ['layer_gradients'])
        self.assertIn('梯度的Inf观察', audit.describe(a, None)[0])
        b = dict(a, detail=audit.AUXILIARY_NONFINITE_PREFIX+" {'nan': ['gradient/02_PReLU'], 'inf': ['loss', 'loss_gradient/06_reshape']}")
        self.assertEqual(audit.nonfinite_kind(b), 'nan_and_inf')
        self.assertEqual(audit.alert_channels(b), ['layer_gradients', 'loss', 'loss_gradients'])
        self.assertIn('损失、梯度的NaN 与 Inf观察', audit.describe(b, None)[0])
        self.assertEqual(a, original)
        self.assertFalse(audit.is_candidate(a))
        self.assertEqual(audit.category(a), 'nonfinite_observation')

    def test_auxiliary_nonfinite_parser_rejects_calls_wrong_prefix_and_shape(self):
        base = record(defect_type='nonfinite_observation', classification='auxiliary_nonfinite', metrics={})
        for suffix in ["dict(nan=['loss'])", "__import__('os').getcwd()", "{'nan': 'loss'}", "{'nan': [1]}", "{'other': ['loss']}"]:
            row = dict(base, detail=audit.AUXILIARY_NONFINITE_PREFIX+suffix)
            self.assertEqual(audit.auxiliary_nonfinite_tensors(row), {})
        self.assertEqual(audit.auxiliary_nonfinite_tensors(dict(base, detail="other: {'nan': ['loss']}")), {})
        self.assertEqual(audit.auxiliary_nonfinite_tensors(dict(base, classification='candidate', detail=audit.AUXILIARY_NONFINITE_PREFIX+"{'nan': ['loss']}")), {})

    def test_message_normalization_preserves_shapes_dtype_and_threshold(self):
        first = 'layer 02_conv2D shape=(2, 3) dtype=float16 threshold=0.15'
        self.assertEqual(audit.normalized_message(first), audit.normalized_message(first.replace('02_', '19_')))
        self.assertNotEqual(audit.normalized_message(first), audit.normalized_message(first.replace('(2, 3)', '(2, 4)')))
        self.assertNotEqual(audit.normalized_message(first), audit.normalized_message(first.replace('float16', 'float32')))

    def test_external_review_requires_exact_manifest_hash(self):
        evidence = dict(case(), manifest_sha256='abc')
        reviews = [{'manifest_sha256':'different','case':'000001','stages':[{'stage':'comparison','backend':'tensorflow_torch','interpretation':'invalid'}]}]
        self.assertFalse(audit.review_annotation(record(), evidence, reviews)['matched'])
        reviews = [{'manifest_sha256':'abc','case':'000001','comparisons':[{'pair':'tensorflow_torch','interpretation':'candidate remains unconfirmed'}]}]
        result = audit.review_annotation(record(), evidence, reviews)
        self.assertTrue(result['matched'])
        self.assertEqual(result['original_category'], 'inconsistency')

    def test_manual_review_requires_manifest_then_case_backend_and_stage(self):
        evidence = dict(case(), manifest_sha256='abc', path='backend_200_cases/keras3.10/full/000028')
        reviews = [{'manifest_sha256': 'abc', 'case': '000028', 'comparisons': []}]
        mapping = {'case_path': 'C:\\machine\\run200\\backend_200_cases\\keras3.10\\full\\000028',
                   'backend': 'tensorflow_torch', 'stage': 'comparison',
                   'review_classification': 'retain_unconfirmed_numerical_candidate',
                   'interpretation': 'softmax one-ULP residual amplification',
                   'detail_file': 'case000028_review.json', 'independent_checks': [{'max_abs': 83465.0}]}
        before = copy.deepcopy(record())
        result = audit.review_annotation(before, evidence, reviews, [mapping])
        self.assertTrue(result['matched'])
        self.assertIn('one-ULP', result['conclusion'])
        self.assertEqual(result['manual_review_mappings'][0]['detail_file'], mapping['detail_file'])
        self.assertEqual(result['original_category'], 'inconsistency')
        self.assertEqual(before, record())
        self.assertFalse(audit.review_annotation(before, dict(evidence, manifest_sha256='different'), reviews, [mapping])['matched'])
        for key, value in [('case_path', mapping['case_path'].replace('000028', '000029')),
                           ('case_path', mapping['case_path'].replace('full', 'no_it')),
                           ('backend', 'tensorflow'), ('stage', 'training')]:
            self.assertFalse(audit.review_annotation(before, evidence, reviews, [dict(mapping, **{key: value})])['matched'])
        self.assertFalse(audit.same_review_case_path(mapping['case_path'], '000028'))

    def test_manual_review_embeds_detail_json_for_portable_html_evidence(self):
        with tempfile.TemporaryDirectory() as directory:
            detail = Path(directory)/'detail.json'
            detail.write_text(json.dumps({'backend_source': 'pad(mode="replicate")', 'proof': [1, 2]}), encoding='utf-8')
            mappings = [{'detail_file': 'detail.json'}, {'detail_file': 'missing.json'}]
            result = audit.review_detail_snapshots(mappings, Path(directory)/'review.json')
            self.assertEqual(result[0]['detail_file_snapshot']['status'], 'embedded')
            self.assertEqual(result[0]['detail_file_snapshot']['content']['backend_source'], 'pad(mode="replicate")')
            self.assertEqual(result[0]['detail_file_snapshot']['sha256'], audit.file_hash(detail))
            self.assertEqual(result[1]['detail_file_snapshot']['status'], 'unavailable')
            self.assertNotIn('detail_file_snapshot', mappings[0])

    def test_relocated_review_prefers_relative_file_over_original_absolute(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'moved').mkdir()
            (root/'moved'/'detail.json').write_text('{"source":"moved", "backend_code":"padding=replicate"}', encoding='utf-8')
            old = root/'old.json'
            old.write_text('{"source":"old"}', encoding='utf-8')
            mapping = {'detail_file': str(old), 'detail_relative_path': 'moved/detail.json'}
            result = audit.review_detail_snapshots([mapping], root/'runtime_review.json')[0]['detail_file_snapshot']
            self.assertEqual(result['resolved_from'], 'detail_relative_path')
            self.assertEqual(result['content']['source'], 'moved')
            mapping['detail_file'] = str(root/'missing_old_machine.json')
            result = audit.review_detail_snapshots([mapping], root/'runtime_review.json')[0]['detail_file_snapshot']
            self.assertEqual(result['status'], 'embedded')
            self.assertEqual(result['content']['backend_code'], 'padding=replicate')

    def test_relocated_diagnostics_directory_handles_old_prefix_and_literal_filename(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'diagnostics').mkdir()
            filename = 'detail$(not_executed).json'
            detail = root/'diagnostics'/filename
            detail.write_text('{"complete_evidence":[1,2,3]}', encoding='utf-8')
            for prefix in ('', 'analysis_tools/'):
                mapping = {'detail_file': str(root/'old_missing'/filename), 'detail_relative_path': prefix+filename}
                result = audit.review_detail_snapshots([mapping], root/'runtime_review.json')[0]['detail_file_snapshot']
                self.assertEqual(result['status'], 'embedded')
                self.assertEqual(result['resolved_from'], 'diagnostics_basename')
                self.assertEqual(result['content']['complete_evidence'], [1,2,3])
                self.assertEqual(result['sha256'], audit.file_hash(detail))

    def test_only_explicit_review_classification_excludes_candidate(self):
        mapping = {'stage': 'comparison', 'review_classification': 'invalid_test_dtype_operator',
                   'interpretation': 'comparison invalid unsynchronized stochastic layer'}
        annotation = {'manual_review_mappings': [mapping]}
        self.assertEqual(audit.reviewed_candidate_status(True, annotation), 'retained')
        mapping['review_classification'] = 'comparison_invalid_unsynchronized_nested_stochastic_layer'
        self.assertEqual(audit.reviewed_candidate_status(True, annotation), 'review_excluded')
        self.assertEqual(audit.reviewed_candidate_status(False, annotation), 'not_candidate')
        mapping['stage'] = 'training'
        self.assertEqual(audit.reviewed_candidate_status(True, annotation), 'retained')

    def test_reviewed_comparison_includes_consistent_case_without_alerts(self):
        evidence = dict(case(), manifest_sha256='sha160', path='backend_200_cases/keras3.10/full/000160',
                        comparisons={'tensorflow_torch': {'classification': 'consistent', 'gradient_exclusions': [],
                                     'metrics': {'layer_gradients': {'x': {'classification': 'consistent'}}}}})
        reviews = [{'manifest_sha256': 'sha160', 'case': '000160'}]
        mappings = [{'case_path': 'C:/run/'+evidence['path'], 'stage': 'comparison', 'backend': 'tensorflow_torch',
                     'review_classification': 'comparison_invalid_unsynchronized_nested_stochastic_layer'}]
        rows = audit.reviewed_case_comparisons(evidence, reviews, mappings)
        self.assertEqual(len(rows), 1)
        self.assertTrue(rows[0]['original_comparison_eligible'])
        self.assertTrue(rows[0]['original_gradient_eligible'])
        self.assertFalse(rows[0]['review_retained_comparison'])
        self.assertFalse(rows[0]['review_retained_gradient'])
        self.assertEqual(evidence['comparisons']['tensorflow_torch']['classification'], 'consistent')
        self.assertTrue(audit.reviewed_case_comparisons(evidence, [], mappings)[0]['review_retained_comparison'])

    def test_review_candidate_counts_partition_without_changing_original(self):
        retained = {'candidate': True, 'reviewed_candidate_status': 'retained', 'case_path': 'case1', 'problem_type_id': 'G-1'}
        excluded = {'candidate': True, 'reviewed_candidate_status': 'review_excluded', 'case_path': 'case2', 'problem_type_id': 'G-2'}
        unknown = {'candidate': False, 'reviewed_candidate_status': 'not_candidate', 'case_path': 'case3'}
        raw = [retained, retained, excluded, unknown]
        result = audit.reviewed_candidate_counts(raw, [retained, excluded, unknown], [retained, excluded])
        self.assertEqual(result['raw'], {'original': 3, 'retained': 2, 'review_excluded': 1})
        self.assertEqual(result['exact'], {'original': 2, 'retained': 1, 'review_excluded': 1})
        self.assertEqual(result['strict'], result['exact'])
        self.assertEqual(result['review_excluded_case_paths'], ['case2'])
        self.assertEqual(result['original_problem_types'], 2)
        self.assertEqual(result['retained_problem_types'], 1)
        self.assertEqual(result['excluded_only_problem_types'], 1)
        excluded['problem_type_id'] = retained['problem_type_id']
        same_type = audit.reviewed_candidate_counts(raw, [retained, excluded, unknown], [retained, excluded])
        self.assertEqual(same_type['excluded_only_problem_types'], 0)
        self.assertTrue(excluded['candidate'])

    def test_no_nan_serialization_extension(self):
        content = audit.canonical({'x': float('nan')})
        value = json.loads(content, parse_constant=lambda x: self.fail(x))
        self.assertEqual(value['x']['nonfinite_float'], 'NaN')

    def test_harness_attempt_is_not_a_model_id_after_generation_failure(self):
        parent = Path('fixture/pool/full').resolve()
        cache = {parent/'000001': {'manifest': {'metadata': {'case_index': 2}}},
                 parent/'000003': {'manifest': {'metadata': {'case_index': 4}}}}
        path, explanation = audit.resolve_record_case({'model_id':3,'backend':'harness'}, parent, cache)
        self.assertEqual(path.name, '000001')
        path, explanation = audit.resolve_record_case({'model_id':2,'backend':'harness'}, parent, cache)
        self.assertTrue(path.name.startswith('__unresolved'))

    def test_extreme_and_excluded_gradient_metrics_are_not_effective_comparisons(self):
        pairs = {'tensorflow_torch': {'classification':'consistent', 'gradient_exclusions':[],
                 'metrics':{'layer_gradients':{'x':{'classification':'extreme_scale_observation'},
                                             'y':{'classification':'extreme_scale_observation'}},
                            'loss_gradients':{'out':{'classification':'excluded'}}}}}
        counts = audit.gradient_comparison_counts(pairs)
        self.assertEqual(counts['attempted_gradient_metrics'], 3)
        self.assertTrue(counts['attempted_gradient_comparison_cases'])
        self.assertEqual(counts['eligible_gradient_metrics'], 0)
        self.assertFalse(counts['gradient_comparison_cases'])
        pairs['tensorflow_torch']['metrics']['layer_gradients']['x']['classification'] = 'candidate'
        self.assertEqual(audit.gradient_comparison_counts(pairs)['eligible_gradient_metrics'], 1)
        self.assertTrue(audit.gradient_comparison_counts(pairs)['gradient_comparison_cases'])

    def test_pair_exclusion_blocks_apparently_valid_gradient_metrics(self):
        pairs = {'tensorflow_torch':{'classification':'excluded','gradient_exclusions':[],
                 'metrics':{'loss_gradients':{'out':{'classification':'consistent'}}}}}
        self.assertFalse(audit.gradient_comparison_counts(pairs)['gradient_comparison_cases'])
        pairs['tensorflow_torch']['classification']='consistent'
        pairs['tensorflow_torch']['gradient_exclusions']=['nonsmooth point']
        self.assertFalse(audit.gradient_comparison_counts(pairs)['gradient_comparison_cases'])


if __name__ == '__main__':
    unittest.main()
