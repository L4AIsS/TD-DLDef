"""Diagnose saved case 000188 without executing its model or changing evidence.

Usage: python analyze_case000188.py --results-root <run200> --output <json>
NumPy supplies centered float64 references. Optional Torch arithmetic reproduces
the installed adapter's float32 reduction order on the saved BN input only.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def maximum_error(first, second):
    return float(np.max(np.abs(np.asarray(first, dtype=np.float64) - np.asarray(second, dtype=np.float64))))


def analyze(results_root):
    relative = "backend_200_cases/keras3.10/full/000188"
    case = results_root / relative
    model = read_json(case / "models/model.json")
    nodes = list(model["model_structure"].values())
    names = [n["args"]["name"] for n in nodes]
    comparison = read_json(case / "logs/comparison.json")["tensorflow_torch"]
    workers = {b: read_json(case / "logs" / ("training_" + b + ".json")) for b in ("tensorflow", "torch")}
    outputs = {b: {n: np.load(case / "layer_outputs" / b / (n + ".npy"), allow_pickle=False) for n in names} for b in workers}
    details = []
    evidence = [relative + "/models/model.json", relative + "/logs/comparison.json", relative + "/case_manifest.json"]
    for name in names:
        first, second = [outputs[b][name] for b in workers]
        details.append({"layer": name, "dtype": str(first.dtype), "shape": list(first.shape),
                        "max_abs_difference": maximum_error(first, second),
                        "both_finite": bool(np.isfinite(first).all() and np.isfinite(second).all())})
        for b in workers:
            evidence.append(relative + "/layer_outputs/" + b + "/" + name + ".npy")
    batchnorm = []
    for index in (2, 3):
        name, previous = names[index], names[index - 1]
        args = nodes[index]["args"]
        with np.load(case / "models/initial_weights" / (name + ".npz"), allow_pickle=False) as archive:
            values = [archive["arr_" + str(i)].copy() for i in range(len(archive.files))]
        k = 0
        gamma = values[k] if args["scale"] else np.asarray(1., dtype=np.float32)
        k += int(args["scale"])
        beta = values[k] if args["center"] else np.asarray(0., dtype=np.float32)
        k += int(args["center"])
        entry = {"layer": name, "epsilon": args["epsilon"], "axis": args["axis"],
                 "scale": args["scale"], "center": args["center"],
                 "initial_moving_mean_all_zero": bool(np.all(values[k] == 0)),
                 "initial_moving_variance_all_one": bool(np.all(values[k + 1] == 1)),
                 "max_abs_gamma": float(np.abs(gamma).max()), "max_abs_beta": float(np.abs(beta).max()),
                 "same_saved_input": bool(np.array_equal(outputs["tensorflow"][previous], outputs["torch"][previous])),
                 "backend_reference_errors": {}}
        evidence.append(relative + "/models/initial_weights/" + name + ".npz")
        for backend in workers:
            x = outputs[backend][previous].astype(np.float64)
            mean = x.mean(axis=0)
            variance = ((x - mean) ** 2).mean(axis=0)
            reference = gamma.astype(np.float64) * (x - mean) / np.sqrt(variance + args["epsilon"]) + beta
            entry["backend_reference_errors"][backend] = {
                "max_abs_error_centered_float64_reference": maximum_error(outputs[backend][name], reference),
                "mean_absolute_max": float(np.abs(mean).max()),
                "centered_variance_min": float(variance.min()), "centered_variance_max": float(variance.max())}
        try:
            import torch
        except ImportError:
            entry["torch_arithmetic_reference"] = {"available": False, "reason": "Torch not installed"}
        else:
            # Saved arrays only: no loading/running the generated Keras model.
            x = outputs["torch"][previous]
            t = torch.from_numpy(x.copy())
            mu = t.mean(dim=0, keepdim=True)
            vsub = (t * t).mean(dim=0, keepdim=True) - mu * mu
            alternate = (t - mu) * (vsub + args["epsilon"]).rsqrt() * torch.from_numpy(np.asarray(gamma).copy()) + torch.from_numpy(np.asarray(beta).copy())
            centered = ((x.astype(np.float64) - x.astype(np.float64).mean(0)) ** 2).mean(0)
            v = vsub.numpy()[0]
            worst = int(np.argmax(np.abs(centered - v)))
            entry["torch_arithmetic_reference"] = {
                "available": True, "torch_version": torch.__version__,
                "formula": "mean32 = mean(x); variance32 = mean(x*x) - mean32*mean32; (x-mean32)*rsqrt(variance32+epsilon)*gamma+beta",
                "max_abs_error_against_saved_torch_output": maximum_error(outputs["torch"][name], alternate.numpy()),
                "max_abs_variance_error_against_centered_float64": maximum_error(centered, v),
                "worst_variance_channel": worst, "worst_channel_mean_float64": float(x.astype(np.float64).mean(0)[worst]),
                "worst_channel_centered_variance_float64": float(centered[worst]),
                "worst_channel_subtractive_variance_float32": float(v[worst])}
        batchnorm.append(entry)
    last = names[-1]
    first, second = [outputs[b][last].astype(np.float64) for b in workers]
    metric = comparison["metrics"]["outputs"][last]
    delta = np.abs(first - second)
    joint = (delta > .15) & (delta > metric["atol"] + metric["rtol"] * np.maximum(np.abs(first), np.abs(second)))
    weights = np.load(case / "models/initial_weights/05_dense.npz", allow_pickle=False)["arr_0"].astype(np.float64)
    dense_prediction = (outputs["tensorflow"]["04_reshape"].astype(np.float64) - outputs["torch"]["04_reshape"].astype(np.float64)) @ weights
    return {"case_relative_path": relative, "backend": "tensorflow_torch", "stage": "comparison",
            "classification": "retain_unconfirmed_numerical_candidate", "original_evidence_changed": False,
            "manifest_sha256": hashlib.sha256((case / "case_manifest.json").read_bytes()).hexdigest(),
            "trigger": {k: comparison.get(k) for k in ("output", "loss", "loss_grads", "raw_output", "raw_loss", "raw_loss_grads", "gradient_exclusions", "gradient_precision_basis")},
            "candidate_channels": ["output"], "candidate_output_joint_exceed_count": int(joint.sum()),
            "candidate_output_max_joint_abs_difference": float(delta[joint].max()) if joint.any() else None,
            "worker_equivalence_matches": workers["tensorflow"]["equivalence"] == workers["torch"]["equivalence"],
            "first_divergent_layer": next(x["layer"] for x in details if x["max_abs_difference"] > 0),
            "first_material_amplification_layer": "03_batch_normalization",
            "mechanism_group": "float32_variance_subtractive_cancellation", "layer_differences": details,
            "batchnorm": batchnorm,
            "dense_amplification": {"max_abs_kernel_weight": float(np.abs(weights).max()),
                                     "max_abs_predicted_output_difference": float(np.abs(dense_prediction).max()),
                                     "max_abs_residual_after_propagating_bn_difference": maximum_error(first - second, dense_prediction)},
            "auxiliary_nonfinite": {b: w.get("numerical_evidence", {}).get("auxiliary_nonfinite") for b, w in workers.items()},
            "source_location": {"module_relative_to_environment": "Lib/site-packages/keras/src/backend/torch/nn.py",
                                "function": "moments", "lines": [776, 801],
                                "mechanism": "Installed Keras 3.10 Torch adapter uses E[x^2]-E[x]^2. Second BN input contains first-BN beta offsets with near-unit variance, exposing subtractive cancellation."},
            "analysis": "Only final output triggers. Loss remains within relative tolerance; all gradient metrics are excluded or extreme-scale observations. The first BN produces a tiny backend difference; the second BN amplifies it. Centered float64 references closely match TensorFlow, and the Torch adapter's float32 subtractive-variance arithmetic closely reproduces the saved Torch result. First-BN beta offsets increase cancellation in second-BN variance; a large Dense kernel amplifies the resulting difference into the output candidate. Shared execution fingerprints and valid initial moving statistics provide no evidence of a harness state mismatch. This remains an unconfirmed numerical-stability candidate, not a confirmed framework defect.",
            "evidence_relative_paths": evidence + [relative + "/models/initial_weights/05_dense.npz"] + [relative + "/logs/training_" + b + ".json" for b in workers],
            "limitations": "Saved-tensor diagnostic only; NumPy reference and optional local Torch arithmetic, no generated-model rerun or maintainer confirmation. Mechanism similarity to another BN case does not establish a shared root cause."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-root", type=Path, default=Path(__file__).resolve().parents[2] / "outputs/run200")
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("case000188_review.json"))
    args = parser.parse_args()
    result = analyze(args.results_root.resolve())
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("case_relative_path", "classification", "candidate_channels", "candidate_output_joint_exceed_count", "worker_equivalence_matches")}, ensure_ascii=False))
