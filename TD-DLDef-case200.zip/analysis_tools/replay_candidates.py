"""Replay saved candidate cases in a separate directory, without touching the run."""
import argparse,concurrent.futures,datetime,json,subprocess,sys,time
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run-dir',type=Path,required=True)
    ap.add_argument('--code-dir',type=Path,required=True)
    ap.add_argument('--workers',type=int,default=2)
    args=ap.parse_args()
    run=args.run_dir.resolve();code=args.code_dir.resolve()
    root=run/'backend_200_cases';output=run/'candidate_replays'
    output.mkdir(parents=True,exist_ok=True)
    result_file=run/'candidate_replay_summary.json'
    completed={};pending={};seen=set()
    if result_file.exists():
        previous=json.loads(result_file.read_text(encoding='utf-8'))
        completed={x['case']:x for x in previous.get('cases',[])};seen.update(completed)
    def run_case(case):
        name=case.relative_to(root).as_posix();dest=output/('_'.join(case.relative_to(root).parts))
        command=[sys.executable,str(code/'scripts/reproduce_case.py'),'--case',str(case),'--out',str(dest)]
        log=output/(dest.name+'.log')
        with log.open('w',encoding='utf-8') as f:
            execution=subprocess.run(command,cwd=code,stdout=f,stderr=subprocess.STDOUT,timeout=600)
        saved=dest/'replay_summary.json'
        data=json.loads(saved.read_text(encoding='utf-8')) if saved.exists() else {}
        return {'case':name,'return_code':execution.returncode,'execution_status':data.get('execution_status'),
                'summary_path':saved.relative_to(run).as_posix(),'reproduction_evidence':data.get('reproduction_evidence'),
                'comparisons':{k:{f:v.get(f) for f in ('classification','output','loss','loss_grads')}
                               for k,v in data.get('comparisons',{}).items()},
                'original_candidate_reproduced':any(v.get('classification')=='candidate' for v in data.get('comparisons',{}).values())}
    def save(status):
        data={'status':status,'scope':'Auxiliary replays; not additional models in case_num=200.',
              'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'cases':sorted(completed.values(),key=lambda x:x['case'])}
        temporary=result_file.with_suffix('.tmp');temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');temporary.replace(result_file)
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
        while True:
            for manifest in sorted(root.glob('*/*/*/case_manifest.json')):
                case=manifest.parent;name=case.relative_to(root).as_posix()
                if name in seen:continue
                try:data=json.loads(manifest.read_text(encoding='utf-8'))
                except (ValueError,OSError):continue
                if any(v.get('classification')=='candidate' for v in data.get('metadata',{}).get('comparisons',{}).values()):
                    pending[executor.submit(run_case,case)]=name;seen.add(name)
            for job in list(pending):
                if not job.done():continue
                name=pending.pop(job)
                try:completed[name]=job.result()
                except Exception as exc:completed[name]={'case':name,'execution_status':'replay_error','error':repr(exc)}
                save('running');print(json.dumps({'replay_completed':name,'result':completed[name].get('original_candidate_reproduced')},ensure_ascii=False),flush=True)
            if (run/'backend_200.json').exists() and not pending:
                # Parent writes its summary after every case manifest is captured.
                save('completed');return
            time.sleep(5)

if __name__=='__main__':main()
