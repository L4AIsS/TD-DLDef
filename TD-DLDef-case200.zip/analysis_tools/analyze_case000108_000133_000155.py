"""Saved-array diagnostics for additional run200 cases, without executing backends."""
import argparse,json
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--cases-root',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args();base=a.cases_root.resolve();out=a.output_dir;out.mkdir(parents=True,exist_ok=True)
def load(c,f,b,n):return np.load(c/f/b/(n+'.npy'),allow_pickle=False)
def basic(cid):
 c=base/cid;r=json.loads((c/'logs/comparison.json').read_text(encoding='utf-8'))['tensorflow_torch'];rel=c.relative_to(base.parents[2]).as_posix()
 return c,{'case_relative_path':rel,'backend':'tensorflow_torch','stage':'comparison','classification':'retain_unconfirmed_numerical_candidate',
 'original_evidence_changed':False,'trigger':{k:r.get(k) for k in ['output','loss','loss_grads','raw_output','raw_loss','raw_loss_grads','gradient_exclusions','gradient_precision_basis']},
 'evidence_relative_paths':[rel+'/models/model.json',rel+'/logs/comparison.json'],
 'limitations':'diagnostic reference on saved tensors only; no new backend execution, no maintainer confirmation, no automatic root-cause deduplication'}

c,r=basic('000108');n='01_separable_conv2D';r['first_divergent_layer']=n;r['mechanism_group']='saturated_softmax_normalization_residual_amplified';r['softmax']={}
for bk in ['tensorflow','torch']:
 v=load(c,'layer_outputs',bk,n);g=load(c,'layer_gradients',bk,n);local=v*(g-(g*v).sum(axis=-1,keepdims=True));ig=load(c,'layer_gradients',bk,'00_input_object')
 r['softmax'][bk]={'unique_probabilities':np.unique(v).tolist(),'max_normalization_error':float(np.abs(v.sum(axis=-1)-1).max()),
 'local_vjp_max_abs':float(np.abs(local).max()),'nonzero_local_vjp_elements':int(np.count_nonzero(local)),
 'input_gradient_max_abs':float(np.abs(ig).max()),'nonzero_input_gradient_elements':int(np.count_nonzero(ig))}
r['analysis']='Like case28, the first softmax is saturated: TensorFlow saves 0 and 0.99999994 while Torch saves 0 and 1. The resulting small normalization residual can survive the softmax VJP and be amplified upstream; only the gradient channel triggers. No channel-layout or loss-reduction mismatch is established. Retain for numerical-stability investigation.'
(out/'case000108_review.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print('108',r['softmax'])

c,r=basic('000133');x=load(c,'layer_outputs','tensorflow','02_global_max_pooling2D').astype('float64')
assert np.array_equal(x,load(c,'layer_outputs','torch','02_global_max_pooling2D'))
with np.load(c/'models/initial_weights/03_batch_normalization.npz',allow_pickle=False) as w:gamma=w['arr_0'].astype('float64')
eps=.00390625;mean=x.mean(axis=0);variance=x.var(axis=0);ref=(x-mean)/np.sqrt(variance+eps)*gamma
f=x.astype('float32');alt_variance=(f*f).mean(axis=0)-f.mean(axis=0)**2;alt=(f-f.mean(axis=0))/np.sqrt(alt_variance+eps)*gamma
r['first_divergent_layer']='03_batch_normalization';r['mechanism_group']='float32_variance_subtractive_cancellation';r['batchnorm']={'axis':-1,'epsilon':eps,'center':False,'scale':True,'training':True,
 'identical_saved_input':True,'reference_formula':'gamma * (x - mean(x)) / sqrt(mean((x-mean(x))**2) + epsilon)',
 'alternate_float32_formula':'variance = mean(x*x) - mean(x)**2',
 'reference_variance_float64':variance.tolist(),'alternate_variance_float32':alt_variance.tolist(),'backend_reference_errors':{}}
for bk in ['tensorflow','torch']:
 y=load(c,'layer_outputs',bk,'03_batch_normalization');r['batchnorm']['backend_reference_errors'][bk]={
 'max_abs_error_centered_float64_reference':float(np.abs(y-ref).max()),'max_abs_error_float32_subtractive_variance_reference':float(np.abs(y-alt).max())}
r['source_location']={'official_tag_url':'https://github.com/keras-team/keras/blob/v3.10.0/keras/src/backend/torch/nn.py',
 'module_relative_to_environment':'Lib/site-packages/keras/src/backend/torch/nn.py','function':'moments','lines':[776,801],
 'mechanism':'The installed Torch adapter computes variance by subtracting the squared mean from mean squared values; this is susceptible to cancellation.'}
r['analysis']='Divergence first appears in training BatchNorm with identical pooled inputs and synchronized starting state. Independent centered float64 statistics closely match TensorFlow, while float32 E[x^2]-E[x]^2 closely matches Torch. Dense layers amplify the BatchNorm difference into output/loss candidates. This is a numerical-stability candidate with a concrete variance-cancellation explanation, not a demonstrated harness state mismatch.'
(out/'case000133_review.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print('133',r['batchnorm']['backend_reference_errors'])

c,r=basic('000155');r['first_material_divergent_layer']='02_average_pooling2D';r['mechanism_group']='keras_torch_average_pool_asymmetric_same_replicated_padding';r['pool']={'layout':'NHWC','input_shape':[10,6,6,3],'pool':[8,8],'stride':[3,3],'SAME_padding':[[2,3],[2,3]]};r['references']={}
for bk in ['tensorflow','torch']:
 x=load(c,'layer_outputs',bk,'01_batch_normalization').astype('float64');observed=load(c,'layer_outputs',bk,'02_average_pooling2D')
 edge=np.pad(x,[(0,0),(2,3),(2,3),(0,0)],mode='edge');ref_valid=np.empty((10,2,2,3));ref_edge=np.empty_like(ref_valid)
 for h in range(2):
  for w in range(2):
   top,left=h*3-2,w*3-2;ref_valid[:,h,w,:]=x[:,max(0,top):min(6,top+8),max(0,left):min(6,left+8),:].mean(axis=(1,2))
   ref_edge[:,h,w,:]=edge[:,h*3:h*3+8,w*3:w*3+8,:].mean(axis=(1,2))
 r['references'][bk]={'max_abs_error_valid_elements_average':float(np.abs(observed-ref_valid).max()),'max_abs_error_replicated_edge_average':float(np.abs(observed-ref_edge).max())}
r['analysis']='There is only a tiny upstream BatchNorm difference. At AveragePooling2D, TensorFlow matches valid-element averaging and Torch matches replicated-edge averaging under asymmetric SAME padding, repeating the code-path mechanism of case53. The large output/loss discrepancy is not explained by ordinary float32 rounding or a channel-layout mismatch. Treat as a Keras Torch adapter padding-semantics candidate; shared mechanism is evidence for triage, not automatic confirmation or deduplication.'
r['source_reference']='See case000053_review.json for installed-source hash, line snippets and official Keras v3.10.0 tag link.'
(out/'case000155_review.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print('155',r['references'])
