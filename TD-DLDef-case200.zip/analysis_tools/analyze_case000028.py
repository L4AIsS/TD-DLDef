"""Case-specific saved-tensor diagnostic, not a replacement correctness oracle."""
import argparse,json,numpy as np
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--cases-root',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
root=(args.cases_root/'000028').resolve();name='02_separable_conv2D'
a=np.load(root/'layer_outputs/tensorflow'/(name+'.npy'),allow_pickle=False);b=np.load(root/'layer_outputs/torch'/(name+'.npy'),allow_pickle=False)
ga=np.load(root/'layer_gradients/tensorflow'/(name+'.npy'),allow_pickle=False);gb=np.load(root/'layer_gradients/torch'/(name+'.npy'),allow_pickle=False)
with np.load(root/'models/initial_weights/03_conv2D_transpose.npz',allow_pickle=False) as w:
 z=np.einsum('nhwc,oc->nhwo',a.astype('float64'),w['arr_0'][0,0].astype('float64'))+w['arr_1'].astype('float64')
x=np.load(root/'layer_outputs/tensorflow/01_dense.npy',allow_pickle=False).astype('float64')
with np.load(root/'models/initial_weights/02_separable_conv2D.npz',allow_pickle=False) as w:dw,pw,bias=[w['arr_%d'%i].astype('float64') for i in range(3)]
xp=np.pad(x,[(0,0),(1,1),(1,1),(0,0)]);mid=np.zeros((10,6,6,8))
for h in range(6):
 for col in range(6):mid[:,h,col,:]=np.einsum('nxyc,xycm->ncm',xp[:,h:h+3:2,col:col+3:2,:],dw).reshape(10,8)
logits=mid@pw[0,0]+bias;margin=np.abs(logits[...,0]-logits[...,1])
info={'case_path':str(root),'case_relative_path':'backend_200_cases/keras3.10/full/000028',
 'mechanism_group':'saturated_softmax_normalization_residual_amplified',
 'evidence_relative_paths':['backend_200_cases/keras3.10/full/000028/case_manifest.json','backend_200_cases/keras3.10/full/000028/models/model.json','backend_200_cases/keras3.10/full/000028/logs/comparison.json'],
 'backend':'tensorflow_torch','stage':'comparison',
 'classification':'retain_unconfirmed_numerical_candidate','raw_status_unchanged':True,
 'softmax':{'tensorflow_unique_values':np.unique(a).tolist(),'torch_unique_values':np.unique(b).tolist(),
 'tensorflow_max_normalization_error':float(np.abs(a.sum(axis=-1)-1).max()),
 'torch_max_normalization_error':float(np.abs(b.sum(axis=-1)-1).max()),
 'reconstructed_float64_logit_margin_min':float(margin.min()),'reconstructed_float64_logit_margin_max':float(margin.max()),
 'reconstructed_logits_all_finite':bool(np.isfinite(logits).all())},
 'selu_minimum_absolute_preactivation':float(np.abs(z).min()),'local_softmax_vjp':{},
 'analysis':'The saved upstream gradients multiplied by the one-ULP softmax normalization residual can produce nonzero local TensorFlow gradients while Torch returns zero on saturated one-hot probabilities. Large convolution/dense weights amplify the residual. This explains a numerical route for the mismatch, not a harness objective mismatch or confirmed framework defect.',
 'harness_checks':'saved tensors are finite with matching shape/dtype; equivalence fingerprints match; same-coordinate bounds and float32 gradient precision verified; SELU preactivation is far from zero, softmax is smooth; no supported reason to delete this candidate',
 'limitations':'Read-only algebra on saved tensors and weights; no new backend execution or independent replay; high-precision reconstruction is diagnostic only'}
for bk,p,g in [('tensorflow',a,ga),('torch',b,gb)]:
 dz=p*(g-(g*p).sum(axis=-1,keepdims=True));info['local_softmax_vjp'][bk]={'max_abs':float(np.abs(dz).max()),'nonzero_elements':int(np.count_nonzero(dz))}
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
