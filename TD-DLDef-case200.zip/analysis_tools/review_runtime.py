"""Read one snapshot of completed run200 manifests; never alter execution evidence."""
import argparse, collections, datetime, hashlib, json
from pathlib import Path
import numpy as np

parser=argparse.ArgumentParser()
parser.add_argument('--cases-root',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();base=args.cases_root.resolve()
expected='821356fad7163322331227bd2dc4786f2cfb9cf1135607794529a15b27308035'
review={'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'read-only snapshot of completed case_manifest.json files; no reruns or mutations',
 'expected_frozen_source_sha256':expected,
 'protocol_review':[
  'Workers verify actual backend identity, shared weights/state, actual inputs/targets and normalized architecture/configuration equivalence.',
  'One training-mode forward/backward pass; no optimizer update. Missing artifacts and unknown worker exceptions do not prove framework defects.',
  'Same-coordinate absolute+dtype-aware bounds are required; gradient tolerance accounts for the lowest observed forward precision.',
  'Top-level stochastic/stateful execution is excluded by the frozen worker. Final audit found nested stochastic guard omissions in cases160/174; those comparisons are explicitly excluded without altering raw evidence.',
  'Nonfinite output counts require an equivalent finite peer; auxiliary loss/gradient nonfinite values remain observations.',
  'Generated tests can still violate kernel constraints. Their invalid_test statuses describe unusable tests and are not framework failures.'
 ],'cases':[],'pending_directories':[],'new_proven_harness_failures':[]}
status_counts=collections.Counter();candidate_cases=[]
for case in sorted(p for p in base.iterdir() if p.is_dir()):
 manifest=case/'case_manifest.json'
 if not manifest.is_file():review['pending_directories'].append(case.name);continue
 try:doc=json.loads(manifest.read_text(encoding='utf-8'))
 except (OSError,ValueError):review['pending_directories'].append(case.name);continue
 meta=doc['metadata'];record={'case':case.name,'case_path':str(case.resolve()),'case_relative_path':case.relative_to(base.parents[2]).as_posix(),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),
  'source_sha256':meta.get('source_sha256'),'source_matches':meta.get('source_sha256')==expected,
  'input_dtype':meta.get('input_dtype'),'stages':[],'comparisons':[], 'nonfinite':[]}
 for stage,key in [('generation','generation_status'),('training','status')]:
  for backend,state in meta.get(key,{}).items():
   status=state.get('status','unknown');status_counts[stage+':'+status]+=1
   item={'stage':stage,'backend':backend,'status':status,'message':state.get('message'),
         'exception_type':state.get('exception_type'),'interpretation':None}
   message=state.get('message','')
   if status=='ok':item['interpretation']='worker_completed; compare only after equivalence gates'
   elif status=='invalid_test':
    if 'integer convolution input' in message:item['interpretation']='invalid generated dtype/kernel combination; excluded correctly, not a framework defect'
    elif 'missing shared initial weight' in message or 'weights/state differ' in message:
     item['interpretation']='harness artifact/equivalence failure, not a framework defect'
     review['new_proven_harness_failures'].append({'case':case.name,**item})
    else:item['interpretation']='explicit test-domain or contract rejection; inspect message, not a framework defect'
   elif status=='unsupported':item['interpretation']='backend/device or adapter configuration unsupported; excluded from differential claims'
   elif status=='unknown':
    integer_tensor=('dtype=int' in message or 'dtype=uint' in message)
    if ('only supports the NHWC tensor format on the CPU' in message or 'Depthwise convolution on CPU is only supported for NHWC format' in message):
     item['interpretation']='reviewed unsupported TensorFlow CPU NCHW kernel; backend/device limitation, not a framework defect'
     item['triage_classification']='unsupported_backend_device'
     item['review_rule']='explicit_cpu_nhwc_only_error'
    elif integer_tensor and (('not in the list of allowed values' in message and "attr 'T'" in message) or 'not implemented for' in message or (('expected scalar type ' in message) and ('but found Float' in message)) or 'Incompatible type conversion requested to type int' in message or 'Incompatible type conversion requested to type uint' in message or '`x.dtype` must be a floating point tensor' in message or "result type Float can't be cast to the desired output type Long" in message):
     item['interpretation']='reviewed integer input/operator kernel dtype contract violation; invalid test or unsupported dtype combination, not a framework defect'
     item['triage_classification']='invalid_test_dtype_operator'
     item['review_rule']='explicit_integer_dtype_kernel_rejection'
     item['harness_limitation']='preflight convolution checks do not cover every operator or actual runtime integer dtype; raw unknown status remains unchanged and correctly avoids a false defect count'
    else:item['interpretation']='untriaged exception; traceback required before assigning a cause; not a proven crash'
   elif status=='tool_error':item['interpretation']='pipeline/artifact failure; not a framework defect'
   elif status=='environment_error':item['interpretation']='runtime/dependency/identity problem; not a framework defect'
   elif status=='timeout':item['interpretation']='resource/time budget observation; not a proven framework crash'
   else:item['interpretation']='observation requiring separate triage; not automatically a confirmed defect'
   if status!='ok':item['traceback']=state.get('traceback')
   detail_path=Path(__file__).parent/('case'+case.name+'_review.json')
   if detail_path.is_file():
    detail=json.loads(detail_path.read_text(encoding='utf-8'))
    if detail.get('backend')==backend and detail.get('stage')==stage:
     item['triage_classification']=detail.get('classification',item.get('triage_classification',status))
     item['interpretation']=detail.get('analysis',item['interpretation'])
     item['review_rule']='case_specific_manual_contract_and_source_review'
     item['detail_relative_path']='analysis_tools/'+detail_path.name
   record['stages'].append(item)
   evidence=state.get('numerical_evidence',{})
   if any(evidence.get('affected_tensors',{}).values()) or any(evidence.get('auxiliary_nonfinite',{}).values()):
    record['nonfinite'].append({'backend':backend,'evidence':evidence,
      'interpretation':'candidate only with eligible equivalent finite peer; otherwise nonfinite observation'})
 for pair,result in meta.get('comparisons',{}).items():
  compared={'pair':pair,'classification':result.get('classification'),
   'inconsistent':result.get('inconsistent'), 'reason':result.get('reason'),
   'raw_output':result.get('raw_output'),'raw_loss':result.get('raw_loss'),'raw_loss_grads':result.get('raw_loss_grads'),
   'gradient_exclusions':result.get('gradient_exclusions',[]),'gradient_precision_basis':result.get('gradient_precision_basis'),
   'candidate_tensor_checks':[]}
  if result.get('inconsistent'):
   candidate_cases.append(case.name)
   a,b='tensorflow','torch';states=meta.get('status',{})
   compared['equivalence_matches']=bool(states.get(a,{}).get('equivalence')) and states[a]['equivalence']==states.get(b,{}).get('equivalence')
   for group,folder in [('outputs','layer_outputs'),('loss_gradients','loss_gradients'),('layer_gradients','layer_gradients')]:
    for name,metric in result.get('metrics',{}).get(group,{}).items():
     if not metric.get('candidate'):continue
     tensors=[np.load(case/folder/backend/(name+'.npy'),allow_pickle=False) for backend in (a,b)]
     x,y=[t.astype('float64') for t in tensors];diff=np.abs(x-y);scale=np.maximum(np.abs(x),np.abs(y))
     valid=np.isfinite(x).all() and np.isfinite(y).all() and tensors[0].shape==tensors[1].shape and tensors[0].dtype==tensors[1].dtype
     joint=(diff>meta.get('threshold',.15))&(diff>metric['atol']+metric['rtol']*scale)
     check={'group':group,'layer':name,'storage_dtype':str(tensors[0].dtype),'precision_dtype':metric.get('precision_dtype'),
            'shape':list(x.shape),'finite_matching_contract':bool(valid),'joint_exceed_count':int(joint.sum()),
            'max_abs':float(diff.max()),'max_joint_abs':float(diff[joint].max()) if joint.any() else None}
     compared['candidate_tensor_checks'].append(check)
     if not valid or not joint.any():review['new_proven_harness_failures'].append({'case':case.name,'problem':'saved candidate metric fails independent finite/same-coordinate gate','metric':check})
   compared['interpretation']='unconfirmed numerical discrepancy; retained for independent replay/triage, not a proven framework bug'
  elif result.get('classification')=='consistent':compared['interpretation']='no eligible tensor exceeded both bounds; excluded gradient metrics are not evidence of backward correctness'
  else:compared['interpretation']='comparison excluded; no differential correctness conclusion'
  detail_path=Path(__file__).parent/('case'+case.name+'_review.json')
  if detail_path.is_file():
   detail=json.loads(detail_path.read_text(encoding='utf-8'))
   if detail.get('requires_exclusion_from_audited_comparisons'):
    compared['review_classification']=detail['classification']
    compared['review_excluded']=True
    compared['interpretation']=detail['analysis']
    review['new_proven_harness_failures'].append({'case':case.name,'backend':pair,'stage':'comparison',
      'mechanism_group':detail.get('mechanism_group'),'problem':detail['classification'],
      'original_classification':compared['classification'],'detail_relative_path':'analysis_tools/'+detail_path.name})
  record['comparisons'].append(compared)
 review['cases'].append(record)
review['manual_review_mappings']=[]
for case_record in review['cases']:
 for item in case_record['stages']:
  if item['status']=='ok':continue
  mapping={'case':case_record['case'],'case_path':case_record['case_path'],
   'case_relative_path':case_record['case_relative_path'],
   'backend':item['backend'],'stage':item['stage'],'raw_status':item['status'],
   'review_classification':item.get('triage_classification',item['status']),
   'interpretation':item['interpretation'],'message_evidence':item.get('message'),
   'rule':item.get('review_rule','explicit_raw_status_and_message'),
   'evidence_path':str(Path(case_record['case_path'])/'logs'/(item['stage']+'_'+item['backend']+'.json')),
   'evidence_relative_path':case_record['case_relative_path']+'/logs/'+item['stage']+'_'+item['backend']+'.json',
   'detail_relative_path':item.get('detail_relative_path'),
   'counts_as_confirmed_framework_defect':False,'original_evidence_changed':False}
  mapping['mapping_id']=case_record['case_path']+'|'+item['backend']+'|'+item['stage']
  mapping['portable_mapping_id']=case_record['case_relative_path']+'|'+item['backend']+'|'+item['stage']
  review['manual_review_mappings'].append(mapping)
 for comparison in case_record['comparisons']:
  if not comparison.get('inconsistent') and not comparison.get('review_excluded'):continue
  extra={}
  evidence_file=Path(__file__).parent/('case'+case_record['case']+'_review.json')
  if evidence_file.is_file():extra=json.loads(evidence_file.read_text(encoding='utf-8'))
  review['manual_review_mappings'].append({'mapping_id':case_record['case_path']+'|'+comparison['pair']+'|comparison',
   'case':case_record['case'],'case_path':case_record['case_path'],'case_relative_path':case_record['case_relative_path'],
   'portable_mapping_id':case_record['case_relative_path']+'|'+comparison['pair']+'|comparison',
   'backend':comparison['pair'],'stage':'comparison',
   'raw_status':comparison.get('classification'),
   'review_classification':comparison.get('review_classification','retain_unconfirmed_numerical_candidate'),
   'requires_exclusion_from_audited_comparisons':bool(comparison.get('review_excluded')),
   'requires_exclusion_from_audited_candidates':bool(comparison.get('review_excluded') and comparison.get('inconsistent')),
   'mechanism_group':extra.get('mechanism_group'),
   'counts_as_confirmed_framework_defect':False,'original_evidence_changed':False,
   'interpretation':extra.get('analysis',comparison['interpretation']),
   'independent_checks':comparison.get('candidate_tensor_checks'),
   'detail_file':str(evidence_file.resolve()) if evidence_file.is_file() else None,
   'detail_relative_path':'analysis_tools/'+evidence_file.name if evidence_file.is_file() else None,
   'evidence_relative_path':case_record['case_relative_path']+'/logs/comparison.json'})
review['summary']={'completed_cases_reviewed':len(review['cases']),'pending_directories':len(review['pending_directories']),
 'status_counts':dict(status_counts),'candidate_cases':sorted(set(candidate_cases)),
 'audited_candidate_cases':sorted({m['case'] for m in review['manual_review_mappings'] if m['stage']=='comparison' and m['raw_status']=='candidate' and not m.get('requires_exclusion_from_audited_candidates')}),
 'review_excluded_comparison_cases':sorted({m['case'] for m in review['manual_review_mappings'] if m.get('requires_exclusion_from_audited_comparisons')}),
 'raw_comparable_case_count':sum(any(c.get('classification') in ('consistent','candidate') for c in r['comparisons']) for r in review['cases']),
 'audited_comparable_case_count':sum(any(c.get('classification') in ('consistent','candidate') and not c.get('review_excluded') for c in r['comparisons']) for r in review['cases']),
 'source_mismatches':[r['case'] for r in review['cases'] if not r['source_matches']],
 'new_proven_harness_failure_count':len(review['new_proven_harness_failures']),
 'unknown_triage_counts':dict(collections.Counter(m['review_classification'] for m in review['manual_review_mappings'] if m['raw_status']=='unknown')),
 'untriaged_unknown_keys':[m['portable_mapping_id'] for m in review['manual_review_mappings'] if m['raw_status']=='unknown' and m['review_classification']=='unknown'],
 'conclusion':'snapshot only; ordinary exceptions, invalid tests and unsupported configurations are not framework bugs'}
mapping_path=args.output.with_name('runtime_review_mappings.json')
mapping_path.write_text(json.dumps(review['manual_review_mappings'],ensure_ascii=False,indent=2),encoding='utf-8')
args.output.parent.mkdir(parents=True,exist_ok=True);tmp=args.output.with_suffix('.tmp');tmp.write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(args.output)
print(json.dumps(review['summary'],ensure_ascii=False))
