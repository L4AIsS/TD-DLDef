import argparse
import sys
import json
import numpy as np
from pathlib import Path
from typing import Tuple
import warnings

from utils.utils import switch_backend, get_layer_func
from utils.mutation import MutationConfig, NeuronMutator
from utils.runtime import exception_record, write_json, InvalidTest
from utils.weight_transfer import restore_source_weights, save_weight_manifest
from utils.input_adaptation import adapt_inbound_tensors

warnings.filterwarnings("ignore")


def __parse_mutation_flag(mutation: str):
    """One worker builds one baseline or one single-neuron-strategy mutant."""
    if mutation in (None, '', 'none'):
        return []
    if mutation not in ('nf', 'ws', 'wr'):
        raise ValueError('choose one of none/nf/ws/wr; run three independent variants for all operators')
    return [mutation]


def __generate_layer(layer_info: dict, weight_range: Tuple[float], input_dtype=None):
    # 解析层信息
    from copy import deepcopy
    layer_type, layer_args, pre_layers, ouput_shape = tuple(map(layer_info.get, ['type', 'args', 'pre_layers', 'output_shape']))
    layer_args = deepcopy(layer_args)
    layer = get_layer_func(layer_type)

    # 解析参数
    for k, v in layer_args.items():
        if k == 'layer':
            layer_args[k], _, _ = __generate_layer(v, weight_range, input_dtype)  # 嵌套层需要递归生成
        elif k[-12:] == '_initializer':
            a, b = weight_range
            if k == 'moving_variance_initializer':
                layer_args[k] = 'ones'
            elif k == 'moving_mean_initializer':
                layer_args[k] = 'zeros'
            else:
                layer_args[k] = keras.initializers.random_uniform(a, b)  # initializer

    # Input Type Mutation (IT): 指定输入层的数据类型
    if layer_type == 'input_object' and input_dtype is not None:
        if layer_args.get('dtype') is None:
            layer_args['dtype'] = input_dtype

    return layer(**layer_args), pre_layers, ouput_shape


def apply_neuron_mutation(model, neuron_mutator: NeuronMutator):
    """Apply NF/WS/WR and return auditable layer-level provenance.

    This function is deliberately public so the end-to-end wiring can be unit
    tested without invoking a backend subprocess.
    """
    summary = {
        'enabled_operators': sorted(neuron_mutator.config.enabled) if neuron_mutator else [],
        'layers': [],
        'mutated_layers': 0,
        'mutated_weight_tensors': 0,
        'changed_values': 0,
        'skipped_layers': [],
    }
    if neuron_mutator is None:
        return summary
    operators = set(neuron_mutator.config.enabled).intersection({'nf', 'ws', 'wr'})
    if len(operators) > 1:
        raise ValueError('each mutant must use one neuron operator, independently of the original')
    neuron_mutator.begin_model()
    for layer in model.layers:
        try:
            weights = layer.get_weights()
            if not weights:
                summary['skipped_layers'].append({'layer': layer.name, 'reason': 'no_weights'})
                continue
            variables = getattr(layer, 'weights', [])
            indices = [i for i in range(len(weights)) if not variables or bool(variables[i].trainable)]
            if not indices:
                summary['skipped_layers'].append({'layer': layer.name, 'reason': 'no_trainable_weights'})
                continue
            changed, report = neuron_mutator.mutate_weights_with_report([weights[i] for i in indices])
            mutated = [w.copy() for w in weights]
            for i, value in zip(indices, changed):
                mutated[i] = value
            import hashlib
            report['checksums'] = [hashlib.sha256(np.ascontiguousarray(w).view(np.uint8)).hexdigest() for w in mutated]
            report['trainable_indices'] = indices
            report['preserved_state_indices'] = [i for i in range(len(weights)) if i not in indices]
            if [w.shape for w in mutated] != [w.shape for w in weights]:
                raise ValueError('neuron mutation changed a weight shape')
            layer.set_weights(mutated)
            layer_record = {'layer': layer.name, **report}
            summary['layers'].append(layer_record)
            if report['changed_values']:
                summary['mutated_layers'] += 1
            summary['mutated_weight_tensors'] += report['changed_tensors']
            summary['changed_values'] += report['changed_values']
        except Exception as e:
            raise InvalidTest('neuron mutation failed for layer %s: %s' % (layer.name, e)) from e
    return summary


def __generate_model(json_path: str, weight_range: Tuple[float], input_dtype=None):
    # 加载模型结构数据
    with open(json_path, 'r') as f:
        model_info = json.load(f)

    input_id_list, output_id_list = model_info['input_id_list'], model_info['output_id_list']

    input_list, output_list, layer_dict = [], [], {}
    for layer_id, layer_info in model_info['model_structure'].items():  # 按拓扑排序遍历
        layer_id = int(layer_id)
        # 生成层
        layer, inbound_layers_idx, ouput_shape = __generate_layer(layer_info, weight_range, input_dtype)

        # 层拼接
        if layer_id in input_id_list:
            layer_dict[layer_id] = layer  # input_object
            input_list.append(layer_dict[layer_id])

        else:
            inbound_layers = [layer_dict[i] for i in inbound_layers_idx]
            import keras
            inbound_layers = adapt_inbound_tensors(layer_info, inbound_layers, keras.ops)
            layer_dict[layer_id] = layer(inbound_layers[0] if len(inbound_layers) == 1 else inbound_layers)  # 对layers进行连接

        if layer_id in output_id_list:
            output_list.append(layer_dict[layer_id])

        # 检查形状 keras verison
        import keras
        if keras.__version__ == "2.15.0":
            from keras import backend as K
            if K.int_shape(layer_dict[layer_id]) != tuple(ouput_shape):
                raise Exception(f"[Debug] layer_id: {layer_id} expected shape: {tuple(ouput_shape)}  actual shape: {K.int_shape(layer_dict[layer_id])}")

        else:
            from keras import ops
            if ops.shape(layer_dict[layer_id]) != tuple(ouput_shape):
                raise Exception(f"[Debug] layer_id: {layer_id} expected shape: {tuple(ouput_shape)}  actual shape: {ops.shape(layer_dict[layer_id])}")


    return keras.Model(inputs=[layer_dict[int(i)] for i in input_id_list],
                       outputs=[layer_dict[int(i)] for i in output_id_list])


def __save_weights(model, weights_dir, bk):
    if bk == 'theano':
        keras.utils.convert_all_kernels_in_model(model)
    for layer in model.layers:
        save_path = Path(weights_dir) / f'{layer.name}.npz'
        np.savez(save_path, *layer.get_weights())
    save_weight_manifest(model, weights_dir)


if __name__ == "__main__":
    # 获取参数
    parse = argparse.ArgumentParser()
    parse.add_argument("--backend", type=str)
    parse.add_argument("--json_path", type=str)
    parse.add_argument("--weight_minv", type=float)
    parse.add_argument("--weight_maxv", type=float)
    parse.add_argument("--output_dir", type=str)
    parse.add_argument("--mutation", type=str, default='none', choices=['none', 'nf', 'ws', 'wr'])
    parse.add_argument('--source_weight_dir', help='completed original weights, restored before mutation')
    parse.add_argument("--input_dtype", type=str, default=None,
                       help="input dtype: float16/32/64, int8/16/32/64, or uint8")
    parse.add_argument("--seed", type=int, default=None, help="isolated neuron-mutation RNG seed")
    parse.add_argument('--status_path')
    flags = parse.parse_args(sys.argv[1:])
    flags.status_path = flags.status_path or str(Path(flags.output_dir).parent / 'logs' / ('generation_%s.json' % flags.backend))
    Path(flags.output_dir).mkdir(parents=True, exist_ok=True)

    try:
        identity = switch_backend(flags.backend)
        import keras
        keras.utils.set_random_seed(flags.seed or 0)

        # 神经元突变配置
        neuron_mutator = None
        ops = __parse_mutation_flag(flags.mutation)
        if ops and not flags.source_weight_dir:
            raise InvalidTest('a neuron mutant requires completed original weights')
        if ops:
            from utils.mutation import MutationConfig as _MC
            neuron_mutator = NeuronMutator(_MC(enabled=ops, seed=flags.seed))

        model = __generate_model(flags.json_path, (flags.weight_minv, flags.weight_maxv),
                                 input_dtype=flags.input_dtype)

        inheritance = restore_source_weights(model, flags.source_weight_dir) if flags.source_weight_dir else None

        # P0 fix: neuron mutation is part of the actual end-to-end path.  The
        # first backend mutates once; all remaining backends load the exact same
        # saved tensors from initial_weights.
        mutation_provenance = apply_neuron_mutation(model, neuron_mutator)
        mutation_provenance['backend'] = flags.backend
        mutation_provenance['seed'] = flags.seed
        mutation_provenance['weight_inheritance'] = inheritance
        print('[NeuronMutation] mutated_layers={mutated_layers} '
              'mutated_weight_tensors={mutated_weight_tensors} '
              'changed_values={changed_values}'.format(**mutation_provenance))

        # 保存模型
        model_path = Path(flags.output_dir) / f'{flags.backend}.keras'
        model.save(str(model_path), include_optimizer=False)
        generation_config_path = Path(flags.output_dir) / 'generation_config.json'
        generation_config = json.loads(generation_config_path.read_text(encoding='utf-8')) if generation_config_path.exists() else {}
        generation_config.update(input_dtype=flags.input_dtype, seed=flags.seed or 0,
                                 weight_range=[flags.weight_minv, flags.weight_maxv], mutation=flags.mutation)
        write_json(generation_config_path, generation_config)

        # # 保存图片
        # pic_path = Path(flags.output_dir) / f'{flags.backend}.png'
        # keras.utils.plot_model(model, str(pic_path), show_shapes=True)

        # 保存模型权重
        weights_dir = Path(flags.output_dir) / 'initial_weights'
        weights_dir.mkdir(parents=True, exist_ok=True)
        __save_weights(model, weights_dir, flags.backend)

        provenance_path = Path(flags.output_dir) / 'mutation_provenance.json'
        with provenance_path.open('w', encoding='utf-8') as f:
            json.dump(mutation_provenance, f, ensure_ascii=False, indent=2)

        write_json(flags.status_path, {'status': 'ok', 'stage': 'generation', **identity,
                   'model_path': str(model_path), 'input_dtype': flags.input_dtype})

    except Exception as exc:
        write_json(flags.status_path, exception_record(exc, 'generation', flags.backend))
        import traceback

        # 创建log文件
        log_dir = Path(flags.output_dir).parent / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)

        with (log_dir / 'generation.log').open(mode='a', encoding='utf-8') as f:
            f.write(f"[ERROR] Fail when generating model with {flags.backend}\n")
            traceback.print_exc(file=f)
            f.write("\n\n")

        traceback.print_exc(file=sys.stderr)
        sys.exit(2)
