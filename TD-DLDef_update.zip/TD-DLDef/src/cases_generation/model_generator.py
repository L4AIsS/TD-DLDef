from typing import List, Optional
from pathlib import Path
import json
import sys

from utils.utils import CmdProcess
from utils.runtime import collect_process_status, write_json


class ModelGenerator(object):
    '''模型生成器
    '''

    def __init__(self, weight_val_range: tuple, backends: List[str], db_manager, selector, timeout,
                 python_path: Optional[str] = None, coverage_tracker=None,
                 input_dtype='float32', neuron_mutator=None, defect_reporter=None,
                 mutation_seed=0):
        super().__init__()
        self.__weight_val_range = weight_val_range
        self.__backends = backends
        self.__db_manager = db_manager
        self.__selector = selector
        self.__timeout = timeout
        # 可执行 python 路径: 默认使用当前解释器 (跨平台), 可指定 conda 环境
        self.__python_path = python_path if python_path is not None else sys.executable
        self.__coverage_tracker = coverage_tracker
        self.__input_dtype = input_dtype
        self.__neuron_mutator = neuron_mutator
        self.__defect_reporter = defect_reporter   # 缺陷记录器 (生成阶段 crash)
        self.__last_dtype = input_dtype            # 最近一次生成使用的输入 dtype
        self.__mutation_seed = int(mutation_seed)

    def generate(self, json_path: str, exp_dir: str, model_id: int,
                 initial_weight_dir: Optional[str] = None, input_dtype: Optional[str] = None,
                 neuron_operator: Optional[str] = None, source_weight_dir: Optional[str] = None,
                 generation_seed: Optional[int] = None):
        """Build a baseline, or one independent mutant of saved baseline weights.

        ``initial_weight_dir`` restores already-final weights without mutation;
        ``source_weight_dir`` adapts original weights before one neuron operator.
        No constructor setting can implicitly compose NF, WS and WR.
        """
        if neuron_operator not in (None, 'nf', 'ws', 'wr'):
            raise ValueError('one model must select exactly one of nf/ws/wr')
        if initial_weight_dir is not None and (source_weight_dir is not None or neuron_operator is not None):
            raise ValueError('final weight replay cannot be combined with source mutation')
        if neuron_operator is not None and source_weight_dir is None:
            raise ValueError('neuron mutation requires the completed original weight directory')
        mutation_flag = neuron_operator or 'none'
        seed = self.__mutation_seed + int(model_id) if generation_seed is None else int(generation_seed)
        model_dir = Path(exp_dir) / 'models'
        source_reference = None
        if source_weight_dir is not None:
            import shutil
            original = Path(source_weight_dir).resolve()
            if not original.is_dir():
                raise ValueError('completed original weights are missing: %s' % original)
            snapshot = model_dir / 'source_original' / 'initial_weights'
            if original != snapshot.resolve():
                shutil.copytree(original, snapshot, dirs_exist_ok=True)
                manifest = original.parent / 'weights_manifest.json'
                if manifest.is_file():
                    shutil.copy2(manifest, snapshot.parent / manifest.name)
            source_weight_dir = str(snapshot.resolve())
            source_reference = 'models/source_original/initial_weights'

        # 每次生成可指定输入 dtype (IT 突变); 未指定时用构造时默认值
        dtype = input_dtype if input_dtype is not None else self.__input_dtype
        self.__last_dtype = dtype

        model_dir.mkdir(parents=True, exist_ok=True)
        write_json(model_dir / 'generation_config.json', {
            'weight_range': list(self.__weight_val_range),
            'mutation': mutation_flag, 'input_dtype': dtype or 'float32',
            'source_weight_dir': source_reference,
            'seed': seed, 'backends': list(self.__backends)})
        log_dir = Path(exp_dir) / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)
        fail_backends, first_bk = [], None
        self.last_status = {}

        def execute(bk, module, extra):
            manifest = log_dir / ('generation_%s.json' % bk)
            manifest.unlink(missing_ok=True)
            (model_dir / (bk + '.keras')).unlink(missing_ok=True)
            argv = [self.__python_path, '-m', module, '--backend', bk,
                    '--json_path', str(json_path), '--output_dir', str(model_dir),
                    '--status_path', str(manifest), *extra]
            process = CmdProcess(argv, log_prefix=log_dir / ('generation_%s' % bk))
            process.run(self.__timeout)
            record = collect_process_status(process, manifest, bk, 'generation')
            if record['status'] == 'ok' and not (model_dir / (bk + '.keras')).is_file():
                record.update(status='tool_error', message='successful worker did not create model artifact')
                write_json(manifest, record)
            self.last_status[bk] = record
            return record['status'] == 'ok'

        if initial_weight_dir is None:
            for bk in self.__backends:
                if execute(bk, 'src.cases_generation.generate_one',
                           ['--weight_minv', str(self.__weight_val_range[0]),
                            '--weight_maxv', str(self.__weight_val_range[1]),
                            '--mutation', mutation_flag,
                            '--input_dtype', dtype or 'float32',
                            '--seed', str(seed)] +
                           (['--source_weight_dir', str(source_weight_dir)] if source_weight_dir is not None else [])):
                    first_bk = bk
                    break
                fail_backends.append(bk)
            # Without a successful producer there are no trusted common weights.
        else:
            import shutil
            shutil.copytree(initial_weight_dir, model_dir / 'initial_weights', dirs_exist_ok=True)
        if first_bk is not None or initial_weight_dir is not None:
            for bk in self.__backends:
                if bk != first_bk and bk not in fail_backends:
                    if not execute(bk, 'src.cases_generation.generate_other',
                                   ['--input_dtype', dtype or 'float32']):
                        fail_backends.append(bk)
        else:
            fail_backends = list(self.__backends)

        # 层选择在部分模型生成期间已即时反馈；此处只记录覆盖率。
        if any(bk not in fail_backends for bk in self.__backends):
            self.__record_model(json_path)

        if fail_backends:
            self.__db_manager.update_model_generate_fail_backends(model_id, fail_backends)
            if self.__defect_reporter is not None:
                model_info = json.loads(Path(json_path).read_text(encoding='utf-8'))
                for bk in fail_backends:
                    record = self.last_status.get(bk, {'status': 'unknown'})
                    kind = record['status']
                    self.__defect_reporter.record(
                        model_id, 'crash' if kind == 'candidate_crash' else kind, bk,
                        model_info, stage='generation',
                        detail=record.get('message') or record.get('stderr') or kind,
                        extra={'runtime_status': record, 'classification': kind,
                               'evidence_status': 'candidate' if kind == 'candidate_crash' else 'excluded',
                               'case_dir': str(exp_dir)})

        return [bk for bk in self.__backends if bk not in fail_backends]

    def __record_model(self, json_path):
        with open(json_path, 'r') as f:
            model_info = json.load(f)

        # 覆盖率追踪 (LIC/LPC/LSC 的"已覆盖"部分)
        # 修正: 使用本次生成实际的输入 dtype (IT 突变), 而非构造默认值
        if self.__coverage_tracker is not None:
            self.__coverage_tracker.record_model(model_info, input_dtype=self.__last_dtype)

        # P0: do not perform delayed model-level TS feedback here.  It would
        # duplicate the immediate select -> DIV -> accept/reject updates.


if __name__ == '__main__':
    pass
