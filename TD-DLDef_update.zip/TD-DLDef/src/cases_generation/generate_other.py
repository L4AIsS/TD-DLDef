import argparse
import sys
import json
import numpy as np
from pathlib import Path
import warnings
import hashlib

from utils.utils import switch_backend, get_layer_func
from utils.runtime import exception_record, write_json, InvalidTest
from utils.input_adaptation import adapt_inbound_tensors

warnings.filterwarnings("ignore")


def __generate_layer(layer_info: dict, input_dtype=None):
    # 解析层信息
    layer_type, layer_args, pre_layers, ouput_shape = tuple(map(layer_info.get, ['type', 'args', 'pre_layers', 'output_shape']))
    from copy import deepcopy
    layer_args = deepcopy(layer_args)
    layer = get_layer_func(layer_type)

    # 解析参数
    for k, v in layer_args.items():
        if k == 'layer':
            layer_args[k], _, _ = __generate_layer(v, input_dtype)  # 嵌套层需要递归生成
        elif k[-12:] == '_initializer':
            layer_args[k] = 'zeros'

    if layer_type == 'input_object' and input_dtype is not None:
        if layer_args.get('dtype') is None:
            layer_args['dtype'] = input_dtype
    return layer(**layer_args), pre_layers, ouput_shape


def __generate_model(json_path: str, input_dtype=None):
    # 加载模型结构数据
    with open(json_path, 'r') as f:
        model_info = json.load(f)

    input_id_list, output_id_list = model_info['input_id_list'], model_info['output_id_list']

    input_list, output_list, layer_dict = [], [], {}
    for layer_id, layer_info in model_info['model_structure'].items():  # 按拓扑排序遍历
        layer_id = int(layer_id)
        # 生成层
        layer, inbound_layers_idx, ouput_shape = __generate_layer(layer_info, input_dtype)

        # 层拼接
        if layer_id in input_id_list:
            layer_dict[layer_id] = layer  # input_object
            input_list.append(layer_dict[layer_id])

        else:
            inbound_layers = [layer_dict[i] for i in inbound_layers_idx]
            import keras
            inbound_layers = adapt_inbound_tensors(layer_info, inbound_layers, keras.ops)
            layer_dict[layer_id] = layer(inbound_layers[0] if len(inbound_layers) == 1 else inbound_layers)  # 对layers进行连接

        if layer_id in output_id_list:
            output_list.append(layer_dict[layer_id])

        # 检查形状 keras 2.0
        import keras
        if keras.__version__ == "2.15.0":
            from keras import backend as K
            if K.int_shape(layer_dict[layer_id]) != tuple(ouput_shape):
                raise Exception(f"[Debug] layer_id: {layer_id} expected shape: {tuple(ouput_shape)}  actual shape: {K.int_shape(layer_dict[layer_id])}")
        else:
            from keras import ops
            if ops.shape(layer_dict[layer_id]) != tuple(ouput_shape):
                raise Exception(f"[Debug] layer_id: {layer_id} expected shape: {tuple(ouput_shape)}  actual shape: {ops.shape(layer_dict[layer_id])}")



    return keras.Model(inputs=[layer_dict[int(i)] for i in input_id_list],
                       outputs=[layer_dict[int(i)] for i in output_id_list])


def _checksum(array):
    return hashlib.sha256(np.ascontiguousarray(array).view(np.uint8)).hexdigest()


def __set_weights(model, weights_dir, bk):
    provenance_path = Path(weights_dir).parent / 'mutation_provenance.json'
    expected = {}
    if provenance_path.exists():
        with provenance_path.open('r', encoding='utf-8') as f:
            expected = {item['layer']: item.get('checksums', [])
                        for item in json.load(f).get('layers', [])}
    for layer in model.layers:
        weights_path = Path(weights_dir) / f'{layer.name}.npz'
        with np.load(weights_path, allow_pickle=False) as archive:
            stored = [archive['arr_%d' % i] for i in range(len(archive.files))]
        layer.set_weights(stored)
        actual_weights = layer.get_weights()
        if len(stored) != len(actual_weights) or any(a.shape != b.shape or a.dtype != b.dtype or not np.array_equal(a, b, equal_nan=True)
               for a, b in zip(stored, actual_weights)):
            raise InvalidTest('shared initial weight mismatch: %s' % layer.name)
        if layer.name in expected:
            actual = [_checksum(w) for w in layer.get_weights()]
            if actual != expected[layer.name]:
                raise ValueError('cross-backend weight checksum mismatch: %s' % layer.name)
    if bk == 'theano':
        keras.utils.convert_all_kernels_in_model(model)


if __name__ == "__main__":
    # 获取参数
    parse = argparse.ArgumentParser()
    parse.add_argument("--backend", type=str)
    parse.add_argument("--json_path", type=str)
    parse.add_argument("--output_dir", type=str)
    parse.add_argument('--status_path')
    parse.add_argument('--input_dtype')
    flags = parse.parse_args(sys.argv[1:])
    flags.status_path = flags.status_path or str(Path(flags.output_dir).parent / 'logs' / ('generation_%s.json' % flags.backend))
    Path(flags.output_dir).mkdir(parents=True, exist_ok=True)

    try:
        identity = switch_backend(flags.backend)
        import keras
        config_path = Path(flags.output_dir) / 'generation_config.json'
        config = json.loads(config_path.read_text(encoding='utf-8')) if config_path.exists() else {}
        keras.utils.set_random_seed(config.get('seed', 0))
        dtype = flags.input_dtype or config.get('input_dtype')
        model = __generate_model(flags.json_path, dtype)

        # 设置模型权重
        weights_dir = Path(flags.output_dir) / 'initial_weights'
        __set_weights(model, weights_dir, flags.backend)

        # 保存模型
        model_path = Path(flags.output_dir) / f'{flags.backend}.keras'
        model.save(str(model_path), include_optimizer=False)

        # # 保存图片
        # pic_path = Path(flags.output_dir) / f'{flags.backend}.png'
        # keras.utils.plot_model(model, str(pic_path), show_shapes=True)

        write_json(flags.status_path, {'status': 'ok', 'stage': 'generation', **identity,
                   'model_path': str(model_path), 'input_dtype': dtype})

    except Exception as exc:
        write_json(flags.status_path, exception_record(exc, 'generation', flags.backend))
        import traceback

        # 创建log文件
        log_dir = Path(flags.output_dir).parent / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)

        with (log_dir / 'generation.log').open(mode='a', encoding='utf-8') as f:
            f.write(f"[ERROR] Fail when generating model with {flags.backend}\n")
            traceback.print_exc(file=f)
            f.write("\n\n")

        traceback.print_exc(file=sys.stderr)
        sys.exit(2)
