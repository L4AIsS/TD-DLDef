"""Regression coverage for portable replay and evidence integrity."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from utils.reproducibility import (capture_case, verify_case, replay_configuration,
    compare_replay_evidence, validate_replay_configuration, validate_generation_configuration)
from scripts.reproduce_case import validate_destination, resolve_configuration, replay_generation, main


def model_info():
    return {'model_structure': {'0': {'type': 'input_object', 'args': {'name': '00_input', 'shape': [2]}, 'pre_layers': []}},
            'input_id_list': [0], 'output_id_list': [0]}


CONFIG = {'loss': 'mean_squared_error', 'optimizer': 'sgd', 'seed': 17, 'threshold': .012}
GENERATION = {'weight_range': [-10., 10.], 'mutation': 'none', 'input_dtype': 'int16',
              'seed': 23, 'backends': ['tensorflow', 'torch']}


def create_case(root):
    (root/'models/initial_weights').mkdir(parents=True)
    (root/'dataset').mkdir()
    (root/'models/model.json').write_text(json.dumps(model_info()), encoding='utf-8')
    # These bytes are not framework fixtures. Replay orchestration is mocked;
    # identity/hash and configuration behavior are tested without a DL import.
    for name in ['models/tensorflow.keras', 'models/torch.keras', 'models/initial_weights/00_input.npz',
                 'dataset/inputs.npz', 'dataset/ground_truths.npz']:
        (root/name).write_bytes(b'fixture')
    return capture_case(root, metadata=dict(CONFIG, input_dtype='int16'))


class ReplayAuditTests(unittest.TestCase):
    def test_rejects_recursive_destination_before_copy(self):
        with tempfile.TemporaryDirectory() as temp:
            case = Path(temp)/'case'
            case.mkdir()
            for out in (case, case/'models'/'replay', case/'child'):
                with self.assertRaises(ValueError):
                    validate_destination(case, out)
            self.assertEqual(validate_destination(case, Path(temp)/'outside'), Path(temp)/'outside')

    def test_missing_settings_do_not_use_invented_defaults(self):
        with self.assertRaisesRegex(ValueError, 'metadata missing'):
            resolve_configuration({'metadata': {'loss': 'mean_squared_error'}})
        for bad in (float('nan'), float('inf'), -1):
            with self.assertRaises(ValueError):
                validate_replay_configuration(dict(CONFIG, threshold=bad))

    def test_saved_threshold_and_explicit_override(self):
        config, changes = resolve_configuration({'metadata': CONFIG})
        self.assertEqual(config, CONFIG)
        self.assertEqual(changes, {})
        config, changes = resolve_configuration({'metadata': CONFIG}, .25)
        self.assertEqual(config['threshold'], .25)
        self.assertEqual(changes['threshold']['original'], .012)

    def test_worker_seed_wins_over_generation_metadata(self):
        actual = {'tensorflow': {'config': {'seed': 0, 'loss': 'huber', 'optimizer': {'class_name': 'SGD'}}}}
        config = replay_configuration(dict(CONFIG), actual)
        self.assertEqual(config['values']['seed'], 0)
        self.assertEqual(config['values']['loss'], 'huber')
        self.assertEqual(config['sources']['seed'], 'verified_worker_config')

    def test_rendered_source_carries_input_dtype_and_is_hashed(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            manifest = create_case(root)
            self.assertTrue(manifest['replay_ready'])
            self.assertIn("dtype='int16'", (root/'model_source.py').read_text(encoding='utf8'))
            self.assertIn('model_source.py', manifest['artifacts'])
            self.assertIn('reproduce.py', manifest['artifacts'])
            self.assertEqual(len(manifest['source_sha256']), 64)
            verify_case(root)
            (root/'model_source.py').write_text('tampered', encoding='utf8')
            with self.assertRaisesRegex(ValueError, 'model_source.py'):
                verify_case(root)

    def test_manifest_cannot_reference_parent_files(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)/'case'
            root.mkdir()
            manifest = create_case(root)
            manifest['artifacts']['../outside'] = {'sha256': 'a'*64}
            (root/'case_manifest.json').write_text(json.dumps(manifest), encoding='utf8')
            with self.assertRaises(ValueError):
                verify_case(root)

    def test_environment_and_config_changes_are_reported_not_hidden(self):
        before = {'source_sha256': 'abc', 'runtime_identities': {'tensorflow': {'versions': {'tensorflow': 'old'}}},
                  'execution_equivalence': {'tensorflow': {'inputs': 'a', 'config': {'seed': 0}}}}
        after = copy.deepcopy(before)
        after['runtime_identities']['tensorflow']['versions']['tensorflow'] = 'new'
        after['execution_equivalence']['tensorflow']['config']['seed'] = 1
        result = compare_replay_evidence(before, after)
        self.assertFalse(result['environments']['tensorflow']['match'])
        self.assertIsNone(result['environments']['torch']['match'])
        self.assertEqual(result['inputs_weights_and_execution_config']['tensorflow']['changed_fields'], ['config'])
        self.assertIsNone(result['comparison_outcomes_match'])

    def test_replay_passes_saved_seed_optimizer_threshold(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            case, out = root/'case', root/'out'
            create_case(case)
            statuses = {b: {'status': 'ok'} for b in ('tensorflow', 'torch')}
            values = (statuses, {}, {}, {}, {}, ['tensorflow', 'torch'], {})
            with mock.patch('scripts.reproduce_case.Trainer') as trainer, mock.patch('scripts.reproduce_case.Comparator') as comparator:
                trainer.return_value.train.return_value = values
                comparator.return_value.compare.return_value = {}
                self.assertEqual(main(['--case', str(case), '--out', str(out)]), 0)
                sent = trainer.return_value.train.call_args.kwargs
                self.assertEqual(sent['seed'], 17)
                self.assertEqual(sent['optimizer'], 'sgd')
                self.assertEqual(sent['loss'], 'mean_squared_error')
                self.assertEqual(comparator.call_args.kwargs['threshold'], .012)
                summary = json.loads((out/'replay_summary.json').read_text(encoding='utf8'))
                self.assertFalse(summary['confirmed_defect'])
                self.assertEqual(summary['replay_configuration'], CONFIG)

    def test_generation_configuration_requires_saved_mutation_and_weight_range(self):
        with self.assertRaisesRegex(ValueError, 'metadata missing'):
            validate_generation_configuration({'seed': 23, 'input_dtype': 'int16'})
        self.assertEqual(validate_generation_configuration(GENERATION), GENERATION)

    def test_generation_failure_replay_does_not_require_training_artifacts(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            case, out = root/'case', root/'out'
            (case/'models').mkdir(parents=True)
            (case/'models/model.json').write_text(json.dumps(model_info()), encoding='utf8')
            (case/'models/generation_config.json').write_text(json.dumps(GENERATION), encoding='utf8')
            original = {'tensorflow': {'status': 'invalid_test'}, 'torch': {'status': 'invalid_test'}}
            manifest = capture_case(case, metadata={'generation_status': original})
            self.assertTrue(manifest['generation_replay_ready'])
            self.assertFalse(manifest['differential_replay_ready'])
            with mock.patch('scripts.reproduce_case.replay_generation', return_value=original) as generate, mock.patch('scripts.reproduce_case.Trainer') as trainer:
                self.assertEqual(main(['--case', str(case), '--out', str(out)]), 0)
                trainer.assert_not_called()
                self.assertEqual(generate.call_args.args[1], GENERATION)
                summary = json.loads((out/'replay_summary.json').read_text(encoding='utf8'))
                self.assertEqual(summary['replay_stage'], 'generation_only')
                self.assertTrue(summary['generation_statuses_match'])

    def test_generation_worker_uses_new_paths_and_original_seed(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            with mock.patch('scripts.reproduce_case.CmdProcess') as process, mock.patch('scripts.reproduce_case.collect_process_status', return_value={'status': 'environment_error'}):
                result = replay_generation(root, GENERATION, 1)
                self.assertEqual(set(result), {'tensorflow', 'torch'})
                self.assertEqual(process.call_count, 2)
                argv = process.call_args.args[0]
                self.assertEqual(argv[argv.index('--seed')+1], '23')
                self.assertEqual(argv[argv.index('--mutation')+1], 'none')
                self.assertEqual(argv[argv.index('--json_path')+1], str(root/'models/model.json'))

    def test_mutant_generation_replay_uses_local_original_weight_snapshot(self):
        import numpy as np
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / 'models/source_original/initial_weights'
            source.mkdir(parents=True)
            np.savez(source / 'hidden.npz', np.ones((2, 3), dtype='float32'))
            (source.parent / 'weights_manifest.json').write_text('{}', encoding='utf8')
            config = dict(GENERATION, mutation='nf', source_weight_dir='models/source_original/initial_weights')
            with mock.patch('scripts.reproduce_case.CmdProcess') as process, \
                    mock.patch('scripts.reproduce_case.collect_process_status', return_value={'status': 'environment_error'}):
                replay_generation(root, config, 1)
            for invocation in process.call_args_list:
                argv = invocation.args[0]
                self.assertEqual(argv[argv.index('--mutation') + 1], 'nf')
                self.assertEqual(argv[argv.index('--source_weight_dir') + 1], str(source.resolve()))

    def test_mutant_generation_without_original_weights_cannot_claim_replay_ready(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / 'models').mkdir()
            (root / 'models/model.json').write_text(json.dumps(model_info()), encoding='utf8')
            config = dict(GENERATION, mutation='nf', source_weight_dir='models/source_original/initial_weights')
            (root / 'models/generation_config.json').write_text(json.dumps(config), encoding='utf8')
            manifest = capture_case(root)
            self.assertFalse(manifest['generation_replay_ready'])

    def test_composed_neuron_mutations_cannot_be_replayed_as_one_variant(self):
        with self.assertRaises(ValueError):
            validate_generation_configuration(dict(GENERATION, mutation='nf,ws'))


if __name__ == '__main__':
    unittest.main()
