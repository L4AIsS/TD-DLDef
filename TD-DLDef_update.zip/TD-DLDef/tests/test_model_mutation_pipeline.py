"""Regressions for completed originals, independent mutants and legal adaptation."""
import copy
import ast
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock
from types import SimpleNamespace

import numpy as np

from utils.mutation import MutationConfig, NeuronMutator, ValueMutator
from utils.model_mutation import ModelMutator
from src.cases_generation.generate_one import apply_neuron_mutation, restore_source_weights
from src.cases_generation.layer_info_generator import LayerInfoGenerator
from src.cases_generation.model_info_generator import ModelInfoGenerator
from src.cases_generation.variable_generator import VariableGenerator
from utils.selection import Selector
from utils.runtime import InvalidTest
from utils.input_adaptation import adapt_inbound_tensors
from utils.model_snippet import render_model_snippet


VAR = dict(tensor_dimension_range=(2, 5), tensor_element_size_range=(2, 5),
           weight_value_range=(-10.0, 10.0), small_value_range=(0, 1), vocabulary_size=101)
MODEL = dict(var=VAR, node_num_range=(5, 5), dag_io_num_range=(1, 2),
             dag_max_branch_num=2, cell_num=3, node_num_per_normal_cell=10,
             node_num_per_reduction_cell=2)


def dense_model():
    return {
        'input_id_list': [0], 'output_id_list': [2],
        'model_structure': {
            '0': {'type': 'input_object', 'args': {'name': 'input', 'shape': [4], 'dtype': 'float16'},
                  'pre_layers': [], 'output_shape': [None, 4]},
            '1': {'type': 'dense', 'args': {'name': 'hidden', 'units': 6, 'activation': 'relu', 'use_bias': True},
                  'pre_layers': [0], 'output_shape': [None, 6]},
            '2': {'type': 'reshape', 'args': {'name': 'output', 'target_shape': [2, 3]},
                  'pre_layers': [1], 'output_shape': [None, 2, 3]},
        },
    }


class FakeLayer:
    def __init__(self, name, weights):
        self.name = name
        self._weights = [np.array(w, copy=True) for w in weights]

    def get_weights(self):
        return [w.copy() for w in self._weights]

    def set_weights(self, weights):
        if [w.shape for w in weights] != [w.shape for w in self._weights]:
            raise ValueError('shape mismatch')
        self._weights = [np.array(w, copy=True) for w in weights]


class FakeModel:
    def __init__(self, layers):
        self.layers = layers


class NumpyOps:
    """Record actual array adaptations without importing a DL runtime."""
    def __init__(self):
        self.events = []

    def clip(self, tensor, low, high):
        self.events.append(('clip', low, high))
        return np.clip(tensor, low, high)

    def cast(self, tensor, dtype):
        self.events.append(('cast', dtype))
        return np.asarray(tensor).astype(dtype)


class ModelMutationPipelineTests(unittest.TestCase):
    def test_runner_builds_original_before_planning_and_never_chains_siblings(self):
        from scripts.run_ablation_exp2 import run_one
        events, calls = [], []
        runtime = SimpleNamespace(last_status={})

        def generate(**kwargs):
            calls.append(kwargs)
            events.append('generate:' + str(kwargs.get('neuron_operator')))
            models = Path(kwargs['exp_dir']) / 'models'
            weights = models / 'initial_weights'
            weights.mkdir(parents=True, exist_ok=True)
            np.savez(weights / 'hidden.npz', np.ones((4, 6), dtype='float32'))
            for backend in ('tensorflow', 'torch'):
                (models / (backend + '.keras')).write_bytes(b'unit-test fixture')
            runtime.last_status = {backend: {'status': 'ok'} for backend in ('tensorflow', 'torch')}
            return ['tensorflow', 'torch']

        original_mutate = ModelMutator.mutate_model

        def plan(mutator, original, input_dtype='float32'):
            self.assertEqual(events, ['generate:None'])
            self.assertTrue((Path(calls[0]['exp_dir']) / 'models/initial_weights/hidden.npz').is_file())
            events.append('plan')
            return original_mutate(mutator, original, input_dtype)

        runtime.generate = generate
        statuses = {backend: {'status': 'ok'} for backend in ('tensorflow', 'torch')}
        trained = (statuses, {}, {}, {}, {}, ['tensorflow', 'torch'], {})
        with tempfile.TemporaryDirectory() as directory, \
                mock.patch.object(ModelInfoGenerator, 'generate_seq_model', return_value=(dense_model(), {}, {}, 3)), \
                mock.patch('src.cases_generation.model_generator.ModelGenerator', return_value=runtime), \
                mock.patch.object(ModelMutator, 'mutate_model', autospec=True, side_effect=plan), \
                mock.patch('src.incons_detection.trainer.Trainer.train', return_value=trained), \
                mock.patch('src.incons_detection.comparator.Comparator.compare', return_value={}):
            summary = run_one('keras3.10', 'full', 1, 15, .15, 1, directory)
        self.assertEqual(events, ['generate:None', 'plan', 'generate:nf', 'generate:ws', 'generate:wr'])
        self.assertEqual(summary['original_models_built'], 1)
        self.assertEqual(summary['mutated_models'], 3)
        self.assertEqual(summary['ok_models'], 3)
        source = str(Path(calls[0]['exp_dir']) / 'models' / 'initial_weights')
        self.assertTrue(all(call['source_weight_dir'] == source for call in calls[1:]))
        self.assertEqual(len({call['exp_dir'] for call in calls}), 4)
        self.assertEqual([call['generation_seed'] for call in calls], [15, 16, 17, 18])
        self.assertNotEqual(calls[0]['generation_seed'], 15 + calls[0]['model_id'])

    def test_runner_does_not_mutate_when_original_was_not_materialized(self):
        from scripts.run_ablation_exp2 import run_one
        runtime = SimpleNamespace(last_status={'tensorflow': {'status': 'environment_error'},
                                               'torch': {'status': 'environment_error'}},
                                  generate=mock.Mock(return_value=[]))
        with tempfile.TemporaryDirectory() as directory, \
                mock.patch.object(ModelInfoGenerator, 'generate_seq_model', return_value=(dense_model(), {}, {}, 3)), \
                mock.patch('src.cases_generation.model_generator.ModelGenerator', return_value=runtime), \
                mock.patch.object(ModelMutator, 'mutate_model') as mutate:
            summary = run_one('keras3.10', 'full', 1, 15, .15, 1, directory)
        mutate.assert_not_called()
        self.assertEqual(summary['original_models_built'], 0)
        self.assertEqual(summary['mutated_models'], 0)
        self.assertEqual(summary['original_gen_fail'], 1)

    def test_structure_generation_never_calls_value_mutation(self):
        selector = Selector(['dense'], {'dense': None})
        gen = ModelInfoGenerator(MODEL, None, selector, 'seq',
                                 MutationConfig(seed=15), layer_types=['dense'])
        selector.reset_model_state()
        with mock.patch.object(ValueMutator, 'mutate_layer_args', side_effect=AssertionError('early PV/BV')), \
                mock.patch.object(ValueMutator, 'input_type', side_effect=AssertionError('early IT')):
            model, _, _, _ = gen.generate_seq_model(5, input_shape=(None, 4), output_shape=(None, 3))
        self.assertTrue(model['output_id_list'])
        self.assertTrue(all(not node.get('mutations') for node in model['model_structure'].values()))

    def test_all_three_variants_share_value_mutations_and_independent_graphs(self):
        original = dense_model()
        before = copy.deepcopy(original)
        variants = ModelMutator(MutationConfig(seed=14)).mutate_model(original, input_dtype='float16')
        self.assertEqual([v['neuron_operator'] for v in variants], ['nf', 'ws', 'wr'])
        self.assertEqual(original, before)
        structures = [v['model_info']['model_structure'] for v in variants]
        self.assertEqual(structures[0], structures[1])
        self.assertEqual(structures[1], structures[2])
        self.assertEqual(len({v['input_dtype'] for v in variants}), 1)
        structures[0]['1']['args']['activation'] = 'changed_only_in_nf'
        self.assertNotEqual(structures[0], structures[1])
        self.assertEqual(original, before)
        json.dumps(variants, allow_nan=False)

    def test_global_it_is_selected_once_for_all_layers_and_variants(self):
        with mock.patch.object(ValueMutator, 'input_type', return_value='float32') as choose:
            variants = ModelMutator(MutationConfig(['it', 'nf', 'ws', 'wr'], 14)).mutate_model(
                dense_model(), input_dtype='float16')
        self.assertEqual(choose.call_count, 1)
        for variant in variants:
            self.assertEqual(variant['input_dtype'], 'float32')
            for node in variant['model_info']['model_structure'].values():
                self.assertEqual(node['args']['dtype'], 'float32')

    def test_disabled_neuron_operator_removes_only_that_variant(self):
        variants = ModelMutator(MutationConfig(['pv', 'bv', 'it', 'ws', 'wr'], 7)).mutate_model(dense_model())
        self.assertEqual([v['neuron_operator'] for v in variants], ['ws', 'wr'])

    def test_value_only_variant_preserves_dtype_when_it_disabled(self):
        variants = ModelMutator(MutationConfig(['bv'], 7)).mutate_model(dense_model())
        self.assertEqual(len(variants), 1)
        self.assertEqual(variants[0]['name'], 'none')
        self.assertIsNone(variants[0]['neuron_operator'])
        self.assertEqual(variants[0]['input_dtype'], 'float16')
        self.assertEqual(variants[0]['model_info']['model_structure']['0']['args']['dtype'], 'float16')

    def test_unsupported_global_dtype_adapts_only_constrained_layer(self):
        original = dense_model()
        original['model_structure']['1']['supported_dtypes'] = ['float32']
        with mock.patch.object(ValueMutator, 'input_type', return_value='float64'):
            variants = ModelMutator(MutationConfig(['it', 'nf', 'ws', 'wr'], 4)).mutate_model(original)
        for variant in variants:
            structure = variant['model_info']['model_structure']
            self.assertEqual(structure['0']['args']['dtype'], 'float64')
            self.assertEqual(structure['1']['args']['dtype'], 'float32')
            self.assertEqual(structure['2']['args']['dtype'], 'float64')
            plan = variant['mutation_plan']
            records = [record for record in plan['layers'] if str(record['layer_id']) == '1']
            self.assertEqual(len(records), 1)
            self.assertTrue(records[0]['adaptations'])
        self.assertEqual(original['model_structure']['0']['args']['dtype'], 'float16')

    def test_integer_it_casts_to_float_before_convolution(self):
        model = {
            'input_id_list': [0], 'output_id_list': [1], 'model_structure': {
                '0': {'type': 'input_object', 'args': {'name': 'input', 'shape': [4, 4, 1]},
                      'pre_layers': [], 'output_shape': [None, 4, 4, 1]},
                '1': {'type': 'conv2D', 'args': {'name': 'conv', 'filters': 2, 'kernel_size': [2, 2],
                      'strides': [1, 1], 'dilation_rate': [1, 1], 'padding': 'valid', 'data_format': 'channels_last'},
                      'pre_layers': [0], 'output_shape': [None, 3, 3, 2]},
            }}
        with mock.patch.object(ValueMutator, 'input_type', return_value='int8'):
            variant = ModelMutator(MutationConfig(['it', 'nf'], 4)).mutate_model(model)[0]
        conv = variant['model_info']['model_structure']['1']
        self.assertEqual(conv['args']['dtype'], 'float32')
        self.assertEqual(conv['input_casts'], ['float32'])
        values = np.arange(16, dtype='int8').reshape(1, 4, 4, 1)
        ops = NumpyOps()
        inbound = adapt_inbound_tensors(conv, [values], ops)
        self.assertEqual(ops.events, [('cast', 'float32')])
        self.assertEqual(inbound[0].dtype, np.dtype('float32'))
        np.testing.assert_array_equal(inbound[0], values)

    def test_embedding_bounds_are_applied_before_integer_cast(self):
        model = dense_model()
        model['output_id_list'] = [1]
        model['model_structure'].pop('2')
        model['model_structure']['1'] = {
            'type': 'embedding', 'args': {'name': 'embedding', 'input_dim': 7, 'output_dim': 3},
            'pre_layers': [0], 'output_shape': [None, 4, 3],
        }
        with mock.patch.object(ValueMutator, 'input_type', return_value='float64'):
            variant = ModelMutator(MutationConfig(['it', 'nf'], 4)).mutate_model(model)[0]
        node = variant['model_info']['model_structure']['1']
        self.assertEqual(node['input_casts'], ['int32'])
        self.assertEqual(node['input_index_bounds'], {'min': 0, 'max_exclusive': 7})
        ops = NumpyOps()
        values = np.array([[-1e100, 1.9, 6.8, 1e100]], dtype='float64')
        actual = adapt_inbound_tensors(node, [values], ops)[0]
        self.assertEqual(ops.events, [('clip', 0, 6), ('cast', 'int32')])
        np.testing.assert_array_equal(actual, np.array([[0, 1, 6, 6]], dtype='int32'))

    def test_time_distributed_embedding_propagates_index_adaptation(self):
        model = dense_model()
        model['model_structure']['0']['args']['shape'] = [2, 4]
        model['model_structure']['0']['output_shape'] = [None, 2, 4]
        model['model_structure'].pop('2')
        model['output_id_list'] = [1]
        model['model_structure']['1'] = {
            'type': 'time_distributed', 'args': {'name': 'wrapper', 'layer': {
                'type': 'embedding', 'args': {'name': 'embedding', 'input_dim': 7, 'output_dim': 3},
                'pre_layers': [], 'output_shape': [None, 4, 3]}},
            'pre_layers': [0], 'output_shape': [None, 2, 4, 3],
        }
        with mock.patch.object(ValueMutator, 'input_type', return_value='float64'):
            variant = ModelMutator(MutationConfig(['it', 'nf'], 4)).mutate_model(model)[0]
        wrapper = variant['model_info']['model_structure']['1']
        inner = wrapper['args']['layer']
        self.assertEqual(wrapper['input_casts'], ['int32'])
        self.assertEqual(wrapper['input_index_bounds'], inner['input_index_bounds'])
        ops = NumpyOps()
        values = np.array([[[-1, 1.9, 6.8, 1e100], [-100, 0, 1, 7]]], dtype='float64')
        actual = adapt_inbound_tensors(wrapper, [values], ops)[0]
        self.assertEqual(actual.dtype, np.dtype('int32'))
        self.assertEqual(actual.shape, (1, 2, 4))
        self.assertGreaterEqual(actual.min(), 0)
        self.assertLess(actual.max(), inner['args']['input_dim'])
        self.assertEqual(ops.events, [('clip', 0, 6), ('cast', 'int32')])

    def test_input_adaptation_rejects_wrong_predecessor_count(self):
        with self.assertRaisesRegex(ValueError, 'predecessor count'):
            adapt_inbound_tensors({'input_casts': ['float32']}, [np.ones(1), np.ones(1)], NumpyOps())

    def test_rendered_source_preserves_adapter_order_dtype_and_clip_before_cast(self):
        model = {
            'input_dtype': 'float64', 'input_id_list': [0], 'output_id_list': [1],
            'model_structure': {
                '1': {'type': 'embedding', 'args': {'name': 'embedding', 'input_dim': 7, 'output_dim': 3,
                      'dtype': 'float32'}, 'pre_layers': [9], 'output_shape': [None, 4, 3],
                      'input_casts': ['int32'], 'input_index_bounds': {'min': 0, 'max_exclusive': 7},
                      'mutations': {'pv': {'status': 'changed', 'changes': {'input_dim': [8, 7]}},
                                    'it': {'status': 'applied', 'requested': 'float64', 'applied': 'float32'}}},
                '9': {'type': 'reshape', 'args': {'name': 'adapter', 'target_shape': [4], 'dtype': 'float32'},
                      'pre_layers': [0], 'output_shape': [None, 4], 'mutation_adapter': True},
                '0': {'type': 'input_object', 'args': {'name': 'input', 'shape': [4], 'dtype': 'float32'},
                      'pre_layers': [], 'output_shape': [None, 4]},
            }}
        source = render_model_snippet(model)
        tree = ast.parse(source)
        assignments = [node for node in tree.body if isinstance(node, ast.Assign)]
        self.assertEqual([node.targets[0].id for node in assignments], ['x_0', 'x_9', 'x_1', 'model'])
        input_keywords = {node.arg: node.value for node in assignments[0].value.keywords}
        self.assertEqual(input_keywords['dtype'].value, 'float32')
        adapted = assignments[2].value.args[0]
        self.assertIsInstance(adapted, ast.Call)
        self.assertEqual(adapted.func.attr, 'cast')
        self.assertEqual(adapted.args[1].value, 'int32')
        self.assertEqual(adapted.args[0].func.attr, 'clip')
        self.assertEqual(adapted.args[0].args[0].id, 'x_9')
        self.assertEqual([arg.value for arg in adapted.args[0].args[1:]], [0, 6])
        self.assertIn('[PV] input_dim: 8 -> 7', source)
        self.assertIn('[IT]', source)

    def test_reshape_after_unit_mutation_has_matching_element_count(self):
        variants = ModelMutator(MutationConfig(['bv', 'nf'], 3)).mutate_model(dense_model())
        structure = variants[0]['model_info']['model_structure']
        hidden = structure['1']
        reshape = structure['2']
        self.assertNotEqual(hidden['args']['units'], 6)
        self.assertEqual(np.prod(hidden['output_shape'][1:]), np.prod(reshape['args']['target_shape']))
        self.assertEqual(tuple(reshape['output_shape'][1:]), tuple(reshape['args']['target_shape']))

    def test_merge_branches_remain_compatible_after_independent_parameter_changes(self):
        model = dense_model()
        model['model_structure']['2'] = {
            'type': 'dense', 'args': {'name': 'right', 'units': 6},
            'pre_layers': [0], 'output_shape': [None, 6],
        }
        model['model_structure']['3'] = {
            'type': 'add', 'args': {'name': 'merge'},
            'pre_layers': [1, 2], 'output_shape': [None, 6],
        }
        model['output_id_list'] = [3]
        for seed in range(5):
            with self.subTest(seed=seed):
                variant = ModelMutator(MutationConfig(['bv', 'nf'], seed)).mutate_model(model)[0]
                structure = variant['model_info']['model_structure']
                merge = structure['3']
                parent_shapes = [tuple(structure[str(parent)]['output_shape']) for parent in merge['pre_layers']]
                self.assertEqual(parent_shapes[0], parent_shapes[1])
                self.assertEqual(tuple(merge['output_shape']), parent_shapes[0])
                self.assertEqual(model['model_structure']['3']['pre_layers'], [1, 2])

    def test_neuron_operator_composition_is_rejected(self):
        model = FakeModel([FakeLayer('dense', [np.ones((3, 4), dtype='float32')])])
        original = model.layers[0].get_weights()[0]
        with self.assertRaises(ValueError):
            apply_neuron_mutation(model, NeuronMutator(MutationConfig(['nf', 'ws'], 13)))
        np.testing.assert_array_equal(model.layers[0].get_weights()[0], original)

    def test_neuron_failure_is_not_reported_as_successful_skipped_layer(self):
        layer = FakeLayer('dense', [np.ones((3, 4), dtype='float32')])
        mutator = NeuronMutator(MutationConfig(['nf'], 7))
        with mock.patch.object(mutator, 'mutate_weights_with_report', side_effect=RuntimeError('test failure')):
            with self.assertRaisesRegex(InvalidTest, 'test failure'):
                apply_neuron_mutation(FakeModel([layer]), mutator)

    def test_ws_uses_one_model_level_scale_for_every_weighted_layer(self):
        model = FakeModel([
            FakeLayer('a', [np.ones((3, 4), dtype='float32')]),
            FakeLayer('b', [np.full((5, 2), 2, dtype='float32')]),
        ])
        apply_neuron_mutation(model, NeuronMutator(MutationConfig(['ws'], 19)))
        scale_a = model.layers[0].get_weights()[0][0, 0]
        scale_b = model.layers[1].get_weights()[0][0, 0] / 2
        self.assertEqual(scale_a, scale_b)

    def test_wr_adapts_vectors_and_scalars_preserving_shape_dtype_and_norm(self):
        original = [np.arange(1, 6, dtype='float32'), np.array(3, dtype='float64'),
                    np.array([2], dtype='float16')]
        mutated, report = NeuronMutator(MutationConfig(['wr'], 11)).mutate_weights_with_report(original)
        for before, after in zip(original, mutated):
            with self.subTest(shape=before.shape, dtype=str(before.dtype)):
                self.assertEqual(after.shape, before.shape)
                self.assertEqual(after.dtype, before.dtype)
                self.assertFalse(np.array_equal(before, after))
                np.testing.assert_allclose(np.linalg.norm(after), np.linalg.norm(before), rtol=2e-5, atol=2e-5)
        self.assertEqual(report['changed_tensors'], 3)
        self.assertTrue(all(r['applied'] for r in report['operators'][0]['details']['rotations']))

    def test_variants_restore_original_weights_before_independent_mutation(self):
        with tempfile.TemporaryDirectory() as directory:
            original = np.arange(1, 13, dtype='float32').reshape(3, 4)
            path = Path(directory) / 'hidden.npz'
            np.savez(path, original)
            archive_bytes = path.read_bytes()
            for operator in ('nf', 'ws', 'wr'):
                with self.subTest(operator=operator):
                    destination = FakeLayer('hidden', [np.full((3, 4), 10000, dtype='float32')])
                    model = FakeModel([destination])
                    restore_source_weights(model, directory)
                    np.testing.assert_array_equal(destination.get_weights()[0], original)
                    actual_mutator = NeuronMutator(MutationConfig([operator], 10))
                    apply_neuron_mutation(model, actual_mutator)
                    expected_model = FakeModel([FakeLayer('hidden', [original])])
                    apply_neuron_mutation(expected_model, NeuronMutator(MutationConfig([operator], 10)))
                    np.testing.assert_array_equal(destination.get_weights()[0], expected_model.layers[0].get_weights()[0])
                    self.assertEqual(path.read_bytes(), archive_bytes)

    def test_unset_input_dtype_uses_configured_baseline_in_builders_and_plan(self):
        import importlib
        from utils.model_snippet import render_model_snippet
        original = dense_model()
        input_node = original['model_structure']['0']
        input_node['args']['dtype'] = None
        for module_name in ('generate_one', 'generate_other'):
            module = importlib.import_module('src.cases_generation.' + module_name)
            constructor = mock.Mock(return_value='symbolic_input')
            build = getattr(module, '__generate_layer')
            with mock.patch.object(module, 'get_layer_func', return_value=constructor):
                if module_name == 'generate_one':
                    build(input_node, (-1, 1), 'float16')
                else:
                    build(input_node, 'float16')
            self.assertEqual(constructor.call_args.kwargs['dtype'], 'float16')
            self.assertIsNone(input_node['args']['dtype'])
        variants = ModelMutator(MutationConfig(['ws'], 17)).mutate_model(original, input_dtype='float16')
        self.assertEqual(variants[0]['input_dtype'], 'float16')
        self.assertEqual(variants[0]['model_info']['model_structure']['0']['args']['dtype'], 'float16')
        source = render_model_snippet(dict(original, input_dtype='float16'))
        self.assertIn("dtype='float16'", source)

    def test_original_weight_shape_and_dtype_adaptation_is_deterministic(self):
        with tempfile.TemporaryDirectory() as directory:
            original = np.arange(1, 7, dtype='float16').reshape(2, 3)
            np.savez(Path(directory) / 'hidden.npz', original)
            a = FakeModel([FakeLayer('hidden', [np.zeros((3, 4), dtype='float32')])])
            b = FakeModel([FakeLayer('hidden', [np.full((3, 4), 1000, dtype='float32')])])
            report_a = restore_source_weights(a, directory)
            report_b = restore_source_weights(b, directory)
            expected = np.resize(original, (3, 4)).astype('float32')
            np.testing.assert_array_equal(a.layers[0].get_weights()[0], expected)
            np.testing.assert_array_equal(b.layers[0].get_weights()[0], expected)
            self.assertEqual(a.layers[0].get_weights()[0].dtype, np.dtype('float32'))
            self.assertEqual(report_a, report_b)
            json.dumps(report_a, allow_nan=False)


if __name__ == '__main__':
    unittest.main()
