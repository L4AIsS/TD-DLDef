"""Regression tests for recursive stochastic comparability guards."""
import os
import importlib.util
import subprocess
import sys
import textwrap
import unittest
from types import SimpleNamespace

from src.incons_detection.train import validate_stochastic_layers
from utils.runtime import UnsupportedTest


class NestedStochasticGuardTests(unittest.TestCase):
    def test_top_level_named_dropout_stays_unsupported(self):
        dropout = type('Dropout', (), {'name': 'drop', 'rate': 0})()
        with self.assertRaises(UnsupportedTest):
            validate_stochastic_layers(SimpleNamespace(name='model', layers=[dropout]))

    def test_top_level_recurrent_options_stay_unsupported(self):
        for key in ('dropout', 'recurrent_dropout', 'stateful'):
            with self.subTest(key=key), self.assertRaises(UnsupportedTest):
                validate_stochastic_layers(SimpleNamespace(name='model', layers=[SimpleNamespace(name='rnn', **{key: .1})]))

    def test_wrapper_and_cell_paths_are_checked(self):
        for relationship in ('layer', 'forward_layer', 'backward_layer', 'cell'):
            with self.subTest(relationship=relationship), self.assertRaises(UnsupportedTest) as caught:
                validate_stochastic_layers(SimpleNamespace(name='wrapper', **{relationship: SimpleNamespace(name='inner', recurrent_dropout=.1)}))
            self.assertIn(relationship, str(caught.exception))

    def test_nested_models_and_stacked_cells_are_checked(self):
        for relationship in ('layers', 'cells'):
            with self.subTest(relationship=relationship), self.assertRaises(UnsupportedTest):
                validate_stochastic_layers(SimpleNamespace(name='outer', **{relationship: [SimpleNamespace(name='inner', dropout=.1)]}))

    def test_deterministic_nested_graph_and_cycles_are_allowed(self):
        root = SimpleNamespace(name='root', dropout=0, recurrent_dropout=0, stateful=False)
        child = SimpleNamespace(name='child', layer=root)
        root.layers = [child, child]
        validate_stochastic_layers(root)

    @unittest.skipUnless(importlib.util.find_spec('keras') and importlib.util.find_spec('torch'),
                         'requires installed Keras and PyTorch backends')
    def test_real_keras_wrappers_and_nested_models(self):
        # Isolate backend imports so this test cannot select the backend for
        # unrelated tests. No tensor execution or GPU is required by this guard.
        script = textwrap.dedent("""
            import keras
            from src.incons_detection.train import validate_stochastic_layers
            from utils.runtime import UnsupportedTest
            L = keras.layers
            stochastic = [
                L.TimeDistributed(L.LSTM(2, recurrent_dropout=.00390625)),
                L.Bidirectional(L.LSTM(2, dropout=.1)),
                keras.Sequential([keras.Sequential([L.Dropout(.2)])]),
                L.RNN([L.LSTMCell(2), L.LSTMCell(2, recurrent_dropout=.1)]),
            ]
            for layer in stochastic:
                try:
                    validate_stochastic_layers(layer)
                except UnsupportedTest:
                    pass
                else:
                    raise AssertionError(type(layer).__name__ + ' was not rejected')
            deterministic = [
                L.TimeDistributed(L.LSTM(2, dropout=0, recurrent_dropout=0)),
                L.Bidirectional(L.LSTM(2)),
                keras.Sequential([keras.Sequential([L.Dense(2)])]),
                L.RNN([L.LSTMCell(2), L.LSTMCell(2)]),
            ]
            for layer in deterministic:
                validate_stochastic_layers(layer)
            print('real Keras wrapper guard: 4 stochastic rejected, 4 deterministic allowed')
        """)
        env = dict(os.environ, KERAS_BACKEND='torch', CUDA_VISIBLE_DEVICES='-1')
        result = subprocess.run([sys.executable, '-c', script], env=env, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


if __name__ == '__main__':
    unittest.main()
