# -*- coding: utf-8 -*-
"""
模型源码片段渲染模块

把 model_info (model.json 同构的模型结构 dict) 渲染为可读的 Keras 模型源码,
用于缺陷报告: 标注每个缺陷是由哪段模型代码片段造成的。

渲染风格与 src/cases_generation/generate_one.py 的实际构建逻辑一致:
    * input_object       -> keras.Input(shape=..., dtype=...)
    * 普通层             -> x = keras.layers.Dense(units=..., ...)(x_prev)
    * 包装层 (嵌套 layer) -> keras.layers.TimeDistributed(keras.layers.Dense(...))
    * 被 PV/BV 突变改动的参数以  # [PV] param: old -> new  行内注释标出。
"""

from typing import Optional


def _fmt_value(v, indent=0):
    """格式化参数值为 Python 源码字面量"""
    if isinstance(v, str):
        return repr(v)
    if isinstance(v, (list, tuple)):
        inner = ', '.join(_fmt_value(x) for x in v)
        return ('(%s%s)' % (inner, ',' if len(v) == 1 else '')) if isinstance(v, tuple) else '[%s]' % inner
    if isinstance(v, dict):
        return repr(v)
    if v is None:
        return 'None'
    return repr(v)


def _camel(layer_type):
    """'conv2D' -> 'Conv2D', 'dense' -> 'Dense' (与 utils.get_layer_func 一致)"""
    if layer_type == 'input_object':
        return 'Input'
    res = ''
    i = 0
    while i < len(layer_type):
        if i == 0:
            res += layer_type[i].upper()
        elif layer_type[i] == '_':
            i += 1
            res += layer_type[i].upper()
        else:
            res += layer_type[i]
        i += 1
    return res


def _iter_items(d):
    """Topological order, including inserted adapters with higher numeric IDs."""
    remaining = {str(k): v for k, v in d.items()}
    emitted = set()
    while remaining:
        ready = [k for k, info in remaining.items()
                 if all(str(p) in emitted for p in info.get('pre_layers', []))]
        if not ready:
            raise ValueError('model graph has missing predecessors or a cycle')
        for key in ready:
            yield key, remaining.pop(key)
            emitted.add(key)


def render_layer_call(layer_type: str, args: dict, mutations: Optional[dict] = None) -> str:
    """渲染单个层的构造函数调用, 如 keras.layers.Conv2D(filters=3, ...)

    :param layer_type: 层类型
    :param args:       层参数 (含 name; 不含 pre_layers)
    :param mutations:  (保留兼容, 注释由 mutation_note 生成并追加到语句末尾)
    """
    if layer_type == 'input_object':
        shape = args.get('batch_shape') or (None, *tuple(args.get('shape', ())))
        dtype = args.get('dtype')
        return 'keras.Input(shape=%s, name=%r%s)' % (
            _fmt_value(tuple(shape[1:]) if shape else ()), args.get('name'),
            ', dtype=%s' % repr(dtype) if dtype else '')

    parts = []
    for k, v in args.items():
        if k == 'layer' and isinstance(v, dict):   # 包装层: 递归渲染内层
            inner = render_layer_call(v.get('type'), v.get('args', {}), v.get('mutations'))
            parts.append('%s' % inner)
            continue
        if k.endswith('_initializer') and isinstance(v, str):
            parts.append('%s=keras.initializers.RandomUniform(%s, 10.0)' % (k, '0.0' if k == 'moving_variance_initializer' else '-10.0'))
            continue
        parts.append('%s=%s' % (k, _fmt_value(v)))
    return 'keras.layers.%s(%s)' % (_camel(layer_type), ', '.join(parts))


def mutation_note(mutations: Optional[dict]) -> str:
    """生成突变标注注释: '   # MUTATED [PV] filters: 4 -> 3; [BV] units: 5 -> 1'"""
    if not mutations:
        return ''
    notes = []
    for op, changes in mutations.items():
        if isinstance(changes, dict):
            if op == 'it' and 'requested' in changes:
                notes.append('[IT] requested=%s, applied=%s' % (
                    _fmt_value(changes['requested']), _fmt_value(changes.get('applied'))))
                continue
            changes = changes.get('changes', changes)
            for p, on in changes.items():
                if not isinstance(on, (list, tuple)) or len(on) != 2:
                    continue
                o, n = on
                notes.append('[%s] %s: %s -> %s' % (op.upper(), p, _fmt_value(o), _fmt_value(n)))
    return ('   # MUTATED ' + '; '.join(notes)) if notes else ''


def render_model_snippet(model_info: dict, only_layer: Optional[str] = None) -> str:
    """渲染整个模型的源码片段 (函数式 API 风格)

    :param model_info: 模型结构 dict (model.json 同构)
    :param only_layer: 若指定层名 (如 '03_conv2D'), 只返回该层及其直接前驱的片段
    :return: 多行源码字符串
    """
    structure = {str(k): v for k, v in model_info['model_structure'].items()}
    var_of = {}          # layer_id -> 输出变量名
    lines = []

    for layer_id, info in _iter_items(structure):
        ltype = info['type']
        args = info.get('args', {})
        name = args.get('name', '%s_%s' % (layer_id.zfill(2), ltype))
        mutations = info.get('mutations')
        pre = [str(i) for i in info.get('pre_layers', [])]

        args = dict(args)
        if ltype == 'input_object' and model_info.get('input_dtype'):
            if args.get('dtype') is None:
                args['dtype'] = model_info['input_dtype']
        call = render_layer_call(ltype, args, mutations)
        note = mutation_note(mutations)
        if ltype == 'input_object':
            stmt = 'x_%s = %s' % (layer_id, call)
        else:
            tensors = []
            casts = info.get('input_casts')
            if casts is not None and len(casts) != len(pre):
                raise ValueError('input cast plan does not match layer predecessor count')
            bounds = info.get('input_index_bounds')
            for index, parent in enumerate(pre):
                tensor = var_of[parent]
                if bounds is not None:
                    tensor = 'keras.ops.clip(%s, %s, %s)' % (
                        tensor, _fmt_value(bounds.get('min', 0)),
                        _fmt_value(bounds['max_exclusive'] - 1))
                if casts is not None:
                    tensor = 'keras.ops.cast(%s, %r)' % (tensor, casts[index])
                tensors.append(tensor)
            inbound = ', '.join(tensors)
            if len(pre) > 1:
                inbound = '[%s]' % inbound
            stmt = 'x_%s = %s(%s)' % (layer_id, call, inbound)
        stmt += note
        var_of[layer_id] = 'x_' + layer_id
        lines.append((name, stmt))

    if only_layer is not None:
        selected = [stmt for name, stmt in lines if name == only_layer]
        if selected:
            header = '# --- 缺陷定位: 层 %s ---' % only_layer
            return header + '\n' + '\n'.join(selected)
        return '# layer %s not found in model' % only_layer
    inputs = ', '.join('x_' + str(i) for i in model_info['input_id_list'])
    outputs = ', '.join('x_' + str(i) for i in model_info['output_id_list'])
    return 'import keras\n' + '\n'.join(stmt for _, stmt in lines) + '\nmodel = keras.Model(inputs=[' + inputs + '], outputs=[' + outputs + '])\n'


def layer_source_snippet(model_info: dict, layer_name: str) -> str:
    """Construction excerpt only; localization is a hint, not a proven cause."""
    return render_model_snippet(model_info, only_layer=layer_name)


def mutated_layers(model_info: dict) -> list:
    """返回模型中所有被值突变改动过的层: [(layer_name, mutations), ...]"""
    structure = {str(k): v for k, v in model_info['model_structure'].items()}
    out = []
    for _, info in _iter_items(structure):
        muts = []
        if info.get('mutations'):
            muts.append(info['mutations'])
        inner = info.get('args', {}).get('layer')
        if isinstance(inner, dict) and inner.get('mutations'):
            muts.append({'inner(%s)' % inner.get('type'): inner['mutations']})
        if muts:
            out.append((info.get('args', {}).get('name', '?'), muts))
    return out


if __name__ == '__main__':
    mi = {
        'model_structure': {
            '0': {'type': 'input_object', 'args': {'name': '00_input_object', 'shape': (6, 6, 3)},
                  'pre_layers': [], 'output_shape': (None, 6, 6, 3)},
            '1': {'type': 'conv2D',
                  'args': {'name': '01_conv2D', 'filters': 3, 'kernel_size': (2, 2), 'padding': 'valid'},
                  'pre_layers': [0], 'output_shape': (None, 5, 5, 3),
                  'mutations': {'pv': {'filters': [4, 3]}}},
            '2': {'type': 'flatten', 'args': {'name': '02_flatten'},
                  'pre_layers': [1], 'output_shape': (None, 75)},
            '3': {'type': 'dense', 'args': {'name': '03_dense', 'units': 4},
                  'pre_layers': [2], 'output_shape': (None, 4)},
        },
        'input_id_list': [0], 'output_id_list': [3],
    }
    print(render_model_snippet(mi))
    print('---')
    print(layer_source_snippet(mi, '01_conv2D'))
    print('---')
    print(mutated_layers(mi))
