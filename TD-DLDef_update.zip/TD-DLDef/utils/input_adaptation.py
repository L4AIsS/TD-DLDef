"""Explicit, serialisable Keras operations at mutated graph edges."""


def adapt_inbound_tensors(layer_info, tensors, ops):
    """Apply the checked graph plan before calling a layer's backend kernel.

    Layer dtype policies alone do not guarantee integer-to-float autocasting.
    These native operations also survive .keras serialization and gradients.
    """
    casts = layer_info.get('input_casts')
    bounds = layer_info.get('input_index_bounds')
    if casts is not None and len(casts) != len(tensors):
        raise ValueError('input cast plan does not match layer predecessor count')
    result = []
    for index, tensor in enumerate(tensors):
        if bounds is not None:
            tensor = ops.clip(tensor, bounds['min'], bounds['max_exclusive'] - 1)
        if casts is not None:
            tensor = ops.cast(tensor, casts[index])
        result.append(tensor)
    return result
