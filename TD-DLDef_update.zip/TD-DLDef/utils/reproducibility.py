"""Portable evidence manifests and case replay without regenerating weights."""
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import platform
import re
import sys
from utils.model_snippet import render_model_snippet


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def source_digest(root):
    root = Path(root)
    records = []
    for p in sorted(root.glob('*.py')):
        records.append((p.relative_to(root).as_posix(), sha256(p)))
    for sub in ('utils', 'src', 'scripts'):
        for p in sorted((root/sub).rglob('*.py')):
            records.append((p.relative_to(root).as_posix(), sha256(p)))
    return hashlib.sha256(json.dumps(records).encode()).hexdigest()


def runtime_evidence(root):
    """Read actual worker identities/configuration, never infer from a pool label."""
    identities, executions = {}, {}
    for backend in ('tensorflow', 'torch'):
        for stage in ('generation', 'training'):
            path = Path(root) / 'logs' / ('%s_%s.json' % (stage, backend))
            if not path.is_file():
                continue
            value = json.loads(path.read_text(encoding='utf-8'))
            if value.get('actual_backend') == backend and value.get('versions'):
                identities[backend] = {k: value.get(k) for k in ('actual_backend', 'versions', 'platform')}
            if stage == 'training' and value.get('equivalence'):
                executions[backend] = value['equivalence']
    return identities, executions


def replay_configuration(metadata, executions):
    """Capture explicit settings; absent evidence stays missing, not guessed."""
    config = {k: metadata[k] for k in ('loss', 'optimizer', 'seed', 'threshold') if k in metadata}
    sources = {k: 'case_metadata' for k in config}
    worker_configs = [x.get('config', {}) for x in executions.values()]
    if worker_configs and all(x == worker_configs[0] for x in worker_configs):
        actual = worker_configs[0]
        for key in ('loss', 'seed'):
            if key in actual:
                config[key], sources[key] = actual[key], 'verified_worker_config'
        if 'optimizer' not in config and isinstance(actual.get('optimizer'), dict):
            name = actual['optimizer'].get('class_name')
            if name:
                config['optimizer'], sources['optimizer'] = name.lower(), 'worker_optimizer_class'
    missing = [k for k in ('loss', 'optimizer', 'seed', 'threshold') if k not in config]
    return {'values': config, 'sources': sources, 'missing': missing,
            'optimizer_note': 'No optimizer update is performed; serialized worker configuration is compared after replay.'}


def validate_replay_configuration(config):
    missing = [k for k in ('loss', 'optimizer', 'seed', 'threshold') if k not in config]
    if missing:
        raise ValueError('Replay metadata missing: ' + ', '.join(missing))
    if not all(isinstance(config[k], str) and config[k] for k in ('loss', 'optimizer')):
        raise ValueError('Replay loss/optimizer must be recorded nonempty names')
    if isinstance(config['seed'], bool) or not isinstance(config['seed'], int):
        raise ValueError('Replay seed must be an integer')
    threshold = config['threshold']
    if isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or not math.isfinite(threshold) or threshold < 0:
        raise ValueError('Replay threshold must be finite and nonnegative')
    return dict(config)


def validate_generation_configuration(config):
    required = ('weight_range', 'mutation', 'input_dtype', 'seed', 'backends')
    missing = [key for key in required if key not in config]
    if missing:
        raise ValueError('Generation replay metadata missing: ' + ', '.join(missing))
    low_high = config['weight_range']
    if (not isinstance(low_high, (list, tuple)) or len(low_high) != 2
            or not all(isinstance(x, (int, float)) and math.isfinite(x) for x in low_high)
            or low_high[0] >= low_high[1]):
        raise ValueError('Invalid recorded generation weight_range')
    if not isinstance(config['seed'], int) or isinstance(config['seed'], bool):
        raise ValueError('Generation seed must be a recorded integer')
    if config['input_dtype'] not in ('float16', 'float32', 'float64', 'int8', 'int16', 'int32', 'int64', 'uint8'):
        raise ValueError('Unsupported recorded input dtype')
    if config['mutation'] not in ('none', 'nf', 'ws', 'wr'):
        raise ValueError('Generation replay requires one neuron operator; historical chained mutation is unsupported')
    source = config.get('source_weight_dir')
    if config['mutation'] != 'none' and not source:
        raise ValueError('Generation replay of a mutant requires saved original source weights')
    if source is not None:
        if not isinstance(source, str):
            raise ValueError('Recorded source_weight_dir must be a case-relative path')
        relative = PurePosixPath(source)
        if (not source or '\\' in source or relative.is_absolute() or '..' in relative.parts
                or relative.as_posix() != source or relative.parts[0] != 'models'):
            raise ValueError('Recorded source_weight_dir must remain inside the case models directory')
    if config['backends'] not in (['tensorflow', 'torch'], ['torch', 'tensorflow']):
        raise ValueError('Generation replay requires the original two-backend order')
    return dict(config)


def resolve_generation_source(case, config, artifacts=None):
    """Resolve a portable, optionally hash-listed baseline snapshot for replay."""
    source = config.get('source_weight_dir')
    if not source:
        return None
    validate_generation_configuration(config)
    root = Path(case).resolve()
    directory = (root / source).resolve()
    model_root = (root / 'models').resolve()
    if not directory.is_relative_to(root) or not directory.is_relative_to(model_root) or not directory.is_dir():
        raise ValueError('Generation replay original source weight directory is missing or outside case')
    paths = sorted(directory.glob('*.npz'))
    manifest = directory.parent / 'weights_manifest.json'
    if not paths or not manifest.is_file():
        raise ValueError('Generation replay requires original weight tensors and weights_manifest.json')
    for path in [*paths, manifest]:
        if not path.resolve().is_relative_to(model_root):
            raise ValueError('Generation replay source artifact resolves outside case')
        name = path.relative_to(root).as_posix()
        if artifacts is not None and name not in artifacts:
            raise ValueError('Generation replay requires saved and hashed ' + name)
    return directory


def compare_replay_evidence(original, current, original_comparisons=None, current_comparisons=None):
    """Report changed conditions separately from observed anomaly outcomes."""
    identity_results, execution_results = {}, {}
    for backend in ('tensorflow', 'torch'):
        before = original.get('runtime_identities', {}).get(backend)
        after = current.get('runtime_identities', {}).get(backend)
        identity_results[backend] = {'original': before, 'replay': after,
                                    'match': before == after if before is not None and after is not None else None}
        a = original.get('execution_equivalence', {}).get(backend)
        b = current.get('execution_equivalence', {}).get(backend)
        execution_results[backend] = {'match': a == b if a is not None and b is not None else None,
            'changed_fields': sorted(k for k in set(a or {}) | set(b or {}) if (a or {}).get(k) != (b or {}).get(k))}
    def outcomes(pairs):
        return {pair: {k: value.get(k) for k in ('classification', 'inconsistent', 'gradient_exclusions')}
                for pair, value in (pairs or {}).items()}
    old_outcomes, new_outcomes = outcomes(original_comparisons), outcomes(current_comparisons)
    old_hash, new_hash = original.get('source_sha256'), current.get('source_sha256')
    return {'source_hash_match': old_hash == new_hash if old_hash and new_hash else None,
            'environments': identity_results, 'inputs_weights_and_execution_config': execution_results,
            'comparison_outcomes_match': old_outcomes == new_outcomes if old_outcomes and new_outcomes else None,
            'original_comparison_outcomes': old_outcomes, 'replay_comparison_outcomes': new_outcomes,
            'interpretation': 'Outcome agreement is a repeated observation, not proof of a framework defect; null means evidence unavailable.'}


def capture_case(exp_dir, model_info=None, metadata=None):
    root = Path(exp_dir).resolve()
    metadata = dict(metadata or {})
    if model_info is None:
        model_info = json.loads((root/'models/model.json').read_text(encoding='utf-8'))
    model_info = dict(model_info)
    dtype_source = 'model_json' if model_info.get('input_dtype') else 'renderer_default'
    if metadata.get('input_dtype'):
        model_info['input_dtype'], dtype_source = metadata['input_dtype'], 'case_metadata'
    generation_config = root / 'models' / 'generation_config.json'
    generation_settings = {}
    if generation_config.is_file():
        generation_settings = json.loads(generation_config.read_text(encoding='utf-8'))
        dtype = generation_settings.get('input_dtype')
        if dtype:
            model_info['input_dtype'], dtype_source = dtype, 'generation_config'
    src = render_model_snippet(model_info)
    src += '''
# Apply saved post-mutation tensors, including BatchNorm state.
from pathlib import Path
import numpy as np
for layer in model.layers:
    path = Path(__file__).resolve().parent / 'models' / 'initial_weights' / (layer.name + '.npz')
    if not path.exists():
        raise FileNotFoundError(path)
    with np.load(path, allow_pickle=False) as archive:
        weights = [archive[k] for k in sorted(archive.files, key=lambda s: int(s.split('_')[-1]))]
    layer.set_weights(weights)
'''
    (root/'model_source.py').write_text(src, encoding='utf-8')
    # Replay is invoked from project root: no machine-specific absolute paths.
    (root/'reproduce.py').write_text('''"""Run from the TD-DLDef project root."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path.cwd()))
from scripts.reproduce_case import main
if __name__ == '__main__':
    raise SystemExit(main(['--case', str(Path(__file__).resolve().parent)] + sys.argv[1:]))
''', encoding='utf-8')
    artifacts = {}
    for sub in ('models', 'dataset', 'logs', 'layer_outputs', 'loss', 'loss_gradients', 'layer_gradients'):
        for p in sorted((root/sub).rglob('*')):
            if p.is_file():
                if not p.resolve().is_relative_to(root):
                    raise ValueError('Artifact resolves outside case: ' + str(p))
                artifacts[p.relative_to(root).as_posix()] = {'sha256': sha256(p), 'bytes': p.stat().st_size}
    for name in ('model_source.py', 'reproduce.py'):
        p = root / name
        artifacts[name] = {'sha256': sha256(p), 'bytes': p.stat().st_size}
    identities, executions = runtime_evidence(root)
    config = replay_configuration(metadata, executions)
    required = ['models/model.json', 'models/tensorflow.keras', 'models/torch.keras',
                'dataset/inputs.npz', 'dataset/ground_truths.npz']
    missing_artifacts = [name for name in required if name not in artifacts]
    if not any(name.startswith('models/initial_weights/') for name in artifacts):
        missing_artifacts.append('models/initial_weights/*.npz')
    generation_ready, generation_problem = False, None
    try:
        validate_generation_configuration(generation_settings)
        resolve_generation_source(root, generation_settings, artifacts)
        generation_ready = 'models/model.json' in artifacts
    except ValueError as exc:
        generation_problem = str(exc)
    differential_ready = not (missing_artifacts or config['missing'])
    manifest = {'schema_version': 3, 'metadata': metadata, 'artifacts': artifacts,
                'source_sha256': source_digest(Path(__file__).resolve().parents[1]),
                'capture_runtime': {'python': platform.python_version(), 'executable': sys.executable,
                                    'platform': platform.platform()},
                'runtime_identities': identities, 'execution_equivalence': executions,
                'source_input_dtype': {'value': model_info.get('input_dtype', 'float32'), 'source': dtype_source},
                'replay_config': config, 'replay_ready': differential_ready or generation_ready,
                'differential_replay_ready': differential_ready,
                'generation_replay_ready': generation_ready, 'generation_replay_problem': generation_problem,
                'missing_replay_artifacts': missing_artifacts,
                'replay_command': 'python scripts/reproduce_case.py --case <case_directory> --out <new_directory>',
                'source_note': 'model_source.py restores saved weights; initial constructor RNG does not define replay weights',
                'confirmed_defect': False}
    (root/'case_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    return manifest


def verify_case(case):
    root = Path(case).resolve()
    manifest = json.loads((root/'case_manifest.json').read_text(encoding='utf-8'))
    if not isinstance(manifest.get('artifacts'), dict) or not isinstance(manifest.get('metadata'), dict):
        raise ValueError('Invalid case manifest: artifacts and metadata must be objects')
    errors = []
    for name, record in manifest['artifacts'].items():
        relative = PurePosixPath(name)
        if ('\\' in name or relative.is_absolute() or '..' in relative.parts
                or relative.as_posix() != name or not isinstance(record, dict)
                or not re.fullmatch(r'[0-9a-f]{64}', str(record.get('sha256', '')))):
            errors.append(str(name))
            continue
        p = (root/name).resolve()
        if (not p.is_relative_to(root) or not p.is_file() or sha256(p) != record['sha256']
                or ('bytes' in record and p.stat().st_size != record['bytes'])):
            errors.append(name)
    if errors:
        raise ValueError('Case missing or changed artifacts: ' + ', '.join(errors))
    return manifest
