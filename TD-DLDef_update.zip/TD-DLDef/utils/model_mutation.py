"""Mutation of a *completed* seed graph, independently of DIV / TS-RCS.

PV and BV are evaluated for every original layer; IT has one model-wide request.
Their legal, adapted graph is shared by independent NF, WS and WR descendants.
The returned descriptions do not initialise or mutate weights: the execution
stage restores each descendant from the saved original weights first.
"""
from copy import deepcopy
import math

from utils.mutation import ValueMutator
from src.cases_generation.output_shape_calculator import OutputShapeCalculator
from src.cases_generation.layer_info_generator import SHAPE_RECALC_MAP
from src.cases_generation.model_info_generator import ModelInfoGenerator


VALUE_OPERATORS = ('pv', 'bv', 'it')
NEURON_OPERATORS = ('nf', 'ws', 'wr')
MERGE_TYPES = {'concatenate', 'average', 'maximum', 'minimum', 'add',
               'subtract', 'multiply', 'dot'}
SHAPE_TYPES = {'reshape', 'flatten', 'permute', 'repeat_vector',
               'cropping1D', 'cropping2D', 'cropping3D',
               'zero_padding1D', 'zero_padding2D', 'zero_padding3D',
               'up_sampling1D', 'up_sampling2D', 'up_sampling3D'}


def _elements(shape):
    return math.prod(int(d) for d in shape[1:])


def _sequence(value, count):
    if isinstance(value, (tuple, list)):
        if len(value) != count:
            raise ValueError('spatial argument has incorrect rank')
        return tuple(int(v) for v in value)
    return (int(value),) * count


def _shape_ok(shape):
    # Bound whole activations as well as dimensions: a later Flatten must
    # remain inside the generator's per-dimension limit.
    return bool(shape) and all(isinstance(d, int) and 0 < d <= 1000000
                               for d in shape[1:]) and _elements(shape) <= 1000000


class ModelMutator:
    """Create siblings from one immutable, fully generated original graph.

    ``supported_dtypes`` on a layer can restrict its compute policy; an optional
    ``backend_supported_dtypes`` mapping intersects capabilities of selected
    backends. These are explicit execution constraints, never claimed as runtime
    observations. Floating computational layers use floating policies; shape
    operations and model inputs also admit integer input types. TensorFlow CPU
    3-D pool kernels use the conservative common float32 policy.
    """

    def __init__(self, config, backends=('tensorflow', 'torch'),
                 preserve_output_shapes=False):
        self.config = config
        self.backends = tuple(backends)
        self.preserve_output_shapes = preserve_output_shapes
        self.value_mutator = ValueMutator(config, mutation_probability=1.0)
        self.shape_calculator = OutputShapeCalculator()

    def _supported_dtypes(self, layer):
        kind = layer['type']
        defaults = ValueMutator.INPUT_DTYPES if kind == 'input_object' or kind in SHAPE_TYPES else ('float16', 'float32', 'float64')
        allowed = list(layer.get('supported_dtypes', defaults))
        for backend in self.backends:
            capabilities = layer.get('backend_supported_dtypes', {}).get(backend)
            if capabilities is not None:
                allowed = [dtype for dtype in allowed if dtype in capabilities]
        if ('tensorflow' in self.backends and
                kind in ('max_pooling3D', 'average_pooling3D')):
            allowed = [dtype for dtype in allowed if dtype == 'float32']
        if not allowed:
            raise ValueError('no common supported dtype for layer %s' % layer['args'].get('name', kind))
        return allowed

    def _dtype(self, layer, requested):
        allowed = self._supported_dtypes(layer)
        if requested in allowed:
            return requested
        for candidate in ('float32', 'float64', 'float16', 'int32', 'int64'):
            if candidate in allowed:
                return candidate
        return allowed[0]

    @staticmethod
    def _adjust(args, key, value, reason, record):
        old = args.get(key)
        if old != value:
            record['adaptations'].append({'parameter': key, 'requested': deepcopy(old),
                                          'applied': deepcopy(value), 'reason': reason})
            args[key] = value

    def _legal_args(self, layer, args, original, input_shape, record):
        kind = layer['type']
        change = lambda key, value, reason: self._adjust(args, key, value, reason, record)
        # Changing these flags changes the graph's tensor-rank/state contract.
        for key in ('return_sequences', 'keepdims'):
            if key in original:
                change(key, original[key], 'preserve_original_tensor_rank')
        for key in ('return_state', 'stateful'):
            if key in args:
                change(key, False, 'single_tensor_stateless_graph')
        if kind == 'embedding':
            # Masks require separate propagation / gradient-oracle semantics.
            change('mask_zero', False, 'unmasked_execution_contract')
        for key in ValueMutator._RATE_PARAMS:
            if key in args:
                change(key, min(max(float(args[key]), 0.0), 1.0 - 2.0**-16), 'rate_in_half_open_unit_interval')
        if 'epsilon' in args:
            change('epsilon', max(float(args['epsilon']), 2.0**-24), 'positive_epsilon')
        if kind in ('ReLU', 'leakyReLU', 'thresholded_ReLU'):
            for key in ('negative_slope', 'alpha', 'theta', 'max_value'):
                if args.get(key) is not None:
                    change(key, max(0.0, args[key]), 'nonnegative_activation_parameter')
        if 'axis' in args and input_shape:
            axis = args['axis']
            if not isinstance(axis, int) or not -len(input_shape) <= axis < len(input_shape):
                change('axis', -1, 'axis_within_input_rank')
        # Inherited layout determines spatial axes. Changing layout while only
        # changing values would silently reinterpret channel positions.
        if 'data_format' in original:
            change('data_format', original['data_format'], 'preserve_inherited_channel_layout')
        if not input_shape:
            return args
        dim = 3 if '3D' in kind else 2 if '2D' in kind else 1
        data_format = args.get('data_format', 'channels_last')
        shape = input_shape
        if kind == 'convLSTM2D':
            shape = (input_shape[0],) + tuple(input_shape[2:])
        spatial = tuple(shape[-dim-1:-1] if data_format == 'channels_last' else shape[-dim:])
        if 'conv' in kind.lower() or 'locally_connected' in kind:
            strides = _sequence(args.get('strides', 1), dim)
            dilation = _sequence(args.get('dilation_rate', 1), dim)
            for key in ('kernel_size', 'strides', 'dilation_rate'):
                if key in args:
                    change(key, _sequence(args[key], dim), 'normalise_spatial_argument_rank')
            if any(v > 1 for v in strides) and any(v > 1 for v in dilation):
                change('dilation_rate', (1,) * dim, 'strides_and_dilation_cannot_both_exceed_one')
                dilation = (1,) * dim
            if args.get('padding') == 'valid' and 'transpose' not in kind:
                kernel = _sequence(args['kernel_size'], dim)
                legal = tuple(max(1, min(k, (extent - 1) // rate + 1))
                              for k, extent, rate in zip(kernel, spatial, dilation))
                change('kernel_size', legal, 'effective_kernel_fits_spatial_input')
        elif 'pooling' in kind and not kind.startswith('global_'):
            for key in ('pool_size', 'strides'):
                if args.get(key) is not None:
                    values = _sequence(args[key], dim)
                    change(key, values[0] if dim == 1 else values, 'normalise_spatial_argument_rank')
            if args.get('padding') == 'valid':
                window = _sequence(args['pool_size'], dim)
                legal = tuple(min(v, extent) for v, extent in zip(window, spatial))
                change('pool_size', legal[0] if dim == 1 else legal, 'pool_window_fits_spatial_input')
        if kind.startswith('cropping'):
            value = args['cropping']
            if isinstance(value, int):
                pairs = [(value, value)] * dim
            elif isinstance(value[0], int):
                pairs = [tuple(value)] if dim == 1 else [(v, v) for v in value]
            else:
                pairs = [tuple(v) for v in value]
            legal = []
            for (left, right), extent in zip(pairs, spatial):
                left = max(0, min(left, extent - 1))
                right = max(0, min(right, extent - left - 1))
                legal.append((left, right))
            change('cropping', legal[0] if dim == 1 else tuple(legal), 'cropping_leaves_positive_spatial_extent')
        if kind == 'reshape':
            requested = tuple(args['target_shape'])
            total = _elements(input_shape)
            # Keep requested rank and as many trailing dimensions as divide the
            # actual input. Reshape must preserve, never invent, elements.
            target = [1] * len(requested)
            remaining = total
            for index in range(len(requested) - 1, 0, -1):
                value = requested[index]
                if isinstance(value, int) and value > 0 and remaining % value == 0:
                    target[index] = value
                    remaining //= value
            target[0] = remaining
            if math.prod(requested) != total or any(v <= 0 for v in requested):
                change('target_shape', tuple(target), 'reshape_preserves_input_element_count')
        if kind == 'permute':
            expected = set(range(1, len(input_shape)))
            if set(args['dims']) != expected or len(args['dims']) != len(expected):
                change('dims', tuple(sorted(expected)), 'permutation_matches_input_rank')
        return args

    def _output_shape(self, layer, args, inputs, record):
        kind = layer['type']
        shape = tuple(inputs[0]) if inputs else None
        if kind == 'input_object':
            return tuple(layer['output_shape'])
        if kind == 'reshape':
            return (shape[0],) + tuple(args['target_shape'])
        if kind in MERGE_TYPES:
            if kind == 'concatenate':
                axis = args.get('axis', -1) % len(shape)
                result = list(shape)
                result[axis] = sum(s[axis] for s in inputs)
                return tuple(result)
            if kind == 'dot':
                axes = args['axes']
                axes = (axes, axes) if isinstance(axes, int) else axes
                a, b = (axes[0] % len(inputs[0]), axes[1] % len(inputs[1]))
                dims = list(inputs[0][1:a]) + list(inputs[0][a+1:]) + list(inputs[1][1:b]) + list(inputs[1][b+1:])
                return (shape[0],) + tuple(dims or [1])
            return shape
        if kind in ('time_distributed', 'bidirectional'):
            inner = args['layer']
            inner_shape = ((shape[0],) + shape[2:]) if kind == 'time_distributed' else shape
            self._mutate_layer(inner, [inner_shape], record['requested_dtype'], record['nested_layers'])
            out = tuple(inner['output_shape'])
            if kind == 'time_distributed':
                return (shape[0], shape[1]) + out[1:]
            return out[:-1] + (out[-1] * 2,) if args.get('merge_mode') == 'concat' else out
        spec = SHAPE_RECALC_MAP.get(kind)
        if spec is None:
            raise ValueError('no output-shape contract for layer %s' % kind)
        method, extra = spec
        kwargs = dict(args)
        # Some methods supply a fixed 1-D channel layout internally.
        if kind.endswith('pooling1D'):
            kwargs.pop('data_format', None)
        kwargs.update(extra)
        return tuple(getattr(self.shape_calculator, method)(shape, **kwargs))

    def _mutate_layer(self, layer, inputs, dtype, records):
        original = deepcopy(layer['args'])
        kind = layer['type']
        name = original.get('name', kind)
        record = {'layer': name, 'type': kind, 'operators': [], 'adaptations': [],
                  'requested_dtype': dtype, 'nested_layers': []}
        self.value_mutator.last_changes = {}
        pv = self.value_mutator.parameter_value(kind, deepcopy(original))
        bv = self.value_mutator.boundary_value(kind, deepcopy(pv), inputs[0] if inputs else None)
        for op, before, after in (('pv', original, pv), ('bv', pv, bv)):
            changes = {key: [deepcopy(before.get(key)), deepcopy(value)]
                       for key, value in after.items() if value != before.get(key)}
            record[op] = {'status': ('changed' if changes else 'not_applicable')
                          if self.config.is_enabled(op) else 'disabled', 'changes': changes}
            if self.config.is_enabled(op):
                record['operators'].append(op)
        args = self._legal_args(layer, bv, original, inputs[0] if inputs else None, record)
        target_dtype = self._dtype(layer, dtype if self.config.is_enabled('it') else original.get('dtype', 'float32'))
        if self.config.is_enabled('it') or 'dtype' in original:
            self._adjust(args, 'dtype', target_dtype, 'supported_layer_dtype', record)
        record['it'] = {'status': 'applied' if self.config.is_enabled('it') else 'disabled',
                        'requested': dtype, 'applied': target_dtype,
                        'supported': self._supported_dtypes(layer)}
        if self.config.is_enabled('it'):
            record['operators'].append('it')
        # Integer IT inputs may require a floating compute policy. The explicit
        # input_casts plan below performs this conversion before kernel calls.
        layer['args'] = args
        output = self._output_shape(layer, args, inputs, record)
        if not _shape_ok(output) and kind not in ('time_distributed', 'bidirectional'):
            # Project expansive parameters into the execution resource domain,
            # retaining all other PV/BV changes and recording every adjustment.
            for key in ('size', 'n', 'filters', 'units', 'depth_multiplier', 'output_dim'):
                if key in args:
                    safe = tuple(1 for _ in args[key]) if isinstance(args[key], (tuple, list)) else 1
                    self._adjust(args, key, safe, 'activation_resource_bound', record)
                    output = self._output_shape(layer, args, inputs, record)
                    if _shape_ok(output):
                        break
        if not _shape_ok(output):
            raise ValueError('mutated layer exceeds shape/resource contract: %s %s' % (name, output))
        if not ValueMutator.valid_layer_args(kind, args, inputs[0] if inputs else None):
            raise ValueError('could not adapt mutation to layer contract: %s' % name)
        layer['output_shape'] = list(output)
        layer['mutation_input_shapes'] = [list(s) for s in inputs]
        record['input_adaptations'] = []
        nested_index_bounds = args.get('layer', {}).get('input_index_bounds') if kind == 'time_distributed' else None
        needs_indices = kind == 'embedding' or nested_index_bounds is not None
        if inputs and (self.config.is_enabled('it') or needs_indices):
            # Explicit edge casts are needed because layer autocasting does not
            # universally convert integer tensors to floating compute policies.
            cast_dtype = 'int32' if needs_indices else target_dtype
            layer['input_casts'] = [cast_dtype] * len(inputs)
            for index in range(len(inputs)):
                record['input_adaptations'].append({
                    'input_index': index, 'requested_dtype': dtype,
                    'applied_dtype': cast_dtype, 'method': 'cast',
                    'reason': 'embedding_integer_indices' if needs_indices
                              else 'explicit_supported_layer_input_dtype'})
            if needs_indices:
                bounds = ({'min': 0, 'max_exclusive': int(args['input_dim'])}
                          if kind == 'embedding' else deepcopy(nested_index_bounds))
                layer['input_index_bounds'] = bounds
                record['input_adaptations'].append({
                    'method': 'clip_before_cast', 'bounds': deepcopy(bounds),
                    'reason': 'embedding_indices_within_vocabulary'})
        layer['mutations'] = {op: deepcopy(record[op]) for op in VALUE_OPERATORS}
        layer['mutation_adaptations'] = deepcopy(record['adaptations'])
        record['final_changes'] = {key: [deepcopy(original.get(key)), deepcopy(value)]
                                   for key, value in args.items() if value != original.get(key)}
        records.append(record)
        return output

    def _adapter(self, structure, predecessor, source, target, name, dtype, record):
        """Use serialisable built-ins to reconcile one incompatible merge edge."""
        if tuple(source) == tuple(target):
            return predecessor
        current = predecessor
        def append(kind, args, out):
            nonlocal current
            key = str(self._next_id)
            self._next_id += 1
            structure[key] = {'type': kind,
                'args': dict(args, name='mutation_adapter_%s_%s' % (name, key), dtype=dtype),
                'pre_layers': [int(current)], 'output_shape': list(out),
                'mutation_adapter': True}
            current = key
        have, need = _elements(source), _elements(target)
        if have != need:
            append('reshape', {'target_shape': (have, 1)}, (source[0], have, 1))
            if have < need:
                append('zero_padding1D', {'padding': (0, need - have)}, (source[0], need, 1))
            else:
                append('cropping1D', {'cropping': (0, have - need)}, (source[0], need, 1))
        append('reshape', {'target_shape': tuple(target[1:])}, target)
        record.append({'from_layer': str(predecessor), 'to_layer': name,
                       'source_shape': list(source), 'target_shape': list(target),
                       'method': 'reshape' if have == need else 'flatten_pad_or_crop_reshape',
                       'reason': 'reconcile_graph_shape_contract'})
        return int(current)

    def mutate_model(self, original, input_dtype='float32'):
        original = ModelInfoGenerator.canonical_model_info(deepcopy(original))
        input_layers = [original['model_structure'][str(i)] for i in original['input_id_list']]
        original_dtypes = [layer['args'].get('dtype') or input_dtype for layer in input_layers]
        baseline_dtype = original_dtypes[0] if len(set(original_dtypes)) == 1 else input_dtype
        requested_dtype = self.value_mutator.input_type(baseline_dtype)
        input_allowed = [self._supported_dtypes(original['model_structure'][str(i)])
                         for i in original['input_id_list']]
        common = [d for d in ValueMutator.INPUT_DTYPES if all(d in options for options in input_allowed)]
        if not common:
            raise ValueError('model input layers have no common supported dtype')
        actual_input_dtype = requested_dtype if requested_dtype in common else next(
            (d for d in ('float32', 'float64', 'float16', 'int32', 'int64') if d in common), common[0])
        plan = {'value_operators': [op for op in VALUE_OPERATORS if self.config.is_enabled(op)],
                'requested_dtype': requested_dtype, 'input_dtype': actual_input_dtype,
                'layers': [], 'edge_adaptations': [], 'source': 'completed_original_model',
                'backends': list(self.backends)}
        graph = deepcopy(original)
        built = {}
        self._next_id = max(int(k) for k in original['model_structure']) + 1
        for key, layer in graph['model_structure'].items():
            parents = list(layer.get('pre_layers', []))
            inputs = [tuple(built[str(p)]['output_shape']) for p in parents]
            if layer['type'] in MERGE_TYPES and inputs:
                original_inputs = [tuple(original['model_structure'][str(p)]['output_shape']) for p in parents]
                # Preserve the original legal merge signature for all branches;
                # this covers concatenate axes and asymmetric Dot contractions.
                for index, (source, target) in enumerate(zip(inputs, original_inputs)):
                    parents[index] = self._adapter(built, parents[index], source, target,
                        layer['args'].get('name', key), self._dtype(layer, requested_dtype), plan['edge_adaptations'])
                layer['pre_layers'] = parents
                inputs = original_inputs
            output = self._mutate_layer(layer, inputs,
                actual_input_dtype if layer['type'] == 'input_object' else requested_dtype,
                plan['layers'])
            plan['layers'][-1]['layer_id'] = key
            if layer['type'] == 'input_object':
                if not self.config.is_enabled('it'):
                    actual_layer_dtype = original['model_structure'][key]['args'].get('dtype') or input_dtype
                else:
                    actual_layer_dtype = actual_input_dtype
                layer['args']['dtype'] = actual_layer_dtype
                plan['layers'][-1]['it']['requested'] = requested_dtype
                plan['layers'][-1]['it']['applied'] = actual_layer_dtype
            built[key] = layer
        graph['model_structure'] = built
        if self.preserve_output_shapes:
            outputs = []
            for identifier in graph['output_id_list']:
                key = str(identifier)
                source = tuple(built[key]['output_shape'])
                target = tuple(original['model_structure'][key]['output_shape'])
                outputs.append(self._adapter(built, identifier, source, target, 'output_' + key,
                    built[key]['args'].get('dtype', 'float32'), plan['edge_adaptations']))
            graph['output_id_list'] = outputs
        graph = ModelInfoGenerator.canonical_model_info(graph)
        enabled = [op for op in NEURON_OPERATORS if self.config.is_enabled(op)]
        # Value-only ablations still produce one concrete descendant.
        variants = enabled or ['none']
        return [{'name': op, 'neuron_operator': None if op == 'none' else op,
                 'model_info': deepcopy(graph), 'input_dtype': actual_input_dtype,
                 'mutation_plan': deepcopy(dict(plan, neuron_operator=None if op == 'none' else op))}
                for op in variants]
