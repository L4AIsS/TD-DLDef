"""Deterministic inheritance of baseline weights after graph value mutation.

PV/BV can change units, kernel sizes or use_bias. Equal-size tensors reshape;
different-size tensors repeat/crop their flattened baseline values. Newly
introduced variables use zeros (moving variance uses ones), never fresh RNG.
Every conversion is recorded separately from the selected neuron operator.
"""
import hashlib
import json
from pathlib import Path

import numpy as np

from utils.runtime import InvalidTest, write_json


def checksum(array):
    return hashlib.sha256(np.ascontiguousarray(array).view(np.uint8)).hexdigest()


def variable_keys(layer, count):
    variables = getattr(layer, 'weights', [])
    keys = []
    for i in range(count):
        if i < len(variables):
            var = variables[i]
            key = str(getattr(var, 'path', getattr(var, 'name', 'arr_%d' % i)))
            prefix = layer.name + '/'
            key = key.split(prefix, 1)[-1].split(':', 1)[0]
        else:
            key = 'arr_%d' % i
        keys.append(key)
    if len(set(keys)) != len(keys):
        raise InvalidTest('ambiguous variable identities in layer %s' % layer.name)
    return keys


def save_weight_manifest(model, weights_dir):
    manifest = {'format_version': 1, 'layers': {}}
    for layer in model.layers:
        arrays = layer.get_weights()
        manifest['layers'][layer.name] = [
            {'key': key, 'shape': list(w.shape), 'dtype': str(w.dtype), 'checksum': checksum(w)}
            for key, w in zip(variable_keys(layer, len(arrays)), arrays)]
    write_json(Path(weights_dir).parent / 'weights_manifest.json', manifest)
    return manifest


def restore_source_weights(model, source_weight_dir):
    """Restore/adapt one completed original into a new model; never mutate source."""
    source_dir = Path(source_weight_dir)
    if not source_dir.is_dir():
        raise InvalidTest('original weight directory is missing: %s' % source_dir)
    manifest_path = source_dir.parent / 'weights_manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.exists() else {}
    records = []
    for layer in model.layers:
        targets = layer.get_weights()
        if not targets:
            continue  # Native shape adapter/Input layers have no weight files.
        source_path = source_dir / (layer.name + '.npz')
        if not source_path.is_file():
            raise InvalidTest('original layer weights are missing: %s' % layer.name)
        with np.load(source_path, allow_pickle=False) as archive:
            originals = [archive['arr_%d' % i].copy() for i in range(len(archive.files))]
        entries = manifest.get('layers', {}).get(layer.name)
        if entries is not None:
            if len(entries) != len(originals):
                raise InvalidTest('original weight manifest length mismatch: %s' % layer.name)
            for entry, w in zip(entries, originals):
                if entry['checksum'] != checksum(w):
                    raise InvalidTest('original weight checksum mismatch: %s' % layer.name)
            source_keys = [entry['key'] for entry in entries]
        else:
            # Backward-compatible positional replay is only safe at equal count.
            if len(originals) != len(targets):
                raise InvalidTest('variable-count adaptation requires original weights_manifest.json')
            source_keys = variable_keys(layer, len(originals))
        by_key = dict(zip(source_keys, originals))
        inherited = []
        target_keys = variable_keys(layer, len(targets))
        for key, target in zip(target_keys, targets):
            before = by_key.get(key)
            actions = []
            if before is None:
                value = np.ones_like(target) if key.split('/')[-1] == 'moving_variance' else np.zeros_like(target)
                actions.append('new_variable_ones' if key.split('/')[-1] == 'moving_variance' else 'new_variable_zeros')
            else:
                if before.size == target.size:
                    value = before.reshape(target.shape).copy()
                    if before.shape != target.shape:
                        actions.append('reshape_equal_elements')
                elif before.size:
                    value = np.resize(before.reshape(-1), target.size).reshape(target.shape)
                    actions.append('repeat_or_crop_flattened_original')
                else:
                    raise InvalidTest('cannot adapt an empty original weight tensor')
                if value.dtype != target.dtype:
                    if np.issubdtype(target.dtype, np.floating):
                        limit = np.finfo(target.dtype).max
                        finite = np.isfinite(value)
                        clipped = finite & (np.abs(value) > limit)
                        if np.any(clipped):
                            value = np.where(finite, np.clip(value, -limit, limit), value)
                            actions.append('clip_to_target_finite_range')
                    value = value.astype(target.dtype)
                    actions.append('cast_dtype')
            inherited.append(value)
            records.append({'layer': layer.name, 'variable': key,
                            'source_shape': list(before.shape) if before is not None else None,
                            'target_shape': list(target.shape),
                            'source_dtype': str(before.dtype) if before is not None else None,
                            'target_dtype': str(target.dtype), 'adaptations': actions,
                            'source_checksum': checksum(before) if before is not None else None,
                            'inherited_checksum': checksum(value)})
        layer.set_weights(inherited)
        actual = layer.get_weights()
        if len(actual) != len(inherited) or any(
                a.shape != b.shape or a.dtype != b.dtype or not np.array_equal(a, b, equal_nan=True)
                for a, b in zip(actual, inherited)):
            raise InvalidTest('source weight restoration did not round-trip: %s' % layer.name)
        dropped = sorted(set(source_keys) - set(target_keys))
        if dropped:
            records.append({'layer': layer.name, 'removed_variables': dropped,
                            'adaptations': ['variable_disabled_by_value_mutation']})
    return {'source_weight_dir': str(source_dir), 'policy': 'reshape_or_repeat_crop_then_cast',
            'new_variable_policy': 'zeros_except_moving_variance_ones', 'variables': records}
