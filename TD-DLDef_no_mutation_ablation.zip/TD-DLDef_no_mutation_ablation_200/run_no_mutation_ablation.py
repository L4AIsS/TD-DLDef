#!/usr/bin/env python3
"""Paired, structure-only no-mutation ablations using the supplied TD-DLDef code.

The source project is imported without edits. Every group has an attempt budget,
not a success quota. A uses the existing DIV/TS-RCS selector; B uniformly samples
the same condition-filtered candidate pool, with no DIV gate or TS posterior.
Only complete generated original graphs enter the unchanged paper_v2 tracker.
No ModelMutator, backend model construction, weights, or training is executed.
"""

import argparse
from collections import Counter
import contextlib
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import random
import sys
import time
import traceback

import numpy as np


CONFIGS = ("div_ts_rcs_no_mutation", "random_no_div_no_mutation")


def sha256_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True,
                                    separators=(",", ":")).encode("utf-8")).hexdigest()


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def load_project(project_root):
    sys.path.insert(0, str(Path(project_root).resolve()))
    from scripts.run_ablation_exp1 import (MODEL_CONFIG, INPUT_SHAPE, OUTPUT_SHAPE,
                                          NODE_NUM, ALL_SPACES, source_digest)
    from utils.framework_config import NEW_FRAMEWORKS, OLD_FRAMEWORKS, get_framework_config
    from utils.selection import Selector
    from utils.mutation import MutationConfig
    from utils.coverage import CoverageTracker
    from utils.db_manager import DbManager
    from src.cases_generation.model_info_generator import ModelInfoGenerator
    return locals()


class UniformRandomSelector:
    """The same availability filter as Selector; uniform choice, no feedback."""

    def __init__(self, layer_types, layer_conditions):
        self.allowed = set(layer_types)
        self.conditions = dict(layer_conditions)
        self.selected = Counter()
        self.admitted = Counter()

    def choose_element(self, pool, **kwargs):
        candidates = []
        for name in pool:
            if name not in self.allowed:
                continue
            condition = self.conditions.get(name)
            if condition is None or condition(**kwargs):
                candidates.append(name)
        if not candidates:
            return None
        # Keep selection draws on NumPy's seeded stream, as the existing TS
        # selector does; structural parameter draws use Python's random stream.
        choice = candidates[int(np.random.randint(len(candidates)))]
        self.selected[choice] += 1
        return choice

    def admit_candidate(self, name, **kwargs):
        self.admitted[name] += 1
        return True

    def reset_model_state(self):
        pass

    def finish_model_state(self):
        pass

    def record_committed_layer(self, name, **kwargs):
        pass


def make_tracker(api, framework):
    cfg = api["get_framework_config"](framework)
    model_config = api["MODEL_CONFIG"]
    return api["CoverageTracker"](
        cfg.layer_types, cfg.layer_conditions,
        activation_pool=cfg.activation_pool, padding_pool=cfg.padding_pool,
        element_range=model_config["var"]["tensor_element_size_range"],
        dim_range=model_config["var"]["tensor_dimension_range"],
        metric_mode="paper_v2"), cfg


def assert_no_mutations(model_info):
    for layer in model_info["model_structure"].values():
        if layer.get("mutations"):
            raise AssertionError("Unexpected per-layer mutation evidence in original graph")
    if model_info.get("mutation_plan") or model_info.get("model_mutations"):
        raise AssertionError("Unexpected model mutation evidence in original graph")


def verify_group(api, group_dir, expected):
    """Recompute unchanged metrics from saved successful models, without sampling."""
    tracker, _ = make_tracker(api, expected["framework_pool"])
    records = [json.loads(line) for line in
               (Path(group_dir) / "records.jsonl").read_text(encoding="utf-8").splitlines()]
    assert len(records) == expected["attempted_models"] == expected["requested_attempts"]
    assert [r["attempt_index"] for r in records] == list(range(1, len(records) + 1))
    success = 0
    for record in records:
        if record["status"] != "structure_generated":
            assert "model_info" not in record
            continue
        model = record["model_info"]
        assert_no_mutations(model)
        assert canonical_hash(model) == record["model_sha256"]
        assert record["input_dtype"] == "float32"
        tracker.record_model(model, input_dtype=record["input_dtype"])
        success += 1
    recomputed = tracker.summary()
    for key, value in recomputed.items():
        assert expected[key] == value, (key, expected[key], value)
    assert expected["success_models"] == success
    assert expected["fail_models"] == len(records) - success
    assert expected["coverage_detail"] == tracker.detail()
    return {"status": "passed", "records_checked": len(records),
            "successful_model_hashes_checked": success,
            "metric_recomputation_equal": True,
            "recomputed_summary": recomputed}


def run_group(api, framework, config, n_models, seed, out_dir, provenance):
    started = time.monotonic()
    random.seed(seed)
    np.random.seed(seed)
    tracker, cfg = make_tracker(api, framework)
    is_div = config == CONFIGS[0]
    selector = (api["Selector"](cfg.layer_types, cfg.layer_conditions,
                                diversity_spaces=list(api["ALL_SPACES"]))
                if is_div else UniformRandomSelector(cfg.layer_types, cfg.layer_conditions))
    generator = api["ModelInfoGenerator"](
        api["MODEL_CONFIG"], api["DbManager"](":memory:"), selector, "seq",
        mutation_config=api["MutationConfig"]([], seed), coverage_tracker=tracker,
        layer_types=cfg.layer_types, layer_conditions=cfg.layer_conditions)
    group_dir = Path(out_dir) / framework / config
    group_dir.mkdir(parents=True, exist_ok=False)
    failures = Counter()
    nodes = Counter()
    success = 0
    with (group_dir / "records.jsonl").open("w", encoding="utf-8") as records:
        for index in range(1, n_models + 1):
            attempt_started = time.monotonic()
            record = {"attempt_index": index, "framework_pool": framework,
                      "ablation": config, "input_dtype": "float32"}
            log_path = group_dir / "generation_logs" / (f"{index:06d}.log")
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with log_path.open("w", encoding="utf-8") as log:
                try:
                    selector.reset_model_state()
                    with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
                        model_info, _, _, node_num = generator.generate_seq_model(
                            node_num=api["NODE_NUM"], input_shape=api["INPUT_SHAPE"],
                            output_shape=api["OUTPUT_SHAPE"])
                        model_info = generator.canonical_model_info(model_info)
                        assert_no_mutations(model_info)
                    # Freeze the exact JSON-compatible graph before counting it;
                    # this is the same graph later used for independent replay.
                    model_info = json.loads(json.dumps(model_info))
                    tracker.record_model(model_info, input_dtype="float32")
                    success += 1
                    nodes[node_num] += 1
                    record.update(status="structure_generated", model_info=model_info,
                                  node_count=node_num, model_sha256=canonical_hash(model_info))
                except Exception as exc:
                    status = ("tool_resource_rejection" if "Shape too big" in str(exc)
                              else "tool_generation_error")
                    failures[status] += 1
                    record.update(status=status, exception_type=type(exc).__name__, message=str(exc))
                    traceback.print_exc(file=log)
                finally:
                    selector.finish_model_state()
            record["duration_seconds"] = round(time.monotonic() - attempt_started, 6)
            record["generation_log"] = str(log_path.relative_to(Path(out_dir)))
            records.write(json.dumps(record, ensure_ascii=False) + "\n")
            records.flush()
    summary = tracker.summary()
    summary.update({
        "framework_pool": framework, "ablation": config, "seed": seed,
        "requested_attempts": n_models, "attempted_models": n_models,
        "success_models": success, "fail_models": n_models - success,
        "failures_by_type": dict(failures),
        "node_count_distribution": {str(k): v for k, v in sorted(nodes.items())},
        "enabled_spaces": list(api["ALL_SPACES"]) if is_div else [],
        "sampling": "source_TS-RCS" if is_div else "uniform_random_after_compatibility_filter",
        "enabled_mutations": [], "mutation_pipeline_invoked": False,
        "model_generation_mode": "seq", "requested_node_positions": api["NODE_NUM"],
        "input_shape": list(api["INPUT_SHAPE"]), "output_shape": list(api["OUTPUT_SHAPE"]),
        "input_dtype": "float32", "model_config": api["MODEL_CONFIG"],
        "coverage_scope": "generated_complete_original_structures_only",
        "framework_execution_performed": False,
        "framework_label_is_configuration_only": True,
        "actual_backends_executed": [],
        "coverage_detail": tracker.detail(),
        "attempted_layers_diagnostic_only": dict(tracker.attempt_cnt),
        "duration_seconds": round(time.monotonic() - started, 6),
        "provenance": provenance,
    })
    if is_div:
        summary["diversity"] = selector.diversity_summary()
        summary["selector_posterior_observation_counts"] = selector.get_single_record()
        summary["ts_final_posteriors"] = {name: selector.posterior_params(name) for name in cfg.layer_types}
    else:
        summary["diversity"] = {"evaluation_performed": False}
        summary["selector_draw_counts"] = dict(selector.selected)
        summary["selector_admission_counts"] = dict(selector.admitted)
        summary["ts_posterior_updates"] = 0
    summary["verification"] = verify_group(api, group_dir, summary)
    write_json(group_dir / "summary.json", summary)
    return summary


def write_aggregate(out_dir, metadata, summaries, status):
    import csv
    out_dir = Path(out_dir)
    write_json(out_dir / "results.json", {"meta": metadata, "status": status, "results": summaries})
    columns = ["framework_pool", "ablation", "seed", "requested_attempts", "attempted_models",
               "success_models", "fail_models", "LIC", "LPC", "LSC", "LIC_cov", "LIC_denom",
               "LPC_cov", "LPC_denom", "LSC_cov_seq", "LSC_denom", "covered_layer_types",
               "total_layer_types", "duration_seconds"]
    with (out_dir / "summary.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows({k: row[k] for k in columns} for row in summaries)


class Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, value):
        for stream in self.streams:
            stream.write(value)

    def flush(self):
        for stream in self.streams:
            stream.flush()


def main():
    base = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=base / "code" / "TD-DLDef")
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--models", type=int, default=200, help="Attempts per pool/configuration")
    parser.add_argument("--seed", type=int, default=2024)
    parser.add_argument("--fw", nargs="+", help="One or more exact source framework-pool labels")
    parser.add_argument("--input-zip", type=Path, default=base / "upload" / "TD-DLDef_update_1020.zip")
    parser.add_argument("--verify-only", action="store_true", help="Recompute metrics from existing saved models")
    args = parser.parse_args()
    if args.models <= 0:
        parser.error("--models must be positive")
    api = load_project(args.project_root)
    source_sha = api["source_digest"]()
    if args.verify_only:
        saved = json.loads((args.out_dir / "results.json").read_text(encoding="utf-8"))
        assert saved["meta"]["provenance"]["source_sha256"] == source_sha, "Source fingerprint differs"
        checks = []
        for row in saved["results"]:
            group = args.out_dir / row["framework_pool"] / row["ablation"]
            check = verify_group(api, group, row)
            checks.append({"framework_pool": row["framework_pool"], "ablation": row["ablation"], **check})
        result = {"status": "passed", "groups_verified": len(checks), "groups": checks}
        write_json(args.out_dir / "reverification.json", result)
        print(json.dumps({"status": "passed", "groups_verified": len(checks)}, ensure_ascii=False))
        return
    frameworks = args.fw or api["NEW_FRAMEWORKS"] + api["OLD_FRAMEWORKS"]
    known = api["NEW_FRAMEWORKS"] + api["OLD_FRAMEWORKS"]
    if any(fw not in known for fw in frameworks) or len(set(frameworks)) != len(frameworks):
        parser.error("--fw must contain distinct known framework-pool labels")
    if args.out_dir.exists() and any(args.out_dir.iterdir()):
        parser.error("--out-dir must be absent or empty; existing evidence will not be overwritten")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    provenance = {
        "source_sha256": source_sha,
        "driver_sha256": sha256_file(__file__),
        "input_archive_name": args.input_zip.name if args.input_zip.is_file() else None,
        "input_archive_sha256": sha256_file(args.input_zip) if args.input_zip.is_file() else None,
    }
    metadata = {
        "experiment": "paired_no_mutation_structure_coverage",
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "seed": args.seed, "attempts_per_group": args.models,
        "framework_pools": frameworks, "configurations": list(CONFIGS),
        "environment": {"python": platform.python_version(), "numpy": np.__version__,
                        "platform": platform.platform()},
        "provenance": provenance,
        "metric_mode": "paper_v2", "shape_and_numeric_domain_sigma": 5,
        "LIC_aggregation": "arithmetic mean of per-layer ratios, NOT LIC_cov / LIC_denom",
        "framework_execution_performed": False,
        "limitations": [
            "Structural coverage only; no backend model construction or execution was performed.",
            "Framework labels select supplied compatibility tables, not installed runtime versions.",
            "Dtypes without execution metadata are estimates under the source compute-policy rules.",
            "Shape and numeric parameter domains use the source sigma=5 finite approximation.",
            "A single seed is a paired observation, not an estimate of variance or statistical significance.",
            "Source TS-RCS is preserved, including its current inverse-Beta-sample scoring.",
            "Attempt budget includes failures; unsuccessful attempts are not replaced or counted in coverage.",
        ],
    }
    summaries = []
    with (args.out_dir / "run.log").open("w", encoding="utf-8") as log:
        with contextlib.redirect_stdout(Tee(sys.stdout, log)):
            print(json.dumps(metadata, ensure_ascii=False, indent=2), flush=True)
            for fw in frameworks:
                for config in CONFIGS:
                    print(f"Running {fw} / {config}, attempts={args.models}, seed={args.seed}", flush=True)
                    summary = run_group(api, fw, config, args.models, args.seed, args.out_dir, provenance)
                    summaries.append(summary)
                    write_aggregate(args.out_dir, metadata, summaries, "in_progress")
                    print(f"  success={summary['success_models']}/{args.models}; LIC={summary['LIC']}%; "
                          f"LPC={summary['LPC']}%; LSC={summary['LSC']}%; replay=passed", flush=True)
            assert api["source_digest"]() == source_sha, "Source changed during experiment"
            metadata["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
            metadata["source_unchanged_during_run"] = True
            write_aggregate(args.out_dir, metadata, summaries, "completed")
            print(f"Completed {len(summaries)} groups; saved to {args.out_dir}", flush=True)


if __name__ == "__main__":
    main()
