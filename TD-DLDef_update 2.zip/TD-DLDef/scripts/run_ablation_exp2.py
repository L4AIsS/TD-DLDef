# -*- coding: utf-8 -*-
"""Reproducible model-pool ablations on actual TensorFlow / PyTorch backends.

Pool labels describe generation constraints, never an executed framework version.
All observations are candidates or diagnostics, not confirmed unique defects.
Outputs are fresh, with source/config/environment metadata and per-case replay.
"""

import argparse
import contextlib
import io
import json
import os
import random
import sys
import time
from pathlib import Path

PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
sys.path.insert(0, PROJECT_ROOT)


# ---------------------------------------------------------------------- #
# 消融配置 (与 run_ablation_exp1.py 完全一致)
# ---------------------------------------------------------------------- #
ALL_SPACES = ['layer', 'edge', 'shape', 'dim']
ALL_OPS = ['pv', 'bv', 'it', 'nf', 'ws', 'wr']

SPACE_ABLATIONS = {
    'full': ALL_SPACES,
    'no_layer': [s for s in ALL_SPACES if s != 'layer'],
    'no_edge': [s for s in ALL_SPACES if s != 'edge'],
    'no_shape': [s for s in ALL_SPACES if s != 'shape'],
    'no_dim': [s for s in ALL_SPACES if s != 'dim'],
}

MUTATION_ABLATIONS = {
    'full': ALL_OPS,
    'no_pv': [o for o in ALL_OPS if o != 'pv'],
    'no_bv': [o for o in ALL_OPS if o != 'bv'],
    'no_it': [o for o in ALL_OPS if o != 'it'],
    'no_nf': [o for o in ALL_OPS if o != 'nf'],
    'no_ws': [o for o in ALL_OPS if o != 'ws'],
    'no_wr': [o for o in ALL_OPS if o != 'wr'],
}

ABLATION_ORDER = ['full'] + list(SPACE_ABLATIONS)[1:] + list(MUTATION_ABLATIONS)[1:]

# 新框架共享 Keras 3 全量层池 (framework_config 中三者为同一层池), 只实际运行一次;
# 老框架各用独立受限层池。
FRAMEWORK_POOLS = {
    'tensorflow2.16.1': 'keras3.10',
    'pytorch2.2.0': 'keras3.10',
    'keras3.10': 'keras3.10',
    'tensorflow2.0.0': 'tensorflow2.0.0',
    'cntk2.7.0': 'cntk2.7.0',
    'theano1.0.4': 'theano1.0.4',
}
UNIQUE_POOLS = ['keras3.10', 'tensorflow2.0.0', 'cntk2.7.0', 'theano1.0.4']
NEW_FRAMEWORKS = ['tensorflow2.16.1', 'pytorch2.2.0', 'keras3.10']
OLD_FRAMEWORKS = ['tensorflow2.0.0', 'cntk2.7.0', 'theano1.0.4']

MODEL_CONFIG = {
    'var': {
        'tensor_dimension_range': (2, 5),
        'tensor_element_size_range': (2, 5),
        'weight_value_range': (-10.0, 10.0),
        'small_value_range': (0, 1),
        'vocabulary_size': 1001,
    },
    'node_num_range': (8, 8),
    'dag_io_num_range': (1, 3),
    'dag_max_branch_num': 2,
    'cell_num': 3,
    'node_num_per_normal_cell': 10,
    'node_num_per_reduction_cell': 2,
}

INPUT_SHAPE = (None, 6, 6, 3)
OUTPUT_SHAPE = (None, 4)
NODE_NUM = 8
INPUT_DTYPES = ('float16', 'float32', 'float64', 'int8', 'int16', 'int32', 'int64', 'uint8')
BACKENDS = ('tensorflow', 'torch')
CASE_NUM = 200          # 默认每个消融配置生成 200 个模型


def model_io_shapes(model_info):
    """Read the actual named interfaces of an already completed graph."""
    structure = {str(key): value for key, value in model_info['model_structure'].items()}
    def shapes(field):
        return {structure[str(key)]['args']['name']: tuple(structure[str(key)]['output_shape'])
                for key in model_info[field]}
    return shapes('input_id_list'), shapes('output_id_list')


def save_mutant_case(db, original_case, original_id, variant):
    """Register a mutant without feeding it back into original-graph selection."""
    from utils.runtime import write_json
    from src.cases_generation.model_info_generator import ModelInfoGenerator
    model_info = ModelInfoGenerator.canonical_model_info(variant['model_info'])
    model_id = db.register_model(model_info.get('dataset_name'), len(model_info['model_structure']))
    exp_dir = Path(original_case) / 'mutants' / variant['name']
    model_dir = exp_dir / 'models'
    model_dir.mkdir(parents=True, exist_ok=True)
    json_path = model_dir / 'model.json'
    write_json(json_path, model_info)
    write_json(model_dir / 'mutation_plan.json', variant['mutation_plan'])
    write_json(model_dir / 'mutation_lineage.json', {
        'original_model_id': original_id, 'relative_to': 'case_directory',
        'original_case': '../..',
        'original_weights': '../../models/initial_weights',
        'neuron_operator': variant['neuron_operator'],
        'value_mutations_shared_between_siblings': True,
        'starts_from_original_weights': True,
    })
    input_shapes, output_shapes = model_io_shapes(model_info)
    return json_path, input_shapes, output_shapes, model_id, str(exp_dir)


def run_one(pool_name: str, ablation: str, n_models: int, seed: int, threshold: float,
            timeout: float, out_root: str, execution_path: str = 'single_step',
            batch_size: int = 32) -> dict:
    """运行一个 (层池, 消融配置) 组合, 返回缺陷 + LIC/LPC/LSC 统计 summary"""
    if execution_path not in ('single_step', 'one_epoch'):
        raise ValueError('execution_path must be single_step or one_epoch')
    if isinstance(batch_size, bool) or not isinstance(batch_size, int) or batch_size <= 0:
        raise ValueError('batch_size must be a positive integer')
    from utils.framework_config import get_framework_config
    from utils.selection import Selector
    from utils.mutation import MutationConfig
    from utils.model_mutation import ModelMutator
    from utils.coverage import CoverageTracker
    from utils.oracle import DefectCollector
    from utils.defect_report import DefectReporter
    from utils.db_manager import DbManager
    from src.cases_generation.model_info_generator import ModelInfoGenerator
    from src.cases_generation.model_generator import ModelGenerator
    from src.cases_generation.data_generator import DataGenerator
    from src.incons_detection.trainer import Trainer
    from src.incons_detection.comparator import Comparator

    import numpy as np
    from utils.reproducibility import capture_case, source_digest
    np.random.seed(seed)
    random.seed(seed)   # 同时固定模块级 random (值突变/神经元突变内部使用)
    fw_cfg = get_framework_config(pool_name)
    source_hash = source_digest(PROJECT_ROOT)

    # 依据消融配置解析启用的空间与算子 (与实验 1 相同)
    if ablation in SPACE_ABLATIONS:
        enabled_spaces = SPACE_ABLATIONS[ablation]
        enabled_ops = ALL_OPS                       # 空间消融: 突变算子不变
    else:
        enabled_spaces = ALL_SPACES                 # 算子消融: 空间评估不变
        enabled_ops = MUTATION_ABLATIONS[ablation]

    db = DbManager(':memory:')
    selector = Selector(fw_cfg.layer_types, fw_cfg.layer_conditions,
                        diversity_spaces=enabled_spaces)
    mutation_cfg = MutationConfig(enabled=enabled_ops, seed=seed)
    model_mutator = ModelMutator(mutation_cfg, backends=BACKENDS)
    # 覆盖率追踪器: 框架适配的参数空间
    tracker = CoverageTracker(fw_cfg.layer_types, fw_cfg.layer_conditions,
                              activation_pool=fw_cfg.activation_pool,
                              padding_pool=fw_cfg.padding_pool,
                              element_range=MODEL_CONFIG['var']['tensor_element_size_range'],
                              dim_range=MODEL_CONFIG['var']['tensor_dimension_range'])
    # 缺陷明细记录器 (定位层 + 源码片段)
    reporter = DefectReporter(framework=pool_name, ablation=ablation)
    gen = ModelInfoGenerator(MODEL_CONFIG, db, selector, 'seq',
                             mutation_config=MutationConfig([], seed), coverage_tracker=tracker,
                             layer_types=fw_cfg.layer_types,
                             layer_conditions=fw_cfg.layer_conditions)
    model_gen = ModelGenerator(MODEL_CONFIG['var']['weight_value_range'], list(BACKENDS), db, selector,
                               timeout, coverage_tracker=tracker, input_dtype='float32',
                               defect_reporter=reporter, mutation_seed=seed)
    trainer = Trainer(db, timeout, defect_reporter=reporter)
    comparator = Comparator(db, threshold=threshold, defect_reporter=reporter)
    collector = DefectCollector(list(BACKENDS), threshold=threshold)

    output_dir = Path(out_root) / pool_name / ablation
    output_dir.mkdir(parents=True, exist_ok=True)

    ok_total, gen_fail, original_gen_fail = 0, 0, 0
    original_built, attempted_mutants, mutation_plan_fail = 0, 0, 0
    case_summaries, original_summaries = [], []

    def capture(exp_dir, model_id, case_index, role, dtype, generation_status,
                status=None, comparisons=None, original_id=None, neuron_operator=None):
        status, comparisons = status or {}, comparisons or {}
        metadata = {'seed': seed, 'case_index': case_index, 'case_role': role,
                    'model_id': model_id, 'original_model_id': original_id,
                    'neuron_operator': neuron_operator,
                    'framework_pool': pool_name, 'ablation': ablation, 'input_dtype': dtype,
                    'loss': 'mean_squared_error', 'optimizer': 'sgd', 'threshold': threshold,
                    'execution_path': execution_path, 'batch_size': batch_size,
                    'source_sha256': source_hash, 'generation_status': generation_status,
                    'status': status, 'comparisons': comparisons}
        try:
            capture_case(exp_dir, metadata=metadata)
        except Exception as exc:
            reporter.record(model_id, 'tool_error', 'harness', stage='evidence_capture',
                            detail=str(exc), extra={'case_dir': str(exp_dir)})
        return {'case': str(Path(exp_dir).relative_to(Path(out_root))),
                'model_id': model_id, 'case_role': role, 'original_model_id': original_id,
                'neuron_operator': neuron_operator,
                'generation_status': {bk: st.get('status') for bk, st in generation_status.items()},
                'status': {bk: st.get('status') if isinstance(st, dict) else st
                           for bk, st in status.items()}, 'comparisons': comparisons}

    for i in range(n_models):
        original_dir, original_id, original_info = None, None, None
        original_status = {}
        try:
            # Phase 1: DIV and TS-RCS complete the original architecture first.
            # Neither value nor neuron mutation is enabled during construction.
            selector.reset_model_state()
            with contextlib.redirect_stdout(io.StringIO()):
                original_info, _, _, _ = gen.generate_seq_model(
                    node_num=NODE_NUM, input_shape=INPUT_SHAPE, output_shape=OUTPUT_SHAPE)
                selector.finish_model_state()
                original_info = gen.canonical_model_info(original_info)
                json_path, _, _, original_id, original_dir = gen.generate(
                    str(output_dir), model_info=original_info, selection_already_recorded=True)
            original_backends = model_gen.generate(
                json_path=json_path, exp_dir=original_dir, model_id=original_id,
                input_dtype='float32', neuron_operator=None, generation_seed=seed + i)
            original_status = dict(model_gen.last_status)
            if not original_backends:
                original_gen_fail += 1
                continue
            original_built += 1

            # Phase 2 starts only after the complete original and its initial
            # weights exist. All siblings share PV/BV/IT; each chooses one
            # neuron operator and restores the original, never another sibling.
            variants = model_mutator.mutate_model(original_info, input_dtype='float32')
            for variant in variants:
                attempted_mutants += 1
                exp_dir, model_id = None, None
                generation_status, status, pair_deltas = {}, {}, {}
                try:
                    json_path, ins_shapes, out_shapes, model_id, exp_dir = save_mutant_case(
                        db, original_dir, original_id, variant)
                    ok_backends = model_gen.generate(
                        json_path=json_path, exp_dir=exp_dir, model_id=model_id,
                        input_dtype=variant['input_dtype'],
                        neuron_operator=variant['neuron_operator'] if variant['neuron_operator'] != 'none' else None,
                        source_weight_dir=str(Path(original_dir) / 'models' / 'initial_weights'),
                        generation_seed=seed + i + {'nf': 1, 'ws': 2, 'wr': 3}.get(variant['neuron_operator'], 0))
                    generation_status = dict(model_gen.last_status)
                    for bk in BACKENDS:
                        if bk not in ok_backends:
                            collector.record_generate_fail(bk, generation_status.get(bk))
                    if len(ok_backends) < 2:
                        gen_fail += 1
                        continue
                    # A private, reset per-family RNG gives all sibling variants
                    # identical inputs/targets and cannot perturb graph selection.
                    data_gen = DataGenerator({'instance_num': 10, 'element_val_range': (0, 100),
                                              'seed': seed + i})
                    data_gen.generate(ins_shapes, exp_dir, out_shapes,
                                      input_dtype=variant['input_dtype'], model_info=variant['model_info'])
                    status, outputs, losses, loss_grads, grads, ok_backends2, _ = trainer.train(
                        model_id=model_id, exp_dir=exp_dir, ok_backends=ok_backends,
                        loss='mean_squared_error', optimizer='sgd', seed=seed,
                        execution_path=execution_path, batch_size=batch_size)
                    pair_deltas = comparator.compare(
                        model_id=model_id, exp_dir=exp_dir, backends_outputs=outputs,
                        backends_losses=losses, backends_loss_grads=loss_grads,
                        backends_grads=grads, ok_backends=ok_backends2)
                    collector.record_model(model_id, status, outputs, pair_deltas)
                    ok_total += int(len(ok_backends2) >= 2)
                except Exception as exc:
                    import traceback
                    gen_fail += 1
                    reporter.record(model_id or original_id, 'tool_error', 'harness',
                                    variant['model_info'], stage='mutation_orchestration',
                                    detail=str(exc), extra={'traceback': traceback.format_exc(),
                                                          'original_model_id': original_id,
                                                          'neuron_operator': variant['neuron_operator']})
                finally:
                    if exp_dir is not None:
                        case_summaries.append(capture(
                            exp_dir, model_id, i, 'mutant', variant['input_dtype'],
                            generation_status, status, pair_deltas, original_id,
                            variant['neuron_operator']))
        except Exception as exc:
            import traceback
            if original_status and any(v.get('status') == 'ok' for v in original_status.values()):
                mutation_plan_fail += 1
                failed_stage = 'mutation_planning'
            else:
                original_gen_fail += 1
                failed_stage = 'original_generation'
            reporter.record(original_id or i + 1, 'tool_error', 'harness', original_info,
                            stage=failed_stage, detail=str(exc),
                            extra={'traceback': traceback.format_exc()})
        finally:
            selector.finish_model_state()
            if original_dir is not None:
                original_summaries.append(capture(
                    original_dir, original_id, i, 'original', 'float32', original_status))

    s = collector.summary()
    s['framework_pool'] = pool_name
    s['ablation'] = ablation
    s['enabled_spaces'] = enabled_spaces
    s['enabled_ops'] = sorted(enabled_ops)
    s['total_models'] = attempted_mutants
    s['model_count_unit'] = 'attempted mutated models; originals counted separately'
    s['original_models'] = n_models
    s['original_models_built'] = original_built
    s['original_gen_fail'] = original_gen_fail
    s['mutation_plan_fail'] = mutation_plan_fail
    s['mutated_models'] = attempted_mutants
    s['mutation_protocol'] = 'complete original, shared PV+BV+IT, one independent NF/WS/WR sibling per enabled neuron operator'
    s['execution_path'] = execution_path
    s['batch_size'] = batch_size
    s['original_cases'] = original_summaries
    s['ok_models'] = ok_total
    s['gen_fail'] = gen_fail
    s['cases'] = case_summaries
    s['coverage_scope'] = 'structures built successfully by at least one backend; not framework source coverage'
    s['coverage_detail'] = tracker.summary()

    # LIC / LPC / LSC (基于本配置全部生成模型, 跨模型累积)
    cov = tracker.summary()
    s['LIC'] = cov['LIC']
    s['LPC'] = cov['LPC']
    s['LSC'] = cov['LSC']
    s['LSC_cov_seq'] = cov['LSC_cov_seq']
    s['LSC_denom'] = cov['LSC_denom']
    s['diversity'] = selector.diversity_summary()

    reporter.dump(output_dir / 'observations.jsonl')
    s['observations'] = reporter.summary()
    s['defect_records'] = len(reporter.records)
    (output_dir / 'summary.json').write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding='utf-8')
    return s


def main():
    from scripts.check_environment import probe_environment
    from utils.reproducibility import source_digest
    parse = argparse.ArgumentParser(description=__doc__)
    parse.add_argument('--ablation', choices=['all']+ABLATION_ORDER, default='all')
    parse.add_argument('--pool', choices=UNIQUE_POOLS, default='keras3.10')
    parse.add_argument('--models', type=int, default=CASE_NUM,
                       help='Number of complete original models; full produces three mutants per original')
    parse.add_argument('--threshold', type=float, default=0.15)
    parse.add_argument('--out', required=True, help='Fresh summary file; sibling <stem>_cases stores evidence')
    parse.add_argument('--timeout', type=float, default=120)
    parse.add_argument('--seed', type=int, default=2024)
    parse.add_argument('--workers', type=int, default=1)
    parse.add_argument('--execution-path', choices=['single_step', 'one_epoch'], default='single_step',
                       help='single_step: one forward/backward without updates; one_epoch: one ordered pass with mini-batch optimizer updates')
    parse.add_argument('--batch-size', type=int, default=32,
                       help='Positive mini-batch size for one_epoch; single_step always uses the entire dataset')
    flags = parse.parse_args()
    if flags.models < 1 or flags.workers < 1 or flags.timeout <= 0 or flags.threshold < 0 or flags.batch_size < 1:
        parse.error('models/workers/timeout/batch-size must be positive and threshold nonnegative')
    out = Path(flags.out).resolve()
    out_root = out.parent / (out.stem + '_cases')
    if out.exists() or (out_root.exists() and any(out_root.iterdir())):
        parse.error('Output exists. Choose a fresh --out; stale summaries are never reused.')
    out.parent.mkdir(parents=True, exist_ok=True)
    environment = probe_environment()
    meta = {'experiment':'ablation_exp2_v2', 'source_sha256':source_digest(PROJECT_ROOT),
            'original_models_per_config':flags.models, 'models_per_config':flags.models,
            'model_argument_unit':'original models; full creates three independent mutants per original', 'threshold':flags.threshold, 'seed':flags.seed,
            'framework_pool': flags.pool, 'environment':environment,
            'backend_identity_rule':'Only environment.backends identifies executed frameworks; pool is a generator domain.',
            'count_unit':'candidate observations, not confirmed bugs or unique root causes',
            'loss':'mean_squared_error', 'optimizer':'sgd',
            'execution_path':flags.execution_path, 'batch_size':flags.batch_size,
            'phase':('single forward/backward evaluation; no optimizer update'
                     if flags.execution_path == 'single_step' else
                     'one epoch: one ordered dataset pass with mini-batch optimizer updates'),
            'comparison_threshold':'dtype-aware allclose gate and MAD > threshold',
            'historical_results_reused':False}
    if not environment['ready']:
        out.write_text(json.dumps({'meta':meta, 'status':'environment_error', 'by_pool':{}},
                                 ensure_ascii=False, indent=2), encoding='utf-8')
        raise SystemExit('Backend preflight failed; see ' + str(out))
    ablations = ABLATION_ORDER if flags.ablation == 'all' else [flags.ablation]
    tasks = [(flags.pool, ab, flags.models, flags.seed, flags.threshold, flags.timeout, str(out_root),
              flags.execution_path, flags.batch_size)
             for ab in ablations]
    start = time.time()
    if flags.workers > 1 and len(tasks)>1:
        import multiprocessing as mp
        with mp.get_context('spawn').Pool(flags.workers) as pool:
            results = pool.starmap(run_one, tasks)
    else:
        results=[]
        for task in tasks:
            print('Running ' + task[0] + '/' + task[1], flush=True)
            results.append(run_one(*task))
    meta['elapsed_sec']=round(time.time()-start, 3)
    result={'meta':meta, 'status':'completed', 'by_pool':{flags.pool:{s['ablation']:s for s in results}}}
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Saved '+str(out))


if __name__ == '__main__':
    main()
