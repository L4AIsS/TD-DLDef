from pathlib import Path
from typing import List, Optional
import datetime

from utils.db_manager import DbManager
from utils.utils import get_HH_mm_ss
from src.cases_generation.model_info_generator import ModelInfoGenerator
from src.cases_generation.model_generator import ModelGenerator
from src.cases_generation.data_generator import DataGenerator
from src.incons_detection.trainer import Trainer
from src.incons_detection.comparator import Comparator
from utils.selection import Selector


class TrainingDebugger(object):

    def __init__(self, config: dict, generate_mode: str = 'seq', timeout: float = 300):
        super().__init__()
        self.__output_dir = config['output_dir']
        self.__db_manager = DbManager(config['db_path'])
        # Selector 处理器
        from utils.utils import layer_types, layer_conditions
        from utils.mutation import MutationConfig
        from utils.model_mutation import ModelMutator
        from utils.coverage import CoverageTracker
        from utils.defect_report import DefectReporter
        self.__selector = Selector(layer_types=layer_types,
                                   layer_conditions=layer_conditions)
        # 突变配置与覆盖率追踪器 (支持消融实验)
        self.__mutation_config = MutationConfig(enabled=config.get('mutation_ops', None),
                                                seed=config.get('seed', 0))
        self.__input_dtype = config.get('input_dtype', 'float32')
        self.__execution_path = config.get('execution_path', 'single_step')
        self.__batch_size = config.get('batch_size', 32)
        self.__model_mutator = ModelMutator(self.__mutation_config, backends=config['backends'],
                                            preserve_output_shapes=True)
        self.__families = {}
        self.__seed = config.get('seed', 0)
        self.__generation_index = 0
        self.__coverage_tracker = CoverageTracker(layer_types, layer_conditions)
        # 缺陷记录器 (统计所有符合 oracle 检查的缺陷信息 + 源码片段定位)
        self.__defect_reporter = DefectReporter(framework='main')
        self.__model_info_generator = ModelInfoGenerator(config['model'], self.__db_manager, self.__selector, generate_mode,
                                                         mutation_config=MutationConfig([], config.get('seed', 0)),
                                                         coverage_tracker=self.__coverage_tracker)
        self.__model_generator = ModelGenerator(config['model']['var']['weight_value_range'], config['backends'], self.__db_manager, self.__selector, timeout,
                                                coverage_tracker=self.__coverage_tracker,
                                                input_dtype=self.__input_dtype,
                                                python_path=config.get('python_path'),
                                                defect_reporter=self.__defect_reporter,
                                                mutation_seed=config.get('seed', 0))
        self.__training_data_generator = DataGenerator(config['training_data'])
        self.__weights_trainer = Trainer(self.__db_manager, timeout, python_path=config.get('python_path', None),
                                         defect_reporter=self.__defect_reporter)
        self.__weights_comparator = Comparator(self.__db_manager, threshold=config.get('distance_threshold', 0.15),
                                               defect_reporter=self.__defect_reporter)


    @staticmethod
    def _copy_dataset(source, destination, model_info, input_dtype):
        """Retain dataset values/labels and map named interfaces after mutation."""
        import json
        import numpy as np
        from scripts.run_ablation_exp2 import model_io_shapes
        source, destination = Path(source), Path(destination)
        destination.mkdir(parents=True, exist_ok=True)
        input_shapes, output_shapes = model_io_shapes(model_info)
        for filename, shapes, dtype in (
                ('inputs.npz', input_shapes, input_dtype),
                ('ground_truths.npz', output_shapes, None)):
            with np.load(source / filename, allow_pickle=False) as archive:
                if len(archive.files) != len(shapes):
                    raise ValueError('dataset/model interface count mismatch: ' + filename)
                names = list(shapes)
                keys = names if set(names) == set(archive.files) else archive.files
                arrays = {}
                for name, key in zip(names, keys):
                    array = archive[key]
                    if tuple(array.shape[1:]) != tuple(shapes[name][1:]):
                        raise ValueError('dataset shape contract changed for ' + name)
                    arrays[name] = array.astype(dtype) if dtype is not None else array.copy()
            np.savez(destination / filename, **arrays)
        (destination / 'dataset_generation.json').write_text(json.dumps({
            'scope': 'existing_dataset', 'input_dtype': input_dtype,
            'output_contract_preserved': True,
            'interface_names_remapped_by_declared_order': True,
        }, indent=2), encoding='utf-8')

    def run_generation_for_dataset(self, dataset_name: str):
        """Complete one original, then independently build its mutation family.

        The legacy return tuple identifies the original. ``run_detection`` on
        that tuple executes every generated child; the original stays intact.
        """
        import json
        from scripts.run_ablation_exp2 import save_mutant_case
        from utils.reproducibility import capture_case
        family_seed = self.__seed + self.__generation_index
        self.__generation_index += 1
        json_path, _, _, model_id, exp_dir = self.__model_info_generator.generate_for_dataset(
            save_dir=self.__output_dir, dataset_name=dataset_name)
        original = json.loads(Path(json_path).read_text(encoding='utf-8'))
        ok_backends = self.__model_generator.generate(
            json_path=json_path, model_id=model_id, exp_dir=exp_dir,
            input_dtype=self.__input_dtype, neuron_operator=None, generation_seed=family_seed)
        self.__families[model_id] = []
        capture_case(exp_dir, metadata={'case_role': 'original', 'seed': self.__seed,
                                       'input_dtype': self.__input_dtype})
        if not ok_backends:
            return model_id, exp_dir, ok_backends
        self._copy_dataset(Path('dataset') / dataset_name, Path(exp_dir) / 'dataset',
                           original, self.__input_dtype)
        variants = self.__model_mutator.mutate_model(original, input_dtype=self.__input_dtype)
        for variant in variants:
            mutant_json, _, _, mutant_id, mutant_dir = save_mutant_case(
                self.__db_manager, exp_dir, model_id, variant)
            mutant_backends = []
            try:
                mutant_backends = self.__model_generator.generate(
                    json_path=mutant_json, model_id=mutant_id, exp_dir=mutant_dir,
                    input_dtype=variant['input_dtype'], neuron_operator=variant['neuron_operator'],
                    source_weight_dir=str(Path(exp_dir) / 'models' / 'initial_weights'),
                    generation_seed=family_seed + {'nf': 1, 'ws': 2, 'wr': 3}.get(variant['neuron_operator'], 0))
                if len(mutant_backends) >= 2:
                    self._copy_dataset(Path(exp_dir) / 'dataset', Path(mutant_dir) / 'dataset',
                                       variant['model_info'], variant['input_dtype'])
            except Exception as exc:
                mutant_backends = []
                self.__defect_reporter.record(mutant_id, 'tool_error', 'harness',
                    variant['model_info'], stage='mutation_orchestration', detail=str(exc),
                    extra={'original_model_id': model_id,
                           'neuron_operator': variant['neuron_operator'], 'case_dir': mutant_dir})
            finally:
                self.__families[model_id].append((mutant_id, mutant_dir, mutant_backends))
                capture_case(mutant_dir, metadata={'case_role': 'mutant', 'seed': self.__seed,
                             'original_model_id': model_id, 'neuron_operator': variant['neuron_operator'],
                             'input_dtype': variant['input_dtype']})
        capture_case(exp_dir, metadata={'case_role': 'original', 'seed': self.__seed,
                                       'input_dtype': self.__input_dtype})
        return model_id, exp_dir, ok_backends

    def get_mutant_cases(self, original_model_id):
        return list(self.__families.get(original_model_id, []))

    def run_detection(self, model_id: int, exp_dir: str, ok_backends: List[str],  loss: Optional[str] = None, optimizer: Optional[str] = None):
        if model_id in self.__families:
            # Compatibility with callers that pass the original tuple: detect
            # all independent siblings, without training or mutating the source.
            successful, family_counts, family_deltas = set(), {}, {}
            for child_id, child_dir, child_backends in self.__families[model_id]:
                completed, counts, deltas = self.run_detection(
                    child_id, child_dir, child_backends, loss, optimizer)
                successful.update(completed)
                family_counts[Path(child_dir).name] = counts
                family_deltas[Path(child_dir).name] = deltas
            return sorted(successful), family_counts, family_deltas
        defect_counts = {}
        if len(ok_backends) >= 2:
            print('Training开始...')
            status, backends_outputs, backends_losses, backends_loss_grads, backends_grads, ok_backends, defect_counts = self.__weights_trainer.train(model_id=model_id,
                                                                                                                                                     exp_dir=exp_dir,
                                                                                                                                                     ok_backends=ok_backends,
                                                                                                                                                     loss=loss or 'mean_squared_error',
                                                                                                                                                     optimizer=optimizer or 'sgd',
                                                                                                                                                     seed=self.__seed,
                                                                                                                                                     execution_path=self.__execution_path,
                                                                                                                                                     batch_size=self.__batch_size)
            print(f'Training结束: ok_backends={ok_backends}')

            self.__db_manager.record_status(model_id, status)

        pair_deltas = {}
        if len(ok_backends) >= 2:
            print('Compare开始...')
            pair_deltas = self.__weights_comparator.compare(model_id=model_id,
                                                            exp_dir=exp_dir,
                                                            backends_outputs=backends_outputs,
                                                            backends_losses=backends_losses,
                                                            backends_loss_grads=backends_loss_grads,
                                                            backends_grads=backends_grads,
                                                            # backends_weights=backends_weights,
                                                            ok_backends=ok_backends)
            print('Compare结束.')

        from utils.reproducibility import capture_case
        capture_case(exp_dir, metadata={'case_role': 'mutant', 'seed': self.__seed,
                     'loss': loss or 'mean_squared_error', 'optimizer': optimizer or 'sgd',
                     'execution_path': self.__execution_path, 'batch_size': self.__batch_size})
        return ok_backends, defect_counts, pair_deltas

    def get_coverage(self):
        return self.__selector.coverage()

    def get_branch_lines(self):
        return self.__selector.branch_lines()

    def get_single_record(self):
        return self.__selector.get_single_record()

    def get_coverage_tracker(self):
        """LIC/LPC/LSC 覆盖率追踪器 (跨全部模型累积)"""
        return self.__coverage_tracker

    def get_diversity_summary(self):
        """任务级四多样性空间统计 (跨全部模型)"""
        return self.__selector.diversity_summary()

    def get_defect_reporter(self):
        return self.__defect_reporter

def main(dataset_name: str, case_num: int, generate_mode: str, model_gen_only: int):
    # Legacy API. Prefer the audited CLI in scripts/run_ablation_exp2.py.
    import random
    import numpy as np
    random.seed(0)
    np.random.seed(0)
    config = {
        'model': {
            'var': {
                'tensor_dimension_range': (2, 5),
                'tensor_element_size_range': (2, 5),
                'weight_value_range': (-10.0, 10.0),
                'small_value_range': (0, 1),
                'vocabulary_size': 1001,
            },
            'node_num_range': (8, 8),
            'dag_io_num_range': (1, 3),
            'dag_max_branch_num': 2,
            'cell_num': 3,
            'node_num_per_normal_cell': 10,
            'node_num_per_reduction_cell': 2,
        },
        'training_data': {
            'instance_num': 10,
            'element_val_range': (0, 100),
        },
        'db_path': str(Path.cwd() / 'data' / f'{dataset_name}.db'),
        'output_dir': str(Path.cwd() / 'data' / f'{dataset_name}_output'),
        'report_dir': str(Path.cwd() / 'data' / f'{dataset_name}_report'),
        'backends': ['tensorflow', 'torch'], # Keras 3 可用后端: "jax"、"tensorflow"、"torch"
        'distance_threshold': 0.15,
    }


    debugger = TrainingDebugger(config, generate_mode, 300)

    start_time = datetime.datetime.now()
    # 现成数据集 + 随机模型
    for i in range(case_num):
        if model_gen_only == 1:
            print(f"********** Model {i} **********")
            try:
                model_id, exp_dir, ok_backends = debugger.run_generation_for_dataset(dataset_name)
            except Exception:
                import traceback
                traceback.print_exc()
        else:
            print(f"********** Model {i} **********")
            try:
                print(f"------------- Generating model {i}  -------------")
                model_id, exp_dir, ok_backends = debugger.run_generation_for_dataset(dataset_name)
                print(f"------------- Detecting Model {i}  -------------")
                ok_backends, defect_counts, pair_deltas = debugger.run_detection(model_id, exp_dir, ok_backends)
            except Exception:
                import traceback
                traceback.print_exc()

    end_time = datetime.datetime.now()
    time_delta = round(end_time.timestamp() - start_time.timestamp(), 2)
    print(f"All is done: Time used: {time_delta} sec")
    percent, _ = debugger.get_coverage()
    branch_cnt, lines_cnt = debugger.get_branch_lines()
    single_record = debugger.get_single_record()
    print(f"Coverage: {percent} %, Branch: {branch_cnt}, lines: {lines_cnt}")

    # LIC / LPC / LSC (COMET 原理 + 目标框架适配参数, 跨全部模型统计)
    cov_summary = debugger.get_coverage_tracker().summary()
    print(f"LIC={cov_summary['LIC']}% LPC={cov_summary['LPC']}% LSC={cov_summary['LSC']}% "
          f"(cov_seq={cov_summary['LSC_cov_seq']}/{cov_summary['LSC_denom']})")

    # 任务级四多样性空间统计 (跨全部模型)
    div_summary = debugger.get_diversity_summary()
    print(f"Diversity spaces (task-level): {div_summary['space_sizes']}, "
          f"avg_new_per_model={div_summary['avg_new_per_model']:.2f}")

    # 缺陷统计: 所有符合 oracle 检查的缺陷 (含源码片段定位)
    reporter = debugger.get_defect_reporter()
    print('\n================= Defect Summary (oracle-checked) =================')
    print(reporter.to_table())
    defect_jsonl, defect_csv = reporter.dump(
        Path.cwd() / 'data' / f'{dataset_name}_defect_records.jsonl')
    print(f'Defect records saved: {defect_jsonl} , {defect_csv}')

    return time_delta, percent, branch_cnt, lines_cnt, single_record, cov_summary

if __name__ == '__main__':
    # One authoritative CLI avoids divergent defect accounting in old main.
    from scripts.run_ablation_exp2 import main as audited_main
    audited_main()
