"""Execution-budget, parameter propagation, and optional real-backend regressions."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import textwrap
import unittest
from unittest import mock

from src.incons_detection import train
from src.incons_detection.trainer import Trainer
from scripts.reproduce_case import main as replay_main, resolve_configuration
from utils.reproducibility import capture_case, replay_configuration, validate_replay_configuration
from utils.runtime import InvalidTest


REPLAY_CONFIG = {'loss': 'mean_squared_error', 'optimizer': 'sgd', 'seed': 17, 'threshold': .012}


def model_info():
    return {'model_structure': {
        '0': {'type': 'input_object', 'args': {'name': '00_input', 'shape': [1]}, 'pre_layers': []},
        '1': {'type': 'dense', 'args': {'name': '01_dense', 'units': 1}, 'pre_layers': [0]}},
        'input_id_list': [0], 'output_id_list': [1]}


def create_replay_fixture(root, config):
    (root / 'models/initial_weights').mkdir(parents=True)
    (root / 'dataset').mkdir()
    (root / 'models/model.json').write_text(json.dumps(model_info()), encoding='utf-8')
    # This fixture tests orchestration only; no fake bytes reach a DL backend.
    for name in ('models/tensorflow.keras', 'models/torch.keras',
                 'models/initial_weights/00_input.npz', 'dataset/inputs.npz',
                 'dataset/ground_truths.npz'):
        (root / name).write_bytes(b'orchestration fixture')
    capture_case(root, metadata=config)


class ExecutionBatchTests(unittest.TestCase):
    def test_default_single_step_uses_one_complete_batch(self):
        self.assertEqual(train.execution_batches(5), [(0, 5)])
        self.assertEqual(train.execution_batches(5, 'single_step', 2), [(0, 5)])

    def test_one_epoch_covers_each_sample_once_in_order_including_tail(self):
        for count, size in ((5, 2), (6, 2), (1, 32), (7, 1), (65, 32)):
            with self.subTest(count=count, batch_size=size):
                batches = train.execution_batches(count, 'one_epoch', size)
                observed = [index for start, stop in batches for index in range(start, stop)]
                self.assertEqual(observed, list(range(count)))
                self.assertEqual(len(batches), (count + size - 1) // size)
                self.assertTrue(all(0 < stop - start <= size for start, stop in batches))
        self.assertEqual(train.execution_batches(5, 'one_epoch', 2), [(0, 2), (2, 4), (4, 5)])

    def test_invalid_paths_budgets_and_empty_data_are_rejected(self):
        for count in (0, -1, 2.5, True):
            with self.subTest(sample_count=count), self.assertRaises((ValueError, InvalidTest)):
                train.execution_batches(count, 'one_epoch', 2)
        for size in (0, -1, 1.5, True):
            for path in ('single_step', 'one_epoch'):
                with self.subTest(batch_size=size, path=path), self.assertRaises((ValueError, InvalidTest)):
                    train.execution_batches(5, path, size)
        for path in ('two_epochs', '', None):
            with self.subTest(path=path), self.assertRaises((ValueError, InvalidTest)):
                train.execution_batches(5, path, 2)

    def test_worker_cli_keeps_legacy_default_and_accepts_epoch_options(self):
        argv = []
        for name in ('backend', 'loss', 'optimizer', 'model_path', 'model_info_path',
                     'training_instances_path', 'ground_truths_path', 'outputs_dir',
                     'loss_path', 'loss_grads_dir', 'gradients_dir'):
            argv.extend(['--' + name, 'fixture'])
        with mock.patch.object(train, 'run') as execute:
            self.assertEqual(train.main(argv), 0)
            flags = execute.call_args.args[0]
            self.assertEqual(flags.execution_path, 'single_step')
            self.assertEqual(flags.batch_size, 32)
            self.assertEqual(train.main(argv + ['--execution-path', 'one_epoch', '--batch-size', '2']), 0)
            flags = execute.call_args.args[0]
            self.assertEqual(flags.execution_path, 'one_epoch')
            self.assertEqual(flags.batch_size, 2)


class ExecutionPropagationTests(unittest.TestCase):
    def test_trainer_sends_epoch_budget_to_each_backend(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / 'models').mkdir()
            (root / 'models/model.json').write_text(json.dumps(model_info()), encoding='utf-8')
            with mock.patch('src.incons_detection.trainer.CmdProcess') as worker, \
                    mock.patch('src.incons_detection.trainer.collect_process_status',
                               return_value={'status': 'environment_error'}):
                result = Trainer(mock.Mock(), 1).train(
                    1, str(root), ['tensorflow', 'torch'], loss='mean_squared_error',
                    optimizer='sgd', seed=17, execution_path='one_epoch', batch_size=2)
            self.assertEqual(worker.call_count, 2)
            for call in worker.call_args_list:
                argv = call.args[0]
                self.assertEqual(argv[argv.index('--execution-path') + 1], 'one_epoch')
                self.assertEqual(argv[argv.index('--batch-size') + 1], '2')
                self.assertEqual(argv[argv.index('--seed') + 1], '17')
            self.assertEqual(result[5], [])
            self.assertTrue(all(record['status'] == 'environment_error' for record in result[0].values()))

    def test_replay_preserves_new_settings_and_leaves_old_config_unchanged(self):
        legacy, overrides = resolve_configuration({'metadata': dict(REPLAY_CONFIG)})
        self.assertEqual(legacy, REPLAY_CONFIG)
        self.assertNotIn('execution_path', legacy)
        self.assertNotIn('batch_size', legacy)
        self.assertEqual(overrides, {})
        saved = dict(REPLAY_CONFIG, execution_path='one_epoch', batch_size=2)
        current, overrides = resolve_configuration({'metadata': saved})
        self.assertEqual(current, saved)
        self.assertEqual(overrides, {})

    def test_verified_worker_execution_settings_override_metadata(self):
        metadata = dict(REPLAY_CONFIG, execution_path='single_step', batch_size=32)
        worker_config = {'loss': 'mean_squared_error', 'seed': 17,
                         'execution_path': 'one_epoch', 'batch_size': 2,
                         'optimizer': {'class_name': 'SGD'}}
        actual = {backend: {'config': worker_config} for backend in ('tensorflow', 'torch')}
        captured = replay_configuration(metadata, actual)
        self.assertEqual(captured['values']['execution_path'], 'one_epoch')
        self.assertEqual(captured['values']['batch_size'], 2)
        self.assertEqual(captured['sources']['execution_path'], 'verified_worker_config')
        self.assertEqual(captured['sources']['batch_size'], 'verified_worker_config')

    def test_replay_rejects_unknown_path_and_invalid_batch_size(self):
        for path in ('two_epochs', '', None):
            with self.subTest(path=path), self.assertRaises(ValueError):
                validate_replay_configuration(dict(REPLAY_CONFIG, execution_path=path, batch_size=2))
        for size in (0, -1, 2.5, True):
            with self.subTest(batch_size=size), self.assertRaises(ValueError):
                validate_replay_configuration(dict(REPLAY_CONFIG, execution_path='one_epoch', batch_size=size))
        with self.assertRaisesRegex(ValueError, 'batch_size'):
            validate_replay_configuration(dict(REPLAY_CONFIG, execution_path='one_epoch'))

    def test_saved_epoch_configuration_reaches_replay_trainer(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            case, output = root / 'case', root / 'replayed'
            config = dict(REPLAY_CONFIG, execution_path='one_epoch', batch_size=2)
            create_replay_fixture(case, config)
            statuses = {backend: {'status': 'ok'} for backend in ('tensorflow', 'torch')}
            with mock.patch('scripts.reproduce_case.Trainer') as trainer, \
                    mock.patch('scripts.reproduce_case.Comparator') as comparator:
                trainer.return_value.train.return_value = (statuses, {}, {}, {}, {}, ['tensorflow', 'torch'], {})
                comparator.return_value.compare.return_value = {}
                self.assertEqual(replay_main(['--case', str(case), '--out', str(output)]), 0)
            sent = trainer.return_value.train.call_args.kwargs
            self.assertEqual(sent['execution_path'], 'one_epoch')
            self.assertEqual(sent['batch_size'], 2)
            summary = json.loads((output / 'replay_summary.json').read_text(encoding='utf-8'))
            self.assertEqual(summary['replay_configuration'], config)

    def test_legacy_replay_uses_single_step_without_rewriting_saved_settings(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            case, output = root / 'case', root / 'replayed'
            create_replay_fixture(case, dict(REPLAY_CONFIG))
            statuses = {backend: {'status': 'ok'} for backend in ('tensorflow', 'torch')}
            with mock.patch('scripts.reproduce_case.Trainer') as trainer, \
                    mock.patch('scripts.reproduce_case.Comparator') as comparator:
                trainer.return_value.train.return_value = (statuses, {}, {}, {}, {}, ['tensorflow', 'torch'], {})
                comparator.return_value.compare.return_value = {}
                self.assertEqual(replay_main(['--case', str(case), '--out', str(output)]), 0)
            sent = trainer.return_value.train.call_args.kwargs
            self.assertEqual(sent['execution_path'], 'single_step')
            self.assertEqual(sent['batch_size'], 32)
            summary = json.loads((output / 'replay_summary.json').read_text(encoding='utf-8'))
            self.assertEqual(summary['replay_configuration'], REPLAY_CONFIG)


class RealExecutionPathTests(unittest.TestCase):
    """Real autodiff/optimizer checks, skipped only when backend packages are absent."""

    def check_backend(self, backend):
        # The saved Dense kernel starts at 1. Its analytically calculated SGD
        # trajectory proves the tail batch is applied once and no second epoch
        # runs. The other path must leave the loaded kernel exactly unchanged.
        script = textwrap.dedent('''
            import json
            from pathlib import Path
            import tempfile
            from types import SimpleNamespace
            from unittest import mock
            import numpy as np
            from utils.utils import switch_backend
            backend = BACKEND_NAME
            switch_backend(backend)
            import keras
            from src.incons_detection.train import run
            with tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                (root / 'models/initial_weights').mkdir(parents=True)
                inputs = keras.Input(shape=(1,), dtype='float32', name='00_input')
                outputs = keras.layers.Dense(1, use_bias=False, kernel_initializer='ones', name='01_dense')(inputs)
                model = keras.Model(inputs, outputs)
                model_path = root / 'models' / (backend + '.keras')
                model.save(model_path)
                for layer in model.layers:
                    np.savez(root / 'models/initial_weights' / (layer.name + '.npz'), *layer.get_weights())
                info = {'model_structure': {
                    '0': {'type': 'input_object', 'args': {'name': '00_input', 'shape': [1]}, 'pre_layers': []},
                    '1': {'type': 'dense', 'args': {'name': '01_dense', 'units': 1}, 'pre_layers': [0]}},
                    'input_id_list': [0], 'output_id_list': [1]}
                (root / 'model.json').write_text(json.dumps(info))
                x = np.arange(1, 6, dtype='float32').reshape(-1, 1)
                np.savez(root / 'inputs.npz', **{'00_input': x})
                np.savez(root / 'targets.npz', **{'01_dense': np.zeros_like(x)})
                learning_rate = float(keras.ops.convert_to_numpy(keras.optimizers.get('sgd').learning_rate))
                expected = 1.0
                epoch_predictions = []
                epoch_input_gradients, epoch_output_gradients = [], []
                for batch in (x[:2], x[2:4], x[4:]):
                    predictions = batch * expected
                    epoch_predictions.append(predictions)
                    # Each batch has its own mean loss; in particular the
                    # one-sample tail has no factor-of-two batch divisor.
                    epoch_output_gradients.append(2 * predictions / len(batch))
                    epoch_input_gradients.append(2 * expected * predictions / len(batch))
                    expected -= learning_rate * 2 * expected * float(np.mean(batch * batch))
                loader = keras.models.load_model
                for path in ('single_step', 'one_epoch'):
                    loaded = []
                    def capture_loaded(*args, **kwargs):
                        actual = loader(*args, **kwargs)
                        loaded.append(actual)
                        return actual
                    flags = SimpleNamespace(
                        backend=backend, loss='mean_squared_error', optimizer='sgd', seed=17,
                        execution_path=path, batch_size=2, model_path=str(model_path),
                        model_info_path=str(root / 'model.json'),
                        training_instances_path=str(root / 'inputs.npz'), ground_truths_path=str(root / 'targets.npz'),
                        outputs_dir=str(root / path / 'outputs'), loss_path=str(root / path / 'loss.txt'),
                        loss_grads_dir=str(root / path / 'loss_grads'), gradients_dir=str(root / path / 'gradients'),
                        status_path=str(root / path / 'status.json'))
                    if path == 'single_step':
                        # Callers predating the new flags must retain the old protocol.
                        del flags.execution_path
                        del flags.batch_size
                    with mock.patch('keras.models.load_model', side_effect=capture_loaded):
                        result = run(flags)
                    kernel = loaded[0].get_layer('01_dense').get_weights()[0]
                    np.testing.assert_allclose(kernel, [[1.0 if path == 'single_step' else expected]],
                                               atol=1e-6, rtol=1e-5)
                    assert result['status'] == 'ok'
                    assert result['equivalence']['config']['optimizer_steps'] == (0 if path == 'single_step' else 3)
                    execution = result['execution']
                    assert execution['epochs_completed'] == (0 if path == 'single_step' else 1)
                    assert execution['batches_completed'] == (1 if path == 'single_step' else 3)
                    assert execution['forward_passes'] == execution['backward_passes'] == execution['batches_completed']
                    assert execution['samples_seen'] == 5
                    assert execution['sample_order'] == 'sequential'
                    np.testing.assert_array_equal(np.load(root / path / 'outputs/00_input.npy'), x)
                    np.testing.assert_allclose(np.load(root / path / 'outputs/01_dense.npy'),
                        x if path == 'single_step' else np.concatenate(epoch_predictions), atol=1e-6, rtol=1e-5)
                    expected_predictions = x if path == 'single_step' else np.concatenate(epoch_predictions)
                    # Sample-weighted batch means equal the mean of these
                    # per-sample losses, not the unweighted mean of 3 batches.
                    expected_loss = float(np.mean(expected_predictions ** 2))
                    np.testing.assert_allclose(float(Path(flags.loss_path).read_text()), expected_loss,
                                               atol=1e-6, rtol=1e-5)
                    expected_input_grad = 2 * x / len(x) if path == 'single_step' else np.concatenate(epoch_input_gradients)
                    expected_output_grad = 2 * x / len(x) if path == 'single_step' else np.concatenate(epoch_output_gradients)
                    np.testing.assert_allclose(np.load(root / path / 'gradients/00_input.npy'), expected_input_grad,
                                               atol=1e-6, rtol=1e-5)
                    for directory in ('gradients', 'loss_grads'):
                        np.testing.assert_allclose(np.load(root / path / directory / '01_dense.npy'), expected_output_grad,
                                                   atol=1e-6, rtol=1e-5)
                    if path == 'single_step':
                        assert result['final_weights'] == result['equivalence']['initial_weights']
                        assert 'execution_path' not in result['equivalence']['config']
                    else:
                        assert result['final_weights'] != result['equivalence']['initial_weights']
                if backend == 'torch':
                    # Integer inputs plus a weight-free identity have no
                    # differentiable tensors. Traversal still completes, but
                    # neither a backward call nor an optimizer update occurs.
                    inputs = keras.Input(shape=(1,), dtype='int32', name='00_input')
                    outputs = keras.layers.Activation('linear', dtype='int32', name='01_linear')(inputs)
                    integer_model = keras.Model(inputs, outputs)
                    integer_model.save(model_path)
                    for layer in integer_model.layers:
                        np.savez(root / 'models/initial_weights' / (layer.name + '.npz'), *layer.get_weights())
                    info['model_structure']['1'] = {'type': 'activation',
                        'args': {'name': '01_linear', 'activation': 'linear'}, 'pre_layers': [0]}
                    (root / 'model.json').write_text(json.dumps(info))
                    np.savez(root / 'inputs.npz', **{'00_input': x.astype('int32')})
                    np.savez(root / 'targets.npz', **{'01_linear': np.zeros_like(x)})
                    flags.outputs_dir = str(root / 'integer/outputs')
                    flags.loss_path = str(root / 'integer/loss.txt')
                    flags.loss_grads_dir = str(root / 'integer/loss_grads')
                    flags.gradients_dir = str(root / 'integer/gradients')
                    flags.status_path = str(root / 'integer/status.json')
                    result = run(flags)
                    assert result['status'] == 'ok'
                    assert result['execution']['epochs_completed'] == 1
                    assert result['execution']['forward_passes'] == result['execution']['batches_completed'] == 3
                    assert result['execution']['backward_passes'] == result['execution']['optimizer_steps'] == 0
                    assert result['execution']['samples_seen'] == 5
                    assert result['artifacts']['layer_gradients'] == result['artifacts']['loss_gradients'] == {}
                    assert result['final_weights'] == result['equivalence']['initial_weights']
                print('both execution paths match the exact expected optimizer trajectory')
        ''').replace('BACKEND_NAME', repr(backend))
        environment = dict(os.environ, KERAS_BACKEND=backend, CUDA_VISIBLE_DEVICES='-1',
                           OMP_NUM_THREADS='1', TF_NUM_INTEROP_THREADS='1', TF_NUM_INTRAOP_THREADS='1')
        result = subprocess.run([sys.executable, '-c', script], text=True, env=environment,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    @unittest.skipUnless(importlib.util.find_spec('keras') and importlib.util.find_spec('torch'),
                         'requires installed Keras and PyTorch')
    def test_torch_single_step_vs_exactly_one_epoch(self):
        self.check_backend('torch')

    @unittest.skipUnless(importlib.util.find_spec('keras') and importlib.util.find_spec('tensorflow'),
                         'requires installed Keras and TensorFlow')
    def test_tensorflow_single_step_vs_exactly_one_epoch(self):
        self.check_backend('tensorflow')


if __name__ == '__main__':
    unittest.main()
