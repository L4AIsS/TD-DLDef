"""Run a single forward/backward evaluation or at most one training epoch.

The default single_step path preserves the original no-update evaluation.
one_epoch visits each sample once in sequential mini-batches and updates weights
after each batch. Its observations are concatenated in original sample order;
each output/gradient is measured before that batch's optimizer update.
"""
import argparse
import json
import hashlib
from numbers import Integral
import sys
from pathlib import Path
import numpy as np
from utils.utils import switch_backend
from utils.runtime import (InvalidTest, UnsupportedTest, array_fingerprint,
                           exception_record, load_named_arrays, write_json)


def execution_batches(sample_count, execution_path='single_step', batch_size=32):
    """Return one evaluation batch or exactly one bounded dataset traversal."""
    if execution_path not in ('single_step', 'one_epoch'):
        raise InvalidTest('execution_path must be single_step or one_epoch')
    if isinstance(batch_size, bool) or not isinstance(batch_size, Integral) or batch_size <= 0:
        raise InvalidTest('batch_size must be a positive integer')
    if isinstance(sample_count, bool) or not isinstance(sample_count, Integral) or sample_count <= 0:
        raise InvalidTest('sample_count must be a positive integer')
    size = sample_count if execution_path == 'single_step' else batch_size
    return [(start, min(start + size, sample_count)) for start in range(0, sample_count, size)]


def canonical_loss(name):
    return {'huber_loss': 'huber', 'kullback_leibler_divergence': 'kl_divergence'}.get(name, name)


def validate_loss_domain(name, targets, predictions):
    for target, pred in zip(targets, predictions):
        if target.shape != pred.shape:
            raise InvalidTest('target and output shapes must match exactly; broadcasting is excluded')
        if name in ('categorical_crossentropy', 'binary_crossentropy', 'kl_divergence'):
            if np.any(target < 0) or np.any(target > 1):
                raise InvalidTest('probability loss requires targets in [0, 1]')
            if name in ('categorical_crossentropy', 'kl_divergence') and not np.allclose(target.sum(axis=-1), 1, atol=1e-5):
                raise InvalidTest('categorical/probability targets must sum to one')
            if np.isfinite(pred).all() and (np.any(pred < 0) or np.any(pred > 1)):
                raise InvalidTest('probability loss requires output probabilities in [0, 1]')
        if name == 'poisson' and (np.any(target < 0) or (np.isfinite(pred).all() and np.any(pred <= 0))):
            raise InvalidTest('Poisson loss requires nonnegative targets and positive predictions')


def weight_map(model):
    return {'%s/%d' % (layer.name, i): value for layer in model.layers
            for i, value in enumerate(layer.get_weights())}


def validate_equivalent_weights(model, directory):
    for layer in model.layers:
        path = Path(directory) / (layer.name + '.npz')
        if not path.is_file():
            raise InvalidTest('missing shared initial weight archive: %s' % path)
        with np.load(path, allow_pickle=False) as archive:
            expected = [archive['arr_%d' % i] for i in range(len(archive.files))]
        actual = layer.get_weights()
        if len(expected) != len(actual) or any(a.dtype != b.dtype or a.shape != b.shape or not np.array_equal(a, b, equal_nan=True)
                                              for a, b in zip(expected, actual)):
            raise InvalidTest('initial weights/state differ from shared tensors for %s' % layer.name)
        if any(not np.isfinite(a).all() for a in actual):
            raise InvalidTest('nonfinite initial weights/state for %s' % layer.name)
        if layer.__class__.__name__ == 'BatchNormalization' and any(
                'moving_variance' in str(w.name) and np.any(np.asarray(w) < 0) for w in layer.weights):
            raise InvalidTest('BatchNorm moving variance must be nonnegative')


def validate_layer_contracts(model, backend):
    """Known kernel contracts, checked before a failing forward call."""
    convolution_types = {'Conv1D', 'Conv2D', 'Conv3D', 'Conv1DTranspose',
                         'Conv2DTranspose', 'Conv3DTranspose', 'SeparableConv1D',
                         'SeparableConv2D', 'DepthwiseConv1D', 'DepthwiseConv2D',
                         'ConvLSTM2D'}
    for layer in model.layers:
        kind = layer.__class__.__name__
        if kind in convolution_types:
            symbolic = layer.input if isinstance(layer.input, (list, tuple)) else [layer.input]
            integer_input = any(np.dtype(str(t.dtype)).kind in 'iu' for t in symbolic)
            floating_weights = any(np.dtype(str(w.dtype)).kind == 'f' for w in layer.weights)
            if integer_input and floating_weights:
                raise InvalidTest('integer convolution input with floating-point filter violates kernel dtype contract: %s' % layer.name)
        if backend == 'tensorflow' and kind in ('DepthwiseConv2D', 'Conv2DTranspose') and getattr(layer, 'data_format', None) == 'channels_first':
            raise UnsupportedTest('TensorFlow CPU %s requires NHWC/channels_last in this adapter' % kind)


def validate_stochastic_layers(model):
    """Reject unsynchronized randomness/state inside wrappers and nested models.

    Follow actual Keras layer/cell relationships, not serialized configuration.
    A shared layer or a cyclic wrapper reference is inspected only once.
    """
    stochastic_types = {'Dropout', 'AlphaDropout', 'GaussianDropout',
                        'GaussianNoise', 'SpatialDropout1D', 'SpatialDropout2D',
                        'SpatialDropout3D'}
    pending = [(model, getattr(model, 'name', 'model'))]
    seen = set()
    while pending:
        layer, path = pending.pop()
        if id(layer) in seen:
            continue
        seen.add(id(layer))
        if layer.__class__.__name__ in stochastic_types:
            raise UnsupportedTest('cross-backend stochastic masks are not synchronized: %s' % path)
        if (getattr(layer, 'dropout', 0) or getattr(layer, 'recurrent_dropout', 0)
                or getattr(layer, 'stateful', False)):
            raise UnsupportedTest('stochastic/stateful recurrent execution is not synchronized: %s' % path)
        # TimeDistributed/Wrapper, Bidirectional, RNN and stacked cells.
        for attribute in ('layer', 'forward_layer', 'backward_layer', 'cell'):
            child = getattr(layer, attribute, None)
            if child is not None:
                pending.append((child, path + '.' + attribute))
        # Functional/Sequential models and stacked RNN cells.
        for attribute in ('layers', 'cells'):
            for index, child in enumerate(getattr(layer, attribute, ()) or ()):
                pending.append((child, '%s.%s[%d](%s)' %
                                (path, attribute, index, getattr(child, 'name', child.__class__.__name__))))


def run(flags):
    execution_path = getattr(flags, 'execution_path', 'single_step')
    batch_size = getattr(flags, 'batch_size', 32)
    execution_batches(1, execution_path, batch_size)  # Reject invalid options before backend startup.
    update_weights = execution_path == 'one_epoch'
    identity = switch_backend(flags.backend)
    import keras
    keras.utils.set_random_seed(flags.seed)
    if flags.backend == 'torch':
        import torch
        torch.set_num_threads(1)
        torch.use_deterministic_algorithms(True)
    else:
        import tensorflow as tf
        tf.config.experimental.enable_op_determinism()
    model_info = json.loads(Path(flags.model_info_path).read_text(encoding='utf-8'))
    structure = model_info['model_structure']
    input_names = [structure[str(i)]['args']['name'] for i in model_info['input_id_list']]
    output_names = [structure[str(i)]['args']['name'] for i in model_info['output_id_list']]
    model = keras.models.load_model(flags.model_path, compile=False)
    validate_equivalent_weights(model, Path(flags.model_path).parent / 'initial_weights')
    validate_layer_contracts(model, flags.backend)
    initial_hash = array_fingerprint(weight_map(model))
    # Initializers differ intentionally: the first backend samples weights and
    # peers initialize zeros before loading the identical verified tensors.
    # They cannot affect this pass and must not reject equivalent executions.
    def semantic_config(value):
        if isinstance(value, dict):
            return {k: semantic_config(v) for k, v in value.items()
                    if not k.endswith('_initializer')}
        if isinstance(value, (tuple, list)):
            return [semantic_config(v) for v in value]
        return value
    architecture_hash = hashlib.sha256(json.dumps(semantic_config(model.get_config()),
        sort_keys=True, default=str).encode('utf-8')).hexdigest()
    x = load_named_arrays(flags.training_instances_path, input_names)
    y = load_named_arrays(flags.ground_truths_path, output_names)
    if len(model.inputs) != len(x) or len(model.outputs) != len(y):
        raise InvalidTest('model/data input-output arity mismatch')
    if not x or not y or any(array.ndim == 0 for array in x + y):
        raise InvalidTest('inputs and targets require a sample axis')
    sample_count = len(x[0])
    if any(len(array) != sample_count for array in x + y):
        raise InvalidTest('all inputs and targets must have the same sample count')
    batches = execution_batches(sample_count, execution_path, batch_size)
    for index, (array, symbolic) in enumerate(zip(x, model.inputs)):
        if len(array.shape) != len(symbolic.shape) or any(b is not None and int(b) != a for a, b in zip(array.shape, symbolic.shape)):
            raise InvalidTest('input shape does not match declared model input')
        # The cast is identical and explicitly recorded on both backends.
        declared_dtype = np.dtype(str(symbolic.dtype))
        if declared_dtype.kind in 'iu':
            limits = np.iinfo(declared_dtype)
            if np.any(array < limits.min) or np.any(array > limits.max) or np.any(array != np.floor(array)):
                raise InvalidTest('integer input dtype requires integral values within its representable range')
        x[index] = array.astype(declared_dtype, copy=False)
        if not np.isfinite(x[index]).all():
            raise InvalidTest('declared input dtype cast overflowed')
    input_values = dict(zip(input_names, x))
    for node in structure.values():
        if node['type'].lower() == 'embedding':
            predecessors = node.get('pre_layers', [])
            if len(predecessors) != 1:
                raise InvalidTest('Embedding requires exactly one index input')
            source = structure[str(predecessors[0])]['args']['name']
            if source not in input_values:
                raise UnsupportedTest('transformed Embedding indices require a domain-validation adapter')
            indices = input_values[source]
            if np.any(indices != np.floor(indices)) or np.any(indices < 0) or np.any(indices >= int(node['args']['input_dim'])):
                raise InvalidTest('Embedding indices must be integers in [0, input_dim)')
    validate_stochastic_layers(model)
    layers = [layer for layer in model.layers if layer.name not in input_names]
    layer_names = [layer.name for layer in layers]
    expected_names = {item['args']['name'] for item in structure.values()}
    if set(input_names + layer_names) != expected_names:
        raise UnsupportedTest('model structure contains unreachable or unrepresented layers')
    if any(isinstance(layer.output, (tuple, list, dict)) for layer in layers):
        raise UnsupportedTest('multi-tensor layer outputs require a dedicated adapter')
    probe = keras.Model(model.inputs, [layer.output for layer in layers])
    loss_name = canonical_loss(flags.loss)
    try:
        loss_fn = keras.losses.get(loss_name)
        optimizer = keras.optimizers.get(flags.optimizer)
        optimizer_serialized = keras.optimizers.serialize(optimizer)
        optimizer_config = {key: optimizer_serialized[key] for key in ('class_name', 'config')}
    except (ValueError, TypeError) as exc:
        raise UnsupportedTest(str(exc)) from exc

    def calculate(inputs, targets):
        values = probe(inputs, training=True)
        values = list(values) if isinstance(values, (list, tuple)) else [values]
        named = dict(zip(layer_names, values))
        predictions = [named[name] for name in output_names]
        validate_loss_domain(loss_name, targets, [keras.ops.convert_to_numpy(p) for p in predictions])
        losses = [keras.ops.mean(loss_fn(keras.ops.convert_to_tensor(target, dtype=pred.dtype), pred))
                  for target, pred in zip(targets, predictions)]
        total = sum(losses)
        # Includes weight and activity regularizers from this exact call.
        if probe.losses:
            total = total + sum(probe.losses)
        return named, total

    trainable_weights = list(model.trainable_weights) if update_weights else []
    if trainable_weights:
        # Build once on the full trainable set, including variables whose
        # gradients may be absent in an individual batch.
        optimizer.build(trainable_weights)
    batch_arrays, batch_gradients, batch_losses = [], [], []
    optimizer_steps = 0
    backward_passes = 0
    for start, stop in batches:
        batch_x, batch_y = [a[start:stop] for a in x], [a[start:stop] for a in y]
        if flags.backend == 'tensorflow':
            import tensorflow as tf
            inputs = [tf.convert_to_tensor(a) for a in batch_x]
            with tf.GradientTape(persistent=True) as tape:
                for value in inputs:
                    if value.dtype.is_floating:
                        tape.watch(value)
                named, total = calculate(inputs, batch_y)
            all_values = dict(zip(input_names, inputs)) | named
            differentiable = {n: v for n, v in all_values.items() if v.dtype.is_floating}
            sources = list(differentiable.values()) + [w.value for w in trainable_weights]
            all_grads = tape.gradient(total, sources)
            backward_passes += 1
            del tape
        else:
            import torch
            inputs = [torch.as_tensor(a.copy()) for a in batch_x]
            for value in inputs:
                if value.is_floating_point():
                    value.requires_grad_(True)
            named, total = calculate(inputs, batch_y)
            all_values = dict(zip(input_names, inputs)) | named
            differentiable = {n: v for n, v in all_values.items() if v.is_floating_point() and v.requires_grad}
            sources = list(differentiable.values()) + [w.value for w in trainable_weights]
            if sources and total.requires_grad:
                all_grads = torch.autograd.grad(total, sources, allow_unused=True)
                backward_passes += 1
            else:
                all_grads = [None] * len(sources)
        grads = all_grads[:len(differentiable)]
        weight_grads = all_grads[len(differentiable):]
        # Copy before in-place optimizer updates; all evidence is from this
        # batch's one forward/backward calculation, with no extra evaluation.
        observed = {n: np.array(keras.ops.convert_to_numpy(v), copy=True) for n, v in all_values.items()}
        observed_grads = {n: np.array(keras.ops.convert_to_numpy(g), copy=True)
                          for n, g in zip(differentiable, grads) if g is not None}
        if update_weights and any(a.ndim == 0 or a.shape[0] != stop - start for a in observed.values()):
            raise UnsupportedTest('mini-batch observations must preserve the sample axis')
        batch_arrays.append(observed)
        batch_gradients.append(observed_grads)
        batch_losses.append(float(keras.ops.convert_to_numpy(total)))
        pairs = [(g, w) for g, w in zip(weight_grads, trainable_weights) if g is not None]
        if pairs:
            if flags.backend == 'torch':
                with torch.no_grad():
                    optimizer.apply_gradients(pairs)
            else:
                optimizer.apply_gradients(pairs)
            optimizer_steps += 1
    if len(batches) == 1:
        arrays, gradients, loss_value = batch_arrays[0], batch_gradients[0], batch_losses[0]
    else:
        arrays = {name: np.concatenate([batch[name] for batch in batch_arrays], axis=0)
                  for name in batch_arrays[0]}
        # Never align an incomplete gradient history to the full dataset.
        gradients = {name: np.concatenate([batch[name] for batch in batch_gradients], axis=0)
                     for name in batch_gradients[0] if all(name in batch for batch in batch_gradients)}
        loss_value = sum(value * (stop - start) for value, (start, stop) in zip(batch_losses, batches)) / sample_count
    output_gradients = {n: gradients[n] for n in output_names if n in gradients}
    artifacts = {}
    for kind, directory, values in [('outputs', flags.outputs_dir, arrays),
                                     ('loss_gradients', flags.loss_grads_dir, output_gradients),
                                     ('layer_gradients', flags.gradients_dir, gradients)]:
        Path(directory).mkdir(parents=True, exist_ok=True)
        for name, array in values.items():
            np.save(Path(directory) / (name + '.npy'), array, allow_pickle=False)
        artifacts[kind] = {n: {'shape': list(a.shape), 'dtype': str(a.dtype)} for n, a in values.items()}
    Path(flags.loss_path).parent.mkdir(parents=True, exist_ok=True)
    Path(flags.loss_path).write_text(repr(loss_value), encoding='utf-8')
    config = {'loss': loss_name, 'loss_reduction': 'mean_per_output_then_sum_plus_regularizers',
              'optimizer': optimizer_config, 'training': True, 'optimizer_steps': optimizer_steps, 'seed': flags.seed,
              'device': 'CPU'}
    if update_weights:
        config.update(execution_path=execution_path, batch_size=batch_size, epochs=1,
                      batches=len(batches), sample_order='sequential',
                      loss_aggregation='sample_weighted_mean_of_batch_losses',
                      gradient_scope='per_batch_pre_update')
    manifest = {'status': 'ok', 'stage': 'training', **identity, 'artifacts': artifacts,
                'equivalence': {'inputs': array_fingerprint(dict(zip(input_names, x))),
                                'targets': array_fingerprint(dict(zip(output_names, y))),
                                'initial_weights': initial_hash, 'architecture': architecture_hash, 'config': config},
                'missing_gradients': sorted(set(arrays) - set(gradients)),
                'loss_finite': bool(np.isfinite(loss_value)),
                'protocol': ('one_epoch_minibatch_training' if update_weights
                             else 'single_forward_backward_no_optimizer_update'),
                'final_weights': array_fingerprint(weight_map(model)),
                'execution': {'path': execution_path, 'epochs_completed': int(update_weights),
                              'batch_size': batch_size if update_weights else sample_count,
                              'batches_completed': len(batches), 'forward_passes': len(batches),
                              'backward_passes': backward_passes, 'optimizer_steps': optimizer_steps,
                              'samples_seen': sample_count, 'sample_order': 'sequential',
                              'artifact_scope': ('concatenated_pre_update_batches' if update_weights else 'single_batch')}}
    write_json(flags.status_path, manifest)
    return manifest


def main(argv=None):
    parser = argparse.ArgumentParser()
    for name in ('backend', 'loss', 'optimizer', 'model_path', 'model_info_path',
                 'training_instances_path', 'ground_truths_path', 'outputs_dir',
                 'loss_path', 'loss_grads_dir', 'gradients_dir'):
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--execution-path', choices=('single_step', 'one_epoch'), default='single_step')
    parser.add_argument('--batch-size', type=int, default=32)
    parser.add_argument('--status_path')
    flags = parser.parse_args(argv)
    if not flags.status_path:
        flags.status_path = str(Path(flags.outputs_dir).parent.parent / 'logs' / ('training_%s.json' % flags.backend))
    try:
        run(flags)
        return 0
    except Exception as exc:
        record = exception_record(exc, 'training', flags.backend)
        write_json(flags.status_path, record)
        print(record['traceback'], file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
