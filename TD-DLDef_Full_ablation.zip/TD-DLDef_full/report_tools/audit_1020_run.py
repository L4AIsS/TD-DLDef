#!/usr/bin/env python3
"""Read-only reconstruction of the uploaded 1020 two-stage full run.

No backend is imported or executed. Source and experiment files are never changed.
The default audit hashes JSON/Python evidence and checks every artifact's size;
--full-hashes additionally hashes every binary artifact, including source weights.
"""
import argparse
import ast
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import importlib
import json
from pathlib import Path, PurePosixPath
import sys
import tempfile

sys.dont_write_bytecode = True
DEFAULT_SOURCE = Path(__file__).resolve().parents[1] / 'source' / 'TD-DLDef_1020'
ARTIFACT_DIRS = ('models', 'dataset', 'logs', 'layer_outputs', 'loss',
                 'loss_gradients', 'layer_gradients')
LIMITATIONS = [
    'Coverage is the union of original and mutant structures built by at least one backend; execution success is not required.',
    'LIC dtypes are the uploaded code\'s structural estimates, not measured layer-input/kernel dtypes. Its fallback ignores explicit input_casts and assumes float32 Embedding output.',
    'LIC shape and LPC numeric domains use sigma=5; these are finite approximations, not exhaustive API or source-code coverage.',
    'Identical sibling structures deduplicate coverage sets but each successful sibling increments coverage_detail.models.',
    'Weight-source checks establish snapshot and provenance consistency; this audit does not rerun mutation or numerical execution.',
    'A single seed is descriptive evidence and does not support statistical significance claims.',
]


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write_json(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False) + '\n', encoding='utf-8')


def source_digest(root):
    # Reproduce utils.reproducibility.source_digest without importing its helpers.
    paths = sorted(root.glob('*.py'))
    for directory in ('utils', 'src', 'scripts'):
        paths.extend(sorted((root / directory).rglob('*.py')))
    records = [(p.relative_to(root).as_posix(), sha256(p)) for p in paths]
    return hashlib.sha256(json.dumps(records).encode()).hexdigest()


def source_api(root):
    sys.path.insert(0, str(root))
    coverage = importlib.import_module('utils.coverage')
    frameworks = importlib.import_module('utils.framework_config')
    if Path(coverage.__file__).resolve().parent.parent != root:
        raise ValueError('utils.coverage was imported from a different source tree')
    constants = {}
    tree = ast.parse((root / 'scripts/run_ablation_exp2.py').read_text(encoding='utf-8'))
    for item in tree.body:
        if isinstance(item, ast.Assign):
            for target in item.targets:
                if isinstance(target, ast.Name) and target.id == 'MODEL_CONFIG':
                    constants[target.id] = ast.literal_eval(item.value)
    return coverage.CoverageTracker, frameworks.get_framework_config, constants['MODEL_CONFIG']


class Checks:
    def __init__(self):
        self.count = 0
        self.failures = []
        self.warnings = []
        self.files = 0
        self.hashes = 0
        self.hash_cache = {}

    def check(self, condition, label, **detail):
        self.count += 1
        if not condition:
            detail = json.loads(json.dumps(detail, default=str))
            self.failures.append(dict(check=label, **detail))
        return bool(condition)

    def same(self, actual, expected, label):
        return self.check(actual == expected, label, actual=actual, expected=expected)

    def digest(self, path):
        path = Path(path)
        if path not in self.hash_cache:
            self.hash_cache[path] = sha256(path)
            self.hashes += 1
        return self.hash_cache[path]


def safe_case(cases_root, name):
    part = PurePosixPath(name)
    if part.is_absolute() or '..' in part.parts or '\\' in name:
        raise ValueError('invalid case path: ' + name)
    result = (cases_root / name).resolve()
    if not result.is_relative_to(cases_root):
        raise ValueError('case path escapes evidence root')
    return result


def artifact_files(case):
    # Original-case manifests deliberately do not recursively include mutants/.
    names = set()
    for directory in ARTIFACT_DIRS:
        names.update(p.relative_to(case).as_posix() for p in (case / directory).rglob('*') if p.is_file())
    for filename in ('model_source.py', 'reproduce.py'):
        if (case / filename).is_file():
            names.add(filename)
    return names


def audit_manifest(checks, case, source_hash, full_hashes):
    manifest = read_json(case / 'case_manifest.json')
    label = str(case)
    checks.same(manifest.get('source_sha256'), source_hash, label + ': manifest source hash')
    checks.same(manifest.get('metadata', {}).get('source_sha256'), source_hash,
                label + ': metadata source hash')
    records = manifest.get('artifacts', {})
    actual = artifact_files(case)
    checks.check(set(records) == actual, label + ': artifact file set',
                 missing=sorted(set(records) - actual), extra=sorted(actual - set(records)))
    for name, record in records.items():
        relative = PurePosixPath(name)
        path = (case / name).resolve()
        safe = (not relative.is_absolute() and '..' not in relative.parts and '\\' not in name
                and relative.as_posix() == name and path.is_relative_to(case))
        if not checks.check(safe and path.is_file(), label + ': artifact exists within case', artifact=name):
            continue
        checks.files += 1
        checks.same(path.stat().st_size, record.get('bytes'), label + ': bytes ' + name)
        if full_hashes or path.suffix in ('.json', '.jsonl', '.py'):
            checks.same(checks.digest(path), record.get('sha256'), label + ': SHA256 ' + name)
    return manifest


def audit_run(summary_path, source_root=DEFAULT_SOURCE, expected_originals=200,
              expected_seed=20261020, expected_pool='keras3.10', full_hashes=False):
    summary_path, source_root = Path(summary_path).resolve(), Path(source_root).resolve()
    checks = Checks()
    result = {'audit_schema_version': 1, 'created_utc': datetime.now(timezone.utc).isoformat(),
              'summary_path': str(summary_path), 'source_root': str(source_root),
              'expected_original_attempts': expected_originals,
              'hash_mode': 'all_artifacts' if full_hashes else 'all_sizes_and_JSON_Python_hashes',
              'limitations': list(LIMITATIONS)}
    try:
        doc = read_json(summary_path)
        current_source = source_digest(source_root)
        result['summary_sha256'] = checks.digest(summary_path)
        result['source_sha256'] = current_source
        checks.same(doc.get('status'), 'completed', 'run completed')
        meta = doc['meta']
        checks.same(meta.get('source_sha256'), current_source, 'source digest')
        checks.same(meta.get('seed'), expected_seed, 'seed')
        checks.same(meta.get('original_models_per_config'), expected_originals, 'metadata original budget')
        checks.same(meta.get('models_per_config'), expected_originals, 'metadata model budget')
        checks.same(sorted(doc['by_pool']), [expected_pool], 'one expected pool')
        checks.same(sorted(doc['by_pool'][expected_pool]), ['full'], 'one full-method group')
        group = doc['by_pool'][expected_pool]['full']
        checks.same(group.get('original_models'), expected_originals, 'original budget')
        checks.same(group.get('enabled_ops'), ['bv', 'it', 'nf', 'pv', 'wr', 'ws'], 'all six mutations')
        checks.same(group.get('enabled_spaces'), ['layer', 'edge', 'shape', 'dim'], 'all four DIV spaces')
        CoverageTracker, get_config, model_config = source_api(source_root)
        cfg = get_config(expected_pool)
        tracker = CoverageTracker(cfg.layer_types, cfg.layer_conditions,
                                  activation_pool=cfg.activation_pool, padding_pool=cfg.padding_pool,
                                  element_range=model_config['var']['tensor_element_size_range'],
                                  dim_range=model_config['var']['tensor_dimension_range'])
        cases_root = summary_path.parent / (summary_path.stem + '_cases')
        originals, mutants = group['original_cases'], group['cases']
        all_cases = originals + mutants
        checks.same(len({item['case'] for item in all_cases}), len(all_cases), 'unique case paths')
        checks.same(len({item['model_id'] for item in all_cases}), len(all_cases), 'unique model IDs')
        successful_originals, successful_mutants, completed_mutants = 0, 0, 0
        manifests, models, settings, indexes = {}, {}, {}, {}
        original_by_id = {item['model_id']: item for item in originals}
        families = defaultdict(list)
        for item in all_cases:
            name = item['case']
            try:
                case = safe_case(cases_root, name)
                manifest = audit_manifest(checks, case, current_source, full_hashes)
                manifests[name] = manifest
                metadata = manifest['metadata']
                checks.same(metadata.get('model_id'), item['model_id'], name + ': model ID')
                role = 'original' if item in originals else 'mutant'
                checks.same(item.get('case_role'), role, name + ': summary role')
                checks.same(metadata.get('case_role'), role, name + ': manifest role')
                checks.same(metadata.get('seed'), expected_seed, name + ': seed')
                checks.same(metadata.get('framework_pool'), expected_pool, name + ': pool')
                checks.same(metadata.get('ablation'), 'full', name + ': ablation')
                statuses = item.get('generation_status', {})
                actual_statuses = {bk: st.get('status') for bk, st in metadata.get('generation_status', {}).items()}
                checks.same(statuses, actual_statuses, name + ': generation statuses')
                execution_statuses = {bk: st.get('status') if isinstance(st, dict) else st
                                      for bk, st in metadata.get('status', {}).items()}
                checks.same(item.get('status', {}), execution_statuses, name + ': execution statuses')
                for backend, state in statuses.items():
                    logfile = case / 'logs' / ('generation_' + backend + '.json')
                    if logfile.is_file():
                        checks.same(read_json(logfile).get('status'), state, name + ': worker generation ' + backend)
                    elif state == 'ok':
                        checks.check(False, name + ': successful generation worker status missing', backend=backend)
                successful = any(state == 'ok' for state in statuses.values())
                model = read_json(case / 'models/model.json')
                models[name] = model
                config_path = case / 'models/generation_config.json'
                config = read_json(config_path) if config_path.is_file() else {}
                settings[name] = config
                checks.check(bool(config) or not successful, name + ': successful model has generation config')
                if successful:
                    tracker.record_model(model, input_dtype=config['input_dtype'])
                index = metadata.get('case_index')
                checks.check(isinstance(index, int) and 0 <= index < expected_originals,
                             name + ': original attempt index', value=index)
                if role == 'original':
                    indexes[item['model_id']] = index
                    successful_originals += int(successful)
                    if config:
                        checks.same(config.get('input_dtype'), 'float32', name + ': original dtype')
                        checks.same(config.get('mutation'), 'none', name + ': unmutated original')
                        checks.same(config.get('source_weight_dir'), None, name + ': original has no ancestor weights')
                        checks.same(config.get('seed'), expected_seed + index, name + ': original generation seed')
                else:
                    successful_mutants += int(successful)
                    completed_mutants += int(all(item.get('status', {}).get(bk) == 'ok' for bk in ('tensorflow', 'torch')))
                    families[item['original_model_id']].append(item)
                    op = item.get('neuron_operator')
                    checks.check(op in ('nf', 'ws', 'wr'), name + ': single neuron operator', value=op)
                    checks.same(metadata.get('original_model_id'), item['original_model_id'], name + ': original ID')
                    if config:
                        checks.same(config.get('mutation'), op, name + ': generation neuron operator')
                        checks.same(config.get('source_weight_dir'), 'models/source_original/initial_weights', name + ': snapshot path')
                        checks.same(config.get('seed'), expected_seed + index + {'nf': 1, 'ws': 2, 'wr': 3}[op], name + ': mutant seed')
                    if successful:
                        provenance = read_json(case / 'models/mutation_provenance.json')
                        checks.same(provenance.get('enabled_operators'), [op], name + ': actual neuron operator')
                        checks.check(isinstance(provenance.get('weight_inheritance'), dict), name + ': recorded inheritance')
            except Exception as exc:
                checks.check(False, 'case audit exception', case=name, exception_type=type(exc).__name__, message=str(exc))

        for original_id, siblings in families.items():
            label = 'family ' + str(original_id)
            if not checks.check(original_id in original_by_id, label + ': original exists'):
                continue
            original = original_by_id[original_id]
            original_case = safe_case(cases_root, original['case'])
            checks.check(any(v == 'ok' for v in original['generation_status'].values()), label + ': original built first')
            checks.same(sorted(x['neuron_operator'] for x in siblings), ['nf', 'wr', 'ws'], label + ': three independent siblings')
            reference_graph, reference_plan = None, None
            for item in siblings:
                name = item['case']
                try:
                    case = safe_case(cases_root, name)
                    checks.same(case.parent.parent, original_case, name + ': family directory')
                    manifest = manifests[name]
                    checks.same(manifest['metadata']['case_index'], indexes[original_id], name + ': family attempt index')
                    graph = models[name]
                    plan = read_json(case / 'models/mutation_plan.json')
                    checks.same(plan.get('neuron_operator'), item['neuron_operator'], name + ': planned neuron operator')
                    checks.same(plan.get('value_operators'), ['pv', 'bv', 'it'], name + ': shared value operators')
                    checks.same(plan.get('source'), 'completed_original_model', name + ': completed-original plan')
                    comparable_plan = {k: v for k, v in plan.items() if k != 'neuron_operator'}
                    if reference_graph is None:
                        reference_graph, reference_plan = graph, comparable_plan
                    else:
                        checks.same(graph, reference_graph, name + ': identical sibling graph')
                        checks.same(comparable_plan, reference_plan, name + ': identical sibling PV BV IT plan')
                    lineage = read_json(case / 'models/mutation_lineage.json')
                    checks.same(lineage.get('original_model_id'), original_id, name + ': lineage original ID')
                    checks.same((case / lineage.get('original_case', '')).resolve(), original_case, name + ': lineage original path')
                    checks.same((case / lineage.get('original_weights', '')).resolve(), original_case / 'models/initial_weights', name + ': lineage original weights')
                    checks.same(lineage.get('starts_from_original_weights'), True, name + ': independent weight source')
                    checks.same(lineage.get('value_mutations_shared_between_siblings'), True, name + ': shared value mutations')
                    if settings.get(name):
                        snapshot = case / settings[name]['source_weight_dir']
                        source_manifest = original_case / 'models/weights_manifest.json'
                        copied_manifest = snapshot.parent / 'weights_manifest.json'
                        source_weights = read_json(source_manifest)
                        checks.same(read_json(copied_manifest), source_weights, name + ': identical source weight manifest')
                        source_records = manifests[original['case']]['artifacts']
                        copied_records = manifest['artifacts']
                        expected = {key[len('models/initial_weights/'):]: val for key, val in source_records.items()
                                    if key.startswith('models/initial_weights/')}
                        actual = {key[len('models/source_original/initial_weights/'):]: val for key, val in copied_records.items()
                                  if key.startswith('models/source_original/initial_weights/')}
                        checks.check(bool(expected), name + ': original weight archives exist')
                        checks.same(actual, expected, name + ': snapshot archive SHA256 and sizes match original manifest')
                        if any(v == 'ok' for v in item['generation_status'].values()):
                            inheritance = read_json(case / 'models/mutation_provenance.json')['weight_inheritance']
                            source_suffix = name + '/models/source_original/initial_weights'
                            checks.check(str(inheritance.get('source_weight_dir', '')).endswith(source_suffix),
                                         name + ': actual inheritance source is this sibling original snapshot')
                            by_variable = {(layer, entry['key']): entry
                                           for layer, entries in source_weights.get('layers', {}).items()
                                           for entry in entries}
                            for variable in inheritance.get('variables', []):
                                if 'variable' not in variable:
                                    continue
                                source = by_variable.get((variable['layer'], variable['variable']))
                                for key, source_key in (('source_checksum', 'checksum'),
                                                        ('source_shape', 'shape'), ('source_dtype', 'dtype')):
                                    checks.same(variable.get(key), source.get(source_key) if source else None,
                                                name + ': inheritance ' + key + ' ' + variable['layer'] + '/' + variable['variable'])
                except Exception as exc:
                    checks.check(False, 'family audit exception', case=name, exception_type=type(exc).__name__, message=str(exc))

        checks.same(len(set(indexes.values())), len(indexes), 'unique original attempt indices')
        checks.same(successful_originals, group.get('original_models_built'), 'successful original count')
        checks.same(group.get('original_models_built', 0) + group.get('original_gen_fail', 0), expected_originals, '200 budget conservation')
        checks.same(len(mutants), group.get('mutated_models'), 'saved mutant count equals attempted mutants')
        checks.same(group.get('total_models'), group.get('mutated_models'), 'total_models unit is mutant attempts')
        checks.same(group.get('mutated_models'), 3 * (successful_originals - group.get('mutation_plan_fail', 0)), 'three siblings per successful plan')
        checks.same(len(families), successful_originals - group.get('mutation_plan_fail', 0), 'family count')
        checks.same(completed_mutants, group.get('ok_models'), 'both-backend execution count')
        missing = sorted(set(range(expected_originals)) - set(indexes.values()))
        if missing:
            checks.warnings.append({'kind': 'early_original_attempts_without_case_directory', 'count': len(missing),
                                    'case_indices': missing, 'note': 'Budget conservation uses original_gen_fail; these attempts have no saved original-case manifest.'})
        recomputed = tracker.summary()
        checks.same(recomputed, group.get('coverage_detail'), 'entire coverage_detail reconstructed')
        for key in ('LIC', 'LPC', 'LSC', 'LSC_cov_seq', 'LSC_denom'):
            checks.same(group.get(key), recomputed[key], 'summary ' + key)
        result.update(recomputed_coverage=recomputed,
                      recomputed_unrounded_percent={'LIC': tracker.compute_lic()[0] * 100,
                                                    'LPC': tracker.compute_lpc()[0] * 100,
                                                    'LSC': tracker.compute_lsc()[0] * 100},
                      counts={'requested_original_attempts': expected_originals,
                              'original_case_records': len(originals), 'mutant_case_records': len(mutants),
                              'originals_built_at_least_one_backend': successful_originals,
                              'mutants_built_at_least_one_backend': successful_mutants,
                              'mutants_both_backends_completed': completed_mutants, 'families': len(families)})
    except Exception as exc:
        checks.check(False, 'audit could not complete', exception_type=type(exc).__name__, message=str(exc))
    result.update(status='passed' if not checks.failures else 'failed', checks=checks.count,
                  artifact_records_checked=checks.files, unique_files_hashed=checks.hashes,
                  failures=checks.failures, warnings=checks.warnings)
    return result


def self_test(source_root):
    """Synthetic fixture: a complete family, a failed original, then corruptions."""
    CoverageTracker, get_config, model_config = source_api(source_root)
    cfg = get_config('keras3.10')
    source_hash = source_digest(source_root)
    seed = 20261020
    with tempfile.TemporaryDirectory(prefix='audit_1020_fixture_') as tmp:
        root = Path(tmp)
        summary = root / 'fixture.json'
        cases = root / 'fixture_cases'
        graph = {'model_structure': {
            '0': {'type': 'input_object', 'args': {'name': 'input', 'dtype': 'float32'}, 'pre_layers': [], 'output_shape': [None, 4]},
            '1': {'type': 'dense', 'args': {'name': 'dense', 'units': 4, 'activation': 'linear', 'use_bias': False},
                  'pre_layers': [0], 'output_shape': [None, 4]}}, 'input_id_list': [0], 'output_id_list': [1]}
        tracker = CoverageTracker(cfg.layer_types, cfg.layer_conditions, activation_pool=cfg.activation_pool,
                                  padding_pool=cfg.padding_pool,
                                  element_range=model_config['var']['tensor_element_size_range'],
                                  dim_range=model_config['var']['tensor_dimension_range'])
        originals, mutants = [], []
        source_bytes = b'fixture-only original weight archive'
        weight_manifest = {'format_version': 1, 'layers': {'dense': []}}
        for model_id, op, index in ((1, None, 0), (2, 'nf', 0), (3, 'ws', 0), (4, 'wr', 0), (5, None, 1)):
            role = 'mutant' if op else 'original'
            name = 'keras3.10/full/' + ('000001/mutants/' + op if op else '%06d' % model_id)
            case = cases / name
            model_dir = case / 'models'
            success = model_id != 5
            generation = {bk: {'status': 'ok' if success else 'invalid_test'} for bk in ('tensorflow', 'torch')}
            status = {bk: 'ok' for bk in ('tensorflow', 'torch')} if op else {}
            item = {'case': name, 'model_id': model_id, 'case_role': role,
                    'original_model_id': 1 if op else None, 'neuron_operator': op,
                    'generation_status': {bk: st['status'] for bk, st in generation.items()}, 'status': status}
            (mutants if op else originals).append(item)
            write_json(model_dir / 'model.json', graph)
            config = {'input_dtype': 'float32', 'mutation': op or 'none',
                      'seed': seed + index + {None: 0, 'nf': 1, 'ws': 2, 'wr': 3}[op],
                      'source_weight_dir': 'models/source_original/initial_weights' if op else None,
                      'weight_range': [-10, 10], 'backends': ['tensorflow', 'torch']}
            write_json(model_dir / 'generation_config.json', config)
            for bk, st in generation.items():
                write_json(case / 'logs' / ('generation_' + bk + '.json'), st)
            if success:
                tracker.record_model(graph, 'float32')
                (model_dir / 'initial_weights').mkdir()
                (model_dir / 'initial_weights/dense.npz').write_bytes(source_bytes)
                write_json(model_dir / 'weights_manifest.json', weight_manifest)
            if op:
                snapshot = model_dir / 'source_original/initial_weights'
                snapshot.mkdir(parents=True)
                (snapshot / 'dense.npz').write_bytes(source_bytes)
                write_json(snapshot.parent / 'weights_manifest.json', weight_manifest)
                write_json(model_dir / 'mutation_plan.json', {'neuron_operator': op, 'value_operators': ['pv', 'bv', 'it'], 'source': 'completed_original_model'})
                write_json(model_dir / 'mutation_lineage.json', {'original_model_id': 1, 'original_case': '../..',
                           'original_weights': '../../models/initial_weights', 'starts_from_original_weights': True,
                           'value_mutations_shared_between_siblings': True})
                write_json(model_dir / 'mutation_provenance.json', {'enabled_operators': [op],
                           'weight_inheritance': {'source_weight_dir': str(snapshot), 'variables': []}})
            metadata = dict(item, case_index=index, seed=seed, framework_pool='keras3.10', ablation='full',
                            source_sha256=source_hash, generation_status=generation)
            artifacts = {n: {'sha256': sha256(case / n), 'bytes': (case / n).stat().st_size} for n in artifact_files(case)}
            write_json(case / 'case_manifest.json', {'source_sha256': source_hash, 'metadata': metadata, 'artifacts': artifacts})
        cov = tracker.summary()
        group = {'original_models': 2, 'original_models_built': 1, 'original_gen_fail': 1, 'mutation_plan_fail': 0,
                 'mutated_models': 3, 'total_models': 3, 'ok_models': 3,
                 'enabled_ops': ['bv', 'it', 'nf', 'pv', 'wr', 'ws'], 'enabled_spaces': ['layer', 'edge', 'shape', 'dim'],
                 'original_cases': originals, 'cases': mutants, 'coverage_detail': cov,
                 **{k: cov[k] for k in ('LIC', 'LPC', 'LSC', 'LSC_cov_seq', 'LSC_denom')}}
        doc = {'status': 'completed', 'meta': {'seed': seed, 'source_sha256': source_hash,
               'models_per_config': 2, 'original_models_per_config': 2}, 'by_pool': {'keras3.10': {'full': group}}}
        write_json(summary, doc)
        good = audit_run(summary, source_root, expected_originals=2, full_hashes=True)
        assert good['status'] == 'passed', good['failures']
        group['LIC'] += 1
        write_json(summary, doc)
        bad_metric = audit_run(summary, source_root, expected_originals=2, full_hashes=True)
        assert any(f['check'] == 'summary LIC' for f in bad_metric['failures'])
        group['LIC'] -= 1
        write_json(summary, doc)
        tampered = cases / mutants[0]['case'] / 'models/source_original/initial_weights/dense.npz'
        tampered.write_bytes(b'X' + source_bytes[1:])
        bad_hash = audit_run(summary, source_root, expected_originals=2, full_hashes=True)
        assert any('SHA256' in f['check'] for f in bad_hash['failures'])
        return {'status': 'passed', 'fixture_checks': good['checks'],
                'tests': ['complete family plus failed original passes', 'metric corruption rejected',
                          'same-size source-weight corruption rejected with full hashes'],
                'experiment_execution_performed': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('summary', nargs='?', type=Path)
    parser.add_argument('--source-root', type=Path, default=DEFAULT_SOURCE)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--expected-originals', type=int, default=200)
    parser.add_argument('--expected-seed', type=int, default=20261020)
    parser.add_argument('--expected-pool', default='keras3.10')
    parser.add_argument('--full-hashes', action='store_true')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        report = self_test(args.source_root.resolve())
    else:
        if args.summary is None:
            parser.error('summary path is required unless --self-test is used')
        report = audit_run(args.summary, args.source_root, args.expected_originals,
                           args.expected_seed, args.expected_pool, args.full_hashes)
    output = args.out or (args.summary.with_name(args.summary.stem + '_audit.json') if args.summary else None)
    if output:
        write_json(output, report)
    print(json.dumps({k: report[k] for k in ('status', 'checks', 'artifact_records_checked', 'unique_files_hashed', 'fixture_checks') if k in report}, ensure_ascii=False))
    if report.get('failures'):
        print(json.dumps(report['failures'][:10], ensure_ascii=False, default=str))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
