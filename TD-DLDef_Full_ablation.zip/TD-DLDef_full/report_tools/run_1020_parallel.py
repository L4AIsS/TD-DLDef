#!/usr/bin/env python3
"""External scheduler for unchanged TD-DLDef_1020, full/keras3.10 only.

Original generation, original construction, the persistent ModelMutator and ID
allocation remain serial in the parent. Only independent sibling descendants
run concurrently. This is an explicitly different scheduler, not native run_one.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import random
import sys
import time
import traceback

sys.dont_write_bytecode = True
PROJECT = Path(__file__).resolve().parents[1] / 'source' / 'TD-DLDef_1020'
sys.path.insert(0, str(PROJECT))
for variable in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS',
                 'TF_NUM_INTEROP_THREADS', 'TF_NUM_INTRAOP_THREADS'):
    os.environ[variable] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

import numpy as np
from scripts import run_ablation_exp2 as native
from scripts.check_environment import probe_environment
from utils.coverage import CoverageTracker
from utils.db_manager import DbManager
from utils.defect_report import DefectReporter
from utils.framework_config import get_framework_config
from utils.model_mutation import ModelMutator
from utils.mutation import MutationConfig
from utils.oracle import DefectCollector
from utils.reproducibility import capture_case, source_digest, sha256
from utils.selection import Selector
from src.cases_generation.data_generator import DataGenerator
from src.cases_generation.model_generator import ModelGenerator
from src.cases_generation.model_info_generator import ModelInfoGenerator
from src.incons_detection.comparator import Comparator
from src.incons_detection.trainer import Trainer


def fresh_tracker():
    cfg = get_framework_config('keras3.10')
    return CoverageTracker(cfg.layer_types, cfg.layer_conditions,
        activation_pool=cfg.activation_pool, padding_pool=cfg.padding_pool,
        element_range=native.MODEL_CONFIG['var']['tensor_element_size_range'],
        dim_range=native.MODEL_CONFIG['var']['tensor_dimension_range'])


def capture(exp_dir, model_id, index, role, dtype, generation_status, reporter,
            out_root, seed, threshold, source_hash, status=None, comparisons=None,
            original_id=None, neuron_operator=None):
    status, comparisons = status or {}, comparisons or {}
    metadata = {'seed': seed, 'case_index': index, 'case_role': role,
                'model_id': model_id, 'original_model_id': original_id,
                'neuron_operator': neuron_operator, 'framework_pool': 'keras3.10',
                'ablation': 'full', 'input_dtype': dtype, 'loss': 'mean_squared_error',
                'optimizer': 'sgd', 'threshold': threshold, 'source_sha256': source_hash,
                'generation_status': generation_status, 'status': status,
                'comparisons': comparisons}
    try:
        capture_case(exp_dir, metadata=metadata)
    except Exception as exc:
        reporter.record(model_id, 'tool_error', 'harness', stage='evidence_capture',
                        detail=str(exc), extra={'case_dir': str(exp_dir)})
    return {'case': str(Path(exp_dir).relative_to(out_root)), 'model_id': model_id,
            'case_role': role, 'original_model_id': original_id,
            'neuron_operator': neuron_operator,
            'generation_status': {bk: st.get('status') for bk, st in generation_status.items()},
            'status': {bk: st.get('status') if isinstance(st, dict) else st for bk, st in status.items()},
            'comparisons': comparisons}


def run_mutant(task):
    """No global RNG calls, selector mutation, parent DB, or shared case writes."""
    reporter = DefectReporter(framework='keras3.10', ablation='full')
    db = DbManager(':memory:')
    model_id = task['model_id']
    # The public DB API allocates row IDs. Private per-task placeholders preserve
    # the parent's global ID, so existing DB updates target a real row. These rows
    # never enter the parent's database or influence future model allocation.
    for _ in range(model_id):
        db.register_model(None, len(task['variant']['model_info']['model_structure']))
    local_tracker = fresh_tracker()
    local_collector = DefectCollector(list(native.BACKENDS), threshold=task['threshold'])
    generator = ModelGenerator(native.MODEL_CONFIG['var']['weight_value_range'],
                               list(native.BACKENDS), db, None, task['timeout'],
                               coverage_tracker=local_tracker, input_dtype='float32',
                               defect_reporter=reporter, mutation_seed=task['seed'])
    trainer = Trainer(db, task['timeout'], defect_reporter=reporter)
    comparator = Comparator(db, threshold=task['threshold'], defect_reporter=reporter)
    variant, index, seed = task['variant'], task['index'], task['seed']
    generation_status, status, comparisons = {}, {}, {}
    generation_failures, gen_fail, ok, reached_collector = [], 0, 0, False
    try:
        ok_backends = generator.generate(
            json_path=task['json_path'], exp_dir=task['exp_dir'], model_id=model_id,
            input_dtype=variant['input_dtype'],
            neuron_operator=variant['neuron_operator'] if variant['neuron_operator'] != 'none' else None,
            source_weight_dir=str(Path(task['original_dir']) / 'models/initial_weights'),
            generation_seed=seed + index + {'nf': 1, 'ws': 2, 'wr': 3}.get(variant['neuron_operator'], 0))
        generation_status = dict(generator.last_status)
        generation_failures = [(bk, generation_status.get(bk)) for bk in native.BACKENDS if bk not in ok_backends]
        for bk, generation_state in generation_failures:
            local_collector.record_generate_fail(bk, generation_state)
        if len(ok_backends) < 2:
            gen_fail = 1
        else:
            data = DataGenerator({'instance_num': 10, 'element_val_range': (0, 100), 'seed': seed + index})
            data.generate(task['input_shapes'], task['exp_dir'], task['output_shapes'],
                          input_dtype=variant['input_dtype'], model_info=variant['model_info'])
            status, outputs, losses, loss_grads, grads, completed, _ = trainer.train(
                model_id=model_id, exp_dir=task['exp_dir'], ok_backends=ok_backends,
                loss='mean_squared_error', optimizer='sgd', seed=seed)
            comparisons = comparator.compare(model_id=model_id, exp_dir=task['exp_dir'],
                backends_outputs=outputs, backends_losses=losses,
                backends_loss_grads=loss_grads, backends_grads=grads, ok_backends=completed)
            local_collector.record_model(model_id, status, outputs, comparisons)
            reached_collector, ok = True, int(len(completed) >= 2)
    except Exception as exc:
        gen_fail = 1
        reporter.record(model_id or task['original_id'], 'tool_error', 'harness', variant['model_info'],
                        stage='mutation_orchestration', detail=str(exc),
                        extra={'traceback': traceback.format_exc(), 'original_model_id': task['original_id'],
                               'neuron_operator': variant['neuron_operator']})
    case = capture(task['exp_dir'], model_id, index, 'mutant', variant['input_dtype'],
                   generation_status, reporter, task['out_root'], seed, task['threshold'],
                   task['source_hash'], status, comparisons, task['original_id'], variant['neuron_operator'])
    return {'case': case, 'reports': reporter.records, 'generation_status': generation_status,
            'generation_failures': generation_failures, 'status': status, 'comparisons': comparisons,
            'gen_fail': gen_fail, 'ok': ok, 'reached_collector': reached_collector,
            'collector_delta': local_collector.summary(),
            'coverage_events': [{'model_info': model, 'input_dtype': variant['input_dtype']}
                                for model in local_tracker.models]}


def rng_fingerprint(mutator):
    """Diagnostic snapshot only; querying RNG states does not consume a draw."""
    import pickle
    payload = (random.getstate(), np.random.get_state(),
               mutator.config.py_rng.getstate(), mutator.config.np_rng.get_state(),
               dict(mutator.value_mutator._usage))
    return hashlib.sha256(pickle.dumps(payload, protocol=4)).hexdigest()


def run_parallel(n_models, seed, threshold, timeout, out_root, mutant_workers):
    np.random.seed(seed)
    random.seed(seed)
    cfg = get_framework_config('keras3.10')
    source_hash = source_digest(PROJECT)
    db = DbManager(':memory:')
    selector = Selector(cfg.layer_types, cfg.layer_conditions, diversity_spaces=native.ALL_SPACES)
    mutator = ModelMutator(MutationConfig(enabled=native.ALL_OPS, seed=seed), backends=native.BACKENDS)
    parent_reporter = DefectReporter(framework='keras3.10', ablation='full')
    gen = ModelInfoGenerator(native.MODEL_CONFIG, db, selector, 'seq',
        mutation_config=MutationConfig([], seed), coverage_tracker=fresh_tracker(),
        layer_types=cfg.layer_types, layer_conditions=cfg.layer_conditions)
    original_tracker = fresh_tracker()
    original_generator = ModelGenerator(native.MODEL_CONFIG['var']['weight_value_range'],
        list(native.BACKENDS), db, selector, timeout, coverage_tracker=original_tracker,
        input_dtype='float32', defect_reporter=parent_reporter, mutation_seed=seed)
    output_dir = out_root / 'keras3.10/full'
    output_dir.mkdir(parents=True, exist_ok=True)
    families, original_summaries = [], []
    original_built = original_gen_fail = mutation_plan_fail = attempted_mutants = 0
    with ThreadPoolExecutor(max_workers=mutant_workers, thread_name_prefix='independent_mutant') as executor:
        for index in range(n_models):
            original_dir, original_id, original_info, original_status = None, None, None, {}
            parent_reporter.records = []
            family = {'index': index, 'futures': [], 'original_case': None, 'head_reports': [], 'tail_reports': []}
            original_coverage_start = len(original_tracker.models)
            families.append(family)
            try:
                selector.reset_model_state()
                # No worker emits to stdout, and this global redirection encloses
                # only serial graph generation, as in native run_one.
                with contextlib.redirect_stdout(io.StringIO()):
                    original_info, _, _, _ = gen.generate_seq_model(node_num=native.NODE_NUM,
                        input_shape=native.INPUT_SHAPE, output_shape=native.OUTPUT_SHAPE)
                    selector.finish_model_state()
                    original_info = gen.canonical_model_info(original_info)
                    path, _, _, original_id, original_dir = gen.generate(
                        str(output_dir), model_info=original_info, selection_already_recorded=True)
                backends = original_generator.generate(json_path=path, exp_dir=original_dir,
                    model_id=original_id, input_dtype='float32', neuron_operator=None,
                    generation_seed=seed + index)
                original_status = dict(original_generator.last_status)
                if not backends:
                    original_gen_fail += 1
                    continue
                original_built += 1
                variants = mutator.mutate_model(original_info, input_dtype='float32')
                # Registration follows nf, ws, wr order before any asynchronous
                # completion is observed. Immutable originals are read-only later.
                pending = []
                for variant in variants:
                    attempted_mutants += 1
                    exp_dir, model_id = None, None
                    try:
                        path, ins, outs, model_id, exp_dir = native.save_mutant_case(db, original_dir, original_id, variant)
                        pending.append({'json_path': path, 'input_shapes': ins, 'output_shapes': outs,
                            'model_id': model_id, 'exp_dir': exp_dir, 'original_dir': original_dir,
                            'original_id': original_id, 'variant': variant, 'index': index,
                            'seed': seed, 'threshold': threshold, 'timeout': timeout,
                            'source_hash': source_hash, 'out_root': out_root})
                    except Exception as exc:
                        # No filesystem creation failures are hidden as successful
                        # tasks; preserve the native orchestration failure category.
                        failure = DefectReporter(framework='keras3.10', ablation='full')
                        failure.record(model_id or original_id, 'tool_error', 'harness', variant['model_info'],
                            stage='mutation_orchestration', detail=str(exc), extra={'traceback': traceback.format_exc(),
                            'original_model_id': original_id, 'neuron_operator': variant['neuron_operator']})
                        from concurrent.futures import Future
                        future = Future()
                        future.set_result({'case': None, 'reports': failure.records, 'generation_status': {},
                            'generation_failures': [], 'status': {}, 'comparisons': {}, 'gen_fail': 1,
                            'ok': 0, 'reached_collector': False, 'coverage_events': [],
                            'collector_delta': DefectCollector(list(native.BACKENDS), threshold=threshold).summary()})
                        pending.append(future)
                family['head_reports'] = list(parent_reporter.records)
                parent_reporter.records = []
                family['rng_after_plan'] = rng_fingerprint(mutator)
                for task in pending:
                    family['futures'].append(executor.submit(run_mutant, task) if isinstance(task, dict) else task)
            except Exception as exc:
                if original_status and any(v.get('status') == 'ok' for v in original_status.values()):
                    mutation_plan_fail += 1
                    stage = 'mutation_planning'
                else:
                    original_gen_fail += 1
                    stage = 'original_generation'
                parent_reporter.record(original_id or index + 1, 'tool_error', 'harness', original_info,
                    stage=stage, detail=str(exc), extra={'traceback': traceback.format_exc()})
            finally:
                selector.finish_model_state()
                if original_dir is not None:
                    case = capture(original_dir, original_id, index, 'original', 'float32', original_status,
                        parent_reporter, out_root, seed, threshold, source_hash)
                    original_summaries.append(case)
                    family['original_case'] = case
                family['tail_reports'] = list(parent_reporter.records)
                family['coverage_events'] = [{'model_info': model, 'input_dtype': 'float32'}
                    for model in original_tracker.models[original_coverage_start:]]
                family['rng_after_original_attempt'] = rng_fingerprint(mutator)
                completed = sum(future.done() for fam in families for future in fam['futures'])
                print(json.dumps({'original_attempts': index + 1, 'original_built': original_built,
                                  'mutants_submitted': attempted_mutants, 'mutant_tasks_completed': completed}), flush=True)
        # Executor context waits for all tasks. Results are deliberately reduced
        # in original/nf/ws/wr serial order, not asynchronous completion order.
    tracker = fresh_tracker()
    collector_summary = DefectCollector(list(native.BACKENDS), threshold=threshold).summary()
    reporter = DefectReporter(framework='keras3.10', ablation='full')
    cases, ok_total, gen_fail = [], 0, 0
    coverage_replay_exceptions = []
    def record_coverage(events, case):
        # CoverageTracker appends models before updating sets. Replaying exactly
        # those calls also preserves a rare partial-record/late-report exception;
        # the original worker exception remains in the normal case evidence.
        for event in events:
            try:
                tracker.record_model(event['model_info'], input_dtype=event['input_dtype'])
            except Exception as exc:
                coverage_replay_exceptions.append({'case': case['case'] if case else None,
                    'exception_type': type(exc).__name__, 'message': str(exc)})
    def merge_collector(delta):
        # Public summary is additive because every task receives a unique global
        # model ID, uses the native collector with the real output arrays, and
        # contributes its generation/training events exactly once.
        collector_summary['models'] += delta['models']
        for field in ('status_counts', 'pair_inconsistency', 'total'):
            for key, value in delta[field].items():
                collector_summary[field][key] = collector_summary[field].get(key, 0) + value
        for bk, kinds in delta['backend_defects'].items():
            for kind, value in kinds.items():
                collector_summary['backend_defects'][bk][kind] += value
    for family in families:
        record_coverage(family['coverage_events'], family['original_case'])
        reporter.records.extend(family['head_reports'])
        for future in family['futures']:
            value = future.result()
            merge_collector(value['collector_delta'])
            if value['case']:
                cases.append(value['case'])
            record_coverage(value['coverage_events'], value['case'])
            reporter.records.extend(value['reports'])
            ok_total += value['ok']
            gen_fail += value['gen_fail']
        reporter.records.extend(family['tail_reports'])
    result = collector_summary
    result.update(framework_pool='keras3.10', ablation='full', enabled_spaces=native.ALL_SPACES,
        enabled_ops=sorted(native.ALL_OPS), total_models=attempted_mutants,
        model_count_unit='attempted mutated models; originals counted separately',
        original_models=n_models, original_models_built=original_built,
        original_gen_fail=original_gen_fail, mutation_plan_fail=mutation_plan_fail,
        mutated_models=attempted_mutants,
        mutation_protocol='complete original, shared PV+BV+IT, one independent NF/WS/WR sibling per enabled neuron operator',
        original_cases=original_summaries, ok_models=ok_total, gen_fail=gen_fail, cases=cases,
        coverage_scope='structures built successfully by at least one backend; not framework source coverage',
        coverage_detail=tracker.summary(), diversity=selector.diversity_summary())
    result['scheduler_coverage_replay_exceptions'] = coverage_replay_exceptions
    cov = tracker.summary()
    result.update({key: cov[key] for key in ('LIC', 'LPC', 'LSC', 'LSC_cov_seq', 'LSC_denom')})
    reporter.dump(output_dir / 'observations.jsonl')
    result['observations'], result['defect_records'] = reporter.summary(), len(reporter.records)
    (output_dir / 'summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    fingerprint_records = [{key: value for key, value in family.items() if key.startswith('rng_') or key == 'index'} for family in families]
    (output_dir / 'scheduler_rng_fingerprints.json').write_text(json.dumps(fingerprint_records, indent=2), encoding='utf-8')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--models', type=int, default=200)
    parser.add_argument('--seed', type=int, default=20261020)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--mutant-workers', type=int, default=3)
    parser.add_argument('--timeout', type=float, default=120)
    parser.add_argument('--threshold', type=float, default=.15)
    args = parser.parse_args()
    if args.models < 1 or not 1 <= args.mutant_workers <= 3 or args.timeout <= 0 or args.threshold < 0:
        parser.error('models/timeout must be positive, mutant-workers between 1 and 3, threshold nonnegative')
    out = args.out.resolve()
    out_root = out.parent / (out.stem + '_cases')
    if out.exists() or (out_root.exists() and any(out_root.iterdir())):
        parser.error('fresh --out required')
    out.parent.mkdir(parents=True, exist_ok=True)
    os.chdir(PROJECT)
    environment = probe_environment()
    meta = {'experiment': 'ablation_exp2_v2', 'source_sha256': source_digest(PROJECT),
            'original_models_per_config': args.models, 'models_per_config': args.models,
            'model_argument_unit': 'original models; full creates three independent mutants per original',
            'threshold': args.threshold, 'seed': args.seed, 'framework_pool': 'keras3.10',
            'environment': environment,
            'backend_identity_rule': 'Only environment.backends identifies executed frameworks; pool is a generator domain.',
            'count_unit': 'candidate observations, not confirmed bugs or unique root causes',
            'loss': 'mean_squared_error', 'optimizer': 'sgd',
            'phase': 'single forward/backward evaluation; no optimizer update',
            'comparison_threshold': 'dtype-aware allclose gate and MAD > threshold',
            'historical_results_reused': False,
            'scheduler': {'name': 'external_parallel_siblings_1020_v1', 'path': str(Path(__file__).resolve()),
                          'sha256': sha256(__file__), 'mutant_workers': args.mutant_workers,
                          'maximum_active_backend_processes': args.mutant_workers + 1,
                          'parent_order': 'original graph; original build; persistent shared value plan; original/nf/ws/wr IDs',
                          'reduction_order': 'original,nf,ws,wr per original attempt',
                          'source_tree_modified': False,
                          'thread_limits': {name: os.environ[name] for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'TF_NUM_INTEROP_THREADS', 'TF_NUM_INTRAOP_THREADS')},
                          'python_hash_seed': os.environ.get('PYTHONHASHSEED'),
                          'limitation': 'Concurrency can change resource-related outcomes; equivalence is checked separately, not presumed.'}}
    if not environment['ready']:
        out.write_text(json.dumps({'meta': meta, 'status': 'environment_error', 'by_pool': {}}, indent=2), encoding='utf-8')
        raise SystemExit('Backend preflight failed')
    started = time.time()
    result = run_parallel(args.models, args.seed, args.threshold, args.timeout, out_root, args.mutant_workers)
    meta['elapsed_sec'] = round(time.time() - started, 3)
    doc = {'meta': meta, 'status': 'completed', 'by_pool': {'keras3.10': {'full': result}}}
    out.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Saved ' + str(out), flush=True)


if __name__ == '__main__':
    main()
