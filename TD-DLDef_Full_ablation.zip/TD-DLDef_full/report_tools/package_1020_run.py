"""Package the completed run, unchanged uploaded source and verification evidence."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import zipfile

ap = argparse.ArgumentParser()
ap.add_argument('summary', type=Path)
ap.add_argument('--audit', type=Path, required=True)
ap.add_argument('--out-dir', type=Path, required=True)
args = ap.parse_args()
summary = args.summary.resolve()
source = summary.parent.parent
workspace = source.parent.parent
doc = json.loads(summary.read_text())
audit = json.loads(args.audit.read_text())
assert doc['status'] == 'completed' and audit['status'] == 'passed'
s = doc['by_pool']['keras3.10']['full']
assert s['original_models'] == 200
cases = summary.with_name(summary.stem + '_cases')
assert cases.is_dir()
out = args.out_dir.resolve()
out.mkdir(parents=True, exist_ok=True)
failures = Counter()
status_counts = Counter()
for role, records in [('original', s['original_cases']), ('mutant', s['cases'])]:
    for record in records:
        for bk, status in record['generation_status'].items():
            status_counts[(role, bk, status)] += 1
            if status != 'ok':
                path = cases / record['case'] / 'logs' / ('generation_' + bk + '.json')
                v = json.loads(path.read_text())
                failures[(role, bk, v.get('exception_type'), v.get('message'))] += 1
counts = {k: s[k] for k in ('original_models', 'original_models_built', 'original_gen_fail',
          'mutation_plan_fail', 'mutated_models', 'ok_models', 'gen_fail')}
brief = {
    'experiment': 'TD-DLDef_update_1020 full, 200 original attempts',
    'metrics_percent': {k: s[k] for k in ('LIC','LPC','LSC')},
    'unrounded_metrics_percent': audit['recomputed_unrounded_percent'],
    'counts': counts,
    'audit_counts': audit['counts'],
    'coverage_detail': s['coverage_detail'],
    'environment': doc['meta']['environment'],
    'seed': doc['meta']['seed'],
    'source_sha256': doc['meta']['source_sha256'],
    'scheduler': doc['meta'].get('scheduler', {'name':'native_serial'}),
    'audit': {'status':audit['status'], 'checks':audit['checks'],
              'artifact_records_checked':audit['artifact_records_checked']},
    'generation_status_counts': [{'role':r,'backend':b,'status':st,'count':n}
                                for (r,b,st),n in status_counts.items()],
    'generation_failures': [{'role':r,'backend':b,'exception_type':e,'message':m,'count':n}
                            for (r,b,e,m),n in failures.items()],
    'notes_zh': [
        '200指原始模型尝试；每个成功原模型计划生成NF、WS、WR三个独立变体。失败占预算。',
        '原始模型和变体至少有一个后端构建成功即纳入累计覆盖；同一覆盖项跨模型去重。',
        '采用上传源码paper_v2口径，shape和数值域使用sigma=5有限近似；dtype为结构推断，未完整反映实际input_casts。',
        'PV会将原输入sparse=False翻为True，当前Keras Torch后端拒绝sparse输入，不能将这些构建结果解释为双后端执行成功。',
        '该次实验未修改上传源码的采样、变异和覆盖规则；并行编排器、对照及审计记录随包提供。',
    ],
}
brief_path = out/'TD-DLDef_1020_200次统计.json'
brief_path.write_text(json.dumps(brief,ensure_ascii=False,indent=2)+'\n')
text_path=out/'TD-DLDef_1020_200次结果说明.txt'
lines=[
    'TD-DLDef 1020版：完整方法200次原始模型尝试',
    '',
    'LIC: %.2f%%    LPC: %.2f%%    LSC: %.2f%%' % (s['LIC'],s['LPC'],s['LSC']),
    '执行环境：Keras 3.10.0 / TensorFlow 2.16.1 / PyTorch 2.2.0；CPU；seed=20261020。',
    '原模型尝试%d，构建成功%d；变体尝试%d，至少一个后端构建成功%d，双后端执行成功%d。' %
      (s['original_models'],s['original_models_built'],s['mutated_models'],
       audit['counts']['mutants_built_at_least_one_backend'],s['ok_models']),
    '', *brief['notes_zh'], '',
    '重算结果：独立审计通过%d项检查，检查%d条证据文件记录。' %
      (audit['checks'],audit['artifact_records_checked']),
    '源码指纹：'+doc['meta']['source_sha256'],
    '包中source/TD-DLDef_1020/data和历史validation是原上传包附带数据，不属于本次结果。',
    '本次正式结果入口：source/TD-DLDef_1020/results/'+summary.name,
    '本次原始案例目录：source/TD-DLDef_1020/results/'+cases.name,
    'full_200_20261020_cases仅保存前38个家族的串行对照，独立于正式200次统计。',
    'report_tools包含本次编排器、独立审计和对照工具；原上传包也单独保留。',
    '',
    '建议Python 3.12，安装source/TD-DLDef_1020/results/requirements_actual.txt中的依赖。',
    '从解压目录重跑（新输出路径）：',
    'PYTHONHASHSEED=20261020 python report_tools/run_1020_parallel.py --models 200 --seed 20261020 --mutant-workers 3 --timeout 120 --out source/TD-DLDef_1020/results/repeat_full_200.json',
    '从解压目录复核本次结果：',
    'python report_tools/audit_1020_run.py source/TD-DLDef_1020/results/'+summary.name+' --full-hashes --out audit_recheck.json',
]
text_path.write_text('\n'.join(lines)+'\n')
archive = out/'TD-DLDef_1020_200次实验完整记录.zip'
paths=[]
for p in source.rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
    rel=p.relative_to(source)
    if rel.parts[0]=='results':continue
    paths.append((p, 'source/TD-DLDef_1020/'+rel.as_posix()))
for p in cases.rglob('*'):
    if p.is_file():paths.append((p,'source/TD-DLDef_1020/results/'+p.relative_to(summary.parent).as_posix()))
serial_root=summary.parent/'full_200_20261020_cases'
reference_families=0
for manifest in serial_root.glob('keras3.10/full/*/case_manifest.json'):
    item=json.loads(manifest.read_text())
    if not 0<=item['metadata']['case_index']<38:continue
    reference_families+=1
    for p in manifest.parent.rglob('*'):
        if p.is_file():paths.append((p,'source/TD-DLDef_1020/results/'+p.relative_to(summary.parent).as_posix()))
assert reference_families==38
for p in summary.parent.iterdir():
    if p.is_file() and (p==summary or p==args.audit.resolve() or
       p.name in {'requirements_actual.txt','run_protocol.json','sparse_mutation_finding.json',
                  'parallel_protocol.json','int8_mutation_finding.json','serial_parallel_prefix_equivalence.json',
                  'serial_reference_partial.json','memory_events_after_start.json','memory_events_at_finish.json',
                  'source_integrity_at_finish.json'} or
       'preflight' in p.name or p.name==summary.stem+'.log'):
        paths.append((p,'source/TD-DLDef_1020/results/'+p.name))
for p in (workspace/'report_tools').glob('*1020*'):
    if p.is_file():paths.append((p,'report_tools/'+p.name))
paths += [(workspace/'upload/TD-DLDef_update_1020.zip','TD-DLDef_update_1020.zip'),
          (brief_path,brief_path.name),(text_path,text_path.name)]
assert len({name for _,name in paths})==len(paths)
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path,name in paths:z.write(path,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
print(json.dumps({'files':[{'path':str(p),'bytes':p.stat().st_size,
             'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (brief_path,archive)],
             'archive_members':len(paths)},ensure_ascii=False))
