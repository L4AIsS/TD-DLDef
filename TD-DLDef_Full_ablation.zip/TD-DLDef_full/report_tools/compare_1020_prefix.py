#!/usr/bin/env python3
"""Compare saved serial/parallel families by original case_index; never execute models.

The prefix is exactly case_index 0..families-1. Missing or unfinished siblings
produce not_ready, rather than silently shrinking the comparison population.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
from audit_1020_run import DEFAULT_SOURCE, read_json, source_api, source_digest, write_json

FROZEN_RUNNER_SHA256 = 'c35b92ee4b122a897f58b717626b7659084b8fbdbe68182bef1ea102a839af39'
STATUS_LOG_FIELDS = {'duration_seconds', 'stdout', 'stderr', 'traceback'}


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def normalise(value, cases_root, omit_status_logs=False):
    if isinstance(value, dict):
        return {key: normalise(item, cases_root, omit_status_logs) for key, item in value.items()
                if not (omit_status_logs and key in STATUS_LOG_FIELDS)}
    if isinstance(value, list):
        return [normalise(item, cases_root, omit_status_logs) for item in value]
    if isinstance(value, str):
        return value.replace(str(cases_root), '<CASES_ROOT>')
    return value


def original_index(cases_root, families):
    found, duplicates = {}, []
    for path in sorted((cases_root / 'keras3.10/full').glob('*/case_manifest.json')):
        manifest = read_json(path)
        meta = manifest.get('metadata', {})
        index = meta.get('case_index')
        if meta.get('case_role') == 'original' and isinstance(index, int) and 0 <= index < families:
            if index in found:
                duplicates.append(index)
            found[index] = (path.parent, manifest)
    return found, duplicates


def compare(serial_root, parallel_root, source_root, families=38):
    import numpy as np
    serial_root, parallel_root, source_root = [Path(p).resolve() for p in (serial_root, parallel_root, source_root)]
    report = {'schema_version': 1, 'created_utc': datetime.now(timezone.utc).isoformat(),
              'serial_root': str(serial_root), 'parallel_root': str(parallel_root),
              'source_root': str(source_root), 'requested_families': families,
              'included_case_indices': list(range(families)), 'status': 'not_ready',
              'scope': 'saved original and nf/ws/wr evidence only; no generation or execution',
              'ignored_differences': ['absolute serial/parallel cases root prefix',
                                     'process duration_seconds, stdout, stderr and traceback in status records',
                                     '.keras container timestamps and archive byte encodings'],
              'limitations': ['Agreement covers this saved prefix only, not unobserved remaining cases.',
                              'Concurrent resource pressure can change later timeouts or failures.',
                              'Coverage uses the unchanged source structural dtype estimate, including its input_casts limitation.']}
    indexes = []
    missing = []
    for label, root in (('serial', serial_root), ('parallel', parallel_root)):
        indexed, duplicates = original_index(root, families)
        if duplicates:
            missing.append({'side': label, 'duplicate_original_indices': duplicates})
        for index in range(families):
            if index not in indexed:
                missing.append({'side': label, 'case_index': index, 'missing': 'original manifest'})
                continue
            original_case, _ = indexed[index]
            for operator in ('nf', 'ws', 'wr'):
                if not (original_case / 'mutants' / operator / 'case_manifest.json').is_file():
                    missing.append({'side': label, 'case_index': index, 'missing': operator + ' manifest'})
        indexes.append(indexed)
    if missing:
        report['missing_or_unfinished'] = missing
        return report

    checks, failures = 0, []
    arrays_checked, files_checked = Counter(), Counter()
    family_reports, case_reports = [], []
    def check(condition, label, **detail):
        nonlocal checks
        checks += 1
        if not condition:
            failures.append({'check': label, **detail})
    def same(a, b, label):
        check(a == b, label)
    CoverageTracker, get_config, model_config = source_api(source_root)
    cfg = get_config('keras3.10')
    def tracker():
        return CoverageTracker(cfg.layer_types, cfg.layer_conditions, activation_pool=cfg.activation_pool,
            padding_pool=cfg.padding_pool, element_range=model_config['var']['tensor_element_size_range'],
            dim_range=model_config['var']['tensor_dimension_range'])
    trackers = [tracker(), tracker()]
    current_source_hash = source_digest(source_root)
    runner = Path(__file__).parent / 'run_1020_parallel.py'
    runner_hash = sha(runner)
    same(runner_hash, FROZEN_RUNNER_SHA256, 'frozen parallel runner SHA256')

    for index in range(families):
        serial_original = indexes[0][index][0]
        parallel_original = indexes[1][index][0]
        family_failure_start = len(failures)
        for operator in (None, 'nf', 'ws', 'wr'):
            bases = [serial_original, parallel_original]
            if operator:
                bases = [p / 'mutants' / operator for p in bases]
            a, b = bases
            name = 'case_index=%d/%s' % (index, operator or 'original')
            case_failure_start = len(failures)
            manifests = [read_json(p / 'case_manifest.json') for p in bases]
            for root, manifest in zip((serial_root, parallel_root), manifests):
                same(manifest.get('source_sha256'), current_source_hash, name + ': source SHA ' + root.name)
                same(manifest['metadata'].get('case_index'), index, name + ': original index ' + root.name)
                same(manifest['metadata'].get('neuron_operator'), operator, name + ': neuron operator ' + root.name)
            for field in ('model_id', 'original_model_id', 'case_role', 'seed', 'input_dtype',
                          'loss', 'optimizer', 'threshold', 'framework_pool', 'ablation'):
                same(manifests[0]['metadata'].get(field), manifests[1]['metadata'].get(field), name + ': metadata ' + field)
            for field in ('generation_status', 'status'):
                states = [normalise(m['metadata'].get(field, {}), root, omit_status_logs=True)
                          for m, root in zip(manifests, (serial_root, parallel_root))]
                same(*states, name + ': semantic ' + field)
            for field in ('runtime_identities', 'execution_equivalence', 'source_input_dtype',
                          'replay_config', 'replay_ready', 'differential_replay_ready',
                          'generation_replay_ready', 'missing_replay_artifacts', 'confirmed_defect'):
                same(normalise(manifests[0].get(field), serial_root),
                     normalise(manifests[1].get(field), parallel_root), name + ': manifest ' + field)
            same(normalise(manifests[0]['metadata'].get('comparisons', {}), serial_root),
                 normalise(manifests[1]['metadata'].get('comparisons', {}), parallel_root), name + ': comparisons')

            json_sets = [{p.relative_to(base).as_posix() for p in (base / 'models').rglob('*.json')}
                         for base in bases]
            same(*json_sets, name + ': complete models JSON file set')
            for relative in sorted(json_sets[0] & json_sets[1]):
                values = [normalise(read_json(base / relative), root)
                          for base, root in zip(bases, (serial_root, parallel_root))]
                same(*values, name + ': JSON ' + relative)
                files_checked['model_json'] += 1
            for relative in ('dataset/dataset_generation.json', 'model_source.py'):
                same((a / relative).is_file(), (b / relative).is_file(), name + ': presence ' + relative)
                if (a / relative).is_file() and (b / relative).is_file():
                    same(normalise((a / relative).read_text(), serial_root),
                         normalise((b / relative).read_text(), parallel_root), name + ': content ' + relative)

            for category, directory in (('final_weights', 'models/initial_weights'),
                                        ('original_snapshots', 'models/source_original/initial_weights'),
                                        ('dataset', 'dataset')):
                archives = [{p.relative_to(base).as_posix() for p in (base / directory).glob('*.npz')}
                            for base in bases]
                same(*archives, name + ': NPZ set ' + category)
                for relative in sorted(archives[0] & archives[1]):
                    with np.load(a / relative, allow_pickle=False) as first, np.load(b / relative, allow_pickle=False) as second:
                        same(first.files, second.files, name + ': array names ' + relative)
                        files_checked[category] += 1
                        for key in set(first.files) & set(second.files):
                            x, y = first[key], second[key]
                            check(x.dtype == y.dtype and x.shape == y.shape and x.tobytes(order='C') == y.tobytes(order='C'),
                                  name + ': exact array ' + relative + '/' + key,
                                  serial_dtype=str(x.dtype), parallel_dtype=str(y.dtype),
                                  serial_shape=list(x.shape), parallel_shape=list(y.shape))
                            arrays_checked[category] += 1
            for base, manifest, tracking in zip(bases, manifests, trackers):
                if any(state.get('status') == 'ok' for state in manifest['metadata']['generation_status'].values()):
                    tracking.record_model(read_json(base / 'models/model.json'),
                        input_dtype=read_json(base / 'models/generation_config.json')['input_dtype'])
            states = {}
            for field in ('generation_status', 'status'):
                states[field] = [{bk: st.get('status') if isinstance(st, dict) else st
                                  for bk, st in m['metadata'].get(field, {}).items()} for m in manifests]
            case_reports.append({'case_index': index, 'role': operator or 'original',
                'serial_case': str(a.relative_to(serial_root)), 'parallel_case': str(b.relative_to(parallel_root)),
                'status': 'passed' if len(failures) == case_failure_start else 'failed', **states})
        family_reports.append({'case_index': index,
                               'status': 'passed' if len(failures) == family_failure_start else 'failed'})

    coverage = [t.summary() for t in trackers]
    same(*coverage, 'complete prefix cumulative coverage')
    report.update(status='passed' if not failures else 'failed', checks=checks, failures=failures,
        source_sha256=current_source_hash, parallel_runner_sha256=runner_hash,
        matched_families=families, matched_cases=len(case_reports),
        files_compared=dict(files_checked), arrays_compared=dict(arrays_checked),
        total_npz_files_compared=sum(v for k, v in files_checked.items() if k != 'model_json'),
        total_arrays_compared=sum(arrays_checked.values()),
        array_equality='dtype, shape and contiguous numeric bytes exactly equal; no tolerance',
        serial_coverage=coverage[0], parallel_coverage=coverage[1],
        family_results=family_reports, case_results=case_reports)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, default=DEFAULT_SOURCE)
    parser.add_argument('--serial-root', type=Path)
    parser.add_argument('--parallel-root', type=Path)
    parser.add_argument('--families', type=int, default=38)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    if args.families < 1:
        parser.error('families must be positive')
    results = args.source_root / 'results'
    serial = args.serial_root or results / 'full_200_20261020_cases'
    parallel = args.parallel_root or results / 'full_200_parallel_20261020_cases'
    output = args.out or results / 'serial_parallel_prefix_equivalence.json'
    report = compare(serial, parallel, args.source_root, args.families)
    write_json(output, report)
    print(json.dumps({key: report[key] for key in ('status', 'checks', 'matched_families', 'matched_cases',
                     'total_npz_files_compared', 'total_arrays_compared') if key in report}))
    return 0 if report['status'] == 'passed' else 2 if report['status'] == 'not_ready' else 1


if __name__ == '__main__':
    raise SystemExit(main())
