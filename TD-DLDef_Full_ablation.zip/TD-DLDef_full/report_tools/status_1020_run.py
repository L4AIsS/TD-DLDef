import json
import sys
import time
from collections import Counter
from pathlib import Path

root = Path('/workspace/scratch/8f845743f22f/source/TD-DLDef_1020/results')
stem = sys.argv[1] if len(sys.argv)>1 else 'full_200_parallel_20261020'
group = root / (stem + '_cases/keras3.10/full')
def read(path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return {}

originals = [p for p in group.glob('*/case_manifest.json')]
mutants = [p for p in group.glob('*/mutants/*/case_manifest.json')]
generation, execution = Counter(), Counter()
for p in group.glob('*/mutants/*/logs/*.json'):
    if p.name.startswith('generation_'):
        value=read(p)
        generation[(p.stem, value.get('status', 'in_progress'))] += 1
    elif p.name.startswith('training_'):
        value=read(p)
        execution[(p.stem, value.get('status', 'in_progress'))] += 1
indices = [read(p).get('metadata', {}).get('case_index', -1) for p in originals]
out = {
    'completed_original_case_dirs':len(originals),
    'completed_attempt_index':max(indices, default=-1)+1,
    'completed_mutant_case_dirs':len(mutants),
    'final_summary_exists':(root/(stem+'.json')).is_file(),
    'generation':{str(k):v for k,v in generation.items()},
    'execution':{str(k):v for k,v in execution.items()},
}
print(json.dumps(out,ensure_ascii=False))
