#!/usr/bin/env python3
"""Uniform random selection, no DIV, unchanged full post-generation mutation."""
import argparse
from collections import Counter
import contextlib
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import random
import sys
import traceback
import numpy as np


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


class UniformRandomSelector:
    """Same availability filter, uniform sampling, no DIV or TS feedback."""
    def __init__(self, layer_types, layer_conditions):
        self.allowed = set(layer_types)
        self.conditions = dict(layer_conditions)
        self.draws = Counter()
        self.admissions = Counter()

    def choose_element(self, pool, **kwargs):
        candidates = []
        for name in pool:
            if name not in self.allowed:
                continue
            condition = self.conditions.get(name)
            if condition is None or condition(**kwargs):
                candidates.append(name)
        if not candidates:
            return None
        chosen = candidates[int(np.random.randint(len(candidates)))]
        self.draws[chosen] += 1
        return chosen

    def admit_candidate(self, name, **kwargs):
        self.admissions[name] += 1
        return True

    def reset_model_state(self):
        pass

    def finish_model_state(self):
        pass

    def record_committed_layer(self, name, **kwargs):
        pass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', type=Path, required=True)
    parser.add_argument('--out-dir', type=Path, required=True)
    parser.add_argument('--models', type=int, default=200)
    parser.add_argument('--seed', type=int, default=2024)
    parser.add_argument('--fw', nargs='+', default=['keras3.10', 'tensorflow2.16.1', 'pytorch2.2.0',
                         'tensorflow2.0.0', 'theano1.0.4', 'cntk2.7.0', 'keras2.3.1'])
    parser.add_argument('--verify-only', action='store_true')
    args = parser.parse_args()
    if args.models <= 0:
        parser.error('--models must be positive')
    sys.path.insert(0, str(args.project_root.resolve()))
    from scripts.run_ablation_exp1 import MODEL_CONFIG, INPUT_SHAPE, OUTPUT_SHAPE, NODE_NUM, ALL_OPS, source_digest
    from utils.framework_config import NEW_FRAMEWORKS, OLD_FRAMEWORKS, get_framework_config
    from utils.mutation import MutationConfig
    from utils.model_mutation import ModelMutator
    from utils.coverage import CoverageTracker
    from utils.db_manager import DbManager
    from src.cases_generation.model_info_generator import ModelInfoGenerator

    def tracker_for(fw):
        cfg = get_framework_config(fw)
        return CoverageTracker(cfg.layer_types, cfg.layer_conditions,
            activation_pool=cfg.activation_pool, padding_pool=cfg.padding_pool,
            element_range=MODEL_CONFIG['var']['tensor_element_size_range'],
            dim_range=MODEL_CONFIG['var']['tensor_dimension_range']), cfg

    def verify(row):
        tracker, _ = tracker_for(row['framework'])
        records = [json.loads(line) for line in (args.out_dir / row['framework'] / 'records.jsonl').read_text().splitlines()]
        assert len(records) == row['attempts']
        assert [r['attempt_index'] for r in records] == list(range(1, row['attempts'] + 1))
        success = 0
        for record in records:
            if 'original_model_info' in record:
                assert digest(record['original_model_info']) == record['original_model_sha256']
            if record['status'] != 'structure_generated':
                continue
            assert digest(record['model_info']) == record['model_sha256']
            assert record['planned_neuron_variants'] == ['nf', 'ws', 'wr']
            tracker.record_model(record['model_info'], input_dtype=record['input_dtype'])
            success += 1
        assert success == row['success_models'] == tracker.model_cnt
        assert len(records) - success == row['fail_models']
        assert tracker.summary() == row['coverage_summary']
        assert tracker.detail() == row['coverage_detail']
        return {'framework': row['framework'], 'status': 'passed', 'records': len(records),
                'model_hashes_and_metrics_recomputed': True}

    if args.verify_only:
        saved = json.loads((args.out_dir / 'results.json').read_text())
        assert source_digest() == saved['meta']['source_sha256']
        checks = [verify(row) for row in saved['results']]
        write_json(args.out_dir / 'reverification.json', {'status': 'passed', 'groups': checks})
        print(f'Verified {len(checks)} groups from saved models.')
        return
    if args.out_dir.exists() and any(args.out_dir.iterdir()):
        parser.error('output directory must be absent or empty')
    args.out_dir.mkdir(parents=True, exist_ok=True)
    meta = {'experiment': 'random_no_div_full_mutation', 'seed': args.seed,
            'attempts_per_label': args.models, 'enabled_spaces': [], 'sampling': 'uniform_random',
            'enabled_mutations': ALL_OPS, 'source_sha256': source_digest(),
            'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'started_at_utc': datetime.now(timezone.utc).isoformat(),
            'environment': {'python': platform.python_version(), 'numpy': np.__version__},
            'input_shape': INPUT_SHAPE, 'output_shape': OUTPUT_SHAPE, 'node_budget': NODE_NUM,
            'model_config': MODEL_CONFIG, 'metric_mode': 'paper_v2',
            'coverage_scope': 'generated_mutated_structure_only',
            'actually_exercised_mutations': ['pv', 'bv', 'it'],
            'neuron_mutations_executed': False, 'planned_neuron_variants': ['nf', 'ws', 'wr'],
            'framework_execution_performed': False,
            'keras2.3.1_status': 'undefined label; original default modern-pool fallback'}
    rows = []
    for fw in args.fw:
        random.seed(args.seed)
        np.random.seed(args.seed)
        tracker, cfg = tracker_for(fw)
        selector = UniformRandomSelector(cfg.layer_types, cfg.layer_conditions)
        generator = ModelInfoGenerator(MODEL_CONFIG, DbManager(':memory:'), selector, 'seq',
            mutation_config=MutationConfig([], args.seed), coverage_tracker=tracker,
            layer_types=cfg.layer_types, layer_conditions=cfg.layer_conditions)
        mutator = ModelMutator(MutationConfig(ALL_OPS, args.seed), backends=('tensorflow', 'torch'))
        folder = args.out_dir / fw
        (folder / 'logs').mkdir(parents=True)
        failures = Counter()
        success = 0
        print(f'Running {fw}: {args.models} attempts, no DIV, random, all mutations enabled', flush=True)
        with (folder / 'records.jsonl').open('w', encoding='utf-8') as output:
            for index in range(1, args.models + 1):
                record = {'attempt_index': index, 'stage': 'original_generation'}
                with (folder / 'logs' / f'{index:06d}.log').open('w', encoding='utf-8') as log:
                    try:
                        with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
                            selector.reset_model_state()
                            original, _, _, _ = generator.generate_seq_model(
                                node_num=NODE_NUM, input_shape=INPUT_SHAPE, output_shape=OUTPUT_SHAPE)
                            original = generator.canonical_model_info(original)
                            selector.finish_model_state()
                            assert not any(layer.get('mutations') for layer in original['model_structure'].values())
                            original_hash = digest(original)
                            record.update(original_model_info=original, original_model_sha256=original_hash,
                                          stage='post_generation_mutation')
                            variants = mutator.mutate_model(original, input_dtype='float32')
                            assert digest(original) == original_hash
                            assert [v['name'] for v in variants] == ['nf', 'ws', 'wr']
                            representative = variants[0]
                            for sibling in variants[1:]:
                                assert sibling['model_info'] == representative['model_info']
                                assert sibling['input_dtype'] == representative['input_dtype']
                            model = representative['model_info']
                            dtype = representative['input_dtype']
                            tracker.record_model(model, input_dtype=dtype)
                            record.update(status='structure_generated', stage='completed', model_info=model,
                                model_sha256=digest(model), input_dtype=dtype,
                                planned_neuron_variants=[v['name'] for v in variants],
                                mutation_plan=representative['mutation_plan'])
                            success += 1
                    except Exception as exc:
                        status = 'tool_resource_rejection' if 'Shape too big' in str(exc) else 'tool_generation_error'
                        failures[status] += 1
                        record.update(status=status, exception_type=type(exc).__name__, message=str(exc))
                        traceback.print_exc(file=log)
                    finally:
                        selector.finish_model_state()
                output.write(json.dumps(record, ensure_ascii=False) + '\n')
                output.flush()
        row = {'framework': fw, 'explicit_configuration': fw in NEW_FRAMEWORKS + OLD_FRAMEWORKS,
               'attempts': args.models, 'success_models': success, 'fail_models': args.models - success,
               'failures_by_type': dict(failures), 'coverage_summary': tracker.summary(),
               'coverage_detail': tracker.detail(), 'enabled_spaces': [], 'ts_posterior_updates': 0,
               'diversity_evaluations': 0, 'enabled_mutations': ALL_OPS,
               'selector_draw_counts': dict(selector.draws), 'selector_admission_counts': dict(selector.admissions)}
        row['verification'] = verify(row)
        write_json(folder / 'summary.json', row)
        rows.append(row)
        write_json(args.out_dir / 'results.json', {'status': 'in_progress', 'meta': meta, 'results': rows})
        c = row['coverage_summary']
        print(f"  success={success}/{args.models}; LIC={c['LIC']}%; LPC={c['LPC']}%; LSC={c['LSC']}%; verification=passed", flush=True)
    assert source_digest() == meta['source_sha256']
    meta['source_unchanged'] = True
    meta['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
    write_json(args.out_dir / 'results.json', {'status': 'completed', 'meta': meta, 'results': rows})


if __name__ == '__main__':
    main()
